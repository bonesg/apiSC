package ab.common;

import com.jcraft.jsch.ChannelExec;
import com.jcraft.jsch.JSch;
import com.jcraft.jsch.JSchException;
import com.jcraft.jsch.Session;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class RemoteWebHook implements WebHookStarter {


    String psid;
    private Session session;
    private String username;
    private String password;
    private String host;
    private int port = 22;
    private String webhookWarLocation = "/home/apiadm/webhook/";
//    private String webhookWarLocation = "/apps/apibanking/webhook/";
    private String webhookWarName = "web-hook-client-1.1.0-SNAPSHOT.war";
    private int webhookPort = 8443;
    private String publicKey;
    private String privateKey;
    private String endPoint;

    public static void main(String[] args) throws IOException {
        WebHookStarter webHookStarter = new RemoteWebHook("10.23.210.60", "apiadm", "Admin@2018");

        try {
            webHookStarter.setConfig("port", "8455");
            webHookStarter.start();
            System.out.println(webHookStarter.getWebHookUrl());
        } finally {
            if(webHookStarter!=null)
            webHookStarter.stop();
        }
    }

    public StringBuilder getLog(){
        return webHookCommandRunner.getLog();
    }

    public RemoteWebHook() {

    }
    WebHookCommandRunner webHookCommandRunner;

    public RemoteWebHook(String host, String userName, String password) {
        this.host = host;
        this.username = userName;
        this.password = password;
    }

    public Session getSession() {
        return session;
    }

    public void setSession(Session session) {
        this.session = session;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getHost() {
        return host;
    }

    public void setHost(String host) {
        this.host = host;
    }

    public int getPort() {
        return port;
    }

    public void setPort(int port) {
        this.port = port;
    }

    @Override
    public void start() {

        if (privateKey == null)
            throw new RuntimeException("Set private-key config before starting the webhook");
        if (publicKey == null)
            throw new RuntimeException("Set public-key config before starting the webhook");

        connectToServer();
        StringBuilder commands = new StringBuilder();

        commands.append("\nprivate_key=\"" + privateKey + "\"");
        commands.append("\npublic_key=\"" + publicKey + "\"");
        commands.append("\ncd " + webhookWarLocation);
        commands.append("\njava ");
        commands.append(" -Dprivate-key=\"$private_key\"  -Dpublic-key=\"$public_key\" ");
        commands.append(" -Dport=" + webhookPort);
        commands.append(" -jar " + webhookWarName);

        String commandOutput = executeCommand(commands.toString(), "Started WebHookApp in ");
        Pattern pattern = Pattern.compile("INFO.*\\[35m(\\d+)");
        Matcher matcher = pattern.matcher(commandOutput);
        if (matcher.find()) {
            psid = matcher.group(1);
        }

        if (commandOutput.contains("Remote script exec error!")) {
            stop();
            throw new RuntimeException("Couldn't start webhook");
        }
    }

    @Override
    public void stop() {

        if(webHookCommandRunner!=null){
            webHookCommandRunner.channelExec.disconnect();

            try {
                webHookCommandRunner.join();
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
            webHookCommandRunner=null;
        }

        //Disconnect the Session
        if (session != null) {
            session.disconnect();
        }

    }

    @Override
    public String getWebHookUrl() {
        return String.format("http://%s:%s", this.host, this.webhookPort);
    }

    @Override
    public void setConfig(String key, String value) {
        switch (key) {
            case "private-key":
                setPrivateKey(value);
                break;
            case "public-key":
                setPublicKey(value);
                break;
            case "port":
                webhookPort = Integer.parseInt(value);
                break;
        }
    }

    public void connectToServer() {
        JSch jsch = new JSch();
        try {

            // Open a Session to remote SSH server and Connect.
            // Set User and IP of the remote host and SSH port.
            session = jsch.getSession(username, host, port);
            // When we do SSH to a remote host for the 1st time or if key at the remote host
            // changes, we will be prompted to confirm the authenticity of remote host.
            // This check feature is controlled by StrictHostKeyChecking ssh parameter.
            // By default StrictHostKeyChecking  is set to yes as a security measure.
            session.setConfig("StrictHostKeyChecking", "no");
            session.setConfig("PreferredAuthentications", "publickey,keyboard-interactive,password");
            //Set password
            session.setPassword(password);
//            session.setServerAliveInterval(100);
            session.connect();

        } catch (JSchException e) {
            e.printStackTrace();
            throw new RuntimeException(e);
        }
    }

    public String executeCommand(String command, String expectedTextInLogs) {

        if (!session.isConnected()) {
            connectToServer();
        }
        System.out.println("command" + command);

        webHookCommandRunner  = new WebHookCommandRunner(command);
        webHookCommandRunner.start();

        while (!webHookCommandRunner.isCommandCompleted()){
            if (webHookCommandRunner.getConsoleLogs().contains(expectedTextInLogs)) {
                return webHookCommandRunner.getConsoleLogs();
            }
        }
        return webHookCommandRunner.getConsoleLogs();
    }

    public String executeCommand(String command) {

        return executeCommand(command, null);
    }



    public String getPublicKey() {
        return publicKey;
    }

    public void setPublicKey(String publicKey) {
        this.publicKey = publicKey;
    }

    public String getPrivateKey() {
        return privateKey;
    }

    public void setPrivateKey(String privateKey) {
        this.privateKey = privateKey;
    }


    public class WebHookCommandRunner extends Thread {
        private ChannelExec channelExec;
        String command;
        StringBuilder builder = new StringBuilder();
        boolean interrupted = false;

        public WebHookCommandRunner(String command) {
            this.command = command;

        }
        public StringBuilder getLog(){
           return builder;
        }

        boolean commandCompleted = false;

        public boolean isCommandCompleted() {
            return commandCompleted;
        }

        public String getConsoleLogs() {
            return builder.toString();
        }

        @Override
        public void run() {
            try {

                // create the execution channel over the session
                channelExec = (ChannelExec) session.openChannel("exec");
                // Set the command to execute on the channel and execute the command
                channelExec.setCommand(command);
                channelExec.setPty(true);
                channelExec.connect();

                // Get an InputStream from this channel and read messages, generated
                // by the executing command, from the remote side.
                InputStream in = channelExec.getInputStream();
                BufferedReader reader = new BufferedReader(new InputStreamReader(in));
                String line;
                try {
                    while ((line = reader.readLine()) != null && !Thread.currentThread().isInterrupted()) {
                        System.out.println("Webhook log:" +line);
                        builder.append("Webhook log:\n" + line);
                    }
                } catch (IOException e) {
                    e.printStackTrace();
                    Thread.currentThread().interrupt();
                }
                System.out.println("Is code interrupted");
                // Command execution completed here.

                // Retrieve the exit status of the executed command
                int exitStatus = channelExec.getExitStatus();
                if (exitStatus > 0) {
                    System.out.println("Remote script exec error! " + exitStatus);
                    builder.append("\n" + "Remote script exec error! " + exitStatus);

                }
                commandCompleted = true;

            } catch (IOException e) {
                e.printStackTrace();
            } catch (JSchException e) {
                e.printStackTrace();
            }
        }

        private void closeChannel() {
            try {
                interrupted = true;


                if (channelExec != null) {

                    if (channelExec.isConnected()) {
                        channelExec.setInputStream(null);
                        InputStream in = channelExec.getInputStream();
                        if (in != null) {
                            in.close();
                            in = null;
                        }

                        channelExec.getOutputStream().write(3);
                        channelExec.getOutputStream().flush();

                    } else {
                        executeCommand("kill " + psid);
                    }
                }


            } catch (IOException e) {
                e.printStackTrace();
            }
            channelExec.disconnect();
        }


    }
}
