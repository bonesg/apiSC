package ab.common;


        import java.sql.Connection;
        import java.sql.DriverManager;
        import java.sql.SQLException;

/**
 * Created by 1562214 on 4/2/2018.
 */
public class MySQLTest {
    public static final String MYSQL_DRIVER = "com.mysql.jdbc.Driver";
    public static final String MYSQL_URL = "jdbc:mysql://10.65.224.159:3306/myDB?"
            + "user=root";

    public static void main(String args[]) throws ClassNotFoundException, SQLException {

        Class.forName(MYSQL_DRIVER);
        Connection connection = DriverManager.getConnection(MYSQL_URL);
        System.out.println("Connected");
    }
}

