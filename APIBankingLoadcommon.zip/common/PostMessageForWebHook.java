package ab.common;

import org.apache.commons.io.IOUtils;

import javax.jms.JMSException;
import javax.jms.Message;
import javax.jms.Session;
import javax.jms.TextMessage;
import java.io.IOException;
import java.io.InputStream;

public class PostMessageForWebHook {

       public Message createTextMessage(Session session, InputStream fileInputStream) throws IOException, JMSException {
        TextMessage txt = session.createTextMessage();
        txt.setText(IOUtils.toString(fileInputStream));
        return txt;
    }

}
