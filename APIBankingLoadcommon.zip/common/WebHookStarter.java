package ab.common;

public interface WebHookStarter {

    public void start();
    public void stop();
    public String getWebHookUrl();
    public void setConfig(String key, String value);
    public StringBuilder getLog();
}
