package ab.api.tests;

import ab.common.EndPoint;
import io.restassured.RestAssured;
import io.restassured.config.SSLConfig;
import io.restassured.http.ContentType;

import java.io.*;
import java.security.*;
import java.security.cert.CertificateException;
import java.util.Scanner;

import static io.restassured.RestAssured.given;

/**
 * Created by maneesh on 18/7/17.
 */
public class TestAPI {

    public static void main(String[] args) {
        KeyStore keyStore = null;
        String token = null;
        try {
            token = new Scanner(new File("./src/test/resources/test-data/newtoken.txt")).useDelimiter("\\Z").next();
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }
        try {
            keyStore = KeyStore.getInstance("PKCS12");
        } catch (KeyStoreException e) {
            e.printStackTrace();
        }
        try {
            keyStore.load(new FileInputStream("./src/test/resources/test-data/certificate.pfx"), "123456".toCharArray());
        } catch (IOException e) {
            e.printStackTrace();
        } catch (NoSuchAlgorithmException e) {
            e.printStackTrace();
        } catch (CertificateException e) {
            e.printStackTrace();
        }
        org.apache.http.conn.ssl.SSLSocketFactory clientAuthFactory = null;
        try {
            clientAuthFactory = new org.apache.http.conn.ssl.SSLSocketFactory(keyStore,"123456");
        } catch (NoSuchAlgorithmException e) {
            e.printStackTrace();
        } catch (KeyManagementException e) {
            e.printStackTrace();
        } catch (KeyStoreException e) {
            e.printStackTrace();
        } catch (UnrecoverableKeyException e) {
            e.printStackTrace();
        }
        SSLConfig config = null;
        config = new SSLConfig().with().sslSocketFactory(clientAuthFactory).and().allowAllHostnames();
        //org.apache.http.conn.ssl.SSLSocketFactory(clientAuthFactory).and().allowAllHostnames();
                RestAssured.config = RestAssured.config().sslConfig(config);
                //auth().certificate("./src/test/resources/Test.jks","123456")
        //.proxy("10.65.128.43",8080)
        //  .keyStore("./src/test/resources/Test.jks","123456")
        //   .trustStore("./src/test/resources/Test.jks","123456")
                       String response= given()
                               //auth().certificate("./src/test/resources/Test.jks","123456")
                               //.proxy("10.65.128.43",8080)
                               //  .keyStore("./src/test/resources/Test.jks","123456")
                               //   .trustStore("./src/test/resources/Test.jks","123456")
        .contentType(ContentType.TEXT)
                               .body(token)
                               .when()
                               //      .post(url)
                               .post("https://apitest.standardchartered.com/cib/api/activate")
                               .thenReturn()
                               .asString();
        // String response = RestAssured.given().when().get("https://apitest.standardchartered.com/cib/api/activate").thenReturn().toString();
                System.out.println("Response: "+response);
    }


}
