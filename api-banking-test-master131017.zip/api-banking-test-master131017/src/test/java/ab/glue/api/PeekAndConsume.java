package ab.glue.api;

import ab.common.PeekAndConsumeConfig;
import ab.utils.GenericUtils;
import common.EncryptDecrypt;
import common.EndPoint;
import cucumber.api.Scenario;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import io.restassured.RestAssured;
import io.restassured.config.SSLConfig;
import org.apache.commons.io.IOUtils;
import org.junit.Assert;
import org.junit.Test;

import javax.crypto.NoSuchPaddingException;
import javax.swing.text.html.parser.Element;
import java.io.FileInputStream;
import java.io.IOException;
import java.security.KeyStore;
import java.security.NoSuchAlgorithmException;
import java.security.PrivateKey;
import java.util.HashMap;

import static io.restassured.RestAssured.expect;
import static io.restassured.RestAssured.given;

/**
 * Created by 1571168 on 7/31/2017.
 */
public class PeekAndConsume {


    //public static String activationKey = "eyJhbGciOiJSUzI1NiJ9.eyJpc3MiOiJTQ0IiLCJhdWQiOiJTQ0ItQVBJQmFua2luZyIsImlhdCI6MTUwMjk0MTc5NywiZXhwIjozMDAwMDE1MDI5NDE3OTcsInBheWxvYWQiOnsiZW5hYmxlV2ViSG9vayI6InRydWUiLCJ3ZWJIb29rVXJsIjoiaHR0cDovLzE4LjIyMC4xNTYuMi93ZWJob29rIiwiYWN0aXZhdGlvbktleSI6eyJjb250ZW50IjoiZ2UyT2F5dWZNNnV2Z3ZZYzBWdkxlOTRTYmt5NzdveXJlenhSSzJpL3hocndkRitiQVZicldJcUNZeWFWYXpOZjRScWFlTkJhTkZNSW9BSGdZenhWTFYzdmRoNnVod2V3dGJHelpnNFo0RDVjd2dtZUtiZFpYd2tvOUNEMGE4S3F0TmRENDBVbkRVRU1NK0RZYVZtTlQ0c0dJMEI4K3pJZE0wVDFoVkE5NzdJVDYzYzJaYjNyR29EZGJZWG9xaGRmRWxLL2hJMU5NUDZzUXUzRWdXSlh5UEJjWnNrTkpoeDQ0WWkvV3BVSkNtaU5mcGliREJlWUllKzExNWEyTTJvZzdRcnlrQ0dVQ2RXdUwrYVlJYXlaT200eHgxZmFscUJvNE80NlVnaHp5bUNhN0pJc0lLN0pRMUdZK0RXbDRuN204V3NTVlRpOUVPaithTzlCT0dYeUtmZWdqRXNPcU8wZDlPVFlkbWpFRHNUWHlhWVlQV2JpcnpnYWcwcEJQVXdNaUZodFVOdE9ZSENSV3FVVDdEM1U5Qk81UDN2VmF4ajVjNHUxMHM1elRPR1BRd1d3S291QzBmS01sdldsTXByMDdJamd4djdlNDI5QkF6ZkdlVk1mekt4OGM4QUFWaWVXNndlQ2NYMVB2WlFOWE9FZTJHNmRpdzRyQ0lEQnpnRmwwdGpZVmRwUkhqZDJtWjRJakt1MklTMHE2bk9pNjRRYmVkQXNGckVMZUowYm5xZE9udGk5SnR5N3c0dk43ZWNuQUZVZTlGSHB6Vk9uMnAva0thSVQ3ZUxFUytkcVZ3Tk8vN3YyZkhsbnpyWlVWY3didXplbXdEek9HZXlCYUtCZnpSeVJERENGVFU4SkhueGtrZnArM25RNE5aOU9iQTVscHJWdis4VlhhdW5rWGcreGRRMGRiU3RkOXIzbTBwUjhkQVBOUGs5czFOYUtXRXdWUWpJVFZOelRvZTFlaWxobVpGRis0NEdMS0JFME1zaXI3WVZVV1pUbmtvcld2dzVHMjZkeU1DV3E0a2JwRUxkazczZjd5OU1ubDluM1phYzEwZ0pzcFNOcGJRWDBMTWd5MUwrdENyYlMrcnJRK0ZpZyIsImtleSI6IlpSU3IrSzVBcWR1QTZ3aVk2S21NSS9LTVE2d2NRem5HTzg1ZWJCVVZjdnlqOXZDVEpsRDdQdDNCdHlPUktPQ2grYnNLUi9iRVpBWlNqcG1OTzVlZ0JkRDBzZXdhNkRGaEpNQ0hENG1DS2hDT2RrQ2VreXlST2VtVHUycGx0cWNoNnUwc281a3F2TTBVYmVMcHF0RFRDZ3lKc3ZqdmVjTUNKK0MyZ1ZDZWJhc05lckVmZzM0UXN1ZUVSQlRiZlN6dFpMelVZRUtDaWI4Q2I4L0xtcFN3dFBxam5Nd1M1ckw5TkY2Q0kwS09vQVhtMXRCN0pUMFc1SXR1akNST3FJM2JGUTFlSDlIbzljeFAzWmt4cTJxc2RZYlNkS0phRnZ5eGlDeGQwRE8vOHphVjJoRzMxRStaSVFhTER0MHBORWtScEFaRHgrN1VpbWY5WHpyeXNJTENqQVx1MDAzZFx1MDAzZCJ9fX0.IvSNfIrsitDimWf9cfkCOnSEIYPxgU7o2LrUfdl026XqR7R_UM-SY24SwiOKaHuFFrggeeRQ8DLFhKGWcMiW1daadOxc_l1gY82U7Nerj6Y-9Wluz7Szdj_BmgplAqmAHrf2WvfQVTNnnbrID68cCw0K2fzPYT6ZKfFgGefYg86j6wF9FEeebSDm27l8d0_gB5JoPmDPkZPPLQzhIFByW294Ts1PeSxzLkhdP4dJ3ZvSK2BvNKzZQj8S-4aTB4C1O248cS8dFyUBxCjrCYld_XHOUi_76WkUZ2knAC8bVkXJTjIL3IRfQDs4k9Th50Qhma1-CnjAubTReK233zA0YA";
    //public static String activationKey = "eyJhbGciOiJSUzI1NiJ9.eyJpc3MiOiJTQ0IiLCJhdWQiOiJTQ0ItQVBJQmFua2luZyIsImlhdCI6MTUwMzE1MDk4NiwiZXhwIjozMDAwMDE1MDMxNTA5ODYsInBheWxvYWQiOnsiZW5hYmxlV2ViSG9vayI6InRydWUiLCJ3ZWJIb29rVXJsIjoiaHR0cDovLzEwLjIzLjIxMC41OTo4NDQzIiwiYWN0aXZhdGlvbktleSI6eyJjb250ZW50Ijoib0MyR1cwTXZpcHA4SXdudVlZb2VKVnlVQTVZQ0FDUUZkVVBHNWNVK01WanFTK3UzdWNDTnhBUWYzQWdxdkZVWnNFNDRZR2lEK01uUzFMdzZBbVdLZTh2MXJMS1d3RDU3L0NaSW15M0FmYzZGSkg0ZzRleGlRcWVlbE9zVUhKbGlPc2d1ZEhZM2MwdjVYTWRjZ05jN2xKTUVCWHFMa29rZnJTWU0xaGZkdFVrd0o4QUVQVk5hK0lqTlp2OVo4M2hSVXVNWmwrcnduTUhVb1dNZkx3SmI5T2J5N3lUUmszWnRMcGp2OUovM2h5cHU0ditVY05aRDZiMjNyOTZQZXQvZi94ckpySEFZNWY2VFFYd3NYZHNnMVh2NGRXb3RMMHJnTnFHMEhsbXkwVjNkUmJKMXYxWnJDTk9sZFAwVVRkbjdpZGREaFBTdElmRWU2aXdKcnFacTExeGtWbHRSbDR2bkNZM3I4eTNjckI5V1VaT1ZNNWczZnVxNEhidVM0WWk1WFkvQkc2aWVScUF0TU9QNHIxOVF2TWtVTUJpeEpzVVZMcFJkSkZaTHFNaG91TTMvenRKS1U5Smp0c1RjRUIwRVZBZVUwYkZ3WkFUV3R2WUEzMFZ5a1I2cU95Y0loZ0tEZmwyWWk1OUpFeTdOeUdBSnc5MWd3eG8vb3R6UDcvNy82TU1VNFFmUmsySmFMeEFyWUhGYzA1WEdNa2N5ZDR6a2djRzRxbDVWdjduekpPcFZhTVhtRHYrMEt6Y2pWSnlqTWtORTMzUnUyNkZpMVdhSU5FWEtZdTFacmN4Zm9GdHhGTkNVUzVMWitoRGRaQTM0ZFBUTEFWUmxMV2FYTjU1cDRERGNuYXpERkVqVFovallNdXdvU2QwVHpvMk5HMWtVdEM3Q0ZmYzhDVHV3NmozOEF0MWNEYmxPaVRtUUZ2SXNQYVRFV2Z4SU82UWRiRE9wREx3cS9zZDJmNEhLQTVxR1NpTDdpbVJNUkZIZWhPVjF2RXBlL2ZtZGRwK0dpaDA3UUZ4UXM5ZnhYeGRYa2tRR2ozVWJkUUt0elVTMjBoT0swUTV1cGd1L1U5aUdUZzIzVlErZzRDWkpXSExXZTJ6RyIsImtleSI6IkY4c01aQWEvYUFwejUwak02THplcWF3Q0hmRlMvSUVjQlFKVWl3ZU85VXpZNW9qcmNHY1hZSmp5bm4yUHlRdk5Gams1dkprZ3dhMm9lcVFuZTh6aFJnL0R0Zm9DRjFqSnlXaVBaYitKckVVek5IQzgyRXJJQng0V05EbHFxRzFaZ3VqUUhacDBMVmhkSWdVdVhCdUJtUldWeUUvWHJ3RVZERlVHOEhTaUpDUEZmUGhQd01DNXd5a0xMeWRLRnpTR2lvZVk5OW05bWlITTV6Mkg2TG1OWmpySlV0K3B3Q2k5MStwVUN4Vmc5OEZkSkh1a3hMOHA2aGttN1pMejBOeDFxS0F2dXVqdmduNGdDL1pIam5JcFhodkpJcjAvR3VtVmpOTlRlOFg2VFF4YnY4cGIvQlNSRGVxZnpybUJ0eXhWRWlkKzBzRWVCTTZET3dkME5XdzhBQVx1MDAzZFx1MDAzZCJ9fX0.IyF2f2Ln1j8k0VwUiavG5e4TmTXhS2J3GERjBDBla-KnaRgC13yMX1rCZEKU_Qs7UrYZLouoCu3np8Odw-1-ImSBHNJ1mEihCZ8_5tHG0yGGfbCx0HQLlQSUwT5C-vzM9cx7Vcu-y7uEmd3UqwHgRjsLV1BrGa2JV-WL900vGAkCkow4QLGQgCFRq67pHNqfEtIKj8li8etvLzu1JkXSmzDTjssIsbfEIr9PMa1pOetyJE1pXRk2LOH2cQShZAWbIvUUcPxmOZsk1glpU8OcPb3zaiIjK9YJ1JdrAlvKe6HxDWsKBin2a3f6GZXuEbdr4N6Ug_srheqYh9rmsNIv-Q";
    public static String activationKey = ab.glue.api.activationKey.token;
    public static HashMap<String , String > activKey = new HashMap<String , String >();
    public static String response = "{\n" +
            "    \"content\": \"4zsajyKPZ8LpSNLglyHtvg==\",\n" +
            "    \"key\": \"MrZV9elu/YX9qFIkmNP7vIOJl0nBpjoYPf9rGscxNgwURUv1BN8jvVKXyaEXgtOEuHyXV5tSJ7Zax2kfiZkxKMchOQWTP4EZakzyCILFHFxdPf5sglQ2agXAww2Hg8r0lW6RxkWhIfFG666nKa5phbcfhIi8OwgWQsGWTQBarENqvPhN8EhN3HB6odfd2HDPeyTS6IooTZw+s1c7rWT94yokYfKxxFEF/kuuouDNFzjGzcp2Tr6ksVhRP2WKKST/wR32B0siYGNRYd4k1/7PDbN02Wb7nlX58oEeWI7XQdYM+HQ7GQPzOLIQfyT6u/5IiHwvF7SsH4UNbSOifjQfJg==\"\n" +
            "}\n";
    public static String expectResponse ="";
    public void PeekAndConsume(){
        activKey.put("INDGROUP","eyJhbGciOiJSUzI1NiJ9.eyJpc3MiOiJTQ0IiLCJhdWQiOiJTQ0ItQVBJQmFua2luZyIsImlhdCI6MTUwMjk0MTc5NywiZXhwIjozMDAwMDE1MDI5NDE3OTcsInBheWxvYWQiOnsiZW5hYmxlV2ViSG9vayI6InRydWUiLCJ3ZWJIb29rVXJsIjoiaHR0cDovLzE4LjIyMC4xNTYuMi93ZWJob29rIiwiYWN0aXZhdGlvbktleSI6eyJjb250ZW50IjoiZ2UyT2F5dWZNNnV2Z3ZZYzBWdkxlOTRTYmt5NzdveXJlenhSSzJpL3hocndkRitiQVZicldJcUNZeWFWYXpOZjRScWFlTkJhTkZNSW9BSGdZenhWTFYzdmRoNnVod2V3dGJHelpnNFo0RDVjd2dtZUtiZFpYd2tvOUNEMGE4S3F0TmRENDBVbkRVRU1NK0RZYVZtTlQ0c0dJMEI4K3pJZE0wVDFoVkE5NzdJVDYzYzJaYjNyR29EZGJZWG9xaGRmRWxLL2hJMU5NUDZzUXUzRWdXSlh5UEJjWnNrTkpoeDQ0WWkvV3BVSkNtaU5mcGliREJlWUllKzExNWEyTTJvZzdRcnlrQ0dVQ2RXdUwrYVlJYXlaT200eHgxZmFscUJvNE80NlVnaHp5bUNhN0pJc0lLN0pRMUdZK0RXbDRuN204V3NTVlRpOUVPaithTzlCT0dYeUtmZWdqRXNPcU8wZDlPVFlkbWpFRHNUWHlhWVlQV2JpcnpnYWcwcEJQVXdNaUZodFVOdE9ZSENSV3FVVDdEM1U5Qk81UDN2VmF4ajVjNHUxMHM1elRPR1BRd1d3S291QzBmS01sdldsTXByMDdJamd4djdlNDI5QkF6ZkdlVk1mekt4OGM4QUFWaWVXNndlQ2NYMVB2WlFOWE9FZTJHNmRpdzRyQ0lEQnpnRmwwdGpZVmRwUkhqZDJtWjRJakt1MklTMHE2bk9pNjRRYmVkQXNGckVMZUowYm5xZE9udGk5SnR5N3c0dk43ZWNuQUZVZTlGSHB6Vk9uMnAva0thSVQ3ZUxFUytkcVZ3Tk8vN3YyZkhsbnpyWlVWY3didXplbXdEek9HZXlCYUtCZnpSeVJERENGVFU4SkhueGtrZnArM25RNE5aOU9iQTVscHJWdis4VlhhdW5rWGcreGRRMGRiU3RkOXIzbTBwUjhkQVBOUGs5czFOYUtXRXdWUWpJVFZOelRvZTFlaWxobVpGRis0NEdMS0JFME1zaXI3WVZVV1pUbmtvcld2dzVHMjZkeU1DV3E0a2JwRUxkazczZjd5OU1ubDluM1phYzEwZ0pzcFNOcGJRWDBMTWd5MUwrdENyYlMrcnJRK0ZpZyIsImtleSI6IlpSU3IrSzVBcWR1QTZ3aVk2S21NSS9LTVE2d2NRem5HTzg1ZWJCVVZjdnlqOXZDVEpsRDdQdDNCdHlPUktPQ2grYnNLUi9iRVpBWlNqcG1OTzVlZ0JkRDBzZXdhNkRGaEpNQ0hENG1DS2hDT2RrQ2VreXlST2VtVHUycGx0cWNoNnUwc281a3F2TTBVYmVMcHF0RFRDZ3lKc3ZqdmVjTUNKK0MyZ1ZDZWJhc05lckVmZzM0UXN1ZUVSQlRiZlN6dFpMelVZRUtDaWI4Q2I4L0xtcFN3dFBxam5Nd1M1ckw5TkY2Q0kwS09vQVhtMXRCN0pUMFc1SXR1akNST3FJM2JGUTFlSDlIbzljeFAzWmt4cTJxc2RZYlNkS0phRnZ5eGlDeGQwRE8vOHphVjJoRzMxRStaSVFhTER0MHBORWtScEFaRHgrN1VpbWY5WHpyeXNJTENqQVx1MDAzZFx1MDAzZCJ9fX0.IvSNfIrsitDimWf9cfkCOnSEIYPxgU7o2LrUfdl026XqR7R_UM-SY24SwiOKaHuFFrggeeRQ8DLFhKGWcMiW1daadOxc_l1gY82U7Nerj6Y-9Wluz7Szdj_BmgplAqmAHrf2WvfQVTNnnbrID68cCw0K2fzPYT6ZKfFgGefYg86j6wF9FEeebSDm27l8d0_gB5JoPmDPkZPPLQzhIFByW294Ts1PeSxzLkhdP4dJ3ZvSK2BvNKzZQj8S-4aTB4C1O248cS8dFyUBxCjrCYld_XHOUi_76WkUZ2knAC8bVkXJTjIL3IRfQDs4k9Th50Qhma1-CnjAubTReK233zA0YA");
        activKey.put("INDGRP","eyJhbGciOiJSUzI1NiJ9.eyJpc3MiOiJTQ0IiLCJhdWQiOiJTQ0ItQVBJQmFua2luZyIsImlhdCI6MTUwMzE1MDk4NiwiZXhwIjozMDAwMDE1MDMxNTA5ODYsInBheWxvYWQiOnsiZW5hYmxlV2ViSG9vayI6InRydWUiLCJ3ZWJIb29rVXJsIjoiaHR0cDovLzEwLjIzLjIxMC41OTo4NDQzIiwiYWN0aXZhdGlvbktleSI6eyJjb250ZW50Ijoib0MyR1cwTXZpcHA4SXdudVlZb2VKVnlVQTVZQ0FDUUZkVVBHNWNVK01WanFTK3UzdWNDTnhBUWYzQWdxdkZVWnNFNDRZR2lEK01uUzFMdzZBbVdLZTh2MXJMS1d3RDU3L0NaSW15M0FmYzZGSkg0ZzRleGlRcWVlbE9zVUhKbGlPc2d1ZEhZM2MwdjVYTWRjZ05jN2xKTUVCWHFMa29rZnJTWU0xaGZkdFVrd0o4QUVQVk5hK0lqTlp2OVo4M2hSVXVNWmwrcnduTUhVb1dNZkx3SmI5T2J5N3lUUmszWnRMcGp2OUovM2h5cHU0ditVY05aRDZiMjNyOTZQZXQvZi94ckpySEFZNWY2VFFYd3NYZHNnMVh2NGRXb3RMMHJnTnFHMEhsbXkwVjNkUmJKMXYxWnJDTk9sZFAwVVRkbjdpZGREaFBTdElmRWU2aXdKcnFacTExeGtWbHRSbDR2bkNZM3I4eTNjckI5V1VaT1ZNNWczZnVxNEhidVM0WWk1WFkvQkc2aWVScUF0TU9QNHIxOVF2TWtVTUJpeEpzVVZMcFJkSkZaTHFNaG91TTMvenRKS1U5Smp0c1RjRUIwRVZBZVUwYkZ3WkFUV3R2WUEzMFZ5a1I2cU95Y0loZ0tEZmwyWWk1OUpFeTdOeUdBSnc5MWd3eG8vb3R6UDcvNy82TU1VNFFmUmsySmFMeEFyWUhGYzA1WEdNa2N5ZDR6a2djRzRxbDVWdjduekpPcFZhTVhtRHYrMEt6Y2pWSnlqTWtORTMzUnUyNkZpMVdhSU5FWEtZdTFacmN4Zm9GdHhGTkNVUzVMWitoRGRaQTM0ZFBUTEFWUmxMV2FYTjU1cDRERGNuYXpERkVqVFovallNdXdvU2QwVHpvMk5HMWtVdEM3Q0ZmYzhDVHV3NmozOEF0MWNEYmxPaVRtUUZ2SXNQYVRFV2Z4SU82UWRiRE9wREx3cS9zZDJmNEhLQTVxR1NpTDdpbVJNUkZIZWhPVjF2RXBlL2ZtZGRwK0dpaDA3UUZ4UXM5ZnhYeGRYa2tRR2ozVWJkUUt0elVTMjBoT0swUTV1cGd1L1U5aUdUZzIzVlErZzRDWkpXSExXZTJ6RyIsImtleSI6IkY4c01aQWEvYUFwejUwak02THplcWF3Q0hmRlMvSUVjQlFKVWl3ZU85VXpZNW9qcmNHY1hZSmp5bm4yUHlRdk5Gams1dkprZ3dhMm9lcVFuZTh6aFJnL0R0Zm9DRjFqSnlXaVBaYitKckVVek5IQzgyRXJJQng0V05EbHFxRzFaZ3VqUUhacDBMVmhkSWdVdVhCdUJtUldWeUUvWHJ3RVZERlVHOEhTaUpDUEZmUGhQd01DNXd5a0xMeWRLRnpTR2lvZVk5OW05bWlITTV6Mkg2TG1OWmpySlV0K3B3Q2k5MStwVUN4Vmc5OEZkSkh1a3hMOHA2aGttN1pMejBOeDFxS0F2dXVqdmduNGdDL1pIam5JcFhodkpJcjAvR3VtVmpOTlRlOFg2VFF4YnY4cGIvQlNSRGVxZnpybUJ0eXhWRWlkKzBzRWVCTTZET3dkME5XdzhBQVx1MDAzZFx1MDAzZCJ9fX0.IyF2f2Ln1j8k0VwUiavG5e4TmTXhS2J3GERjBDBla-KnaRgC13yMX1rCZEKU_Qs7UrYZLouoCu3np8Odw-1-ImSBHNJ1mEihCZ8_5tHG0yGGfbCx0HQLlQSUwT5C-vzM9cx7Vcu-y7uEmd3UqwHgRjsLV1BrGa2JV-WL900vGAkCkow4QLGQgCFRq67pHNqfEtIKj8li8etvLzu1JkXSmzDTjssIsbfEIr9PMa1pOetyJE1pXRk2LOH2cQShZAWbIvUUcPxmOZsk1glpU8OcPb3zaiIjK9YJ1JdrAlvKe6HxDWsKBin2a3f6GZXuEbdr4N6Ug_srheqYh9rmsNIv-Q");
    }
    /**
     * This method is used to hit the Peek api and verify the response with the expected response
     */
    @Then("^Peek response should be displayed with the expected value$")
    public void peekTest() {
        GenericUtils utils = new GenericUtils();
        String expectedResponse = commonApiMethods.data.get(0).get("PeekResponse").toString().trim().replaceAll(" ","");
        expectedResponse = utils.peekConsumeTrim(expectedResponse);
        PeekAndConsumeConfig peekAndConsumeConfig = new PeekAndConsumeConfig();
        String actualResponse = peekAndConsumeConfig.getPeekConsumeResponseAsString(ab.glue.api.activationKey.activKey.get(""), "peek").trim();
        System.out.println("Peek response : "+actualResponse);
        actualResponse = utils.peekConsumeTrim(expectedResponse);
        Assert.assertTrue("Peek Response is not displayed as expected. Expected Response - " + expectedResponse + ". Actual Response - " + actualResponse, expectedResponse.equals(actualResponse));
    }

    /**
     * This method is used to hit the Peek api and verify the response with the expected response
     */
    @Then("^Peek response should be displayed with amount '(.+)' accountNo '(.+)' transactionType '(.+)' the expected value for the group '(.+)'$")
    public void peekValueTest(String amount, String accountNo, String trxType, String groupID) throws Throwable {
        GenericUtils utils = new GenericUtils();
        //String expectedResponse = commonApiMethods.data.get(0).get("PeekResponse").toString().trim().replaceAll(" ","");
        String expectedResponse = EndPoint.WEBHOOK_MESSAGE.replaceAll(" ","");
        expectedResponse = utils.expectedValueTrim(expectedResponse,groupID,amount, accountNo,trxType).replaceAll("\\.00","");;
        PeekAndConsumeConfig peekAndConsumeConfig = new PeekAndConsumeConfig();
        activationKey activationKey1 = new activationKey();
        activationKey1.generated_content_and_key_is_passed_to_the_create_token_method_for_the_group(groupID);
        String actualResponse = peekAndConsumeConfig.getPeekConsumeResponseAsString(ab.glue.api.activationKey.activKey.get(groupID), "peek").trim();
        //String actualResponse = peekAndConsumeConfig.getPeekConsumeResponseAsString(activationKey, "peek").trim();
        System.out.println("Peek response : "+actualResponse);
        actualResponse = utils.peekConsumeTrim(actualResponse);
        System.out.println("actualResponse : "+actualResponse);
        System.out.println("expectedResponse : "+expectedResponse);
        Assert.assertTrue("Peek Response is not displayed as expected. Expected Response - " + expectedResponse + ". Actual Response - " + actualResponse, expectedResponse.equals(actualResponse));
        //Assert.assertTrue("Peek Response is not displayed as expected. Expected Response - " + expectedResponse + ". Actual Response - " + actualResponse, actualResponse.startsWith("[{\"groupId\":\""+groupID+"\""));
    }

    /**
     * This method is used to hit the Peek api and verify the response with the expected response
     */
    @Then("^Peek response should be displayed with encrypted value for amount '(.+)' accountNo '(.+)' transactionType '(.+)' the expected value for the group '(.+)'$")
    public void peekValueEncryptedTest(String amount, String accountNo, String trxType, String groupID) throws Throwable {
        GenericUtils utils = new GenericUtils();
        //String expectedResponse = commonApiMethods.data.get(0).get("PeekResponse").toString().trim().replaceAll(" ","");
        expectResponse = EndPoint.WEBHOOK_MESSAGE.replaceAll(" ","");
        int counter = 1;
        if(amount.contains(",")){
            String[] trx = amount.split(",");
            counter = counter+trx.length;
        }
        expectResponse = utils.expectedValueTrim(expectResponse,groupID,amount, accountNo,trxType).replaceAll("\\.00","");
        activationKey activationKey1 = new activationKey();
        activationKey1.generated_content_and_key_is_passed_to_the_create_token_method_for_the_group(groupID);
        PeekAndConsumeConfig peekAndConsumeConfig = new PeekAndConsumeConfig();
        response = peekAndConsumeConfig.getPeekConsumeResponseAsEncryptedString(ab.glue.api.activationKey.activKey.get(groupID), "peek").trim();
        Assert.assertFalse("Peek Response is not displayed as encrypted content. Actual Response - "  + response, expectResponse.equals(response));
          }

@Then("^The messages should be decrypted as expected when using privateKey of group '(.+)' for '(.+)'$")
    public void verifyDecryptedValueGivesActualContent(String privateKey,String pull) throws NoSuchPaddingException, NoSuchAlgorithmException, IOException {
        String content = response.split("\"content\":\"")[1].split("\"")[0];
        String key = response.split("\"key\":\"")[1].split("\"")[0];
        common.EncryptDecrypt encryptDecrypt = new common.EncryptDecrypt();
        PrivateKey privatekey = encryptDecrypt.convertStringToPrivateKey(
                IOUtils.toString(PeekAndConsume.class.getClassLoader().getResourceAsStream(privateKey+"private.txt")));
        response = encryptDecrypt.decryptWithPrivateKey(privatekey, new EncryptDecrypt.EncryptedContent(content, key));
        System.out.println("Peek response : " + response);
        GenericUtils utils = new GenericUtils();
        response = utils.peekConsumeTrim(response);
        System.out.println("actualResponse : "+response);
        System.out.println("expectedResponse : "+expectResponse);
        if(pull.equals("recover"))
            Assert.assertTrue("Decrypted Response is not displayed as expected. Expected Response - " + expectResponse + ". Actual Response - " + response, response.contains(expectResponse));
        else
            Assert.assertTrue("Decrypted Response is not displayed as expected. Expected Response - " + expectResponse + ". Actual Response - " + response, response.equals(expectResponse));

    }

    @Then("^The messages should not be decrypted as expected when using privateKey of group '(.+)' for '(.+)'$")
    public void verifyMessageNotDecrptedForWrongPrivateKey(String privateKey, String pull) throws NoSuchPaddingException, NoSuchAlgorithmException, IOException {
        String content = response.split("content\":\"")[1].split("\"")[0];
        String key = response.split("key\":\"")[1].split("\"")[0];
        common.EncryptDecrypt encryptDecrypt = new common.EncryptDecrypt();
        PrivateKey privatekey = encryptDecrypt.convertStringToPrivateKey(
                IOUtils.toString(PeekAndConsume.class.getClassLoader().getResourceAsStream(privateKey+"private.txt")));
        try {
            response = encryptDecrypt.decryptWithPrivateKey(privatekey, new EncryptDecrypt.EncryptedContent(content, key));
            System.out.println("Peek response : " + response);
            GenericUtils utils = new GenericUtils();
            response = utils.peekConsumeTrim(response);
            System.out.println("actualResponse : " + response);
            System.out.println("expectedResponse : " + expectResponse);
            if (pull.equals("recover"))
                Assert.assertFalse("Able to decrypt message with different private key- " + privateKey, expectResponse.contains(response));
            else
                Assert.assertFalse("Able to decrypt message with different private key- " + privateKey, expectResponse.equals(response));
        }catch(Exception e){
            System.out.println("Could not decrypt with different private key");
        }
    }


    /**
     * This method is used to hit the Consume api and verify the response with the expected response
     */
    @Then("^Consume response should be displayed with amount '(.+)' accountNo '(.+)' transactionType '(.+)' the expected value for the group '(.+)'$")
    public void consumeValueTest(String amount, String accountNo, String trxType, String groupID) throws Throwable {
        GenericUtils utils = new GenericUtils();
        //Thread.sleep(150000);
        String expectedResponse = EndPoint.WEBHOOK_MESSAGE.trim().replaceAll(" ","");
        expectedResponse = utils.expectedValueTrim(expectedResponse,groupID,amount, accountNo,trxType).replaceAll("\\.00","");
        activationKey activationKey1 = new activationKey();
        activationKey1.generated_content_and_key_is_passed_to_the_create_token_method_for_the_group(groupID);
        PeekAndConsumeConfig peekAndConsumeConfig = new PeekAndConsumeConfig();
        System.out.println("The token confirmation is "+ab.glue.api.activationKey.activKey.get(groupID));

        String actualResponse = peekAndConsumeConfig.getPeekConsumeResponseAsString(ab.glue.api.activationKey.activKey.get(groupID), "consume").trim();
        System.out.println("Consume response : "+actualResponse);
        actualResponse = utils.peekConsumeTrim(actualResponse);
        Assert.assertTrue("Consume Response is not displayed as expected. Expected Response - " + expectedResponse + ". Actual Response - " + actualResponse, expectedResponse.equals(actualResponse));
        //Assert.assertTrue("Consume Response is not displayed as expected. Expected Response - " + expectedResponse + ". Actual Response - " + actualResponse, actualResponse.startsWith("[{\"groupId\":\""+groupID+"\""));
    }

    /**
     * This method is used to hit the Peek api and verify the response with the expected response
     */
    @Then("^Consume response should be displayed with encrypted value for amount '(.+)' accountNo '(.+)' transactionType '(.+)' the expected value for the group '(.+)'$")
    public void consumeValueEncryptedTest(String amount, String accountNo, String trxType, String groupID) throws Throwable {
        GenericUtils utils = new GenericUtils();
        //String expectedResponse = commonApiMethods.data.get(0).get("PeekResponse").toString().trim().replaceAll(" ","");
        String expectedResponse = EndPoint.WEBHOOK_MESSAGE.replaceAll(" ","");
        int counter = 1;
        if(amount.contains(",")){
            String[] trx = amount.split(",");
            counter = counter+trx.length;
        }
        expectedResponse = utils.expectedValueTrim(expectedResponse,groupID,amount, accountNo,trxType).replaceAll("\\.00","");
        activationKey activationKey1 = new activationKey();
        activationKey1.generated_content_and_key_is_passed_to_the_create_token_method_for_the_group(groupID);
        PeekAndConsumeConfig peekAndConsumeConfig = new PeekAndConsumeConfig();
        String actualResponse = peekAndConsumeConfig.getPeekConsumeResponseAsEncryptedString(ab.glue.api.activationKey.activKey.get(groupID), "consume").trim();
        response = actualResponse;
        Assert.assertFalse("Consume Response is not displayed as encrypted content. Actual Response - "  + actualResponse, expectedResponse.equals(actualResponse));
        //String actualResponse = peekAndConsumeConfig.getPeekConsumeResponseAsString(activationKey, "peek").trim();
           //Assert.assertTrue("Consume Response is not displayed as expected. Expected Response - " + expectedResponse + ". Actual Response - " + actualResponse, expectedResponse.equals(actualResponse));
    }


    /**
     * This method is used to hit the Recover api and verify the response with the expected response
     */
    @Then("^Recover response should be displayed with amount '(.+)' accountNo '(.+)' transactionType '(.+)' the expected value for the group '(.+)'$")
    public void recoverValueTest(String amount, String accountNo, String trxType, String groupID) throws Throwable {
        GenericUtils utils = new GenericUtils();
        String expectedResponse = EndPoint.WEBHOOK_MESSAGE.trim().replaceAll(" ","");
        expectedResponse = utils.expectedValueTrim(expectedResponse,groupID,amount, accountNo,trxType).replaceAll("\\.00","");
        activationKey activationKey1 = new activationKey();
        activationKey1.generated_content_and_key_is_passed_to_the_create_token_method_for_the_group(groupID);
        PeekAndConsumeConfig peekAndConsumeConfig = new PeekAndConsumeConfig();
        String actualResponse = peekAndConsumeConfig.getPeekConsumeResponseAsString(ab.glue.api.activationKey.activKey.get(groupID), "recover").trim();
        System.out.println("Recover response : "+actualResponse);
        actualResponse = utils.peekConsumeTrim(actualResponse);
        Assert.assertTrue("Recover Response is not displayed as expected. Expected Response - " + expectedResponse + ". Actual Response - " + actualResponse, expectedResponse.equals(actualResponse));
    }

    /**
     * This method is used to hit the Peek api and verify the response with the expected response
     */
    @Then("^Recover response should be displayed with encrypted value for amount '(.+)' accountNo '(.+)' transactionType '(.+)' the expected value for the group '(.+)'$")
    public void recoverValueEncryptedTest(String amount, String accountNo, String trxType, String groupID) throws Throwable {
        GenericUtils utils = new GenericUtils();
        //String expectedResponse = commonApiMethods.data.get(0).get("PeekResponse").toString().trim().replaceAll(" ","");
        String expectedResponse = EndPoint.WEBHOOK_MESSAGE.replaceAll(" ","");
        int counter = 1;
        if(amount.contains(",")){
            String[] trx = amount.split(",");
            counter = counter+trx.length;
        }
        expectedResponse = utils.expectedValueTrim(expectedResponse,groupID,amount, accountNo,trxType).replace("\\.00","");
        activationKey activationKey1 = new activationKey();
        activationKey1.generated_content_and_key_is_passed_to_the_create_token_method_for_the_group(groupID);
        PeekAndConsumeConfig peekAndConsumeConfig = new PeekAndConsumeConfig();
        String actualResponse = peekAndConsumeConfig.getPeekConsumeResponseAsEncryptedString(ab.glue.api.activationKey.activKey.get(groupID), "recover").trim();
        response = actualResponse;
        Assert.assertFalse("Recover Response is not displayed as encrypted content. Actual Response - "  + actualResponse, actualResponse.contains(expectedResponse));
       // Assert.assertTrue("Recover Response is not displayed as expected. Expected Response - " + expectedResponse + ". Actual Response - " + actualResponse, actualResponse.contains(expectedResponse));
       // Assert.assertTrue("Recover Response is not displayed as expected. Expected Response - " + expectedResponse + ". Actual Response - " + actualResponse, actualResponse.startsWith("[{\"groupId\":\""+groupID+"\""));
    }

    /**
     * This method is used to hit the Consume api and verify the response with the expected response
     */
    @Then("^Consume response should be displayed with the expected value$")
    public void consumeTest() {
        GenericUtils utils = new GenericUtils();
        String expectedResponse = EndPoint.WEBHOOK_MESSAGE.trim().replaceAll(" ","");
        expectedResponse = utils.peekConsumeTrim(expectedResponse);
        PeekAndConsumeConfig peekAndConsumeConfig = new PeekAndConsumeConfig();
        String actualResponse = peekAndConsumeConfig.getPeekConsumeResponseAsString(activationKey, "consume").trim().replaceAll(" ","");
        System.out.println("Consume response : "+actualResponse);
        actualResponse = utils.peekConsumeTrim(actualResponse);
        Assert.assertTrue("Consume Response is not displayed as expected. Expected Response - " + expectedResponse + ". Actual Response - " + actualResponse,expectedResponse.equals(actualResponse));
    }

    /**
     * This method is used to hit the Recover api and verify the response with the expected response
     */
    @Then("^Recover response should be displayed with the expected value$")
    public void recoverTest() {
        GenericUtils utils = new GenericUtils();
        String expectedResponse = EndPoint.WEBHOOK_MESSAGE.trim().replaceAll(" ","");
        expectedResponse = utils.peekConsumeTrim(expectedResponse);
        PeekAndConsumeConfig peekAndConsumeConfig = new PeekAndConsumeConfig();
        String actualResponse = peekAndConsumeConfig.getPeekConsumeResponseAsString(activationKey, "recover").trim().replaceAll(" ","");
        System.out.println("Recover response : "+actualResponse);
        actualResponse = utils.peekConsumeTrim(actualResponse);
        Assert.assertTrue("Recover Response is not displayed as expected. Expected Response - " + expectedResponse + ". Actual Response - " + actualResponse,actualResponse.startsWith(expectedResponse));
    }

    /**
     * This method is used to hit the Peek api and verify the response with the expected response
     */
    @Then("^Peek response should be displayed with the empty message for the group '(.+)'$")
    public void peekEmptyTest(String group) throws Throwable {
        PeekAndConsumeConfig peekAndConsumeConfig = new PeekAndConsumeConfig();
        activationKey activationKey1 = new activationKey();
        activationKey1.generated_content_and_key_is_passed_to_the_create_token_method_for_the_group(group);
        String actualResponse = peekAndConsumeConfig.getPeekConsumeResponseAsString(ab.glue.api.activationKey.activKey.get(group), "peek");
        System.out.println("Peek response : "+actualResponse);
        Assert.assertTrue("Peek Response is not displayed as expected. Expected Response - []. Actual Response - " + actualResponse,"[]".equals(actualResponse));
    }

    /**
     * This method is used to hit the Peek api and verify the response with the expected response
     */
    @Then("^Peek response should be displayed with the deactivate error message for the group '(.+)'$")
    public void verifyDeactivateErrorMessageForPeek(String group) throws Throwable {
        PeekAndConsumeConfig peekAndConsumeConfig = new PeekAndConsumeConfig();
        activationKey activationKey1 = new activationKey();
        activationKey1.generated_content_and_key_is_passed_to_the_create_token_method_for_the_group(group);
        String actualResponse = peekAndConsumeConfig.getPeekConsumeResponseAsString(ab.glue.api.activationKey.activKey.get(group), "peek");
        System.out.println("Peek response : "+actualResponse);
        Assert.assertTrue("Peek Response is not displayed as expected. Expected Response - {\"errorMessage\":\"API Banking is not enabled for this group\"}. Actual Response - " + actualResponse,"{\"errorMessage\":\"API Banking is not enabled for this group\"}".equals(actualResponse));
    }
    /**
     * This method is used to hit the Consume api and verify the response with the expected response
     */
    @Then("^Consume response should be displayed with the empty message for the group '(.+)'$")
    public void consumeEmptyTest(String group) throws Throwable {
        PeekAndConsumeConfig peekAndConsumeConfig = new PeekAndConsumeConfig();
        activationKey activationKey1 = new activationKey();
        activationKey1.generated_content_and_key_is_passed_to_the_create_token_method_for_the_group(group);
        String actualResponse = peekAndConsumeConfig.getPeekConsumeResponseAsString(ab.glue.api.activationKey.activKey.get(group), "consume");
        System.out.println("Consume response : "+actualResponse);
        Assert.assertTrue("Consume Response is not displayed as expected. Expected Response - []. Actual Response - " + actualResponse,"[]".equals(actualResponse));
    }

    /**
     * This method is used to hit the Consume api and verify the response with the expected response
     */
    @Then("^Consume response should be displayed with the deactivate error message for the group '(.+)'$")
    public void verifyDeactivateErrorMessageForConsume(String group) throws Throwable {
        PeekAndConsumeConfig peekAndConsumeConfig = new PeekAndConsumeConfig();
        activationKey activationKey1 = new activationKey();
        activationKey1.generated_content_and_key_is_passed_to_the_create_token_method_for_the_group(group);
        String actualResponse = peekAndConsumeConfig.getPeekConsumeResponseAsString(ab.glue.api.activationKey.activKey.get(group), "consume");
        System.out.println("Consume response : "+actualResponse);
        Assert.assertTrue("Consume Response is not displayed as expected. Expected Response - {\"errorMessage\":\"API Banking is not enabled for this group\"}. Actual Response - " + actualResponse,"{\"errorMessage\":\"API Banking is not enabled for this group\"}".equals(actualResponse));
    }

    /**
     * This method is used to hit the Consume api and verify the response with the expected response
     */
    @Then("^Recover response should be displayed with the empty message for the group '(.+)'$")
    public void recoverEmptyTest(String group) throws Throwable {
        PeekAndConsumeConfig peekAndConsumeConfig = new PeekAndConsumeConfig();
        activationKey activationKey1 = new activationKey();
        activationKey1.generated_content_and_key_is_passed_to_the_create_token_method_for_the_group(group);
        String actualResponse = peekAndConsumeConfig.getPeekConsumeResponseAsString(ab.glue.api.activationKey.activKey.get(group), "recover");
        System.out.println("Recover response : "+actualResponse);
        Assert.assertTrue("Recover Response is not displayed as expected. Expected Response - []. Actual Response - " + actualResponse,"[]".equals(actualResponse));
    }


    /**
     * This method is used to hit the Consume api and verify the response with the expected response
     */
    @Then("^Recover response should be displayed with the deactivate error message for the group '(.+)'$")
    public void verifyDeactivateErrorMessageForRecover(String group) throws Throwable {
        PeekAndConsumeConfig peekAndConsumeConfig = new PeekAndConsumeConfig();
        activationKey activationKey1 = new activationKey();
        activationKey1.generated_content_and_key_is_passed_to_the_create_token_method_for_the_group(group);
        String actualResponse = peekAndConsumeConfig.getPeekConsumeResponseAsString(ab.glue.api.activationKey.activKey.get(group), "recover");
        System.out.println("Recover response : "+actualResponse);
        Assert.assertTrue("Recover Response is not displayed as expected. Expected Response - {\"errorMessage\":\"API Banking is not enabled for this group\"}. Actual Response - " + actualResponse,"{\"errorMessage\":\"API Banking is not enabled for this group\"}".equals(actualResponse));
    }

    /**
     * This method is used to hit the Consume api and verify the response with the expected response
     */
    @Then("^I consume all the previous messages$")
    public void consumePreviousMessages() {
        PeekAndConsumeConfig peekAndConsumeConfig = new PeekAndConsumeConfig();
        String actualResponse = peekAndConsumeConfig.getPeekConsumeResponseAsString(activationKey, "consume");
        System.out.println("Consumed the messages : "+actualResponse);
    }
}