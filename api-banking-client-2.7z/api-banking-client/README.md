# SCB API-Banking-Client SDK

To begin using the Standard Chartered API Banking services, the following steps are required:

 1) Creation of a DigiCert rooted certificate
 2) Generate RSA key pair and store your private key in a secure keystore
 3) Supply the Certificate and public key to your Standard Chartered Relationship Manager

**Pre-requisites**

Java 8 with security pack installed 
(JCE 8, http://www.oracle.com/technetwork/java/javase/downloads/jce8-download-2133166.html)

# RSA Key Pair

1) Create Key store for 2028 RSA key pair

> keytool -genkeypair -keysize 2048 -keyalg RSA -alias apibanking-sig-key -keystore scb-api-banking.jks

2) Export certificate

> keytool -exportcert -keystore scb-api-banking.jks -alias apibanking-sig-key -rfc -file cert.pem

3) Convert to PEM (optional)

> openssl x509 -pubkey -noout -in cert.pem  > pubkey.pem

4) Send the pubkey.pem along with the DigiCert certificate (not including private key) to your relationship manager.

# DigiCVert certificate import

5) Import your DigiCert (PKCS 12) into the key store, if the DigiCert is not already in PKCS format, it will first need to be converted using openssl.

> keytool -importkeystore -destkeystore scb-api-banking.jks -srckeystore [filename-new-PKCS-12.p12] -srcstoretype PKCS12

6) Import CA bundle into key store (optional)

> keytool -import -alias bundle -trustcacerts -file [ca_bundle] -keystore scb-api-banking.jks

NOTE: We will never ask you to send a private key.  The private key should be kept secret (ideally in an hardware security module (HSM)).   If you're private key is sent to us by mistake
we will NOT accept the corresponding public key and new RSA key pair will be required.

