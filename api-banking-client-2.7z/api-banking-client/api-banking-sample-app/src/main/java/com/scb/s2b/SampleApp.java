package com.scb.s2b;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.scb.api.client.*;

import java.io.IOException;
import java.security.KeyManagementException;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;
import java.security.cert.CertificateException;
import java.util.List;
import java.util.Map;

public class SampleApp {

    public static void main(String[] args) throws CertificateException, NoSuchAlgorithmException, KeyStoreException, IOException, KeyManagementException {

        ApiBanking apiBanking = ApiBankingBuilder.
                $(ApiBankingEnvironment.Test).
                withKeystore(SampleApp.class.getClassLoader().getResourceAsStream("scb-api-banking.jks"), "password").
                withSignatureAlias("apibanking-sig-key").
                build();

        System.out.println("Activating account for web hook url: " + args[0] + ".. ");

        apiBanking.activate(
                SampleApp.class.getClassLoader().getResourceAsStream("sample-activation.key"),
                args[0]
        );

        System.out.println("Checking message backlog with peek.. ");
        List<Map<String, Object>> messages = apiBanking.peek();
        System.out.println( new ObjectMapper().writeValueAsString(messages));

//        System.out.println("Checking message backlog with consume.. ");
//        messages = apiBanking.consume();
//        System.out.println( new ObjectMapper().writeValueAsString(messages));
//
//        System.out.println("Checking message backlog with recover.. ");
//        messages = apiBanking.recover();
//        System.out.println( new ObjectMapper().writeValueAsString(messages));
//
        //initiate payment using UPI schema
//        apiBanking.schema(UPI.class).initiatePayment(reqPay);

    }

}
