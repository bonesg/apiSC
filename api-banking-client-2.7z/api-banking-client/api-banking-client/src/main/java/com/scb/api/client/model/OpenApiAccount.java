package com.scb.api.client.model;

import java.util.Collection;

public class OpenApiAccount {

    private String id;
    private String label;
    private String number;
    private Collection<OpenApiAccountOwner> owners;
    private String type;
    private OpenApiAccountBalance balance;
    private String IBAN;
    private String swift_bic;
    private String bank_kd;

    public String getId() {
        return id;
    }

    public String getLabel() {
        return label;
    }

    public String getNumber() {
        return number;
    }

    public Collection<OpenApiAccountOwner> getOwners() {
        return owners;
    }

    public String getType() {
        return type;
    }

    public OpenApiAccountBalance getBalance() {
        return balance;
    }

    public String getIBAN() {
        return IBAN;
    }

    public String getSwift_bic() {
        return swift_bic;
    }

    public String getBank_kd() {
        return bank_kd;
    }
}
