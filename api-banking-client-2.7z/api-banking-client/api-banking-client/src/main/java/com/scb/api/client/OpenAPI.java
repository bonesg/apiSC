package com.scb.api.client;

import com.scb.api.client.model.OpenApiAccount;

import java.util.Collection;

public interface OpenAPI {

    Collection<OpenApiAccount> listAccounts();

    Collection<String> paymentTypes();

}
