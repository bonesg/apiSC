package com.scb.api.client;

public class Trade {
}
