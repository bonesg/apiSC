package com.scb.api.client.util;

import com.scb.api.client.ApiBankingEnvironment;
import com.scb.api.client.ApiBankingException;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.net.ssl.*;
import java.security.*;
import java.util.HashMap;

public class HttpUtility {

    private static final Logger logger = LoggerFactory.getLogger(HttpUtility.class);

    private OkHttpClient httpClient;
    private KeyStore keyStore;
    private final String signatureKeyAlias;
    private final char[] keyPassword;
    private ApiBankingEnvironment environment;

    public HttpUtility(OkHttpClient httpClient, KeyStore keyStore, String signatureKeyAlias, char[] keyPassword, ApiBankingEnvironment environment) {
        this.httpClient = httpClient;
        this.keyStore = keyStore;
        this.signatureKeyAlias = signatureKeyAlias;
        this.keyPassword = keyPassword;
        this.environment = environment;
    }

    public Response performGet(String uri) {

        Response response;
        try {

            String token = JWT.createToken(new HashMap<>(), (PrivateKey) keyStore.getKey(signatureKeyAlias, keyPassword));
            response = httpClient.newCall(new Request.Builder().
                    url(environment.urlOfPath(uri)).
                    header("JWTToken", token).
                    get().
                    build()
            ).execute();

            logger.info("Received status " + response.code());

            if (response.code() != 200) {
                //noinspection ConstantConditions
                throw new ApiBankingException(response.code(), response.message() + "/" + response.body().string());
            }
            return response;

        } catch (Exception e) {
            throw new ApiBankingException(e);
        }

    }

    public void performPost(String uri, RequestBody requestBody) {
        Response response;
        try {
            response = httpClient.newCall(new Request.Builder().
                    url(uri).
                    post(requestBody).
                    build()
            ).execute();
        } catch (Exception e) {
            throw new ApiBankingException(e);
        }

        logger.info("Received status " + response.code());

        if (response.code() != 200) {
            throw new ApiBankingException(response.code(), response.message());
        }

    }

    public static OkHttpClient.Builder safeHttpsBuilder(
            KeyStore keyStore,
            String clientCertPassword,
            OkHttpClient.Builder clientBuilder) throws NoSuchAlgorithmException, KeyManagementException {

        SSLContext sslContext = SSLContext.getInstance("TLS");

        KeyManager[] keyManagers = null;
        if (keyStore != null) {
            KeyManagerFactory kmf = KeyManagerFactory.getInstance("SunX509");
            try {
                kmf.init(keyStore, clientCertPassword.toCharArray());
            } catch (KeyStoreException | UnrecoverableKeyException e) {
                throw new RuntimeException(e.getMessage(), e);
            }
            keyManagers = kmf.getKeyManagers();
        }

        X509TrustManager x509TrustManager = null;
        TrustManagerFactory tmf = TrustManagerFactory.getInstance(TrustManagerFactory.getDefaultAlgorithm());
        try {
            tmf.init(keyStore);
        } catch (KeyStoreException e) {
            throw new RuntimeException(e.getMessage(), e);
        }
        for(TrustManager trustManager : tmf.getTrustManagers()) {
            if (trustManager instanceof X509TrustManager) {
                x509TrustManager = (X509TrustManager)trustManager;
            }
        }

        sslContext.init(keyManagers, null, null);
        //noinspection ConstantConditions
        clientBuilder.sslSocketFactory(sslContext.getSocketFactory(),x509TrustManager);

        HostnameVerifier hostnameVerifier = (hostname, session) -> true;

        clientBuilder.hostnameVerifier(hostnameVerifier);
        return clientBuilder;

    }
}
