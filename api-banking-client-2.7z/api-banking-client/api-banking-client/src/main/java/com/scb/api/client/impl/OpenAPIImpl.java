package com.scb.api.client.impl;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.scb.api.client.ApiBankingException;
import com.scb.api.client.OpenAPI;
import com.scb.api.client.model.OpenApiAccount;
import com.scb.api.client.util.HttpUtility;
import okhttp3.Response;

import java.io.IOException;
import java.util.Arrays;
import java.util.Collection;

public class OpenAPIImpl implements OpenAPI {

    private static final String URI_LIST_ACCOUNTS = "/scb/cib/account";

    private HttpUtility httpUtility;

    private ObjectMapper objectMapper = new ObjectMapper();

    OpenAPIImpl(HttpUtility httpUtility) {
        this.httpUtility = httpUtility;
    }

    @Override
    public Collection<OpenApiAccount> listAccounts() {
        Response response = httpUtility.performGet(URI_LIST_ACCOUNTS);
        try {
            //noinspection ConstantConditions
            return Arrays.asList(objectMapper.readValue(response.body().byteStream(), OpenApiAccount[].class));
        } catch (IOException e) {
            throw new ApiBankingException(e);
        }
    }

    @Override
    public Collection<String> paymentTypes() {
        Response response = httpUtility.performGet(URI_LIST_ACCOUNTS);
        try {
            //noinspection ConstantConditions
            return Arrays.asList(objectMapper.readValue(response.body().byteStream(), String[].class));
        } catch (IOException e) {
            throw new ApiBankingException(e);
        }
    }

}
