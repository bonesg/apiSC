package com.scb.api.client.impl;

import com.scb.api.client.*;
import com.scb.api.client.model.ActivationRequest;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.scb.api.client.util.EncryptDecrypt;
import com.scb.api.client.util.HttpUtility;
import com.scb.api.client.util.JWT;
import okhttp3.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.IOException;
import java.io.InputStream;
import java.security.*;
import java.util.Arrays;
import java.util.List;
import java.util.Map;

public class ApiBankingImpl implements ApiBanking {

    private static final Logger logger = LoggerFactory.getLogger(ApiBankingImpl.class);

    private final HttpUtility httpUtility;

    private OkHttpClient httpClient;
    private KeyStore keyStore;
    private char[] keyPassword;
    private ApiBankingEnvironment environment;
    private final String signatureKeyAlias;

    private ObjectMapper objectMapper = new ObjectMapper();

    public ApiBankingImpl(OkHttpClient httpClient, KeyStore keyStore, char[] keyPassword, String signatureKeyAlias, ApiBankingEnvironment environment) {
        this.httpClient = httpClient;
        this.keyStore = keyStore;
        this.keyPassword = keyPassword;
        this.environment = environment;
        this.signatureKeyAlias = signatureKeyAlias;
        this.httpUtility = new HttpUtility(httpClient, keyStore, signatureKeyAlias, keyPassword, environment);
    }

    @Override
    public void activate(InputStream inputStream, String webHookUrl) {

        logger.info("Invoking SCB API Banking Activation..");
        try {
            httpUtility.performPost(environment.urlOfPath(URI_ACTIVATE), constructActivationBody(inputStream,webHookUrl));
        } catch (IOException e) {
            throw new RuntimeException(e.getMessage(),e);
        }

    }

    @Override
    public List<Map<String, Object>> peek() throws IOException {
        logger.info("Invoking SCB API Banking PEEK..");
        Response response = httpUtility.performGet(URI_PEEK);
        //noinspection unchecked
        return Arrays.asList(objectMapper.readValue(response.body().byteStream(), Map[].class));
    }

    @Override
    public List<Map<String, Object>> consume() throws IOException {
        logger.info("Invoking SCB API Banking CONSUME..");
        Response response = httpUtility.performGet(URI_CONSUME);
        //noinspection unchecked
        return Arrays.asList(objectMapper.readValue(response.body().byteStream(), Map[].class));
    }

    @Override
    public List<Map<String, Object>> recover() throws IOException {
        logger.info("Invoking SCB API Banking RECOVER..");
        Response response = httpUtility.performGet(URI_RECOVER);
        //noinspection unchecked
        return Arrays.asList(objectMapper.readValue(response.body().byteStream(), Map[].class));
    }

    @Override
    public <T> T schema(Class<T> type) {
        if (type == OpenAPI.class) {
            return (T)new OpenAPIImpl(httpUtility);
        }
        if (type == UPI.class) {
            return (T)new UPIImpl(httpUtility);
        }
        return null;
    }

    private RequestBody constructActivationBody(InputStream inputStream, String webHookUrl) throws IOException {

        ObjectMapper om = new ObjectMapper();
        EncryptDecrypt.EncryptedContent activationKeyMap = om.readValue(inputStream,EncryptDecrypt.EncryptedContent.class);

        ActivationRequest request = new ActivationRequest(webHookUrl, "true", activationKeyMap );
        try {
            String token = JWT.createToken( request, (PrivateKey) keyStore.getKey(signatureKeyAlias, keyPassword));
            logger.info(token);
            return RequestBody.create( MediaType.parse("text/plain"),token);
        } catch (KeyStoreException | NoSuchAlgorithmException | UnrecoverableKeyException e) {
            throw new ApiBankingException(e);
        }

    }


}
