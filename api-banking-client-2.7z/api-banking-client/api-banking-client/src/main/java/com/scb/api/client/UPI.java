package com.scb.api.client;

public interface UPI {



}
