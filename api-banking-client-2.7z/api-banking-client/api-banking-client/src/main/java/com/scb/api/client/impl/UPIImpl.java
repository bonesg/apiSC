package com.scb.api.client.impl;

import com.scb.api.client.UPI;
import com.scb.api.client.util.HttpUtility;

public class UPIImpl implements UPI {

    private HttpUtility httpUtility;

    UPIImpl(HttpUtility httpUtility) {
        this.httpUtility = httpUtility;
    }


}
