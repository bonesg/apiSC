package com.scb.api.client;

import com.scb.api.client.impl.ApiBankingImpl;
import okhttp3.OkHttpClient;

import java.io.IOException;
import java.io.InputStream;
import java.net.Proxy;
import java.security.KeyManagementException;
import java.security.KeyStore;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;
import java.security.cert.CertificateException;
import java.util.concurrent.TimeUnit;

import static com.scb.api.client.util.HttpUtility.safeHttpsBuilder;

public class ApiBankingBuilder {

    private final ApiBankingEnvironment environment;
    private Proxy proxy;
    private KeyStore keystore;
    private char[] keystorePassword;
    private String signatureKeyAlias;

    public ApiBankingBuilder(ApiBankingEnvironment environment) {
        this.environment = environment;
    }

    public static ApiBankingBuilder $( ApiBankingEnvironment environment) {
        return new ApiBankingBuilder(environment);
    }

    public ApiBankingBuilder withProxy(Proxy proxy) {
        this.proxy = proxy;
        return this;
    }

    public ApiBankingBuilder withKeystore(KeyStore keystore, String keystorePassword) {
        this.keystore = keystore;
        this.keystorePassword = keystorePassword.toCharArray();
        return this;
    }

    public ApiBankingBuilder withKeystore(InputStream keystore, String keystorePassword) throws CertificateException, NoSuchAlgorithmException, IOException, KeyStoreException {
        this.keystore = KeyStore.getInstance("JKS");
        this.keystore.load(keystore, keystorePassword.toCharArray());
        this.keystorePassword = keystorePassword.toCharArray();
        return this;
    }

    public ApiBankingBuilder withSignatureAlias(String signatureKeyAlias) {
        this.signatureKeyAlias = signatureKeyAlias;
        return this;
    }

    public ApiBanking build() throws KeyManagementException, NoSuchAlgorithmException {

        return new ApiBankingImpl(
                safeHttpsBuilder(this.keystore, new String(this.keystorePassword),
                        new OkHttpClient.Builder().
                                proxy(proxy).
                                readTimeout(0, TimeUnit.MICROSECONDS).
                                connectTimeout(0, TimeUnit.MICROSECONDS).
                                writeTimeout(0, TimeUnit.MICROSECONDS)).build(),
                keystore,
                keystorePassword,
                signatureKeyAlias,
                environment
        );
    }

}
