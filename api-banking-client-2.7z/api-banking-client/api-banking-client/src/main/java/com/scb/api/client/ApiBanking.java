package com.scb.api.client;

import java.io.IOException;
import java.io.InputStream;
import java.util.List;
import java.util.Map;

public interface ApiBanking {


    String URI_ACTIVATE = "v1/activate";
    String URI_PEEK     = "core/event/peek";
    String URI_RECOVER  = "core/event/recover";
    String URI_CONSUME  = "core/event/consume";

    void activate(InputStream activationKey, String webHookUrl);

    List<Map<String,Object>> peek() throws IOException;
    List<Map<String,Object>> consume() throws IOException;
    List<Map<String,Object>> recover() throws IOException;

    <T> T schema(Class<T> type);

}
