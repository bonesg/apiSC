package com.scb.api.client.model;

import java.math.BigDecimal;
import java.time.LocalDate;

public class OpenApiAccountBalance {

    private String currency;
    private LocalDate asOf;
    private BigDecimal amount;
    private BigDecimal opening;
    private BigDecimal closing;

    public String getCurrency() {
        return currency;
    }

    public LocalDate getAsOf() {
        return asOf;
    }

    public BigDecimal getAmount() {
        return amount;
    }

    public BigDecimal getOpening() {
        return opening;
    }

    public BigDecimal getClosing() {
        return closing;
    }
}
