package ab.api.tests;

import cucumber.api.CucumberOptions;
import cucumber.api.junit.Cucumber;
import org.junit.runner.RunWith;

@RunWith(Cucumber.class)
@CucumberOptions(
        plugin = {"json:target/result.json"},
        features = {"classpath:api"},
        glue = {
        "classpath:ab.glue",
        },
        tags = {"@genie","~@ignore"},
        format = {"pretty","html:target/CucumberReports"},
        strict = true
)
public class apiTest {

}
