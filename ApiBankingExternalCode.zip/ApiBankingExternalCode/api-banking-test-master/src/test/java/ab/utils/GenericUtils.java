package ab.utils;

import ab.glue.api.PeekAndConsume;
import common.EncryptDecrypt;
import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.response.Response;
import org.apache.commons.io.IOUtils;

import javax.crypto.NoSuchPaddingException;
import java.io.*;
import java.math.BigDecimal;
import java.security.NoSuchAlgorithmException;
import java.security.PrivateKey;
import java.time.LocalDate;
import java.util.Map;

import static io.restassured.RestAssured.given;
import static io.restassured.config.JsonConfig.jsonConfig;
import static io.restassured.path.json.config.JsonPathConfig.NumberReturnType.*;

public class GenericUtils {
public static Response response1 = null;


    /**
     * This method will trim the value of the expected Peek/Consume/Recover response
     * @param value - The value to be trimmed
     * @return value - The value that is trimmed for the verification
     */
    public String peekConsumeTrim(String value){
        String data = "";
        String[] actualData = value.split("\"externalIdentifier\":\\{\"type\":\"Other\",\"identifier\":\"\"}");
        String finalData ="";
        for(int i =0; i<actualData.length-1;i++) {
            value = actualData[i] + "\"externalIdentifier\":{\"type\":\"Other\",\"identifier\":\"\"}}";
            data = value.split("identifier")[0] + "identifier" + "eventDate" + value.split("eventDate")[1].replaceAll("\\.000", "").replaceAll("\\.00", "");
            finalData = finalData + data.replaceAll(" ","");
        }
        return finalData+"]";
    }

    public int verifyNumberOfTransactions( String response, String groupID){
        int value = 0;
        String[] splitValue = response.split(groupID);
        value = splitValue.length - 1;
        return value;
    }

    /**
     *
     * @param headerMap - Map variable which has the HeaderTitles as Keys and HeaderValues as Values
     * @param body - String variable which represents the request body
     * @param endPoint - String variable which represents the URLendpoint to be hit by the POST request
     * @param contentType - ContentType variable which represents the content type of the request.
     * @return response1 - String variable which represents response to the POST request
     * @throws Throwable
     */
    public Response getPOSTResponse(Map<String, String> headerMap,String body, String endPoint, ContentType contentType) throws Throwable {
        //Hit the Post request with URL with the config and print the response
        response1 = given()
                .contentType(contentType)
                .headers(headerMap)
                .body(body)
                .when()
                .post(endPoint);
            System.out.println(response1.thenReturn().asString());
      return response1;
    }

    /**
     *
     * @param headerMap - Map variable with HeaderTitles as Keys and HeaderValue as Values
     * @param endPoint - String variable which is the URL endpoint for which the GET request is to be passed
     * @param contentType - ContentType variable which is the content type of the request
     * @return response1 - The response of the GET request will be returned as String variable.
     * @throws Throwable
     */
    public Response getGETResponse(Map<String, String> headerMap, String endPoint, ContentType contentType) throws Throwable {
        //Hit the GET request with URL with the config and print the response
        response1 = given()
                .contentType(contentType)
                .headers(headerMap)
//                .config(RestAssured.config().jsonConfig(jsonConfig().numberReturnType(FLOAT_AND_DOUBLE)))
                .when()
                .get(endPoint);
        System.out.println(response1.thenReturn().asString());
        return response1;
    }

//    /**
//     * The method will modify and trim the expected value that is to be verified with actual value.
//     * @param value - The value that is to trimmed
//     * @param group - The group ID value which is to be added to verification
//     * @param amount - The amount value which is to be added to verification
//     * @param accountNo - The account number value which is to be added for verification.
//     * @param trxType - The transaction type value which is to be added for verification.
//     * @return - The trimmed/modified data that is to be returned
//     */
//    public String expectedValueTrim(String value, String group, String amount, String accountNo,  String trxType){
//        String data = "";
//        double pretransaction = 99803990.00;
//        //data= multipleTransaction(amount,value);
//        //String[] transactions = data.split("]");
//        String[] amountArray = amount.split(",");
//        String[] accountNoArray = accountNo.split(",");
//        String[] groupArray = group.split(",");
//        String[] trxTypeArray = trxType.split(",");
//        String finaldata ="";
//        for(int i=0; i< amountArray.length;i++) {
//            data = value.split("identifier")[0] + "identifier" + "creditDate" + value.split("creditDate")[1].replaceAll("\\.00", "\"2");
//            data = data.split("groupId\":\"")[0] + "groupId\":\"" + groupArray[i] + "\",\"transactionIdentifier" + data.split("\",\"transactionIdentifier")[1];
//            data = data.split("\"accountId\"")[0] + "\"accountId\":\"" + accountNoArray[i] + "\",\"currencyCode\":{\"isoCode\"" + data.split("\",\"currencyCode\":\\{\"isoCode\"")[1];
//            if (trxTypeArray[i].equals("C")) {
//                trxType = "Credit";
//                pretransaction = pretransaction - Float.parseFloat(amountArray[i]);
//            } else {
//                trxType = "Debit";
//                pretransaction = pretransaction + Float.parseFloat(amountArray[i]);
//            }
//            BigDecimal b = new BigDecimal(pretransaction).setScale(2, BigDecimal.ROUND_HALF_EVEN);
//
//            data = data.split("adviceType")[0] + "adviceType\":\"" + trxType + "\",\"transactionCode" + data.split("\",\"transactionCode")[1];
//            data = data.split("\"preExecutionBalance\":\\{\"currencyCode\":\"INR\",\"amount\":")[0] + "\"preExecutionBalance\":{\"currencyCode\":\"INR\",\"amount\":" + b +"},\"transactionFreeText\"" + data.split("},\"transactionFreeText\"")[1];
//            data = data.split("transactionAmount\":\\{\"currencyCode\":\"INR\",\"amount\":")[0] + "transactionAmount\":{\"currencyCode\":\"INR\",\"amount\":" + amountArray[i] + "},\"clientIdentifier\":" + data.split("},\"clientIdentifier\":")[1];
//            finaldata = finaldata + data;
//        }
//        finaldata = finaldata.replaceAll("\\]\\[",",");
//        return finaldata;
//
//    }

    /**
     * The method will modify and trim the expected value that is to be verified with actual value.
     * @param value - The value that is to trimmed
     * @param group - The group ID value which is to be added to verification
     * @param amount - The amount value which is to be added to verification
     * @param accountNo - The account number value which is to be added for verification.
     * @param trxType - The transaction type value which is to be added for verification.
     * @return - The trimmed/modified data that is to be returned
     */
    public String expectedValueTrim(String value, String group, String amount, String accountNo,  String trxType) {
        String data = "";
        try {
        data = IOUtils.toString(new InputStreamReader(new FileInputStream("./src/test/resources/test-data/MessageFormat.json")));
        BigDecimal posttransaction = new BigDecimal(99803990.00);
        BigDecimal trxAmount = new BigDecimal(amount);
        BigDecimal pretransaction = posttransaction.add(trxAmount);
        //data= multipleTransaction(amount,value);
        //String[] transactions = data.split("]");
//        String[] amountArray = amount.split(",");
//        String[] accountNoArray = accountNo.split(",");
//        String[] groupArray = group.split(",");
//        String[] trxTypeArray = trxType.split(",");
        String finaldata = "";
        String eventDate = LocalDate.now().toString();


            if (trxType.equals("C")) {
                trxType = "Credit";
                pretransaction = posttransaction.subtract(trxAmount);
            } else {
                trxType = "Debit";
                pretransaction = posttransaction.add(trxAmount);
            }

            data = data.split("/EMAILSLOWNESS/\",\"")[0]+"/EMAILSLOWNESS/\",\""+"\"],\"transactionAmount\":"+data.split("/EMAILSLOWNESS/\",\"")[1].split("\"],\"transactionAmount\":")[1];
            data = data.split("/EMAILSLOWNESS/\",\"")[0]+"/EMAILSLOWNESS/\",\""+"\"],\"transactionAmount\":"+data.split("/EMAILSLOWNESS/\",\"")[1].split("\"],\"transactionAmount\":")[1];

            data = IOUtils.toString(new InputStreamReader(new FileInputStream("./src/test/resources/test-data/MessageFormat.json")));
            data = org.apache.commons.lang3.StringUtils.replace(data, "${groupId}", group);
            data = org.apache.commons.lang3.StringUtils.replace(data, "${trxType}", trxType);
            data = org.apache.commons.lang3.StringUtils.replace(data, "${accountNumber}", accountNo);
            data = org.apache.commons.lang3.StringUtils.replace(data, "${preTxnBalance}", "" + pretransaction);
            data = org.apache.commons.lang3.StringUtils.replace(data, "${txnAmount}", ""+trxAmount);
            data = org.apache.commons.lang3.StringUtils.replace(data, "${postTxnBalance}", ""+posttransaction);
            data = org.apache.commons.lang3.StringUtils.replace(data, "${eventDate}", eventDate);
            return data;
        } catch (IOException e) {
            e.printStackTrace();
        }
        return data;
    }
    public String multipleTransaction(String amount, String value){
        int counter = 0;
        if(amount.contains(",")){
            String[] trx = amount.split(",");
            counter = counter+trx.length;
        }
        for(int i=1;i<counter; i++) {
            value = value +value;
        }
        return value;
    }

    public static String readFile(String filename) {
        String data = "";
        try {
            BufferedReader bufferedReader = new BufferedReader(new InputStreamReader( new FileInputStream(filename)));
            StringBuilder stringBuilder = new StringBuilder();
            String line = bufferedReader.readLine();
            while (line != null) {
                stringBuilder.append(line);
                line = bufferedReader.readLine();
            }
            data = stringBuilder.toString();
        } catch (Exception exception) {
            exception.printStackTrace();
        }
        return data;
    }

    public String decryptResponse(Response response, String groupID) throws IOException, NoSuchPaddingException, NoSuchAlgorithmException {
        String responseString;
        String content = response.thenReturn().asString().split("\"content\":\"")[1].split("\"")[0];
        String key = response.thenReturn().asString().split("\"key\":\"")[1].split("\"")[0];
        common.EncryptDecrypt encryptDecrypt = new common.EncryptDecrypt();
        PrivateKey privatekey = encryptDecrypt.convertStringToPrivateKey(
                IOUtils.toString(PeekAndConsume.class.getClassLoader().getResourceAsStream(groupID+"private.txt")));
        responseString = encryptDecrypt.decryptWithPrivateKey(privatekey, new EncryptDecrypt.EncryptedContent(content, key));
        return responseString;
    }
}
