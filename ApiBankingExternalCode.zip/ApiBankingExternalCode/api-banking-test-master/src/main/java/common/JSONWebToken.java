package common;

import com.google.common.collect.ImmutableMap;
import com.google.common.collect.Maps;
import com.google.gson.Gson;
import com.google.gson.JsonObject;
import net.oauth.jsontoken.JsonToken;
import net.oauth.jsontoken.crypto.RsaSHA256Signer;
import org.joda.time.Instant;

import java.security.*;
import java.security.interfaces.RSAPrivateKey;
import java.security.spec.InvalidKeySpecException;
import java.security.spec.PKCS8EncodedKeySpec;
import java.util.Calendar;
import java.util.Map;
import java.util.TimeZone;

import static java.lang.System.currentTimeMillis;
import static javax.xml.bind.DatatypeConverter.parseBase64Binary;
import static org.joda.time.Instant.now;

public class JSONWebToken {

    private static final String ISSUER = "SCB";

    private static final String AUDIENCE = "SCB-APIBanking";

    //private static final long TOKEN_TIMEOUT_DURATION = 1000L * 60L * 5L;
    private static final long TOKEN_TIMEOUT_DURATION = 1000L * 30L;
    private JSONWebToken() { }

    public static void main(String args[]) throws InterruptedException, SignatureException, InvalidKeyException {
        Map<String,Object> activationRequest = Maps.newHashMap();
        //activationRequest.put("webHookUrl", "http://10.23.210.59:8443/webhook");
        //String endpoint = "EndPoint.POST_WEBHOOKURL_"+group;

        activationRequest.put("webHookUrl", "");
        activationRequest.put("enableWebHook", "true");
        activationRequest.put("activationKey",
                ImmutableMap.of("content", "uWyTht60ptKexjw5OIG4pdGn6Cp2mzXCQhF49RP8sQLvvBcO/2kJ2HDff3R51kN0nF8PC3uXgKfsXCD3n+oau0BwKLr6iobjIHVFKGLoK9echSIHeEesEhJ5LP8Z0XzVD6QXx3azi0Y4I5J/Z+75mQEXCVOTxkYDpnjtJs8LCk6XB5/sesdcXC2gLt+jzvQnuSl3jC40FogBWbCuClIhJfQYNRMrVeqvHVVzRlUplwMwhw9plPjxJgE15vEi7hZVFrNt6Buo0ZwHfJUbyf08lfJF/Yl/FTc7ShcJr9t95lqbSzzQPx0/UKYJNoa0mP0t68Rwu5N71gdaxh4DLMwTFSvKK74FvEuQxFig4iATsHzu4nmx0261xdhptfKOjj42jd1ubh0EgyxBMkHlXTrUmIhlEuvBy8vDIYUvUpctdQOkG3gmazbaudw8IEr7IGG45cgezfUCnpO1mzOipHNfM4IKQQmKCV95VK2mw+5B8WlaCjs2q47NAsmDwxzTfwTCGZQZoRThHweEWjnTs+NoYAweMTUy82FNXap8J8v7GALaqBct9QRNwmKF0sQDz0g4848vhNmHzOIxrOLCkZzg55Yk0/s/aDTT/l2F/oMP5pFD6vb7DyS+PyOL2EPQDNeqayhJ42B94rlq/vF92ddPRTJEqmWMspCi0glSQYuRkp33D+RQ0NYm11jy7hSzhXetHWWjTIwq0DLfN79gKTqcJOMVMP9URoGl3nhSirwGCZQUgVc87j7NQPPcvKS8LA+/EC+NSnBPGEe0g3gPqrdAP2a9jcpzUgXf3LQujOzMmbdzj8gN68/K4URTVvT1Rnpa", "key", "e+3eloQT9+SJoYC1FHkq1Hz2Q+QcyR0+COzKWlc9li9Q2+K75c0GdODAfKR8fGiP+RkE2z6KxFRvIMsdazbxqQGqZi0npqpq6UHTvEtSQPCdEywNRaUbbLE79Cs841liyptfiNPSBgG/wBWtBJjOdLvP0ahU1ebcSTZh2eFcISAk/OOZHMIMueS+Aua6bQDLMbIcMJyoa2GJrkmcurKbXtLSOw5sVlY+qLMdCWNUJxyVZwtjtMGEQzGa35YQN8/NgWPBMgOTqoKBUbpQ0NKpq4oesknwbmjM7LoUuMmKjrl5dQJurASTvJsh4VrrFRIUS5jjRWnZ7RLroBCFgS6fSQ=="));

        PKCS8EncodedKeySpec spec = new PKCS8EncodedKeySpec(parseBase64Binary("MIIEwAIBADANBgkqhkiG9w0BAQEFAASCBKowggSmAgEAAoIBAQDDh0NgdL8+KA1S\n" +
                "SW5XXjgcNivncV0ucWAzTzYkcoHBEaV3mr+c1h6x6NT0LgLYADGNs5Qx+zgDhfBq\n" +
                "w5rNT1ghjSGnCmAKVmEzLBSChqtP1pxJB8mfpIQE8e8ZLgtmhr7w28w6VidLSwJ7\n" +
                "z1ZWm+d5Nw0mFjv/wK+PIMrWUmRAT+R+XpEkBHyuxbJd+M2GpWnJtIeZZh+zqjI7\n" +
                "bh68EjCd+7gWrAXv5PG/j5hl5jplSB92BI31PCG5XUBkxdGX+6eW+QDbcO8ZvdzG\n" +
                "FPq9KADRQtbnim+Nw3YdZQlNFPYEXHAD/43F3wx0ILQZLRQKwlnan5I8rrb8uzYD\n" +
                "1/0GTnY3AgMBAAECggEBAJzkbZj5NPeAFehgSazLSoTApwwId/erO8EQH2axhxJP\n" +
                "wZEuV/BWE704EaB5RwjhZuHIJfLRHQoesGJK4G077IDHiShK9/Nzin0QMsjlnJLs\n" +
                "pu0m1Y9G6DQ7mVqACt/S4WXNSJvKw67z2mNUZHgMk3k9Rky4bJ50k6pqarf81rqO\n" +
                "uaqdqnfid8rn8g89kLBtpNS/dKk/tIyPU0L2lAXF06Zn/x/u1JoqDWiSKOQqPOqo\n" +
                "s7D5ZJGflXILyE4dITs5iAk887SluI7e4qzzAG+LieSZfBYgzh5uhC1Taq2vJSt7\n" +
                "CMDmOPHzkfsi5HpP+6Gf89PzIvSr+kL4hEA1DLNiFZECgYEA5OPkssu8uS7x8oV5\n" +
                "OwEMDWi3X1RPR1hy3ZYEHBHCuMbJB/1meKgkU/Sq93SLzRmzKk6ZcO0DrDJgrf9v\n" +
                "sgl3aYeVpGN6Chp6HpL4BAdanrA77VDpv0yndoTUnTHd67ay+j7PtmhSf1q4SZvN\n" +
                "dVGNHouvoPria9/rm1F/VSRk/SkCgYEA2q/Q9/VOi+nMN/S8OsEncM24zo6CLHOs\n" +
                "mEmNq2NKRFRyYTxHUP+TDYXOiO5+uSfchu53QHoSEtet9G97/Z/I8ykIkOyx8QEA\n" +
                "GQUqHFLQYURFN1qKfRgVJWDTfEwVA0VP56fMUq8SrtJ5ne9guu+nsZM0AQzWiUiZ\n" +
                "zjoi40f85F8CgYEAuRDeMAZ1MBGaBKoQzDlbglgBs+1aMGh+b1VFO2DM3VO05WXo\n" +
                "fXQN82fm+C9efdXivDlS7TBmAMu2ydi3ee8XgtbikkjwOs0PojrYl4FOrvH1cjsy\n" +
                "077pw/VAZ10Tfut4qMcycNzGnzw9tx5nMA1hGap9tZ5Ehk5FlI5/ctr7YIkCgYEA\n" +
                "kajxw3b9Lmw3vj2g8nGdV6FvKwX45qrVl0nGtxWXbhPha6q+xdC1nhg2DTbt6V4H\n" +
                "oUhM3gFw8GQAVgO7zp8TNgNq1T0S+Lf13LR37A2tBlx2zfvcqp3T1+W6d9wlUtxj\n" +
                "8KTvj1NVWmSO5QeAooLma3zk8p4ed6qH57kJa+GTLHkCgYEAvIld1ggwWbExRkxV\n" +
                "Zu+FNqENg0oTphHV/bI/0GPna/bcBQpA343llZtkBZHrJM1gjZYfKsdEwONamSyA\n" +
                "2v0peW4SnlV9UP4VlG+3lG77FQJi75idiCBq+SwKjZZ9ojJddRcmQyVoUSqsztfg\n" +
                "QQXJPv+JOBQAMRmQlewAxK45Ouk="));
        PrivateKey pk =null;
        try {
            KeyFactory kf = KeyFactory.getInstance("RSA");
            pk = kf.generatePrivate(spec);
        } catch (NoSuchAlgorithmException | InvalidKeySpecException ex) {
            throw new RuntimeException(ex.getMessage(),ex);
        }

    String token = createToken(activationRequest,pk);
        System.out.println("Token is "+token);
    }

    public static <T> String createToken(T payload, PrivateKey privateKey) throws SignatureException, InvalidKeyException, InterruptedException {

        RsaSHA256Signer signer;
        signer = new RsaSHA256Signer(ISSUER, null, (RSAPrivateKey) privateKey);

        //Configure JSON token
        JsonToken token = new JsonToken(signer);
        //Calendar cal = Calendar.getInstance(TimeZone.getTimeZone("GMT"));
        token.setAudience(AUDIENCE);

        //token.setIssuedAt(now().minus(60*100));
        //token.setExpiration(now().minus(60*100).plus(TOKEN_TIMEOUT_DURATION));

        //token.setIssuedAt(now().minus(239*100));
        //token.setExpiration(now().minus(239*100).plus(TOKEN_TIMEOUT_DURATION));
        token.setIssuedAt(now());
        token.setExpiration(new Instant(currentTimeMillis() + TOKEN_TIMEOUT_DURATION));
        //Configure request object, which provides information of the item
        JsonObject payloadO = token.getPayloadAsJsonObject();
        payloadO.add("payload", new Gson().toJsonTree(payload));
        return token.serializeAndSign();
    }
}
