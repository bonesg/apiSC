package ab.utils;

import com.fasterxml.jackson.annotation.JsonProperty;


public class ActivationBody implements java.io.Serializable {
    private static final long serialVersionUID = -7661581056581835202L;
    @JsonProperty("ActivationKeyBody")
    private ab.utils.ActivationKeyBody ActivationKeyBody;
    @JsonProperty("ActivationKeyBody")

    public ab.utils.ActivationKeyBody getActivationKeyBody() {
        return this.ActivationKeyBody;
    }
    @JsonProperty("ActivationKeyBody")
    public void setActivationKeyBody(ab.utils.ActivationKeyBody ActivationKeyBody) {
        this.ActivationKeyBody = ActivationKeyBody;
    }
}
