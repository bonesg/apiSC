package ab.glue.api;

import ab.common.JWTTest;
import ab.utils.GenericUtils;
import cucumber.api.DataTable;
import cucumber.api.PendingException;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.response.Response;
import org.apache.commons.lang3.StringUtils;
import org.junit.Assert;
import org.w3c.dom.Document;
import org.w3c.dom.Node;
import org.xml.sax.InputSource;

import javax.crypto.NoSuchPaddingException;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.xpath.XPath;
import javax.xml.xpath.XPathFactory;
import javax.xml.xpath.XPathFactoryConfigurationException;
import java.io.*;
import java.security.KeyStore;
import java.security.NoSuchAlgorithmException;
import java.text.SimpleDateFormat;
import java.util.*;

import static net.sf.saxon.lib.NamespaceConstant.OBJECT_MODEL_SAXON;

/**
 * Created by 1571168 on 12/20/2017.
 */
public class AccountBalanceEnquiry {


    GenericUtils genericUtils = new GenericUtils();
    activationKey activationKey = new activationKey();
    public static Response response;
    public static String responseString;
    public static boolean responseEncrypted;

    @Given("^the user hits the account balance inquiry with an account number '(.*)'$")
    public void getAccountBalanceUsingAccountNumber(String accNo) throws IOException, ParserConfigurationException {
        String filepath = new File(".").getCanonicalPath() + "/src/test/resources/rta-template.xml";
        DocumentBuilderFactory docFactory = DocumentBuilderFactory.newInstance();
        DocumentBuilder docBuilder = docFactory.newDocumentBuilder();
        NewStub newStub = new NewStub();
        String request = newStub.readFile(filepath);
        InputSource source = new InputSource(new ByteArrayInputStream(request.getBytes()));
//        ReqBalEnqType reqBalEnqType = new ReqBalEnqType();
//        HeadType head = new HeadType();
//        head.setMsgId("abcd123");
//        head.setOrgId("org123");
//        head.setTs("TS");
//        head.setValue("V");
//        head.setVer(new Float(1.0));
//        PayerType payerType = new PayerType();
//        payerType.setAddr("addr 1");
//        AcType acType = new AcType();
//        acType.setAddrType("ACCOUNT");
//
//        DetailType detailType = new DetailType();
//        detailType.setName("ACTYPE");
//        detailType.setValue("SAVINGS");
//        detailType.setName("ACNUM");
//        detailType.setValue(accNo);
//        acType.getDetail().add(detailType);
//        payerType.getAc().add(acType);
//
//        payerType.setName("Name");
//        payerType.setSeqNum("12345465");
//        payerType.setType("PERSON");
//        payerType.setCode("code");
//        InfoType info = new InfoType();
//        IdentityType identityType = new IdentityType();
//        identityType.setType("ACCOUNT");
//        identityType.setVerifiedName("TRUE");
//        info.setIdentity(identityType);
//        TxnType txnType = new TxnType();
//        txnType.setId("97977897");
//        txnType.setNote("note");
//        txnType.setTs("TS");
//        txnType.setType(TxnTypeValues.PAY);
//        reqBalEnqType.setHead(head);
//        reqBalEnqType.setPayer(payerType);
//        reqBalEnqType.setTxn(txnType);
//        String value = reqBalEnqType.toString();
//        Request request = new Request.Builder()
//                .url("/upi/v1/meta/balance-enquiry")
//                .header("", "")
//                .post(requestBody)
//                .build();
        throw new PendingException();
    }

    @Then("^the user should be able to see response with the details$")
    public void verifyResponse(DataTable dataTable) throws IOException, ParserConfigurationException {
        // Write code here that turns the phrase above into concrete actions
        String accountNum = dataTable.asLists(Object.class).get(1).get(0).toString();
        String amount = dataTable.asLists(Object.class).get(1).get(1).toString();
        KeyStore keyStore = null;
        String data = null;
        Iterator iterator = dataTable.asLists(Object.class).get(1).iterator();
        String accountNumber = "empty";
        String certificate = "empty";
        String token = "empty";
        String contentType = "empty";
        String groupID = "";
        String country = "";
        String currency = "";
        String accountType = "";
        String accountBalance = "";
        int statusCode = 0;
        if (iterator.hasNext())
            statusCode = (int) iterator.next();
        if (iterator.hasNext())
            accountNumber = (String) iterator.next();
        if (iterator.hasNext())
            groupID = (String) iterator.next();
        if (iterator.hasNext())
            country = (String) iterator.next();
        if (iterator.hasNext())
            currency = (String) iterator.next();
        if (iterator.hasNext())
            accountType = (String) iterator.next();
        if (iterator.hasNext())
            accountBalance = (String) iterator.next();
        RestAssured.useRelaxedHTTPSValidation();
        Map<String, String> headerMap = new HashMap<String, String>();
        SimpleDateFormat dateFormatGmt = new SimpleDateFormat("yyyy-MMM-dd HH:mm:ss");
        dateFormatGmt.setTimeZone(TimeZone.getTimeZone("GMT"));
        SimpleDateFormat dateFormatLocal = new SimpleDateFormat("yyyy-MMM-dd HH:mm:ss");

        try {
            Date date = dateFormatLocal.parse( dateFormatGmt.format(new Date()) );
            String responseValue = responseEncrypted ? responseString :response.thenReturn().asString();

            byte[] responseBytes = response.thenReturn().asString().getBytes();
            InputSource source = new InputSource(new ByteArrayInputStream(responseBytes));
            Assert.assertTrue("", response.getStatusCode()==statusCode);
            Assert.assertTrue("", responseString.contains("" + country));
            Assert.assertTrue("",  xPath.evaluate("//*:Payer/*:Amount/@curr", source).equals("" + currency));
            Assert.assertTrue("", responseString.contains("" + accountType));
            Assert.assertTrue("", responseString.contains("" + groupID));
            Assert.assertTrue("", xPath.evaluate("//*:Payer/*:Bal/*:Data/text()", source).equals("" + accountBalance));
            Assert.assertTrue("", responseString.contains("" + date));
        } catch (Throwable throwable) {
            throwable.printStackTrace();
        }
        throw new PendingException();
    }

    static XPathFactory factory;
    static XPath xPath;

    static {
        try {
            factory = XPathFactory.newInstance(OBJECT_MODEL_SAXON);
            xPath=factory.newXPath();
        } catch (XPathFactoryConfigurationException e) {
            throw new RuntimeException(e.getMessage(),e);
        }
    }
    @Then("^the user should be able to see status code as '(\\d+)' with the details$")
    public void verifyResponse(Integer arg0, DataTable dataTable) throws IOException, ParserConfigurationException {
        // Write code here that turns the phrase above into concrete actions

        String filepath = new File(".").getCanonicalPath() + "/src/test/resources/rta-template.xml";
        DocumentBuilderFactory docFactory = DocumentBuilderFactory.newInstance();
        DocumentBuilder docBuilder = docFactory.newDocumentBuilder();
        NewStub newStub = new NewStub();
        String request = newStub.readFile(filepath);
        InputSource source = new InputSource(new ByteArrayInputStream(request.getBytes()));
        String accountNum = dataTable.asLists(Object.class).get(1).get(0).toString();
        String amount = dataTable.asLists(Object.class).get(1).get(1).toString();
        KeyStore keyStore = null;
        String data = null;
        Iterator iterator = dataTable.asLists(Object.class).get(1).iterator();
        String accountNumber = "empty";
        String certificate = "empty";
        String token = "empty";
        String contentType = "empty";
        String groupID = "";
        String country = "";
        String currency = "";
        String accountType = "";
        String accountBalance = "";
        if (iterator.hasNext())
            accountNumber = (String) iterator.next();
        if (iterator.hasNext())
            groupID = (String) iterator.next();
        if (iterator.hasNext())
            country = (String) iterator.next();
        if (iterator.hasNext())
            currency = (String) iterator.next();
        if (iterator.hasNext())
            accountType = (String) iterator.next();
        if (iterator.hasNext())
            accountBalance = (String) iterator.next();
        RestAssured.useRelaxedHTTPSValidation();
        Map<String, String> headerMap = new HashMap<String, String>();
        SimpleDateFormat dateFormatGmt = new SimpleDateFormat("yyyy-MMM-dd HH:mm:ss");
        dateFormatGmt.setTimeZone(TimeZone.getTimeZone("GMT"));
        SimpleDateFormat dateFormatLocal = new SimpleDateFormat("yyyy-MMM-dd HH:mm:ss");

        try {
            Date date = dateFormatLocal.parse( dateFormatGmt.format(new Date()) );
            Response response1 = genericUtils.getPOSTResponse(headerMap, ".xml", "/ReqBalEnq", ContentType.XML);
            String response = response1.thenReturn().toString();
            Assert.assertTrue("", response1.getStatusCode()==arg0);
            Assert.assertTrue("", response.contains("" + country));
            Assert.assertTrue("", response.contains("" + currency));
            Assert.assertTrue("", response.contains("" + accountType));
            Assert.assertTrue("", response.contains("" + groupID));
            Assert.assertTrue("", response.contains("" + accountBalance));
            Assert.assertTrue("", response.contains("" + date));
        } catch (Throwable throwable) {
            throwable.printStackTrace();
        }
        throw new PendingException();
    }

    @Then("^the user hits the account balance inquiry to get encrypted data with the details$")
    public void getAccountBalanceWithEncryption(DataTable dataTable) {
        try {
            responseEncrypted = true;
            getAccountBalance (dataTable);
                   } catch (Throwable throwable) {
            throwable.printStackTrace();
        }
        throw new PendingException();
    }

    @Then("^the user hits the account balance inquiry with details$")
           public void getAccountBalance (DataTable dataTable) {
        // Write code here that turns the phrase above into concrete actions
        try {
            String filepath = new File(".").getCanonicalPath() + "/src/test/resources/test-data/UPI_AccountBalanceEnquiry.xml";
            DocumentBuilderFactory docFactory = DocumentBuilderFactory.newInstance();
            DocumentBuilder docBuilder = docFactory.newDocumentBuilder();
            NewStub newStub = new NewStub();
            String request = newStub.readFile(filepath);
            InputSource source = new InputSource(new ByteArrayInputStream(request.getBytes()));
            Document doc = docBuilder.parse(filepath);
            Node payer = doc.getElementsByTagName("Payer").item(0);
            KeyStore keyStore = null;
            String data = null;

            RestAssured.useRelaxedHTTPSValidation();
            Map<String, String> headerMap = new HashMap<String, String>();
            Iterator iterator = dataTable.asLists(Object.class).get(1).iterator();
            String accountNumber = "empty";
            String certificate = "empty";
            String token = "empty";
            String content = "empty";
            String groupID = "";
            String country = "";
            String currency = "";
            String accountType = "";
            FileInputStream input = new FileInputStream(new File(".\\src\\test\\resources\\test-data\\activationKeyRequest.properties"));
            Properties prop = new Properties();
            prop.load(input);
            if (iterator.hasNext()) {
                accountNumber = (String) iterator.next();
                request = StringUtils.replace(request, "${accountNumber}", accountNumber);
            }
            if (iterator.hasNext())
                groupID = (String) iterator.next();
            if (iterator.hasNext())
                country = (String) iterator.next();
            if (iterator.hasNext())
                currency = (String) iterator.next();
            if (iterator.hasNext())
                accountType = (String) iterator.next();
            if (iterator.hasNext())
                content = (String) iterator.next();
            if (iterator.hasNext()) {
                token = (String) iterator.next();
                if (token.equals("Valid Token")) {
                    //String content = null;
                    //activationKey.a_POST_request_is_made_to_the_activationKey_API_for_Group(groupID);
                    //activationKey.activKey.put(groupID,token);
                    String activKey =  activationKey.getActivationKey(groupID,prop);
                    String[] parts = activKey.split("\"");
                    token = JWTTest.createTokenForGroup(parts[5], parts[9], groupID);
                }
            }
            if (certificate.equals("empty") || certificate.equals("Valid Cert"))
                certificate = prop.getProperty(groupID + "_Certificate");
            if (token.equals("empty"))
                token = "";
            ContentType contentType = ContentType.XML;
            //2) pass to doPost function & put response into responses list

            if(content.equals("JSON"))
                contentType = ContentType.JSON;
            else if(content.equals("TEXT"))
                contentType = ContentType.TEXT;
            else if(content.equals("HTML"))
                contentType = ContentType.HTML;
            else if(content.equals("BINARY"))
                contentType = ContentType.BINARY;
            else
                contentType = ContentType.XML;
            //headerMap.put("ResponseEncryptionType","AES256Signed");
            //headerMap.put("X-Client-Certifcate","MIIFPDCCBCSgAwIBAgIQBhCY9/Oua9sbbZUiKb7/ETANBgkqhkiG9w0BAQsFADBlMQswCQYDVQQGEwJVUzEVMBMGA1UEChMMRGlnaUNlcnQgSW5jMRkwFwYDVQQLExB3d3cuZGlnaWNlcnQuY29tMSQwIgYDVQQDExtEaWdpQ2VydCBTSEEyIEFzc3VyZWQgSUQgQ0EwHhcNMTcwNTIzMDAwMDAwWhcNMTgwNTIzMTIwMDAwWjBXMQswCQYDVQQGEwJTRzESMBAGA1UEBxMJU2luZ2Fwb3JlMSAwHgYDVQQKExdTdGFuZGFyZCBDaGFydGVyZWQgQmFuazESMBAGA1UEAxMJQWNtZSBDb3JwMIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAx+79CIYpTbQdM93rnQe2y+gMCAZGKfwVuyT4xjYDmYfKr4+/6F2OUoVAP0wsS+EufaFOdwGRYD2Xcg8fH/jwp4dynekLNmO94et7pDBIQoHoyqUz5IfYIhbkwUV5zAjJEfrAlLXEfrBB+j8v6/DMWcYoFvXvq2mA/rZCr5S5L7RCKj17Tup6OpRasbohHADLwLx/gk/gaX7fAzV/4jETHw1zxRg9jT8WaPp+Qs3KeQlXqDEX6vpH12flHDl1dF+QfuKN5jlKG77yKsThglYwRTeaxrL3RgU8X6P8T1S5xpzGCIlE7RHFTpta1Hxn3oD59AvhQkQ8CkYyOWzt6GS6uQIDAQABo4IB9DCCAfAwHwYDVR0jBBgwFoAU5wIjgABP2Ne8lAvZP3Q5STI8inkwHQYDVR0OBBYEFIzxOlIwI/C/ktPcOkYtZA1XWTKrMAwGA1UdEwEB/wQCMAAwJgYDVR0RBB8wHYEbcHJhc2FubmEua2FuYWdhc2FiYWlAc2MuY29tMA4GA1UdDwEB/wQEAwIFoDAdBgNVHSUEFjAUBggrBgEFBQcDAgYIKwYBBQUHAwQwQwYDVR0gBDwwOjA4BgpghkgBhv1sBAECMCowKAYIKwYBBQUHAgEWHGh0dHBzOi8vd3d3LmRpZ2ljZXJ0LmNvbS9DUFMwgYgGA1UdHwSBgDB+MD2gO6A5hjdodHRwOi8vY3JsMy5kaWdpY2VydC5jb20vRGlnaUNlcnRTSEEyQXNzdXJlZElEQ0EtZzIuY3JsMD2gO6A5hjdodHRwOi8vY3JsNC5kaWdpY2VydC5jb20vRGlnaUNlcnRTSEEyQXNzdXJlZElEQ0EtZzIuY3JsMHkGCCsGAQUFBwEBBG0wazAkBggrBgEFBQcwAYYYaHR0cDovL29jc3AuZGlnaWNlcnQuY29tMEMGCCsGAQUFBzAChjdodHRwOi8vY2FjZXJ0cy5kaWdpY2VydC5jb20vRGlnaUNlcnRTSEEyQXNzdXJlZElEQ0EuY3J0MA0GCSqGSIb3DQEBCwUAA4IBAQCuOYPuakKB9qCCR7JYaA+92BprzqYFd1LwT62FrdzcPGupHix7ALoiw2jHuMQogrc3Rw0wZPUqgN29b2bcXX8r9B8OMVbxYL6VZGJ8P+WndUPOzbWdl7eAY/9HbkAUgcqzSP+BBcndCyKdR+bs43dYDNvhDzqL7hHgqjmxFxVz8C/25oLmBZ0yOXz5yLpVoTyHBl1OfAkrYj5WeQI8/uiR9bJ4SwY/NvUU+sOB/UJsxECjpmmdS26dYMRyLuFT7hZvmgv8L2wcjO6vyA9qm3kNb0dTJw1/xQG56pdaGRhdVEqp/L3/hW0COgQvOVdRNlVH9dU8cCl57ICj9rtxTrqg");
            //headerMap.put("JWTToken", "");
            //headerMap.put("X-Client-Certifcate", "");
            if(responseEncrypted)
                headerMap.put("ResponseEncryptionType", "AES256Signed");
            response = genericUtils.getPOSTResponse(headerMap, request, "/ReqBalEnq", contentType);
            Assert.assertTrue("The Account Balance enquiry should be displayed with the balance with account number as " + "" + accountNumber + ". But it is displayed as " + response.thenReturn().asString(), response.thenReturn().asString().contains("" + accountNumber));
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        } catch (Throwable throwable) {
            throwable.printStackTrace();
        }
        throw new PendingException();
    }

    @Then("^the user should be able to see error message '(.+)' with status code as '(\\d+)'$")
    public void verifyErrorMessage(String error, Integer expectedStatusCode){
        // Write code here that turns the phrase above into concrete actions
        int actualStatusCode =response.getStatusCode();
        String actualErrorMessage = response.thenReturn().asString();
        commonApiMethods commonApiMethods = new commonApiMethods();
        String expectedErrorMessage = commonApiMethods.errorMessageProperties.get(error).toString();
        Assert.assertTrue("Status code of the response should be displayed as "+expectedStatusCode+". But it is getting displayed as "+actualStatusCode,expectedStatusCode==actualStatusCode);
        Assert.assertTrue("The expected error message is "+expectedErrorMessage+". But actual error message is displayed as "+response.thenReturn().asString(), response.thenReturn().asString().contains(expectedErrorMessage));
        throw new PendingException();
    }

    @Then("^the user should be able to see status code as '(\\d+)' with the below details when decrypting with correct private key$")
            public void verifyDecryptionWithValidPrivateKey(Integer arg0,DataTable dataTable) throws NoSuchPaddingException, NoSuchAlgorithmException, IOException, ParserConfigurationException {
        // Write code here that turns the phrase above into concrete actions
        responseEncrypted=true;
        responseString = genericUtils.decryptResponse(response,dataTable.asLists(String.class).get(1).get(2).toString());
        verifyResponse(dataTable);
        throw new PendingException();
    }
    @Then("^the user should be able to see error message when decrypting with private key of group '(.*)'$")
            public void verifyDecryptionErrorWithInvalidData(String groupID) throws NoSuchPaddingException, NoSuchAlgorithmException, IOException {
        responseEncrypted=true;
        responseString = genericUtils.decryptResponse(response,groupID);
        Assert.assertTrue("", responseString.equals("Encryption error"));
        throw new PendingException();
    }

}
