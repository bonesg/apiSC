package ab.glue.api;

import ab.common.PeekAndConsumeConfig;
import ab.utils.ExcelReader;
import com.webmethods.jms.WmTopic;
import com.webmethods.jms.impl.WmConnectionFactoryImpl;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import org.junit.Assert;
import org.springframework.util.ResourceUtils;
import org.w3c.dom.Document;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

import javax.jms.*;
import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerConfigurationException;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import java.io.*;
import java.util.ArrayList;
import java.util.Properties;


public class NewStub {

    static String[] arrayValue = null;
    public static void main(String[] args) {
        sendFspMessage();
    }

    public static void sendFspMessage() {
        Connection connection = null;
        String contextFactory = "com.webmethods.jms.naming.WmJmsNamingCtxFactory";
        String JNDIUrl = "wmjmsnaming://@10.20.160.24:6661/EDMIFramework";
        String clientGroup = "admin";

        String connectionFactory = "CoreBanking_API_ConnectionFactory";
        String topicName = "scbCoreBankingTxnAlertCorpFinTxnNotifyV1T";
        Context namingContext = null;

        try {
            Properties env = new Properties();
            env.setProperty("java.naming.factory.initial", contextFactory);
            env.setProperty("java.naming.provider.url", JNDIUrl);
            env.setProperty("com.webmethods.jms.naming.clientgroup", clientGroup);
            env.setProperty("com.webmethods.jms.clientIDSharing", "true");
            System.setProperty("com.webmethods.jms.clientIDSharing", "true");

            namingContext = new InitialContext(env);

            WmConnectionFactoryImpl wmConnectionFactory = (WmConnectionFactoryImpl) namingContext.lookup(connectionFactory);
            File trustStoreResource = ResourceUtils.getFile("" +
                    "classpath:edmicorebankingtruststore.jks");
            wmConnectionFactory.setSSLTruststore(trustStoreResource.toString());

            connection = wmConnectionFactory.createConnection("ccsuser", "abc12345");

            System.out.println("Connection created " + connection.toString());
            Session session = connection.createSession(false, Session.AUTO_ACKNOWLEDGE);
            WmTopic dest = (WmTopic) namingContext.lookup(topicName);
            MessageProducer producer = session.createProducer(dest);
            TextMessage message = session.createTextMessage();

            String request = readFile("rta-template.xml");
            System.out.println("Sending Message " + request);
            message.setText(request);
            producer.send(message);
            System.out.println("Message Sent Successfully");

        } catch (Exception e) {
            System.out.println(e.toString());
        } finally {
            if (connection != null)
                try {
                    connection.close();
                    System.out.println("Connection Terminated");
                } catch (JMSException e) {
                    e.printStackTrace();
                }
        }
    }

    public static String readFile(String filename) {
        String data = "";
        try {
            BufferedReader bufferedReader = new BufferedReader(new InputStreamReader( new FileInputStream(filename)));
            StringBuilder stringBuilder = new StringBuilder();
            String line = bufferedReader.readLine();
            while (line != null) {
                stringBuilder.append(line);
                line = bufferedReader.readLine();
            }
            data = stringBuilder.toString();
        } catch (Exception exception) {
            exception.printStackTrace();
        }
        return data;
    }

    @Then("^user should see transaction code accordingly in the Consume response$")
    public void user_modifies_Stub_country_IN_transaction_system_EBBS_transaction_code()throws IOException, ParserConfigurationException, SAXException, TransformerConfigurationException {
        try {
            Connection connection = null;
            String contextFactory = "com.webmethods.jms.naming.WmJmsNamingCtxFactory";
            String JNDIUrl = "wmjmsnaming://@10.20.160.24:6661/EDMIFramework";
            String clientGroup = "admin";
            String connectionFactory = "CoreBanking_API_ConnectionFactory";
            String topicName = "scbCoreBankingTxnAlertCorpFinTxnNotifyV1T";
            Context namingContext = null;
                Properties env = new Properties();
                env.setProperty("java.naming.factory.initial", contextFactory);
                env.setProperty("java.naming.provider.url", JNDIUrl);
                env.setProperty("com.webmethods.jms.naming.clientgroup", clientGroup);
                env.setProperty("com.webmethods.jms.clientIDSharing", "true");
                System.setProperty("com.webmethods.jms.clientIDSharing", "true");
                namingContext = new InitialContext(env);
                WmConnectionFactoryImpl wmConnectionFactory = (WmConnectionFactoryImpl) namingContext.lookup(connectionFactory);
                File trustStoreResource = ResourceUtils.getFile("" +
                        "classpath:edmicorebankingtruststore.jks");
                wmConnectionFactory.setSSLTruststore(trustStoreResource.toString());
                connection = wmConnectionFactory.createConnection("ccsuser", "abc12345");
                System.out.println("Connection created " + connection.toString());
                Session session = connection.createSession(false, Session.AUTO_ACKNOWLEDGE);
                WmTopic dest = (WmTopic) namingContext.lookup(topicName);
                MessageProducer producer = session.createProducer(dest);
                TextMessage message = session.createTextMessage();
            //HashMap<String, String> data = ExcelReader.getExcelData();
            //data.entrySet();
            ArrayList<String> data = ExcelReader.getExcelData();
            for(String value : data) {
                arrayValue = value.split("\\|");
                String filepath = new File(".").getCanonicalPath() + "/src/test/resources/rta-template.xml";
                DocumentBuilderFactory docFactory = DocumentBuilderFactory.newInstance();
                DocumentBuilder docBuilder = docFactory.newDocumentBuilder();
                System.out.println(filepath);
                Document doc = docBuilder.parse(filepath);
                System.out.println(doc);
                Node staff = doc.getElementsByTagName("notifyCorporateFinancialTransactionRequest").item(0);
                System.out.println(staff);
                NodeList list = staff.getChildNodes();
                Node student = list.item(1);
                System.out.println(student);
                NodeList list1 = student.getChildNodes();
                Node trxnRequest = list1.item(3);
                System.out.println(trxnRequest);
                NodeList list2 = trxnRequest.getChildNodes();
                Node trxDetail = list2.item(1);
                System.out.println(trxDetail);
                NodeList list3 = trxDetail.getChildNodes();
                Node trxEntry = list3.item(1);
                System.out.println(trxEntry);
                trxEntry.setTextContent(arrayValue[1]);
                Node trxEntry4 = list3.item(5);
                System.out.println(trxEntry4);
                trxEntry4.setTextContent(arrayValue[0]);


                NodeList entryList = staff.getChildNodes();
                Node entryValue = entryList.item(3);
                System.out.println(entryValue);
                NodeList entryList1 = entryValue.getChildNodes();
                Node entryValue1 = entryList1.item(5);
                System.out.println(entryValue1);
                NodeList entryList2 = entryValue1.getChildNodes();
                Node entryValue2 = entryList2.item(1);
                System.out.println(entryValue2);

                NodeList entryList3 = entryValue2.getChildNodes();
                Node entryValue3 = entryList3.item(1);
                System.out.println(entryValue3);

                NodeList entryList4 = entryValue3.getChildNodes();
                Node entryValue4 = entryList4.item(15);
                System.out.println(entryValue4);
                NodeList entryList5 = entryValue4.getChildNodes();
                Node entryValue5 = entryList5.item(1);

                entryValue5.setTextContent(arrayValue[2]);
                TransformerFactory transformerFactory = TransformerFactory.newInstance();
                Transformer transformer = transformerFactory.newTransformer();
                DOMSource source = new DOMSource(doc);
                StreamResult result = new StreamResult(new File(filepath));
                transformer.transform(source, result);
                String request = readFile(filepath);
                System.out.println("Sending Message " + request);
                message.setText(request);
                producer.send(message);
                System.out.println("Message Sent Successfully");
                PeekAndConsumeConfig peekAndConsumeConfig = new PeekAndConsumeConfig();
                activationKey activationKey1 = new activationKey();
                activationKey1.user_has_already_generated_the_JWT_token_for_the_group("INDGRP1");
                String actualResponse = peekAndConsumeConfig.getPeekConsumeResponseAsString(ab.glue.api.activationKey.activKey.get("INDGRP1"), "consume").trim();
                Assert.assertTrue(actualResponse.contains(arrayValue[3]));
            }
            } catch (Exception e) {
                e.printStackTrace();
            } catch (Throwable throwable) {
            throwable.printStackTrace();
        }
    }

    @When("^user modifies Stub with amount '(.+)' account number '(.+)' transaction type '(.+)' Currency Code '(.+)' BIC '(.+)'$")
    public void modifyxml1(String amount, String accountNumber, String trxType, String currencyCode, String bic) throws IOException, ParserConfigurationException, SAXException, TransformerConfigurationException {
        try {
            String filepath = new File(".").getCanonicalPath() + "/src/test/resources/rta-template.xml";
            DocumentBuilderFactory docFactory = DocumentBuilderFactory.newInstance();
            DocumentBuilder docBuilder = docFactory.newDocumentBuilder();
           // System.out.println(filepath);
            Document doc = docBuilder.parse(filepath);
            System.out.println(doc);
            Node staff = doc.getElementsByTagName("notifyCorporateFinancialTransactionRequest").item(0);
            System.out.println(staff);
            NodeList list = staff.getChildNodes();
            Node student = list.item(3);
            System.out.println(student);
            NodeList list1 = student.getChildNodes();
            Node trxnRequest = list1.item(5);
            System.out.println(trxnRequest);
            NodeList list2 = trxnRequest.getChildNodes();
            Node trxDetail = list2.item(1);
            System.out.println(trxDetail);
            NodeList list3 = trxDetail.getChildNodes();
            Node trxEntry = list3.item(1);
            //System.out.println(student);
            NodeList lists = trxEntry.getChildNodes();
            for (int i = 0; i < lists.getLength(); i++) {
                Node node = lists.item(i);
                // get the salary element, and update the value
                if (node.getNodeName().equals("tns:TrnAmount")) {
                    node.setTextContent(amount);
                    System.out.println(node.getTextContent());
                }
                if (node.getNodeName().equals("tns:Account")) {
                    NodeList accountList = node.getChildNodes();
                    Node currencyCodeNode = accountList.item(1);
                    currencyCodeNode.setTextContent(currencyCode);
                    System.out.println(currencyCodeNode.getTextContent());
                    Node accountNo = accountList.item(3);
                    accountNo.setTextContent(accountNumber);
                    System.out.println(accountNo.getTextContent());
                }
                if (node.getNodeName().equals("tns:CreditDebitFlag")) {
                    node.setTextContent(trxType);
                    System.out.println(node.getTextContent());
                }
                if (node.getNodeName().contains("tns:SwiftAddress")) {
                    node.setTextContent(bic);
                    System.out.println(node.getTextContent());
                }
            }
            TransformerFactory transformerFactory = TransformerFactory.newInstance();
            Transformer transformer = transformerFactory.newTransformer();
            DOMSource source = new DOMSource(doc);
            StreamResult result = new StreamResult(new File(filepath));
            transformer.transform(source, result);
            Connection connection = null;
            String contextFactory = "com.webmethods.jms.naming.WmJmsNamingCtxFactory";
            String JNDIUrl = "wmjmsnaming://@10.20.160.24:6661/EDMIFramework";
            String clientGroup = "admin";

            String connectionFactory = "CoreBanking_API_ConnectionFactory";
            String topicName = "scbCoreBankingTxnAlertCorpFinTxnNotifyV1T";
            Context namingContext = null;

            try {
                Properties env = new Properties();
                env.setProperty("java.naming.factory.initial", contextFactory);
                env.setProperty("java.naming.provider.url", JNDIUrl);
                env.setProperty("com.webmethods.jms.naming.clientgroup", clientGroup);
                env.setProperty("com.webmethods.jms.clientIDSharing", "true");
                System.setProperty("com.webmethods.jms.clientIDSharing", "true");

                namingContext = new InitialContext(env);

                WmConnectionFactoryImpl wmConnectionFactory = (WmConnectionFactoryImpl) namingContext.lookup(connectionFactory);
                File trustStoreResource = ResourceUtils.getFile("" +
                        "classpath:edmicorebankingtruststore.jks");
                wmConnectionFactory.setSSLTruststore(trustStoreResource.toString());

                connection = wmConnectionFactory.createConnection("ccsuser", "abc12345");

                System.out.println("Connection created " + connection.toString());
                Session session = connection.createSession(false, Session.AUTO_ACKNOWLEDGE);
                WmTopic dest = (WmTopic) namingContext.lookup(topicName);
                MessageProducer producer = session.createProducer(dest);
                TextMessage message = session.createTextMessage();

                String request = readFile(filepath);
                //System.out.println("Sending Message " + request);
                message.setText(request);
                producer.send(message);
                System.out.println("Message Sent Successfully");
            } catch (Exception e) {
                e.printStackTrace();
            }
        } catch (TransformerException e) {
            e.printStackTrace();
        }
    }


    @When("^user loops Stub with amount '(.+)' account number '(.+)' transaction type '(.+)' Currency Code '(.+)' BIC '(.+)' for '(.+)' times$")
    public void modifyxml1(String amount, String accountNumber, String trxType, String currencyCode, String bic, int n) throws IOException, ParserConfigurationException, SAXException, TransformerConfigurationException, InterruptedException, NamingException, JMSException {

        String contextFactory = "com.webmethods.jms.naming.WmJmsNamingCtxFactory";
        String JNDIUrl = "wmjmsnaming://@10.20.160.24:6661/EDMIFramework";
        String clientGroup = "admin";

        String connectionFactory = "CoreBanking_API_ConnectionFactory";
        String topicName = "scbCoreBankingTxnAlertCorpFinTxnNotifyV1T";
        Context namingContext = null;

        Properties env = new Properties();
        env.setProperty("java.naming.factory.initial", contextFactory);
        env.setProperty("java.naming.provider.url", JNDIUrl);
        env.setProperty("com.webmethods.jms.naming.clientgroup", clientGroup);
        env.setProperty("com.webmethods.jms.clientIDSharing", "true");
        System.setProperty("com.webmethods.jms.clientIDSharing", "true");

        namingContext = new InitialContext(env);

        WmConnectionFactoryImpl wmConnectionFactory = (WmConnectionFactoryImpl) namingContext.lookup(connectionFactory);
        File trustStoreResource = ResourceUtils.getFile("" +
                "classpath:edmicorebankingtruststore.jks");
        wmConnectionFactory.setSSLTruststore(trustStoreResource.toString());

        Connection connection = wmConnectionFactory.createConnection("ccsuser", "abc12345");

        System.out.println("Connection created " + connection.toString());
        Session session = connection.createSession(false, Session.AUTO_ACKNOWLEDGE);
        WmTopic dest = (WmTopic) namingContext.lookup(topicName);
        MessageProducer producer = session.createProducer(dest);

        int amt = Integer.parseInt(amount);
        n = amt + n;
        for (int j = amt; j < n; j++) {
            try {
                String filepath = new File(".").getCanonicalPath() + "/src/test/resources/rta-template.xml";
                DocumentBuilderFactory docFactory = DocumentBuilderFactory.newInstance();
                DocumentBuilder docBuilder = docFactory.newDocumentBuilder();
                System.out.println(filepath);
                Document doc = docBuilder.parse(filepath);
                System.out.println(doc);
                Node staff = doc.getElementsByTagName("notifyCorporateFinancialTransactionRequest").item(0);
                System.out.println(staff);
                NodeList list = staff.getChildNodes();
                Node student = list.item(3);
                System.out.println(student);
                NodeList list1 = student.getChildNodes();
                Node trxnRequest = list1.item(5);
                System.out.println(trxnRequest);
                NodeList list2 = trxnRequest.getChildNodes();
                Node trxDetail = list2.item(1);
                System.out.println(trxDetail);
                NodeList list3 = trxDetail.getChildNodes();
                Node trxEntry = list3.item(1);
                //System.out.println(student);
                NodeList lists = trxEntry.getChildNodes();
                for (int i = 0; i < lists.getLength(); i++) {
                    Node node = lists.item(i);
                    // get the salary element, and update the value
                    if (node.getNodeName().equals("tns:TrnAmount")) {
                        node.setTextContent("" + j);
                        System.out.println(node.getTextContent());
                    }
                    if (node.getNodeName().equals("tns:Account")) {
                        NodeList accountList = node.getChildNodes();
                        Node currencyCodeNode = accountList.item(1);
                        currencyCodeNode.setTextContent(currencyCode);
                        System.out.println(currencyCodeNode.getTextContent());
                        Node accountNo = accountList.item(3);
                        accountNo.setTextContent(accountNumber);
                        System.out.println(accountNo.getTextContent());
                    }
                    if (node.getNodeName().equals("tns:CreditDebitFlag")) {
                        if (j % 2 == 0)
                            node.setTextContent("C");
                        else
                            node.setTextContent("D");
                        System.out.println(node.getTextContent());
                    }
                    if (node.getNodeName().contains("tns:SwiftAddress")) {
                        node.setTextContent(bic);
                        System.out.println(node.getTextContent());
                    }
                }
                TransformerFactory transformerFactory = TransformerFactory.newInstance();
                Transformer transformer = transformerFactory.newTransformer();
                DOMSource source = new DOMSource(doc);
                StreamResult result = new StreamResult(new File(filepath));
                transformer.transform(source, result);

                try {
                    TextMessage message = session.createTextMessage();

                    String request = readFile(filepath);
                    System.out.println("Sending Message " + request);
                    message.setText(request);
                    producer.send(message);
                    System.out.println("Message Sent Successfully");

                } catch (Exception e) {
                    e.printStackTrace();
                } finally {
                }
            } catch (TransformerException eq) {
                eq.printStackTrace();
            }
        }

        if (connection != null)
            try {
                connection.close();
                System.out.println("Connection Terminated");
            } catch (JMSException e) {
                e.printStackTrace();
            }

    }

}

