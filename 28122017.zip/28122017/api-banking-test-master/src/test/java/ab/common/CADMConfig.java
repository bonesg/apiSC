package ab.common;

import com.sun.jersey.api.client.config.ClientConfig;
import com.sun.jersey.api.client.config.DefaultClientConfig;
import com.sun.jersey.client.urlconnection.HTTPSProperties;
import common.EndPoint;

import javax.net.ssl.*;
import javax.ws.rs.core.MediaType;
import java.security.SecureRandom;
import java.security.cert.CertificateException;
import java.security.cert.X509Certificate;


/**
 * Created by 1567270 on 7/5/2017.
 */
public class CADMConfig {

    /**
     * The method will will create the connection to CADM and will return the ClientConfig object
     * @return ClientConfig - The Client Config object with the corresponding CADM configuration.
     */
    public static ClientConfig configureClient() {
        TrustManager[] certs = new TrustManager[] { new X509TrustManager() {
            public X509Certificate[] getAcceptedIssuers() {
                return null;
            }
            public void checkClientTrusted(X509Certificate[] arg0, String arg1) throws CertificateException {
            }
            public void checkServerTrusted(X509Certificate[] arg0, String arg1) throws CertificateException {
            }
        } };
        SSLContext ctx = null;
        try {
            ctx = SSLContext.getInstance("SSL");
            ctx.init(null, certs, new SecureRandom());
        } catch (java.security.GeneralSecurityException ex) {
        }
        HttpsURLConnection.setDefaultSSLSocketFactory(ctx.getSocketFactory());

        ClientConfig config = new DefaultClientConfig();
        try {
          /*  ((DefaultClientConfig) config).getProperties().put(HTTPSProperties.PROPERTY_HTTPS_PROPERTIES,
                    new HTTPSProperties(new HostnameVerifier() {
                        public boolean verify(String arg0, SSLSession arg1) {
                            return true;
                        }
                    }, ctx));*/
        } catch (Exception e) {
        }

        return config;
    }

    /**
     * The method is configured to get the response for all the GET APIs of CADM
     * @param endpoint - The endpoint of the CADM GET API is to be called.
     * @param groupId  - The group ID for which, details are required
     * @return response - Return the response of the GET APIs
     */
    public String getCADMResponse(String endpoint, String groupId){
        String output="";
        final com.sun.jersey.api.client.Client client = com.sun.jersey.api.client.Client.create(CADMConfig.configureClient());
        final com.sun.jersey.api.client.WebResource webResource = client
                .resource(EndPoint.CADM_URL+endpoint+groupId);
        try {
            com.sun.jersey.api.client.ClientResponse response = webResource.type(MediaType.APPLICATION_JSON_TYPE)
                    .accept(MediaType.APPLICATION_JSON_TYPE).get(com.sun.jersey.api.client.ClientResponse.class);
            System.out.println(response.toString());
            output = response.toString();
            if(response.getStatus() ==200) {
                output = response.getEntity(String.class);
                System.out.println(output);
            }

        } catch (com.sun.jersey.api.client.ClientHandlerException che) {
            che.printStackTrace();
        }
        return output;
    }
}
