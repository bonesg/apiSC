package ab.api.tests;

import ab.glue.api.CADMMethods;
import junit.framework.Assert;

import javax.jms.JMSException;
import java.io.IOException;

/**
 * Created by 1571168 on 8/25/2017.
 */
public class CADMLoop {

    public static void main(String args[]) throws IOException, JMSException {
        CADMMethods cadmMethods = new CADMMethods();
        for (int i=1;i<50;i++){
            cadmMethods.postAddGroupServiceswithAllDetails("INDTEST","pk"+i,"A:B:C:D:"+i,"http://webhook"+i+".com");
            String cadmGroup = cadmMethods.getGroupServices("INDTEST");
            String webookURL = cadmGroup.split("\"webhookUrl\":\"")[1].split("\",\"")[0];

            String fingerprint = cadmGroup.split("certificateFingerprint\":\"")[1].split("\",\"")[0];
            String publickey = cadmGroup.split("\"publicKey\":\"")[1].split("\"")[0];
            Assert.assertTrue("Expected webhook - http://webhook"+i+".com. Actual webhook "+webookURL+
                    ". Expected fingerprint - A:B:C:D:"+i +". Actual fingerprint - "+fingerprint+
                    ". Expected public key - pk"+i+". Actual public key is " +publickey
                    ,webookURL.equals("http://webhook"+i+".com")&&fingerprint.equals("A:B:C:D:"+i)&&publickey.equals("pk"+i));

        }
    }
}
