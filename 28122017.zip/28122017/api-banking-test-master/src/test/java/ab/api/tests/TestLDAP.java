package ab.api.tests;

import ab.glue.api.NewStub;
import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.response.Response;

import java.io.File;
import java.io.IOException;

import static io.restassured.RestAssured.given;

/**
 * Created by 1571168 on 12/20/2017.
 */
public class TestLDAP {

    public static void main(String args[]) throws IOException {
        RestAssured.useRelaxedHTTPSValidation();
        String filepath = new File(".").getCanonicalPath() + "/src/test/resources/test-data/UPI_AccountBalanceEnquiry.xml";
        NewStub newStub = new NewStub();
        String request = newStub.readFile(filepath);
        Response response1 = given()
                .contentType(ContentType.XML)
               // .headers(headerMap)
                .body(request)
                .when()
                .post("https://10.23.210.59:8095/upi/ReqBalEnq/1.0");
        String response = response1.thenReturn().asString();
        System.out.println("Response is "+response);
        System.out.println("Status code is "+response1.getStatusCode());
    }

    public void ldap(){
        Response response1 = given()
                .contentType(ContentType.XML)
                // .headers(headerMap)
                .body("{\n" +
                        "\"request\": {\n" +
                        "\"user\": {\n" +
                        "\"appId\": \"COP\",\n" +
                        "\"groupId\": \"COPINTGP\",\n" +
                        "\"userId\": \"1409314\",\n" +
                        "\"password\":\n" +
                        "{ \"password\": \"abc12345\", \"type\": 10 }\n" +
                        "}\n" +
                        "}\n" +
                        "}")
                .when()
                .post("https://10.23.210.59:8095/upi/ReqBalEnq/1.0");
        String response = response1.thenReturn().asString();
        System.out.println("Response is "+response);

        System.out.println("Status code is "+response1.getStatusCode());
    }
}
