package common;

/**
 * @author 1556780
 * This interface contains research portal API end-points
 */
public interface EndPoint {
	String POST_CreateActivationKey = "/uaasv2/services/jwt/createActivationKey";
	String POST_ActivateUser = "/cib/v1/activate";
    String POST_WEBHOOKURL_INDGROUP = "";
    String POST_WEBHOOKURL_INDGRP = "http://10.23.210.59:8443/webhook";
    String POST_WEBHOOKURL_INDTEST = "http://10.64.224.19:8443/webhook10.64.224.19:8443/webhook10.64.224.19:8443/webhook10.64.224.19:8443/webhook10.64.224.19:8443/webhook10.64.224.19:8443/webhook10.64.224.19:8443/webhook10.64.224.19:8443/webhook10.64.224.19:8443/webhook10.64.224.19:8443/webjkk";
    String POST_WEBHOOKURL_INCRMS02_ = "http://10.23.210.60:8443/webhook";
    String CADM_URL ="https://10.20.166.89:755";
    String PULL_API_URL = "https://uklvadapp006:8080/cib/core/event/" ;
    String  CREATE_ACTIVATION_KEY_URL= "http://10.128.55.216";
    //String  CREATE_ACTIVATION_KEY_URL= "http://10.20.167.163";
     String ACTIVATE_URL = "https://uklvadapp006:8080";
    //String ACTIVATE_URL = "http://10.128.55.216/uaasv2/services/jwt";
    String WEBHOOK_MESSAGE = "[ { \"groupId\": \"INDGROUP\", \"transactionIdentifier\": { \"type\": \"Other\", \"identifier\": \"a2c198e9-3ac8-412b-b5ba-65c4756f4076\" },\"creditDate\": \"2015-11-16\", \"accountIdentifier\": { \"accountId\": \"17082017\", \"currencyCode\": { \"isoCode\": \"INR\" }, \"bankCode\": \"SCBLINBBXXX\" }, \"debitDate\": \"2015-11-16\", \"adviceType\": \"Credit\", \"transactionCode\": \"002\", \"transactionDescription\": \"UPI PAY - SCB Acct to Bene Acct SCB & Non-SCB - DR\", \"postExecutionBalance\": { \"currencyCode\": \"INR\", \"amount\": 99803990 }, \"preExecutionBalance\": { \"currencyCode\": \"INR\", \"amount\": 99809590 }, \"transactionFreeText\": [ \"UPI/715615346607/\", \"UPI CYCLE 2/SIVAAACHEN@SCBL/\", \"75110011017/EMAILSLOWNESS/\", \"123-13123-13123\" ], \"transactionAmount\": { \"currencyCode\": \"INR\", \"amount\": 5600 }, \"clientIdentifier\": { \"type\": \"Other\", \"identifier\": \"\" }, \"externalIdentifier\": { \"type\": \"Other\", \"identifier\": \"\" } } ]";
    String WEBHOOK_EBBS_MESSAGE = "[ { \"groupId\": \"INDGROUP\", \"transactionIdentifier\": { \"type\": \"Other\", \"identifier\": \"a2c198e9-3ac8-412b-b5ba-65c4756f4076\" },\"creditDate\": \"2015-11-16\", \"accountIdentifier\": { \"accountId\": \"17082017\", \"currencyCode\": { \"isoCode\": \"INR\" }, \"bankCode\": \"SCBLINBBXXX\" }, \"debitDate\": \"2015-11-16\", \"adviceType\": \"Credit\", \"transactionCode\": \"002\", \"transactionDescription\": \"UPI PAY - SCB Acct to Bene Acct SCB & Non-SCB - DR\", \"postExecutionBalance\": { \"currencyCode\": \"INR\", \"amount\": 99803990 }, \"preExecutionBalance\": { \"currencyCode\": \"INR\", \"amount\": 99809590 }, \"transactionFreeText\": [\"CASHDEPOSIT\",\"2015-11-16100SUPPORTM1551\",\"22205269504\", \"75110011017/EMAILSLOWNESS/\", \"123-13123-13123\" ], \"transactionAmount\": { \"currencyCode\": \"INR\", \"amount\": 5600 }, \"clientIdentifier\": { \"type\": \"Other\", \"identifier\": \"\" }, \"externalIdentifier\": { \"type\": \"Other\", \"identifier\": \"\" } } ]";
    //String POST_ActivateUser = "/cib/v1/activate";
}
