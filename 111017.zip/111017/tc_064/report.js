$(document).ready(function() {var formatter = new CucumberHTML.DOMFormatter($('.cucumber-report'));formatter.uri("features/api/pull.feature");
formatter.feature({
  "line": 1,
  "name": "Pull Mechanism scenarios",
  "description": "",
  "id": "pull-mechanism-scenarios",
  "keyword": "Feature"
});
formatter.scenarioOutline({
  "line": 157,
  "name": "TC_PULL_006 - When both webhook is down, verify messages for Peek of Group A and Recover of Group B",
  "description": "",
  "id": "pull-mechanism-scenarios;tc-pull-006---when-both-webhook-is-down,-verify-messages-for-peek-of-group-a-and-recover-of-group-b",
  "type": "scenario_outline",
  "keyword": "Scenario Outline",
  "tags": [
    {
      "line": 156,
      "name": "@ab"
    },
    {
      "line": 156,
      "name": "@peekAndConsume"
    },
    {
      "line": 156,
      "name": "@regression"
    },
    {
      "line": 156,
      "name": "@pull"
    },
    {
      "line": 156,
      "name": "@pull6"
    }
  ]
});
formatter.step({
  "comments": [
    {
      "line": 158,
      "value": "#When Add Group Services of CADM is called for the group \u0027\u003cGroupID\u003e\u0027 to disable the group"
    },
    {
      "line": 159,
      "value": "#Then APIBanking should be disabled in CADM for the group \u0027\u003cGroupID\u003e\u0027"
    }
  ],
  "line": 160,
  "name": "\u0027activationKey and activate\u0027 API",
  "keyword": "Given "
});
formatter.step({
  "line": 161,
  "name": "user has valid SSL certificate",
  "keyword": "And "
});
formatter.step({
  "line": 162,
  "name": "user has already generated the JWT token for the group \u0027\u003cGroupIDA\u003e\u0027",
  "keyword": "And "
});
formatter.step({
  "line": 163,
  "name": "a POST request is made to axway endpoint for the group \u0027\u003cGroupIDA\u003e\u0027",
  "keyword": "When "
});
formatter.step({
  "line": 164,
  "name": "user should be registered successfully",
  "keyword": "Then "
});
formatter.step({
  "comments": [
    {
      "line": 165,
      "value": "#And APIBanking should be enabled in CADM for the group \u0027\u003cGroupIDA\u003e\u0027"
    },
    {
      "line": 166,
      "value": "#Given user has already generated the JWT token for the group \u0027\u003cGroupIDB\u003e\u0027"
    },
    {
      "line": 167,
      "value": "#When a POST request is made to axway endpoint for the group \u0027\u003cGroupIDB\u003e\u0027"
    },
    {
      "line": 168,
      "value": "#Then user should be registered successfully"
    },
    {
      "line": 169,
      "value": "#And APIBanking should be enabled in CADM for the group \u0027\u003cGroupIDB\u003e\u0027"
    },
    {
      "line": 170,
      "value": "#When user modifies Stub with amount \u0027\u003cAmount\u003e\u0027 account number \u0027\u003cAccountNo\u003e\u0027 transaction type \u0027\u003cCreditDebit\u003e\u0027 Currency Code \u0027INR\u0027 BIC \u0027SCBLINBBXXX\u0027"
    }
  ],
  "line": 171,
  "name": "Consume response should be displayed with amount \u0027\u003cAmount\u003e\u0027 accountNo \u0027\u003cAccountNo\u003e\u0027 transactionType \u0027\u003cCreditDebit\u003e\u0027 the expected value for the group \u0027\u003cGroupIDA\u003e\u0027",
  "keyword": "Then "
});
formatter.step({
  "line": 172,
  "name": "Recover response should be displayed with amount \u0027\u003cAmount1\u003e\u0027 accountNo \u0027\u003cAccountNo\u003e\u0027 transactionType \u0027\u003cCreditDebit1\u003e\u0027 the expected value for the group \u0027\u003cGroupIDB\u003e\u0027",
  "keyword": "Then "
});
formatter.examples({
  "line": 173,
  "name": "",
  "description": "",
  "id": "pull-mechanism-scenarios;tc-pull-006---when-both-webhook-is-down,-verify-messages-for-peek-of-group-a-and-recover-of-group-b;",
  "rows": [
    {
      "cells": [
        "Amount",
        "AccountNo",
        "CreditDebit",
        "GroupIDA",
        "GroupIDB",
        "Amount1",
        "CreditDebit1"
      ],
      "line": 174,
      "id": "pull-mechanism-scenarios;tc-pull-006---when-both-webhook-is-down,-verify-messages-for-peek-of-group-a-and-recover-of-group-b;;1"
    },
    {
      "cells": [
        "22.33",
        "22205269504",
        "D",
        "INDGROUP",
        "INDGRP",
        "8810",
        "C"
      ],
      "line": 175,
      "id": "pull-mechanism-scenarios;tc-pull-006---when-both-webhook-is-down,-verify-messages-for-peek-of-group-a-and-recover-of-group-b;;2"
    },
    {
      "cells": [
        "22.33",
        "22205269504",
        "D",
        "INDGRP",
        "INDGRP",
        "22.33",
        "D"
      ],
      "line": 176,
      "id": "pull-mechanism-scenarios;tc-pull-006---when-both-webhook-is-down,-verify-messages-for-peek-of-group-a-and-recover-of-group-b;;3"
    }
  ],
  "keyword": "Examples"
});
formatter.before({
  "duration": 505219490,
  "status": "passed"
});
formatter.scenario({
  "line": 175,
  "name": "TC_PULL_006 - When both webhook is down, verify messages for Peek of Group A and Recover of Group B",
  "description": "",
  "id": "pull-mechanism-scenarios;tc-pull-006---when-both-webhook-is-down,-verify-messages-for-peek-of-group-a-and-recover-of-group-b;;2",
  "type": "scenario",
  "keyword": "Scenario Outline",
  "tags": [
    {
      "line": 156,
      "name": "@ab"
    },
    {
      "line": 156,
      "name": "@peekAndConsume"
    },
    {
      "line": 156,
      "name": "@regression"
    },
    {
      "line": 156,
      "name": "@pull6"
    },
    {
      "line": 156,
      "name": "@pull"
    }
  ]
});
formatter.step({
  "comments": [
    {
      "line": 158,
      "value": "#When Add Group Services of CADM is called for the group \u0027\u003cGroupID\u003e\u0027 to disable the group"
    },
    {
      "line": 159,
      "value": "#Then APIBanking should be disabled in CADM for the group \u0027\u003cGroupID\u003e\u0027"
    }
  ],
  "line": 160,
  "name": "\u0027activationKey and activate\u0027 API",
  "keyword": "Given "
});
formatter.step({
  "line": 161,
  "name": "user has valid SSL certificate",
  "keyword": "And "
});
formatter.step({
  "line": 162,
  "name": "user has already generated the JWT token for the group \u0027INDGROUP\u0027",
  "matchedColumns": [
    3
  ],
  "keyword": "And "
});
formatter.step({
  "line": 163,
  "name": "a POST request is made to axway endpoint for the group \u0027INDGROUP\u0027",
  "matchedColumns": [
    3
  ],
  "keyword": "When "
});
formatter.step({
  "line": 164,
  "name": "user should be registered successfully",
  "keyword": "Then "
});
formatter.step({
  "comments": [
    {
      "line": 165,
      "value": "#And APIBanking should be enabled in CADM for the group \u0027\u003cGroupIDA\u003e\u0027"
    },
    {
      "line": 166,
      "value": "#Given user has already generated the JWT token for the group \u0027\u003cGroupIDB\u003e\u0027"
    },
    {
      "line": 167,
      "value": "#When a POST request is made to axway endpoint for the group \u0027\u003cGroupIDB\u003e\u0027"
    },
    {
      "line": 168,
      "value": "#Then user should be registered successfully"
    },
    {
      "line": 169,
      "value": "#And APIBanking should be enabled in CADM for the group \u0027\u003cGroupIDB\u003e\u0027"
    },
    {
      "line": 170,
      "value": "#When user modifies Stub with amount \u0027\u003cAmount\u003e\u0027 account number \u0027\u003cAccountNo\u003e\u0027 transaction type \u0027\u003cCreditDebit\u003e\u0027 Currency Code \u0027INR\u0027 BIC \u0027SCBLINBBXXX\u0027"
    }
  ],
  "line": 171,
  "name": "Consume response should be displayed with amount \u002722.33\u0027 accountNo \u002722205269504\u0027 transactionType \u0027D\u0027 the expected value for the group \u0027INDGROUP\u0027",
  "matchedColumns": [
    0,
    1,
    2,
    3
  ],
  "keyword": "Then "
});
formatter.step({
  "line": 172,
  "name": "Recover response should be displayed with amount \u00278810\u0027 accountNo \u002722205269504\u0027 transactionType \u0027C\u0027 the expected value for the group \u0027INDGRP\u0027",
  "matchedColumns": [
    1,
    4,
    5,
    6
  ],
  "keyword": "Then "
});
formatter.match({
  "arguments": [
    {
      "val": "activationKey and activate",
      "offset": 1
    }
  ],
  "location": "commonApiMethods.an_API(String)"
});
formatter.result({
  "duration": 230214855,
  "status": "passed"
});
formatter.match({
  "location": "activationKey.user_has_valid_SSL_certificate()"
});
formatter.result({
  "duration": 9837493,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "INDGROUP",
      "offset": 56
    }
  ],
  "location": "activationKey.user_has_already_generated_the_JWT_token_for_the_group(String)"
});
formatter.result({
  "duration": 561034632,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "INDGROUP",
      "offset": 56
    }
  ],
  "location": "activationKey.a_POST_request_is_made_to_axway_endpoint(String)"
});
formatter.result({
  "duration": 4365910259,
  "status": "passed"
});
formatter.match({
  "location": "activationKey.user_should_be_registered_successfully()"
});
formatter.result({
  "duration": 64189,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "22.33",
      "offset": 50
    },
    {
      "val": "22205269504",
      "offset": 68
    },
    {
      "val": "D",
      "offset": 98
    },
    {
      "val": "INDGROUP",
      "offset": 135
    }
  ],
  "location": "PeekAndConsume.consumeValueTest(String,String,String,String)"
});
formatter.result({
  "duration": 948787946,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "8810",
      "offset": 50
    },
    {
      "val": "22205269504",
      "offset": 67
    },
    {
      "val": "C",
      "offset": 97
    },
    {
      "val": "INDGRP",
      "offset": 134
    }
  ],
  "location": "PeekAndConsume.recoverValueTest(String,String,String,String)"
});
formatter.result({
  "duration": 963045401,
  "error_message": "java.lang.AssertionError: Recover Response is not displayed as expected. Expected Response - [{\"groupId\":\"INDGRP\",\"transactionIdentifier\":{\"type\":\"Other\",\"identifiercreditDate\":\"2015-11-16\",\"accountIdentifier\":{\"accountId\":\"22205269504\",\"currencyCode\":{\"isoCode\":\"INR\"},\"bankCode\":\"SCBLINBBXXX\"},\"debitDate\":\"2015-11-16\",\"adviceType\":\"Credit\",\"transactionCode\":null,\"transactionDescription\":\"UPIPAY-SCBAccttoBeneAcctSCB\u0026Non-SCB-DR\",\"postExecutionBalance\":{\"currencyCode\":\"INR\",\"amount\":99803990},\"preExecutionBalance\":{\"currencyCode\":\"INR\",\"amount\":99795180},\"transactionFreeText\":[\"UPI/715615346607/\",\"UPICYCLE2/SIVAAACHEN@SCBL/\",\"75110011017/EMAILSLOWNESS/\",\"123-13123-13123\"],\"transactionAmount\":{\"currencyCode\":\"INR\",\"amount\":8810},\"clientIdentifier\":{\"type\":\"Other\",\"identifier\":\"\"},\"externalIdentifier\":{\"type\":\"Other\",\"identifier\":\"\"}}]. Actual Response - [{\"groupId\":\"INDGRP\",\"transactionIdentifier\":{\"type\":\"Other\",\"identifiercreditDate\":\"2015-11-16\",\"accountIdentifier\":{\"accountId\":\"19082017\",\"currencyCode\":{\"isoCode\":\"INR\"},\"bankCode\":\"SCBLINBBXXX\"},\"debitDate\":\"2015-11-16\",\"adviceType\":\"Credit\",\"transactionCode\":null,\"transactionDescription\":\"UPIPAY-SCBAccttoBeneAcctSCB\u0026Non-SCB-DR\",\"postExecutionBalance\":{\"currencyCode\":\"INR\",\"amount\":99803990},\"preExecutionBalance\":{\"currencyCode\":\"INR\",\"amount\":99795180},\"transactionFreeText\":[\"UPI/715615346607/\",\"UPICYCLE2/SIVAAACHEN@SCBL/\",\"75110011017/EMAILSLOWNESS/\",\"123-13123-13123\"],\"transactionAmount\":{\"currencyCode\":\"INR\",\"amount\":8810},\"clientIdentifier\":{\"type\":\"Other\",\"identifier\":\"\"},\"externalIdentifier\":{\"type\":\"Other\",\"identifier\":\"\"}}]\r\n\tat org.junit.Assert.fail(Assert.java:88)\r\n\tat org.junit.Assert.assertTrue(Assert.java:41)\r\n\tat ab.glue.api.PeekAndConsume.recoverValueTest(PeekAndConsume.java:209)\r\n\tat ✽.Then Recover response should be displayed with amount \u00278810\u0027 accountNo \u002722205269504\u0027 transactionType \u0027C\u0027 the expected value for the group \u0027INDGRP\u0027(features/api/pull.feature:172)\r\n",
  "status": "failed"
});
formatter.before({
  "duration": 25648694,
  "status": "passed"
});
formatter.scenario({
  "line": 176,
  "name": "TC_PULL_006 - When both webhook is down, verify messages for Peek of Group A and Recover of Group B",
  "description": "",
  "id": "pull-mechanism-scenarios;tc-pull-006---when-both-webhook-is-down,-verify-messages-for-peek-of-group-a-and-recover-of-group-b;;3",
  "type": "scenario",
  "keyword": "Scenario Outline",
  "tags": [
    {
      "line": 156,
      "name": "@ab"
    },
    {
      "line": 156,
      "name": "@peekAndConsume"
    },
    {
      "line": 156,
      "name": "@regression"
    },
    {
      "line": 156,
      "name": "@pull6"
    },
    {
      "line": 156,
      "name": "@pull"
    }
  ]
});
formatter.step({
  "comments": [
    {
      "line": 158,
      "value": "#When Add Group Services of CADM is called for the group \u0027\u003cGroupID\u003e\u0027 to disable the group"
    },
    {
      "line": 159,
      "value": "#Then APIBanking should be disabled in CADM for the group \u0027\u003cGroupID\u003e\u0027"
    }
  ],
  "line": 160,
  "name": "\u0027activationKey and activate\u0027 API",
  "keyword": "Given "
});
formatter.step({
  "line": 161,
  "name": "user has valid SSL certificate",
  "keyword": "And "
});
formatter.step({
  "line": 162,
  "name": "user has already generated the JWT token for the group \u0027INDGRP\u0027",
  "matchedColumns": [
    3
  ],
  "keyword": "And "
});
formatter.step({
  "line": 163,
  "name": "a POST request is made to axway endpoint for the group \u0027INDGRP\u0027",
  "matchedColumns": [
    3
  ],
  "keyword": "When "
});
formatter.step({
  "line": 164,
  "name": "user should be registered successfully",
  "keyword": "Then "
});
formatter.step({
  "comments": [
    {
      "line": 165,
      "value": "#And APIBanking should be enabled in CADM for the group \u0027\u003cGroupIDA\u003e\u0027"
    },
    {
      "line": 166,
      "value": "#Given user has already generated the JWT token for the group \u0027\u003cGroupIDB\u003e\u0027"
    },
    {
      "line": 167,
      "value": "#When a POST request is made to axway endpoint for the group \u0027\u003cGroupIDB\u003e\u0027"
    },
    {
      "line": 168,
      "value": "#Then user should be registered successfully"
    },
    {
      "line": 169,
      "value": "#And APIBanking should be enabled in CADM for the group \u0027\u003cGroupIDB\u003e\u0027"
    },
    {
      "line": 170,
      "value": "#When user modifies Stub with amount \u0027\u003cAmount\u003e\u0027 account number \u0027\u003cAccountNo\u003e\u0027 transaction type \u0027\u003cCreditDebit\u003e\u0027 Currency Code \u0027INR\u0027 BIC \u0027SCBLINBBXXX\u0027"
    }
  ],
  "line": 171,
  "name": "Consume response should be displayed with amount \u002722.33\u0027 accountNo \u002722205269504\u0027 transactionType \u0027D\u0027 the expected value for the group \u0027INDGRP\u0027",
  "matchedColumns": [
    0,
    1,
    2,
    3
  ],
  "keyword": "Then "
});
formatter.step({
  "line": 172,
  "name": "Recover response should be displayed with amount \u002722.33\u0027 accountNo \u002722205269504\u0027 transactionType \u0027D\u0027 the expected value for the group \u0027INDGRP\u0027",
  "matchedColumns": [
    1,
    4,
    5,
    6
  ],
  "keyword": "Then "
});
formatter.match({
  "arguments": [
    {
      "val": "activationKey and activate",
      "offset": 1
    }
  ],
  "location": "commonApiMethods.an_API(String)"
});
formatter.result({
  "duration": 129510,
  "status": "passed"
});
formatter.match({
  "location": "activationKey.user_has_valid_SSL_certificate()"
});
formatter.result({
  "duration": 863527,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "INDGRP",
      "offset": 56
    }
  ],
  "location": "activationKey.user_has_already_generated_the_JWT_token_for_the_group(String)"
});
formatter.result({
  "duration": 23244636,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "INDGRP",
      "offset": 56
    }
  ],
  "location": "activationKey.a_POST_request_is_made_to_axway_endpoint(String)"
});
formatter.result({
  "duration": 2343096821,
  "status": "passed"
});
formatter.match({
  "location": "activationKey.user_should_be_registered_successfully()"
});
formatter.result({
  "duration": 156696,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "22.33",
      "offset": 50
    },
    {
      "val": "22205269504",
      "offset": 68
    },
    {
      "val": "D",
      "offset": 98
    },
    {
      "val": "INDGRP",
      "offset": 135
    }
  ],
  "location": "PeekAndConsume.consumeValueTest(String,String,String,String)"
});
formatter.result({
  "duration": 850212144,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "22.33",
      "offset": 50
    },
    {
      "val": "22205269504",
      "offset": 68
    },
    {
      "val": "D",
      "offset": 98
    },
    {
      "val": "INDGRP",
      "offset": 135
    }
  ],
  "location": "PeekAndConsume.recoverValueTest(String,String,String,String)"
});
formatter.result({
  "duration": 903470309,
  "status": "passed"
});
});