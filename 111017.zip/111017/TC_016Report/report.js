$(document).ready(function() {var formatter = new CucumberHTML.DOMFormatter($('.cucumber-report'));formatter.uri("features/api/activationKey.feature");
formatter.feature({
  "line": 1,
  "name": "Generate Activation Key and JWT",
  "description": "",
  "id": "generate-activation-key-and-jwt",
  "keyword": "Feature"
});
formatter.before({
  "duration": 407893103,
  "status": "passed"
});
formatter.scenario({
  "line": 147,
  "name": "Verify error message for invalid certificate",
  "description": "",
  "id": "generate-activation-key-and-jwt;verify-error-message-for-invalid-certificate",
  "type": "scenario",
  "keyword": "Scenario",
  "tags": [
    {
      "line": 146,
      "name": "@ab"
    },
    {
      "line": 146,
      "name": "@invalidCertificate"
    },
    {
      "line": 146,
      "name": "@tc16"
    }
  ]
});
formatter.step({
  "line": 148,
  "name": "\u0027activationKey\u0027 API",
  "keyword": "Given "
});
formatter.step({
  "line": 149,
  "name": "user has already generated the JWT token for the group \u0027INDGROUP\u0027",
  "keyword": "And "
});
formatter.step({
  "line": 150,
  "name": "error should be displayed for invalid certificate",
  "keyword": "Then "
});
formatter.match({
  "arguments": [
    {
      "val": "activationKey",
      "offset": 1
    }
  ],
  "location": "commonApiMethods.an_API(String)"
});
formatter.result({
  "duration": 167372176,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "INDGROUP",
      "offset": 56
    }
  ],
  "location": "activationKey.user_has_already_generated_the_JWT_token_for_the_group(String)"
});
formatter.result({
  "duration": 528557765,
  "status": "passed"
});
formatter.match({
  "location": "activationKey.verifyCertificateError()"
});
formatter.result({
  "duration": 3247208639,
  "status": "passed"
});
});