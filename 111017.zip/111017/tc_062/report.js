$(document).ready(function() {var formatter = new CucumberHTML.DOMFormatter($('.cucumber-report'));formatter.uri("features/api/pull.feature");
formatter.feature({
  "line": 1,
  "name": "Pull Mechanism scenarios",
  "description": "",
  "id": "pull-mechanism-scenarios",
  "keyword": "Feature"
});
formatter.scenarioOutline({
  "line": 201,
  "name": "TC_PULL_008 - When both webhook is down, verify messages for Peek of Group A and Consume of Group B",
  "description": "",
  "id": "pull-mechanism-scenarios;tc-pull-008---when-both-webhook-is-down,-verify-messages-for-peek-of-group-a-and-consume-of-group-b",
  "type": "scenario_outline",
  "keyword": "Scenario Outline",
  "tags": [
    {
      "line": 200,
      "name": "@ab"
    },
    {
      "line": 200,
      "name": "@peekAndConsume"
    },
    {
      "line": 200,
      "name": "@regression"
    },
    {
      "line": 200,
      "name": "@pull"
    },
    {
      "line": 200,
      "name": "@pull8"
    }
  ]
});
formatter.step({
  "comments": [
    {
      "line": 202,
      "value": "#When Add Group Services of CADM is called for the group \u0027\u003cGroupID\u003e\u0027 to disable the group"
    },
    {
      "line": 203,
      "value": "#Then APIBanking should be disabled in CADM for the group \u0027\u003cGroupID\u003e\u0027"
    }
  ],
  "line": 204,
  "name": "\u0027activationKey and activate\u0027 API",
  "keyword": "Given "
});
formatter.step({
  "line": 205,
  "name": "user has valid SSL certificate",
  "keyword": "And "
});
formatter.step({
  "line": 206,
  "name": "user has already generated the JWT token for the group \u0027\u003cGroupIDA\u003e\u0027",
  "keyword": "And "
});
formatter.step({
  "line": 207,
  "name": "a POST request is made to axway endpoint for the group \u0027\u003cGroupIDA\u003e\u0027",
  "keyword": "When "
});
formatter.step({
  "comments": [
    {
      "line": 208,
      "value": "#Then user should be registered successfully"
    },
    {
      "line": 209,
      "value": "#And APIBanking should be enabled in CADM for the group \u0027\u003cGroupIDA\u003e\u0027"
    },
    {
      "line": 210,
      "value": "#Given user has already generated the JWT token for the group \u0027\u003cGroupIDB\u003e\u0027"
    },
    {
      "line": 211,
      "value": "#When a POST request is made to axway endpoint for the group \u0027\u003cGroupIDB\u003e\u0027"
    },
    {
      "line": 212,
      "value": "#Then user should be registered successfully"
    },
    {
      "line": 213,
      "value": "#And APIBanking should be enabled in CADM for the group \u0027\u003cGroupIDB\u003e\u0027"
    },
    {
      "line": 214,
      "value": "#When user modifies Stub with amount \u0027\u003cAmount\u003e\u0027 account number \u0027\u003cAccountNo\u003e\u0027 transaction type \u0027\u003cCreditDebit\u003e\u0027 Currency Code \u0027INR\u0027 BIC \u0027SCBLINBBXXX\u0027"
    }
  ],
  "line": 215,
  "name": "Recover response should be displayed with amount \u0027\u003cAmount\u003e\u0027 accountNo \u0027\u003cAccountNo\u003e\u0027 transactionType \u0027\u003cCreditDebit\u003e\u0027 the expected value for the group \u0027\u003cGroupIDA\u003e\u0027",
  "keyword": "Then "
});
formatter.step({
  "line": 216,
  "name": "Consume response should be displayed with amount \u0027\u003cAmount1\u003e\u0027 accountNo \u0027\u003cAccountNo\u003e\u0027 transactionType \u0027\u003cCreditDebit\u003e\u0027 the expected value for the group \u0027\u003cGroupIDB\u003e\u0027",
  "keyword": "Then "
});
formatter.examples({
  "line": 217,
  "name": "",
  "description": "",
  "id": "pull-mechanism-scenarios;tc-pull-008---when-both-webhook-is-down,-verify-messages-for-peek-of-group-a-and-consume-of-group-b;",
  "rows": [
    {
      "cells": [
        "Amount",
        "AccountNo",
        "CreditDebit",
        "GroupIDA",
        "GroupIDB",
        "Amount1"
      ],
      "line": 218,
      "id": "pull-mechanism-scenarios;tc-pull-008---when-both-webhook-is-down,-verify-messages-for-peek-of-group-a-and-consume-of-group-b;;1"
    },
    {
      "cells": [
        "22.33",
        "22205269504",
        "D",
        "INDGROUP",
        "INDGRP",
        "66"
      ],
      "line": 219,
      "id": "pull-mechanism-scenarios;tc-pull-008---when-both-webhook-is-down,-verify-messages-for-peek-of-group-a-and-consume-of-group-b;;2"
    },
    {
      "cells": [
        "22.33",
        "22205269504",
        "D",
        "INDGROUP",
        "INDGROUP",
        "66"
      ],
      "line": 220,
      "id": "pull-mechanism-scenarios;tc-pull-008---when-both-webhook-is-down,-verify-messages-for-peek-of-group-a-and-consume-of-group-b;;3"
    }
  ],
  "keyword": "Examples"
});
formatter.before({
  "duration": 698458602,
  "status": "passed"
});
formatter.scenario({
  "line": 219,
  "name": "TC_PULL_008 - When both webhook is down, verify messages for Peek of Group A and Consume of Group B",
  "description": "",
  "id": "pull-mechanism-scenarios;tc-pull-008---when-both-webhook-is-down,-verify-messages-for-peek-of-group-a-and-consume-of-group-b;;2",
  "type": "scenario",
  "keyword": "Scenario Outline",
  "tags": [
    {
      "line": 200,
      "name": "@ab"
    },
    {
      "line": 200,
      "name": "@peekAndConsume"
    },
    {
      "line": 200,
      "name": "@pull8"
    },
    {
      "line": 200,
      "name": "@regression"
    },
    {
      "line": 200,
      "name": "@pull"
    }
  ]
});
formatter.step({
  "comments": [
    {
      "line": 202,
      "value": "#When Add Group Services of CADM is called for the group \u0027\u003cGroupID\u003e\u0027 to disable the group"
    },
    {
      "line": 203,
      "value": "#Then APIBanking should be disabled in CADM for the group \u0027\u003cGroupID\u003e\u0027"
    }
  ],
  "line": 204,
  "name": "\u0027activationKey and activate\u0027 API",
  "keyword": "Given "
});
formatter.step({
  "line": 205,
  "name": "user has valid SSL certificate",
  "keyword": "And "
});
formatter.step({
  "line": 206,
  "name": "user has already generated the JWT token for the group \u0027INDGROUP\u0027",
  "matchedColumns": [
    3
  ],
  "keyword": "And "
});
formatter.step({
  "line": 207,
  "name": "a POST request is made to axway endpoint for the group \u0027INDGROUP\u0027",
  "matchedColumns": [
    3
  ],
  "keyword": "When "
});
formatter.step({
  "comments": [
    {
      "line": 208,
      "value": "#Then user should be registered successfully"
    },
    {
      "line": 209,
      "value": "#And APIBanking should be enabled in CADM for the group \u0027\u003cGroupIDA\u003e\u0027"
    },
    {
      "line": 210,
      "value": "#Given user has already generated the JWT token for the group \u0027\u003cGroupIDB\u003e\u0027"
    },
    {
      "line": 211,
      "value": "#When a POST request is made to axway endpoint for the group \u0027\u003cGroupIDB\u003e\u0027"
    },
    {
      "line": 212,
      "value": "#Then user should be registered successfully"
    },
    {
      "line": 213,
      "value": "#And APIBanking should be enabled in CADM for the group \u0027\u003cGroupIDB\u003e\u0027"
    },
    {
      "line": 214,
      "value": "#When user modifies Stub with amount \u0027\u003cAmount\u003e\u0027 account number \u0027\u003cAccountNo\u003e\u0027 transaction type \u0027\u003cCreditDebit\u003e\u0027 Currency Code \u0027INR\u0027 BIC \u0027SCBLINBBXXX\u0027"
    }
  ],
  "line": 215,
  "name": "Recover response should be displayed with amount \u002722.33\u0027 accountNo \u002722205269504\u0027 transactionType \u0027D\u0027 the expected value for the group \u0027INDGROUP\u0027",
  "matchedColumns": [
    0,
    1,
    2,
    3
  ],
  "keyword": "Then "
});
formatter.step({
  "line": 216,
  "name": "Consume response should be displayed with amount \u002766\u0027 accountNo \u002722205269504\u0027 transactionType \u0027D\u0027 the expected value for the group \u0027INDGRP\u0027",
  "matchedColumns": [
    1,
    2,
    4,
    5
  ],
  "keyword": "Then "
});
formatter.match({
  "arguments": [
    {
      "val": "activationKey and activate",
      "offset": 1
    }
  ],
  "location": "commonApiMethods.an_API(String)"
});
formatter.result({
  "duration": 192250228,
  "status": "passed"
});
formatter.match({
  "location": "activationKey.user_has_valid_SSL_certificate()"
});
formatter.result({
  "duration": 4842476,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "INDGROUP",
      "offset": 56
    }
  ],
  "location": "activationKey.user_has_already_generated_the_JWT_token_for_the_group(String)"
});
formatter.result({
  "duration": 516187082,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "INDGROUP",
      "offset": 56
    }
  ],
  "location": "activationKey.a_POST_request_is_made_to_axway_endpoint(String)"
});
formatter.result({
  "duration": 4452841089,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "22.33",
      "offset": 50
    },
    {
      "val": "22205269504",
      "offset": 68
    },
    {
      "val": "D",
      "offset": 98
    },
    {
      "val": "INDGROUP",
      "offset": 135
    }
  ],
  "location": "PeekAndConsume.recoverValueTest(String,String,String,String)"
});
formatter.result({
  "duration": 885063994,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "66",
      "offset": 50
    },
    {
      "val": "22205269504",
      "offset": 65
    },
    {
      "val": "D",
      "offset": 95
    },
    {
      "val": "INDGRP",
      "offset": 132
    }
  ],
  "location": "PeekAndConsume.consumeValueTest(String,String,String,String)"
});
formatter.result({
  "duration": 1426880891,
  "status": "passed"
});
formatter.before({
  "duration": 17094598,
  "status": "passed"
});
formatter.scenario({
  "line": 220,
  "name": "TC_PULL_008 - When both webhook is down, verify messages for Peek of Group A and Consume of Group B",
  "description": "",
  "id": "pull-mechanism-scenarios;tc-pull-008---when-both-webhook-is-down,-verify-messages-for-peek-of-group-a-and-consume-of-group-b;;3",
  "type": "scenario",
  "keyword": "Scenario Outline",
  "tags": [
    {
      "line": 200,
      "name": "@ab"
    },
    {
      "line": 200,
      "name": "@peekAndConsume"
    },
    {
      "line": 200,
      "name": "@pull8"
    },
    {
      "line": 200,
      "name": "@regression"
    },
    {
      "line": 200,
      "name": "@pull"
    }
  ]
});
formatter.step({
  "comments": [
    {
      "line": 202,
      "value": "#When Add Group Services of CADM is called for the group \u0027\u003cGroupID\u003e\u0027 to disable the group"
    },
    {
      "line": 203,
      "value": "#Then APIBanking should be disabled in CADM for the group \u0027\u003cGroupID\u003e\u0027"
    }
  ],
  "line": 204,
  "name": "\u0027activationKey and activate\u0027 API",
  "keyword": "Given "
});
formatter.step({
  "line": 205,
  "name": "user has valid SSL certificate",
  "keyword": "And "
});
formatter.step({
  "line": 206,
  "name": "user has already generated the JWT token for the group \u0027INDGROUP\u0027",
  "matchedColumns": [
    3
  ],
  "keyword": "And "
});
formatter.step({
  "line": 207,
  "name": "a POST request is made to axway endpoint for the group \u0027INDGROUP\u0027",
  "matchedColumns": [
    3
  ],
  "keyword": "When "
});
formatter.step({
  "comments": [
    {
      "line": 208,
      "value": "#Then user should be registered successfully"
    },
    {
      "line": 209,
      "value": "#And APIBanking should be enabled in CADM for the group \u0027\u003cGroupIDA\u003e\u0027"
    },
    {
      "line": 210,
      "value": "#Given user has already generated the JWT token for the group \u0027\u003cGroupIDB\u003e\u0027"
    },
    {
      "line": 211,
      "value": "#When a POST request is made to axway endpoint for the group \u0027\u003cGroupIDB\u003e\u0027"
    },
    {
      "line": 212,
      "value": "#Then user should be registered successfully"
    },
    {
      "line": 213,
      "value": "#And APIBanking should be enabled in CADM for the group \u0027\u003cGroupIDB\u003e\u0027"
    },
    {
      "line": 214,
      "value": "#When user modifies Stub with amount \u0027\u003cAmount\u003e\u0027 account number \u0027\u003cAccountNo\u003e\u0027 transaction type \u0027\u003cCreditDebit\u003e\u0027 Currency Code \u0027INR\u0027 BIC \u0027SCBLINBBXXX\u0027"
    }
  ],
  "line": 215,
  "name": "Recover response should be displayed with amount \u002722.33\u0027 accountNo \u002722205269504\u0027 transactionType \u0027D\u0027 the expected value for the group \u0027INDGROUP\u0027",
  "matchedColumns": [
    0,
    1,
    2,
    3
  ],
  "keyword": "Then "
});
formatter.step({
  "line": 216,
  "name": "Consume response should be displayed with amount \u002766\u0027 accountNo \u002722205269504\u0027 transactionType \u0027D\u0027 the expected value for the group \u0027INDGROUP\u0027",
  "matchedColumns": [
    1,
    2,
    4,
    5
  ],
  "keyword": "Then "
});
formatter.match({
  "arguments": [
    {
      "val": "activationKey and activate",
      "offset": 1
    }
  ],
  "location": "commonApiMethods.an_API(String)"
});
formatter.result({
  "duration": 210313,
  "status": "passed"
});
formatter.match({
  "location": "activationKey.user_has_valid_SSL_certificate()"
});
formatter.result({
  "duration": 5052410,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "INDGROUP",
      "offset": 56
    }
  ],
  "location": "activationKey.user_has_already_generated_the_JWT_token_for_the_group(String)"
});
formatter.result({
  "duration": 35196204,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "INDGROUP",
      "offset": 56
    }
  ],
  "location": "activationKey.a_POST_request_is_made_to_axway_endpoint(String)"
});
formatter.result({
  "duration": 3398071845,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "22.33",
      "offset": 50
    },
    {
      "val": "22205269504",
      "offset": 68
    },
    {
      "val": "D",
      "offset": 98
    },
    {
      "val": "INDGROUP",
      "offset": 135
    }
  ],
  "location": "PeekAndConsume.recoverValueTest(String,String,String,String)"
});
formatter.result({
  "duration": 1013036736,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "66",
      "offset": 50
    },
    {
      "val": "22205269504",
      "offset": 65
    },
    {
      "val": "D",
      "offset": 95
    },
    {
      "val": "INDGROUP",
      "offset": 132
    }
  ],
  "location": "PeekAndConsume.consumeValueTest(String,String,String,String)"
});
formatter.result({
  "duration": 1080469665,
  "status": "passed"
});
});