$(document).ready(function() {var formatter = new CucumberHTML.DOMFormatter($('.cucumber-report'));formatter.uri("features/api/pull.feature");
formatter.feature({
  "line": 1,
  "name": "Pull Mechanism scenarios",
  "description": "",
  "id": "pull-mechanism-scenarios",
  "keyword": "Feature"
});
formatter.scenarioOutline({
  "line": 27,
  "name": "TC_PULL_002 - When both webhook is down, verify messages for Peek of Group A and Consume of Group B",
  "description": "",
  "id": "pull-mechanism-scenarios;tc-pull-002---when-both-webhook-is-down,-verify-messages-for-peek-of-group-a-and-consume-of-group-b",
  "type": "scenario_outline",
  "keyword": "Scenario Outline",
  "tags": [
    {
      "line": 26,
      "name": "@ab"
    },
    {
      "line": 26,
      "name": "@peekAndConsume"
    },
    {
      "line": 26,
      "name": "@regression"
    },
    {
      "line": 26,
      "name": "@pull"
    },
    {
      "line": 26,
      "name": "@pull2"
    }
  ]
});
formatter.step({
  "comments": [
    {
      "line": 28,
      "value": "#When Add Group Services of CADM is called for the group \u0027\u003cGroupID\u003e\u0027 to disable the group"
    },
    {
      "line": 29,
      "value": "#Then APIBanking should be disabled in CADM for the group \u0027\u003cGroupID\u003e\u0027"
    }
  ],
  "line": 30,
  "name": "\u0027activationKey and activate\u0027 API",
  "keyword": "Given "
});
formatter.step({
  "comments": [
    {
      "line": 31,
      "value": "#And user has valid SSL certificate"
    }
  ],
  "line": 32,
  "name": "user has already generated the JWT token for the group \u0027\u003cGroupIDA\u003e\u0027",
  "keyword": "And "
});
formatter.step({
  "line": 33,
  "name": "a POST request is made to axway endpoint for the group \u0027\u003cGroupIDA\u003e\u0027",
  "keyword": "When "
});
formatter.step({
  "comments": [
    {
      "line": 34,
      "value": "#Then user should be registered successfully"
    },
    {
      "line": 35,
      "value": "#And APIBanking should be enabled in CADM for the group \u0027\u003cGroupIDA\u003e\u0027"
    },
    {
      "line": 36,
      "value": "#Given user has already generated the JWT token for the group \u0027\u003cGroupIDB\u003e\u0027"
    },
    {
      "line": 37,
      "value": "#When a POST request is made to axway endpoint for the group \u0027\u003cGroupIDB\u003e\u0027"
    },
    {
      "line": 38,
      "value": "#Then user should be registered successfully"
    },
    {
      "line": 39,
      "value": "#And APIBanking should be enabled in CADM for the group \u0027\u003cGroupIDB\u003e\u0027"
    },
    {
      "line": 40,
      "value": "#When user modifies Stub with amount \u0027\u003cAmount\u003e\u0027 account number \u0027\u003cAccountNo\u003e\u0027 transaction type \u0027\u003cCreditDebit\u003e\u0027 Currency Code \u0027INR\u0027 BIC \u0027SCBLINBBXXX\u0027"
    }
  ],
  "line": 41,
  "name": "Peek response should be displayed with amount \u0027\u003cAmount\u003e\u0027 accountNo \u0027\u003cAccountNo\u003e\u0027 transactionType \u0027\u003cCreditDebit\u003e\u0027 the expected value for the group \u0027\u003cGroupIDA\u003e\u0027",
  "keyword": "Then "
});
formatter.step({
  "line": 42,
  "name": "Consume response should be displayed with amount \u0027\u003cAmount\u003e\u0027 accountNo \u0027\u003cAccountNo\u003e\u0027 transactionType \u0027\u003cCreditDebit\u003e\u0027 the expected value for the group \u0027\u003cGroupIDB\u003e\u0027",
  "keyword": "Then "
});
formatter.examples({
  "line": 43,
  "name": "",
  "description": "",
  "id": "pull-mechanism-scenarios;tc-pull-002---when-both-webhook-is-down,-verify-messages-for-peek-of-group-a-and-consume-of-group-b;",
  "rows": [
    {
      "cells": [
        "Amount",
        "AccountNo",
        "CreditDebit",
        "GroupIDA",
        "GroupIDB"
      ],
      "line": 44,
      "id": "pull-mechanism-scenarios;tc-pull-002---when-both-webhook-is-down,-verify-messages-for-peek-of-group-a-and-consume-of-group-b;;1"
    },
    {
      "cells": [
        "8998",
        "22205269504",
        "C",
        "INDGROUP",
        "INDGRP"
      ],
      "line": 45,
      "id": "pull-mechanism-scenarios;tc-pull-002---when-both-webhook-is-down,-verify-messages-for-peek-of-group-a-and-consume-of-group-b;;2"
    },
    {
      "cells": [
        "8998",
        "22205269504",
        "C",
        "INDGRP",
        "INDGROUP"
      ],
      "line": 46,
      "id": "pull-mechanism-scenarios;tc-pull-002---when-both-webhook-is-down,-verify-messages-for-peek-of-group-a-and-consume-of-group-b;;3"
    }
  ],
  "keyword": "Examples"
});
formatter.before({
  "duration": 514872346,
  "status": "passed"
});
formatter.scenario({
  "line": 45,
  "name": "TC_PULL_002 - When both webhook is down, verify messages for Peek of Group A and Consume of Group B",
  "description": "",
  "id": "pull-mechanism-scenarios;tc-pull-002---when-both-webhook-is-down,-verify-messages-for-peek-of-group-a-and-consume-of-group-b;;2",
  "type": "scenario",
  "keyword": "Scenario Outline",
  "tags": [
    {
      "line": 26,
      "name": "@ab"
    },
    {
      "line": 26,
      "name": "@peekAndConsume"
    },
    {
      "line": 26,
      "name": "@regression"
    },
    {
      "line": 26,
      "name": "@pull2"
    },
    {
      "line": 26,
      "name": "@pull"
    }
  ]
});
formatter.step({
  "comments": [
    {
      "line": 28,
      "value": "#When Add Group Services of CADM is called for the group \u0027\u003cGroupID\u003e\u0027 to disable the group"
    },
    {
      "line": 29,
      "value": "#Then APIBanking should be disabled in CADM for the group \u0027\u003cGroupID\u003e\u0027"
    }
  ],
  "line": 30,
  "name": "\u0027activationKey and activate\u0027 API",
  "keyword": "Given "
});
formatter.step({
  "comments": [
    {
      "line": 31,
      "value": "#And user has valid SSL certificate"
    }
  ],
  "line": 32,
  "name": "user has already generated the JWT token for the group \u0027INDGROUP\u0027",
  "matchedColumns": [
    3
  ],
  "keyword": "And "
});
formatter.step({
  "line": 33,
  "name": "a POST request is made to axway endpoint for the group \u0027INDGROUP\u0027",
  "matchedColumns": [
    3
  ],
  "keyword": "When "
});
formatter.step({
  "comments": [
    {
      "line": 34,
      "value": "#Then user should be registered successfully"
    },
    {
      "line": 35,
      "value": "#And APIBanking should be enabled in CADM for the group \u0027\u003cGroupIDA\u003e\u0027"
    },
    {
      "line": 36,
      "value": "#Given user has already generated the JWT token for the group \u0027\u003cGroupIDB\u003e\u0027"
    },
    {
      "line": 37,
      "value": "#When a POST request is made to axway endpoint for the group \u0027\u003cGroupIDB\u003e\u0027"
    },
    {
      "line": 38,
      "value": "#Then user should be registered successfully"
    },
    {
      "line": 39,
      "value": "#And APIBanking should be enabled in CADM for the group \u0027\u003cGroupIDB\u003e\u0027"
    },
    {
      "line": 40,
      "value": "#When user modifies Stub with amount \u0027\u003cAmount\u003e\u0027 account number \u0027\u003cAccountNo\u003e\u0027 transaction type \u0027\u003cCreditDebit\u003e\u0027 Currency Code \u0027INR\u0027 BIC \u0027SCBLINBBXXX\u0027"
    }
  ],
  "line": 41,
  "name": "Peek response should be displayed with amount \u00278998\u0027 accountNo \u002722205269504\u0027 transactionType \u0027C\u0027 the expected value for the group \u0027INDGROUP\u0027",
  "matchedColumns": [
    0,
    1,
    2,
    3
  ],
  "keyword": "Then "
});
formatter.step({
  "line": 42,
  "name": "Consume response should be displayed with amount \u00278998\u0027 accountNo \u002722205269504\u0027 transactionType \u0027C\u0027 the expected value for the group \u0027INDGRP\u0027",
  "matchedColumns": [
    0,
    1,
    2,
    4
  ],
  "keyword": "Then "
});
formatter.match({
  "arguments": [
    {
      "val": "activationKey and activate",
      "offset": 1
    }
  ],
  "location": "commonApiMethods.an_API(String)"
});
formatter.result({
  "duration": 194172491,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "INDGROUP",
      "offset": 56
    }
  ],
  "location": "activationKey.user_has_already_generated_the_JWT_token_for_the_group(String)"
});
formatter.result({
  "duration": 530204774,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "INDGROUP",
      "offset": 56
    }
  ],
  "location": "activationKey.a_POST_request_is_made_to_axway_endpoint(String)"
});
formatter.result({
  "duration": 4389213797,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "8998",
      "offset": 47
    },
    {
      "val": "22205269504",
      "offset": 64
    },
    {
      "val": "C",
      "offset": 94
    },
    {
      "val": "INDGROUP",
      "offset": 131
    }
  ],
  "location": "PeekAndConsume.peekValueTest(String,String,String,String)"
});
formatter.result({
  "duration": 1123014349,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "8998",
      "offset": 50
    },
    {
      "val": "22205269504",
      "offset": 67
    },
    {
      "val": "C",
      "offset": 97
    },
    {
      "val": "INDGRP",
      "offset": 134
    }
  ],
  "location": "PeekAndConsume.consumeValueTest(String,String,String,String)"
});
formatter.result({
  "duration": 864813198,
  "status": "passed"
});
formatter.before({
  "duration": 26712339,
  "status": "passed"
});
formatter.scenario({
  "line": 46,
  "name": "TC_PULL_002 - When both webhook is down, verify messages for Peek of Group A and Consume of Group B",
  "description": "",
  "id": "pull-mechanism-scenarios;tc-pull-002---when-both-webhook-is-down,-verify-messages-for-peek-of-group-a-and-consume-of-group-b;;3",
  "type": "scenario",
  "keyword": "Scenario Outline",
  "tags": [
    {
      "line": 26,
      "name": "@ab"
    },
    {
      "line": 26,
      "name": "@peekAndConsume"
    },
    {
      "line": 26,
      "name": "@regression"
    },
    {
      "line": 26,
      "name": "@pull2"
    },
    {
      "line": 26,
      "name": "@pull"
    }
  ]
});
formatter.step({
  "comments": [
    {
      "line": 28,
      "value": "#When Add Group Services of CADM is called for the group \u0027\u003cGroupID\u003e\u0027 to disable the group"
    },
    {
      "line": 29,
      "value": "#Then APIBanking should be disabled in CADM for the group \u0027\u003cGroupID\u003e\u0027"
    }
  ],
  "line": 30,
  "name": "\u0027activationKey and activate\u0027 API",
  "keyword": "Given "
});
formatter.step({
  "comments": [
    {
      "line": 31,
      "value": "#And user has valid SSL certificate"
    }
  ],
  "line": 32,
  "name": "user has already generated the JWT token for the group \u0027INDGRP\u0027",
  "matchedColumns": [
    3
  ],
  "keyword": "And "
});
formatter.step({
  "line": 33,
  "name": "a POST request is made to axway endpoint for the group \u0027INDGRP\u0027",
  "matchedColumns": [
    3
  ],
  "keyword": "When "
});
formatter.step({
  "comments": [
    {
      "line": 34,
      "value": "#Then user should be registered successfully"
    },
    {
      "line": 35,
      "value": "#And APIBanking should be enabled in CADM for the group \u0027\u003cGroupIDA\u003e\u0027"
    },
    {
      "line": 36,
      "value": "#Given user has already generated the JWT token for the group \u0027\u003cGroupIDB\u003e\u0027"
    },
    {
      "line": 37,
      "value": "#When a POST request is made to axway endpoint for the group \u0027\u003cGroupIDB\u003e\u0027"
    },
    {
      "line": 38,
      "value": "#Then user should be registered successfully"
    },
    {
      "line": 39,
      "value": "#And APIBanking should be enabled in CADM for the group \u0027\u003cGroupIDB\u003e\u0027"
    },
    {
      "line": 40,
      "value": "#When user modifies Stub with amount \u0027\u003cAmount\u003e\u0027 account number \u0027\u003cAccountNo\u003e\u0027 transaction type \u0027\u003cCreditDebit\u003e\u0027 Currency Code \u0027INR\u0027 BIC \u0027SCBLINBBXXX\u0027"
    }
  ],
  "line": 41,
  "name": "Peek response should be displayed with amount \u00278998\u0027 accountNo \u002722205269504\u0027 transactionType \u0027C\u0027 the expected value for the group \u0027INDGRP\u0027",
  "matchedColumns": [
    0,
    1,
    2,
    3
  ],
  "keyword": "Then "
});
formatter.step({
  "line": 42,
  "name": "Consume response should be displayed with amount \u00278998\u0027 accountNo \u002722205269504\u0027 transactionType \u0027C\u0027 the expected value for the group \u0027INDGROUP\u0027",
  "matchedColumns": [
    0,
    1,
    2,
    4
  ],
  "keyword": "Then "
});
formatter.match({
  "arguments": [
    {
      "val": "activationKey and activate",
      "offset": 1
    }
  ],
  "location": "commonApiMethods.an_API(String)"
});
formatter.result({
  "duration": 121581,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "INDGRP",
      "offset": 56
    }
  ],
  "location": "activationKey.user_has_already_generated_the_JWT_token_for_the_group(String)"
});
formatter.result({
  "duration": 24679444,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "INDGRP",
      "offset": 56
    }
  ],
  "location": "activationKey.a_POST_request_is_made_to_axway_endpoint(String)"
});
formatter.result({
  "duration": 2348577030,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "8998",
      "offset": 47
    },
    {
      "val": "22205269504",
      "offset": 64
    },
    {
      "val": "C",
      "offset": 94
    },
    {
      "val": "INDGRP",
      "offset": 131
    }
  ],
  "location": "PeekAndConsume.peekValueTest(String,String,String,String)"
});
formatter.result({
  "duration": 1385563723,
  "error_message": "java.lang.AssertionError: Peek Response is not displayed as expected. Expected Response - [{\"groupId\":\"INDGRP\",\"transactionIdentifier\":{\"type\":\"Other\",\"identifiercreditDate\":\"2015-11-16\",\"accountIdentifier\":{\"accountId\":\"22205269504\",\"currencyCode\":{\"isoCode\":\"INR\"},\"bankCode\":\"SCBLINBBXXX\"},\"debitDate\":\"2015-11-16\",\"adviceType\":\"Credit\",\"transactionCode\":null,\"transactionDescription\":\"UPIPAY-SCBAccttoBeneAcctSCB\u0026Non-SCB-DR\",\"postExecutionBalance\":{\"currencyCode\":\"INR\",\"amount\":99803990},\"preExecutionBalance\":{\"currencyCode\":\"INR\",\"amount\":99794992},\"transactionFreeText\":[\"UPI/715615346607/\",\"UPICYCLE2/SIVAAACHEN@SCBL/\",\"75110011017/EMAILSLOWNESS/\",\"123-13123-13123\"],\"transactionAmount\":{\"currencyCode\":\"INR\",\"amount\":8998},\"clientIdentifier\":{\"type\":\"Other\",\"identifier\":\"\"},\"externalIdentifier\":{\"type\":\"Other\",\"identifier\":\"\"}}]. Actual Response - ]\r\n\tat org.junit.Assert.fail(Assert.java:88)\r\n\tat org.junit.Assert.assertTrue(Assert.java:41)\r\n\tat ab.glue.api.PeekAndConsume.peekValueTest(PeekAndConsume.java:80)\r\n\tat ✽.Then Peek response should be displayed with amount \u00278998\u0027 accountNo \u002722205269504\u0027 transactionType \u0027C\u0027 the expected value for the group \u0027INDGRP\u0027(features/api/pull.feature:41)\r\n",
  "status": "failed"
});
formatter.match({
  "arguments": [
    {
      "val": "8998",
      "offset": 50
    },
    {
      "val": "22205269504",
      "offset": 67
    },
    {
      "val": "C",
      "offset": 97
    },
    {
      "val": "INDGROUP",
      "offset": 134
    }
  ],
  "location": "PeekAndConsume.consumeValueTest(String,String,String,String)"
});
formatter.result({
  "status": "skipped"
});
});