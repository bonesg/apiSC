$(document).ready(function() {var formatter = new CucumberHTML.DOMFormatter($('.cucumber-report'));formatter.uri("features/api/pull.feature");
formatter.feature({
  "line": 1,
  "name": "Pull Mechanism scenarios",
  "description": "",
  "id": "pull-mechanism-scenarios",
  "keyword": "Feature"
});
formatter.scenarioOutline({
  "line": 223,
  "name": "TC_PULL_009 - When both webhook is down, verify messages for Peek of Group A and Recover of Group B",
  "description": "",
  "id": "pull-mechanism-scenarios;tc-pull-009---when-both-webhook-is-down,-verify-messages-for-peek-of-group-a-and-recover-of-group-b",
  "type": "scenario_outline",
  "keyword": "Scenario Outline",
  "tags": [
    {
      "line": 222,
      "name": "@ab"
    },
    {
      "line": 222,
      "name": "@peekAndConsume"
    },
    {
      "line": 222,
      "name": "@regression"
    },
    {
      "line": 222,
      "name": "@pull"
    },
    {
      "line": 222,
      "name": "@pull9"
    }
  ]
});
formatter.step({
  "comments": [
    {
      "line": 224,
      "value": "#When Add Group Services of CADM is called for the group \u0027\u003cGroupID\u003e\u0027 to disable the group"
    },
    {
      "line": 225,
      "value": "#Then APIBanking should be disabled in CADM for the group \u0027\u003cGroupID\u003e\u0027"
    }
  ],
  "line": 226,
  "name": "\u0027activationKey and activate\u0027 API",
  "keyword": "Given "
});
formatter.step({
  "line": 227,
  "name": "user has valid SSL certificate",
  "keyword": "And "
});
formatter.step({
  "line": 228,
  "name": "user has already generated the JWT token for the group \u0027\u003cGroupIDA\u003e\u0027",
  "keyword": "And "
});
formatter.step({
  "line": 229,
  "name": "a POST request is made to axway endpoint for the group \u0027\u003cGroupIDA\u003e\u0027",
  "keyword": "When "
});
formatter.step({
  "comments": [
    {
      "line": 230,
      "value": "#Then user should be registered successfully"
    },
    {
      "line": 231,
      "value": "#And APIBanking should be enabled in CADM for the group \u0027\u003cGroupIDA\u003e\u0027"
    },
    {
      "line": 232,
      "value": "#Given user has already generated the JWT token for the group \u0027\u003cGroupIDB\u003e\u0027"
    },
    {
      "line": 233,
      "value": "#When a POST request is made to axway endpoint for the group \u0027\u003cGroupIDB\u003e\u0027"
    },
    {
      "line": 234,
      "value": "#Then user should be registered successfully"
    },
    {
      "line": 235,
      "value": "# And APIBanking should be enabled in CADM for the group \u0027\u003cGroupIDB\u003e\u0027"
    },
    {
      "line": 236,
      "value": "#When user modifies Stub with amount \u0027\u003cAmount\u003e\u0027 account number \u0027\u003cAccountNo\u003e\u0027 transaction type \u0027\u003cCreditDebit\u003e\u0027 Currency Code \u0027INR\u0027 BIC \u0027SCBLINBBXXX\u0027"
    }
  ],
  "line": 237,
  "name": "Recover response should be displayed with amount \u0027\u003cAmount\u003e\u0027 accountNo \u0027\u003cAccountNo\u003e\u0027 transactionType \u0027\u003cCreditDebit\u003e\u0027 the expected value for the group \u0027\u003cGroupIDA\u003e\u0027",
  "keyword": "Then "
});
formatter.step({
  "line": 238,
  "name": "Recover response should be displayed with amount \u0027\u003cAmount\u003e\u0027 accountNo \u0027\u003cAccountNo\u003e\u0027 transactionType \u0027\u003cCreditDebit\u003e\u0027 the expected value for the group \u0027\u003cGroupIDB\u003e\u0027",
  "keyword": "Then "
});
formatter.examples({
  "line": 239,
  "name": "",
  "description": "",
  "id": "pull-mechanism-scenarios;tc-pull-009---when-both-webhook-is-down,-verify-messages-for-peek-of-group-a-and-recover-of-group-b;",
  "rows": [
    {
      "cells": [
        "Amount",
        "AccountNo",
        "CreditDebit",
        "GroupIDA",
        "GroupIDB"
      ],
      "line": 240,
      "id": "pull-mechanism-scenarios;tc-pull-009---when-both-webhook-is-down,-verify-messages-for-peek-of-group-a-and-recover-of-group-b;;1"
    },
    {
      "cells": [
        "66",
        "22205269504",
        "D",
        "INDGROUP",
        "INDGRP"
      ],
      "line": 241,
      "id": "pull-mechanism-scenarios;tc-pull-009---when-both-webhook-is-down,-verify-messages-for-peek-of-group-a-and-recover-of-group-b;;2"
    },
    {
      "cells": [
        "66",
        "22205269504",
        "D",
        "INDGROUP",
        "INDGROUP"
      ],
      "line": 242,
      "id": "pull-mechanism-scenarios;tc-pull-009---when-both-webhook-is-down,-verify-messages-for-peek-of-group-a-and-recover-of-group-b;;3"
    }
  ],
  "keyword": "Examples"
});
formatter.before({
  "duration": 482285603,
  "status": "passed"
});
formatter.scenario({
  "line": 241,
  "name": "TC_PULL_009 - When both webhook is down, verify messages for Peek of Group A and Recover of Group B",
  "description": "",
  "id": "pull-mechanism-scenarios;tc-pull-009---when-both-webhook-is-down,-verify-messages-for-peek-of-group-a-and-recover-of-group-b;;2",
  "type": "scenario",
  "keyword": "Scenario Outline",
  "tags": [
    {
      "line": 222,
      "name": "@ab"
    },
    {
      "line": 222,
      "name": "@peekAndConsume"
    },
    {
      "line": 222,
      "name": "@pull9"
    },
    {
      "line": 222,
      "name": "@regression"
    },
    {
      "line": 222,
      "name": "@pull"
    }
  ]
});
formatter.step({
  "comments": [
    {
      "line": 224,
      "value": "#When Add Group Services of CADM is called for the group \u0027\u003cGroupID\u003e\u0027 to disable the group"
    },
    {
      "line": 225,
      "value": "#Then APIBanking should be disabled in CADM for the group \u0027\u003cGroupID\u003e\u0027"
    }
  ],
  "line": 226,
  "name": "\u0027activationKey and activate\u0027 API",
  "keyword": "Given "
});
formatter.step({
  "line": 227,
  "name": "user has valid SSL certificate",
  "keyword": "And "
});
formatter.step({
  "line": 228,
  "name": "user has already generated the JWT token for the group \u0027INDGROUP\u0027",
  "matchedColumns": [
    3
  ],
  "keyword": "And "
});
formatter.step({
  "line": 229,
  "name": "a POST request is made to axway endpoint for the group \u0027INDGROUP\u0027",
  "matchedColumns": [
    3
  ],
  "keyword": "When "
});
formatter.step({
  "comments": [
    {
      "line": 230,
      "value": "#Then user should be registered successfully"
    },
    {
      "line": 231,
      "value": "#And APIBanking should be enabled in CADM for the group \u0027\u003cGroupIDA\u003e\u0027"
    },
    {
      "line": 232,
      "value": "#Given user has already generated the JWT token for the group \u0027\u003cGroupIDB\u003e\u0027"
    },
    {
      "line": 233,
      "value": "#When a POST request is made to axway endpoint for the group \u0027\u003cGroupIDB\u003e\u0027"
    },
    {
      "line": 234,
      "value": "#Then user should be registered successfully"
    },
    {
      "line": 235,
      "value": "# And APIBanking should be enabled in CADM for the group \u0027\u003cGroupIDB\u003e\u0027"
    },
    {
      "line": 236,
      "value": "#When user modifies Stub with amount \u0027\u003cAmount\u003e\u0027 account number \u0027\u003cAccountNo\u003e\u0027 transaction type \u0027\u003cCreditDebit\u003e\u0027 Currency Code \u0027INR\u0027 BIC \u0027SCBLINBBXXX\u0027"
    }
  ],
  "line": 237,
  "name": "Recover response should be displayed with amount \u002766\u0027 accountNo \u002722205269504\u0027 transactionType \u0027D\u0027 the expected value for the group \u0027INDGROUP\u0027",
  "matchedColumns": [
    0,
    1,
    2,
    3
  ],
  "keyword": "Then "
});
formatter.step({
  "line": 238,
  "name": "Recover response should be displayed with amount \u002766\u0027 accountNo \u002722205269504\u0027 transactionType \u0027D\u0027 the expected value for the group \u0027INDGRP\u0027",
  "matchedColumns": [
    0,
    1,
    2,
    4
  ],
  "keyword": "Then "
});
formatter.match({
  "arguments": [
    {
      "val": "activationKey and activate",
      "offset": 1
    }
  ],
  "location": "commonApiMethods.an_API(String)"
});
formatter.result({
  "duration": 200009137,
  "status": "passed"
});
formatter.match({
  "location": "activationKey.user_has_valid_SSL_certificate()"
});
formatter.result({
  "duration": 4984823,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "INDGROUP",
      "offset": 56
    }
  ],
  "location": "activationKey.user_has_already_generated_the_JWT_token_for_the_group(String)"
});
formatter.result({
  "duration": 497733193,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "INDGROUP",
      "offset": 56
    }
  ],
  "location": "activationKey.a_POST_request_is_made_to_axway_endpoint(String)"
});
formatter.result({
  "duration": 4276960127,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "66",
      "offset": 50
    },
    {
      "val": "22205269504",
      "offset": 65
    },
    {
      "val": "D",
      "offset": 95
    },
    {
      "val": "INDGROUP",
      "offset": 132
    }
  ],
  "location": "PeekAndConsume.recoverValueTest(String,String,String,String)"
});
formatter.result({
  "duration": 983048505,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "66",
      "offset": 50
    },
    {
      "val": "22205269504",
      "offset": 65
    },
    {
      "val": "D",
      "offset": 95
    },
    {
      "val": "INDGRP",
      "offset": 132
    }
  ],
  "location": "PeekAndConsume.recoverValueTest(String,String,String,String)"
});
formatter.result({
  "duration": 1225104297,
  "status": "passed"
});
formatter.before({
  "duration": 26556020,
  "status": "passed"
});
formatter.scenario({
  "line": 242,
  "name": "TC_PULL_009 - When both webhook is down, verify messages for Peek of Group A and Recover of Group B",
  "description": "",
  "id": "pull-mechanism-scenarios;tc-pull-009---when-both-webhook-is-down,-verify-messages-for-peek-of-group-a-and-recover-of-group-b;;3",
  "type": "scenario",
  "keyword": "Scenario Outline",
  "tags": [
    {
      "line": 222,
      "name": "@ab"
    },
    {
      "line": 222,
      "name": "@peekAndConsume"
    },
    {
      "line": 222,
      "name": "@pull9"
    },
    {
      "line": 222,
      "name": "@regression"
    },
    {
      "line": 222,
      "name": "@pull"
    }
  ]
});
formatter.step({
  "comments": [
    {
      "line": 224,
      "value": "#When Add Group Services of CADM is called for the group \u0027\u003cGroupID\u003e\u0027 to disable the group"
    },
    {
      "line": 225,
      "value": "#Then APIBanking should be disabled in CADM for the group \u0027\u003cGroupID\u003e\u0027"
    }
  ],
  "line": 226,
  "name": "\u0027activationKey and activate\u0027 API",
  "keyword": "Given "
});
formatter.step({
  "line": 227,
  "name": "user has valid SSL certificate",
  "keyword": "And "
});
formatter.step({
  "line": 228,
  "name": "user has already generated the JWT token for the group \u0027INDGROUP\u0027",
  "matchedColumns": [
    3
  ],
  "keyword": "And "
});
formatter.step({
  "line": 229,
  "name": "a POST request is made to axway endpoint for the group \u0027INDGROUP\u0027",
  "matchedColumns": [
    3
  ],
  "keyword": "When "
});
formatter.step({
  "comments": [
    {
      "line": 230,
      "value": "#Then user should be registered successfully"
    },
    {
      "line": 231,
      "value": "#And APIBanking should be enabled in CADM for the group \u0027\u003cGroupIDA\u003e\u0027"
    },
    {
      "line": 232,
      "value": "#Given user has already generated the JWT token for the group \u0027\u003cGroupIDB\u003e\u0027"
    },
    {
      "line": 233,
      "value": "#When a POST request is made to axway endpoint for the group \u0027\u003cGroupIDB\u003e\u0027"
    },
    {
      "line": 234,
      "value": "#Then user should be registered successfully"
    },
    {
      "line": 235,
      "value": "# And APIBanking should be enabled in CADM for the group \u0027\u003cGroupIDB\u003e\u0027"
    },
    {
      "line": 236,
      "value": "#When user modifies Stub with amount \u0027\u003cAmount\u003e\u0027 account number \u0027\u003cAccountNo\u003e\u0027 transaction type \u0027\u003cCreditDebit\u003e\u0027 Currency Code \u0027INR\u0027 BIC \u0027SCBLINBBXXX\u0027"
    }
  ],
  "line": 237,
  "name": "Recover response should be displayed with amount \u002766\u0027 accountNo \u002722205269504\u0027 transactionType \u0027D\u0027 the expected value for the group \u0027INDGROUP\u0027",
  "matchedColumns": [
    0,
    1,
    2,
    3
  ],
  "keyword": "Then "
});
formatter.step({
  "line": 238,
  "name": "Recover response should be displayed with amount \u002766\u0027 accountNo \u002722205269504\u0027 transactionType \u0027D\u0027 the expected value for the group \u0027INDGROUP\u0027",
  "matchedColumns": [
    0,
    1,
    2,
    4
  ],
  "keyword": "Then "
});
formatter.match({
  "arguments": [
    {
      "val": "activationKey and activate",
      "offset": 1
    }
  ],
  "location": "commonApiMethods.an_API(String)"
});
formatter.result({
  "duration": 178596,
  "status": "passed"
});
formatter.match({
  "location": "activationKey.user_has_valid_SSL_certificate()"
});
formatter.result({
  "duration": 1204860,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "INDGROUP",
      "offset": 56
    }
  ],
  "location": "activationKey.user_has_already_generated_the_JWT_token_for_the_group(String)"
});
formatter.result({
  "duration": 19436732,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "INDGROUP",
      "offset": 56
    }
  ],
  "location": "activationKey.a_POST_request_is_made_to_axway_endpoint(String)"
});
formatter.result({
  "duration": 2342302768,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "66",
      "offset": 50
    },
    {
      "val": "22205269504",
      "offset": 65
    },
    {
      "val": "D",
      "offset": 95
    },
    {
      "val": "INDGROUP",
      "offset": 132
    }
  ],
  "location": "PeekAndConsume.recoverValueTest(String,String,String,String)"
});
formatter.result({
  "duration": 869971330,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "66",
      "offset": 50
    },
    {
      "val": "22205269504",
      "offset": 65
    },
    {
      "val": "D",
      "offset": 95
    },
    {
      "val": "INDGROUP",
      "offset": 132
    }
  ],
  "location": "PeekAndConsume.recoverValueTest(String,String,String,String)"
});
formatter.result({
  "duration": 1255958698,
  "status": "passed"
});
});