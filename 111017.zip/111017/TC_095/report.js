$(document).ready(function() {var formatter = new CucumberHTML.DOMFormatter($('.cucumber-report'));formatter.uri("features/api/encryption.feature");
formatter.feature({
  "line": 1,
  "name": "Encryption scenario",
  "description": "",
  "id": "encryption-scenario",
  "keyword": "Feature"
});
formatter.scenarioOutline({
  "line": 4,
  "name": "Verify Encrypted Value displayed for Pull requests. On decrypting the value with correct private key expected message should be displayed",
  "description": "",
  "id": "encryption-scenario;verify-encrypted-value-displayed-for-pull-requests.-on-decrypting-the-value-with-correct-private-key-expected-message-should-be-displayed",
  "type": "scenario_outline",
  "keyword": "Scenario Outline",
  "tags": [
    {
      "line": 3,
      "name": "@ab"
    },
    {
      "line": 3,
      "name": "@peekAndConsume"
    },
    {
      "line": 3,
      "name": "@regression"
    },
    {
      "line": 3,
      "name": "@encryption"
    }
  ]
});
formatter.step({
  "comments": [
    {
      "line": 5,
      "value": "#Given \u0027activationKey and activate\u0027 API"
    },
    {
      "line": 6,
      "value": "#And user has valid SSL certificate"
    },
    {
      "line": 7,
      "value": "#And user has already generated the JWT token for the group \u0027\u003cGroupID\u003e\u0027"
    },
    {
      "line": 8,
      "value": "#When Add Group Services of CADM is called for the group \u0027\u003cGroupID\u003e\u0027 to disable the group"
    },
    {
      "line": 9,
      "value": "#Then APIBanking should be disabled in CADM for the group \u0027\u003cGroupID\u003e\u0027"
    },
    {
      "line": 10,
      "value": "#When a POST request is made to axway endpoint for the group \u0027\u003cGroupID\u003e\u0027"
    },
    {
      "line": 11,
      "value": "#Then user should be registered successfully"
    },
    {
      "line": 12,
      "value": "#And APIBanking should be enabled in CADM for the group \u0027\u003cGroupID\u003e\u0027"
    },
    {
      "line": 13,
      "value": "#When user modifies Stub with amount \u0027\u003cAmount\u003e\u0027 account number \u0027\u003cAccountNo\u003e\u0027 transaction type \u0027\u003cCreditDebit\u003e\u0027 Currency Code \u0027INR\u0027 BIC \u0027SCBLINBBXXX\u0027"
    }
  ],
  "line": 14,
  "name": "Peek response should be displayed with encrypted value for amount \u0027\u003cAmount\u003e\u0027 accountNo \u0027\u003cAccountNo\u003e\u0027 transactionType \u0027\u003cCreditDebit\u003e\u0027 the expected value for the group \u0027\u003cGroupID\u003e\u0027",
  "keyword": "Then "
});
formatter.step({
  "line": 15,
  "name": "The messages should be decrypted as expected when using privateKey of group \u0027\u003cGroupID\u003e\u0027 for \u0027peek\u0027",
  "keyword": "And "
});
formatter.step({
  "line": 16,
  "name": "Consume response should be displayed with encrypted value for amount \u0027\u003cAmount\u003e\u0027 accountNo \u0027\u003cAccountNo\u003e\u0027 transactionType \u0027\u003cCreditDebit\u003e\u0027 the expected value for the group \u0027\u003cGroupID\u003e\u0027",
  "keyword": "And "
});
formatter.step({
  "line": 17,
  "name": "The messages should be decrypted as expected when using privateKey of group \u0027\u003cGroupID\u003e\u0027 for \u0027consume\u0027",
  "keyword": "And "
});
formatter.step({
  "line": 18,
  "name": "Recover response should be displayed with encrypted value for amount \u0027\u003cAmount\u003e\u0027 accountNo \u0027\u003cAccountNo\u003e\u0027 transactionType \u0027\u003cCreditDebit\u003e\u0027 the expected value for the group \u0027\u003cGroupID\u003e\u0027",
  "keyword": "And "
});
formatter.step({
  "line": 19,
  "name": "The messages should be decrypted as expected when using privateKey of group \u0027\u003cGroupID\u003e\u0027 for \u0027recover\u0027",
  "keyword": "And "
});
formatter.examples({
  "line": 20,
  "name": "",
  "description": "",
  "id": "encryption-scenario;verify-encrypted-value-displayed-for-pull-requests.-on-decrypting-the-value-with-correct-private-key-expected-message-should-be-displayed;",
  "rows": [
    {
      "cells": [
        "Amount",
        "AccountNo",
        "CreditDebit",
        "GroupID"
      ],
      "line": 21,
      "id": "encryption-scenario;verify-encrypted-value-displayed-for-pull-requests.-on-decrypting-the-value-with-correct-private-key-expected-message-should-be-displayed;;1"
    },
    {
      "cells": [
        "288",
        "22205269504",
        "C",
        "INDGROUP"
      ],
      "line": 22,
      "id": "encryption-scenario;verify-encrypted-value-displayed-for-pull-requests.-on-decrypting-the-value-with-correct-private-key-expected-message-should-be-displayed;;2"
    }
  ],
  "keyword": "Examples"
});
formatter.before({
  "duration": 966588999,
  "status": "passed"
});
formatter.scenario({
  "line": 22,
  "name": "Verify Encrypted Value displayed for Pull requests. On decrypting the value with correct private key expected message should be displayed",
  "description": "",
  "id": "encryption-scenario;verify-encrypted-value-displayed-for-pull-requests.-on-decrypting-the-value-with-correct-private-key-expected-message-should-be-displayed;;2",
  "type": "scenario",
  "keyword": "Scenario Outline",
  "tags": [
    {
      "line": 3,
      "name": "@encryption"
    },
    {
      "line": 3,
      "name": "@ab"
    },
    {
      "line": 3,
      "name": "@peekAndConsume"
    },
    {
      "line": 3,
      "name": "@regression"
    }
  ]
});
formatter.step({
  "comments": [
    {
      "line": 5,
      "value": "#Given \u0027activationKey and activate\u0027 API"
    },
    {
      "line": 6,
      "value": "#And user has valid SSL certificate"
    },
    {
      "line": 7,
      "value": "#And user has already generated the JWT token for the group \u0027\u003cGroupID\u003e\u0027"
    },
    {
      "line": 8,
      "value": "#When Add Group Services of CADM is called for the group \u0027\u003cGroupID\u003e\u0027 to disable the group"
    },
    {
      "line": 9,
      "value": "#Then APIBanking should be disabled in CADM for the group \u0027\u003cGroupID\u003e\u0027"
    },
    {
      "line": 10,
      "value": "#When a POST request is made to axway endpoint for the group \u0027\u003cGroupID\u003e\u0027"
    },
    {
      "line": 11,
      "value": "#Then user should be registered successfully"
    },
    {
      "line": 12,
      "value": "#And APIBanking should be enabled in CADM for the group \u0027\u003cGroupID\u003e\u0027"
    },
    {
      "line": 13,
      "value": "#When user modifies Stub with amount \u0027\u003cAmount\u003e\u0027 account number \u0027\u003cAccountNo\u003e\u0027 transaction type \u0027\u003cCreditDebit\u003e\u0027 Currency Code \u0027INR\u0027 BIC \u0027SCBLINBBXXX\u0027"
    }
  ],
  "line": 14,
  "name": "Peek response should be displayed with encrypted value for amount \u0027288\u0027 accountNo \u002722205269504\u0027 transactionType \u0027C\u0027 the expected value for the group \u0027INDGROUP\u0027",
  "matchedColumns": [
    0,
    1,
    2,
    3
  ],
  "keyword": "Then "
});
formatter.step({
  "line": 15,
  "name": "The messages should be decrypted as expected when using privateKey of group \u0027INDGROUP\u0027 for \u0027peek\u0027",
  "matchedColumns": [
    3
  ],
  "keyword": "And "
});
formatter.step({
  "line": 16,
  "name": "Consume response should be displayed with encrypted value for amount \u0027288\u0027 accountNo \u002722205269504\u0027 transactionType \u0027C\u0027 the expected value for the group \u0027INDGROUP\u0027",
  "matchedColumns": [
    0,
    1,
    2,
    3
  ],
  "keyword": "And "
});
formatter.step({
  "line": 17,
  "name": "The messages should be decrypted as expected when using privateKey of group \u0027INDGROUP\u0027 for \u0027consume\u0027",
  "matchedColumns": [
    3
  ],
  "keyword": "And "
});
formatter.step({
  "line": 18,
  "name": "Recover response should be displayed with encrypted value for amount \u0027288\u0027 accountNo \u002722205269504\u0027 transactionType \u0027C\u0027 the expected value for the group \u0027INDGROUP\u0027",
  "matchedColumns": [
    0,
    1,
    2,
    3
  ],
  "keyword": "And "
});
formatter.step({
  "line": 19,
  "name": "The messages should be decrypted as expected when using privateKey of group \u0027INDGROUP\u0027 for \u0027recover\u0027",
  "matchedColumns": [
    3
  ],
  "keyword": "And "
});
formatter.match({
  "arguments": [
    {
      "val": "288",
      "offset": 67
    },
    {
      "val": "22205269504",
      "offset": 83
    },
    {
      "val": "C",
      "offset": 113
    },
    {
      "val": "INDGROUP",
      "offset": 150
    }
  ],
  "location": "PeekAndConsume.peekValueEncryptedTest(String,String,String,String)"
});
formatter.result({
  "duration": 3297651560,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "INDGROUP",
      "offset": 77
    },
    {
      "val": "peek",
      "offset": 92
    }
  ],
  "location": "PeekAndConsume.verifyDecryptedValueGivesActualContent(String,String)"
});
formatter.result({
  "duration": 17694952,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "288",
      "offset": 70
    },
    {
      "val": "22205269504",
      "offset": 86
    },
    {
      "val": "C",
      "offset": 116
    },
    {
      "val": "INDGROUP",
      "offset": 153
    }
  ],
  "location": "PeekAndConsume.consumeValueEncryptedTest(String,String,String,String)"
});
formatter.result({
  "duration": 722181255,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "INDGROUP",
      "offset": 77
    },
    {
      "val": "consume",
      "offset": 92
    }
  ],
  "location": "PeekAndConsume.verifyDecryptedValueGivesActualContent(String,String)"
});
formatter.result({
  "duration": 11493940,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "288",
      "offset": 70
    },
    {
      "val": "22205269504",
      "offset": 86
    },
    {
      "val": "C",
      "offset": 116
    },
    {
      "val": "INDGROUP",
      "offset": 153
    }
  ],
  "location": "PeekAndConsume.recoverValueEncryptedTest(String,String,String,String)"
});
formatter.result({
  "duration": 837895455,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "INDGROUP",
      "offset": 77
    },
    {
      "val": "recover",
      "offset": 92
    }
  ],
  "location": "PeekAndConsume.verifyDecryptedValueGivesActualContent(String,String)"
});
formatter.result({
  "duration": 19889074,
  "status": "passed"
});
});