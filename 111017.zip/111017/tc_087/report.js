$(document).ready(function() {var formatter = new CucumberHTML.DOMFormatter($('.cucumber-report'));formatter.uri("features/api/endToEnd.feature");
formatter.feature({
  "line": 1,
  "name": "End to End Scenarios for APIBanking",
  "description": "",
  "id": "end-to-end-scenarios-for-apibanking",
  "keyword": "Feature"
});
formatter.scenarioOutline({
  "line": 147,
  "name": "TC_008 - When Api banking is disabled, Peek consume, recover and webhook messages should not be displayed.",
  "description": "",
  "id": "end-to-end-scenarios-for-apibanking;tc-008---when-api-banking-is-disabled,-peek-consume,-recover-and-webhook-messages-should-not-be-displayed.",
  "type": "scenario_outline",
  "keyword": "Scenario Outline",
  "tags": [
    {
      "line": 146,
      "name": "@ab"
    },
    {
      "line": 146,
      "name": "@tc8"
    },
    {
      "line": 146,
      "name": "@regression"
    }
  ]
});
formatter.step({
  "comments": [
    {
      "line": 148,
      "value": "#Given \u0027activationKey and activate\u0027 API"
    },
    {
      "line": 149,
      "value": "#And user has valid SSL certificate"
    },
    {
      "line": 150,
      "value": "#And user has already generated the JWT token for the group \u0027\u003cGroupID\u003e\u0027"
    },
    {
      "line": 151,
      "value": "#When a POST request is made to axway endpoint for the group \u0027\u003cGroupID\u003e\u0027"
    },
    {
      "line": 152,
      "value": "#Then user should be registered successfully"
    },
    {
      "line": 153,
      "value": "#And APIBanking should be enabled in CADM for the group \u0027\u003cGroupID\u003e\u0027"
    },
    {
      "line": 154,
      "value": "#When Add Group Services of CADM is called for the group \u0027\u003cGroupID\u003e\u0027 to disable the group"
    },
    {
      "line": 155,
      "value": "#And I clear the cache for the \u0027\u003cGroupID\u003e\u0027 group"
    },
    {
      "line": 156,
      "value": "#Then APIBanking should be disabled in CADM for the group \u0027\u003cGroupID\u003e\u0027"
    },
    {
      "line": 157,
      "value": "# I consume all the previous messages"
    },
    {
      "line": 158,
      "value": "#When the webhook is turned off"
    },
    {
      "line": 159,
      "value": "#When user modifies Stub with amount \u0027\u003cAmount\u003e\u0027 account number \u0027\u003cAccountNo\u003e\u0027 transaction type \u0027\u003cCreditDebit\u003e\u0027 Currency Code \u0027INR\u0027 BIC \u0027SCBLINBBXXX\u0027"
    }
  ],
  "line": 160,
  "name": "Peek response should be displayed with the deactivate error message for the group \u0027\u003cGroupID\u003e\u0027",
  "keyword": "Then "
});
formatter.step({
  "line": 161,
  "name": "Consume response should be displayed with the deactivate error message for the group \u0027\u003cGroupID\u003e\u0027",
  "keyword": "And "
});
formatter.step({
  "line": 162,
  "name": "Recover response should be displayed with the deactivate error message for the group \u0027\u003cGroupID\u003e\u0027",
  "keyword": "And "
});
formatter.examples({
  "comments": [
    {
      "line": 163,
      "value": "#When the Webhook is turned on"
    },
    {
      "line": 164,
      "value": "#Then Webhook should be displayed with the empty message"
    }
  ],
  "line": 165,
  "name": "",
  "description": "",
  "id": "end-to-end-scenarios-for-apibanking;tc-008---when-api-banking-is-disabled,-peek-consume,-recover-and-webhook-messages-should-not-be-displayed.;",
  "rows": [
    {
      "cells": [
        "Amount",
        "AccountNo",
        "CreditDebit",
        "GroupID"
      ],
      "line": 166,
      "id": "end-to-end-scenarios-for-apibanking;tc-008---when-api-banking-is-disabled,-peek-consume,-recover-and-webhook-messages-should-not-be-displayed.;;1"
    },
    {
      "cells": [
        "3260",
        "22082017",
        "D",
        "INDGRP"
      ],
      "line": 167,
      "id": "end-to-end-scenarios-for-apibanking;tc-008---when-api-banking-is-disabled,-peek-consume,-recover-and-webhook-messages-should-not-be-displayed.;;2"
    }
  ],
  "keyword": "Examples"
});
formatter.before({
  "duration": 459164436,
  "status": "passed"
});
formatter.scenario({
  "line": 167,
  "name": "TC_008 - When Api banking is disabled, Peek consume, recover and webhook messages should not be displayed.",
  "description": "",
  "id": "end-to-end-scenarios-for-apibanking;tc-008---when-api-banking-is-disabled,-peek-consume,-recover-and-webhook-messages-should-not-be-displayed.;;2",
  "type": "scenario",
  "keyword": "Scenario Outline",
  "tags": [
    {
      "line": 146,
      "name": "@ab"
    },
    {
      "line": 146,
      "name": "@regression"
    },
    {
      "line": 146,
      "name": "@tc8"
    }
  ]
});
formatter.step({
  "comments": [
    {
      "line": 148,
      "value": "#Given \u0027activationKey and activate\u0027 API"
    },
    {
      "line": 149,
      "value": "#And user has valid SSL certificate"
    },
    {
      "line": 150,
      "value": "#And user has already generated the JWT token for the group \u0027\u003cGroupID\u003e\u0027"
    },
    {
      "line": 151,
      "value": "#When a POST request is made to axway endpoint for the group \u0027\u003cGroupID\u003e\u0027"
    },
    {
      "line": 152,
      "value": "#Then user should be registered successfully"
    },
    {
      "line": 153,
      "value": "#And APIBanking should be enabled in CADM for the group \u0027\u003cGroupID\u003e\u0027"
    },
    {
      "line": 154,
      "value": "#When Add Group Services of CADM is called for the group \u0027\u003cGroupID\u003e\u0027 to disable the group"
    },
    {
      "line": 155,
      "value": "#And I clear the cache for the \u0027\u003cGroupID\u003e\u0027 group"
    },
    {
      "line": 156,
      "value": "#Then APIBanking should be disabled in CADM for the group \u0027\u003cGroupID\u003e\u0027"
    },
    {
      "line": 157,
      "value": "# I consume all the previous messages"
    },
    {
      "line": 158,
      "value": "#When the webhook is turned off"
    },
    {
      "line": 159,
      "value": "#When user modifies Stub with amount \u0027\u003cAmount\u003e\u0027 account number \u0027\u003cAccountNo\u003e\u0027 transaction type \u0027\u003cCreditDebit\u003e\u0027 Currency Code \u0027INR\u0027 BIC \u0027SCBLINBBXXX\u0027"
    }
  ],
  "line": 160,
  "name": "Peek response should be displayed with the deactivate error message for the group \u0027INDGRP\u0027",
  "matchedColumns": [
    3
  ],
  "keyword": "Then "
});
formatter.step({
  "line": 161,
  "name": "Consume response should be displayed with the deactivate error message for the group \u0027INDGRP\u0027",
  "matchedColumns": [
    3
  ],
  "keyword": "And "
});
formatter.step({
  "line": 162,
  "name": "Recover response should be displayed with the deactivate error message for the group \u0027INDGRP\u0027",
  "matchedColumns": [
    3
  ],
  "keyword": "And "
});
formatter.match({
  "arguments": [
    {
      "val": "INDGRP",
      "offset": 83
    }
  ],
  "location": "PeekAndConsume.verifyDeactivateErrorMessageForPeek(String)"
});
formatter.result({
  "duration": 4266534740,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "INDGRP",
      "offset": 86
    }
  ],
  "location": "PeekAndConsume.verifyDeactivateErrorMessageForConsume(String)"
});
formatter.result({
  "duration": 1055573490,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "INDGRP",
      "offset": 86
    }
  ],
  "location": "PeekAndConsume.verifyDeactivateErrorMessageForRecover(String)"
});
formatter.result({
  "duration": 663474975,
  "status": "passed"
});
});