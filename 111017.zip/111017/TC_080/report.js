$(document).ready(function() {var formatter = new CucumberHTML.DOMFormatter($('.cucumber-report'));formatter.uri("features/api/pull.feature");
formatter.feature({
  "line": 1,
  "name": "Pull Mechanism scenarios",
  "description": "",
  "id": "pull-mechanism-scenarios",
  "keyword": "Feature"
});
formatter.scenarioOutline({
  "line": 114,
  "name": "TC_PULL_005 - When both webhook is down, verify messages for Peek of Group A and Consume of Group B",
  "description": "",
  "id": "pull-mechanism-scenarios;tc-pull-005---when-both-webhook-is-down,-verify-messages-for-peek-of-group-a-and-consume-of-group-b",
  "type": "scenario_outline",
  "keyword": "Scenario Outline",
  "tags": [
    {
      "line": 113,
      "name": "@ab"
    },
    {
      "line": 113,
      "name": "@peekAndConsume"
    },
    {
      "line": 113,
      "name": "@regression"
    },
    {
      "line": 113,
      "name": "@pull"
    },
    {
      "line": 113,
      "name": "@pull5"
    }
  ]
});
formatter.step({
  "comments": [
    {
      "line": 115,
      "value": "#When Add Group Services of CADM is called for the group \u0027\u003cGroupID\u003e\u0027 to disable the group"
    },
    {
      "line": 116,
      "value": "#Then APIBanking should be disabled in CADM for the group \u0027\u003cGroupID\u003e\u0027"
    }
  ],
  "line": 117,
  "name": "\u0027activationKey and activate\u0027 API",
  "keyword": "Given "
});
formatter.step({
  "line": 118,
  "name": "user has valid SSL certificate",
  "keyword": "And "
});
formatter.step({
  "line": 119,
  "name": "user has already generated the JWT token for the group \u0027\u003cGroupIDA\u003e\u0027",
  "keyword": "And "
});
formatter.step({
  "line": 120,
  "name": "a POST request is made to axway endpoint for the group \u0027\u003cGroupIDA\u003e\u0027",
  "keyword": "When "
});
formatter.step({
  "comments": [
    {
      "line": 121,
      "value": "#Then user should be registered successfully"
    },
    {
      "line": 122,
      "value": "#And APIBanking should be enabled in CADM for the group \u0027\u003cGroupIDA\u003e\u0027"
    },
    {
      "line": 123,
      "value": "#Given user has already generated the JWT token for the group \u0027\u003cGroupIDB\u003e\u0027"
    },
    {
      "line": 124,
      "value": "#When a POST request is made to axway endpoint for the group \u0027\u003cGroupIDB\u003e\u0027"
    },
    {
      "line": 125,
      "value": "#Then user should be registered successfully"
    },
    {
      "line": 126,
      "value": "#And APIBanking should be enabled in CADM for the group \u0027\u003cGroupIDB\u003e\u0027"
    },
    {
      "line": 127,
      "value": "#When user modifies Stub with amount \u0027\u003cAmount\u003e\u0027 account number \u0027\u003cAccountNo\u003e\u0027 transaction type \u0027\u003cCreditDebit\u003e\u0027 Currency Code \u0027INR\u0027 BIC \u0027SCBLINBBXXX\u0027"
    }
  ],
  "line": 128,
  "name": "Consume response should be displayed with amount \u0027\u003cAmount\u003e\u0027 accountNo \u0027\u003cAccountNo\u003e\u0027 transactionType \u0027\u003cCreditDebit\u003e\u0027 the expected value for the group \u0027\u003cGroupIDA\u003e\u0027",
  "keyword": "Then "
});
formatter.step({
  "line": 129,
  "name": "Consume response should be displayed with amount \u0027\u003cAmount\u003e\u0027 accountNo \u0027\u003cAccountNo\u003e\u0027 transactionType \u0027\u003cCreditDebit\u003e\u0027 the expected value for the group \u0027\u003cGroupIDB\u003e\u0027",
  "keyword": "Then "
});
formatter.examples({
  "line": 130,
  "name": "",
  "description": "",
  "id": "pull-mechanism-scenarios;tc-pull-005---when-both-webhook-is-down,-verify-messages-for-peek-of-group-a-and-consume-of-group-b;",
  "rows": [
    {
      "cells": [
        "Amount",
        "AccountNo",
        "CreditDebit",
        "GroupIDA",
        "GroupIDB"
      ],
      "line": 131,
      "id": "pull-mechanism-scenarios;tc-pull-005---when-both-webhook-is-down,-verify-messages-for-peek-of-group-a-and-consume-of-group-b;;1"
    },
    {
      "cells": [
        "7744",
        "22205269504",
        "C",
        "INDGRP",
        "INDGROUP"
      ],
      "line": 132,
      "id": "pull-mechanism-scenarios;tc-pull-005---when-both-webhook-is-down,-verify-messages-for-peek-of-group-a-and-consume-of-group-b;;2"
    }
  ],
  "keyword": "Examples"
});
formatter.before({
  "duration": 548062085,
  "status": "passed"
});
formatter.scenario({
  "line": 132,
  "name": "TC_PULL_005 - When both webhook is down, verify messages for Peek of Group A and Consume of Group B",
  "description": "",
  "id": "pull-mechanism-scenarios;tc-pull-005---when-both-webhook-is-down,-verify-messages-for-peek-of-group-a-and-consume-of-group-b;;2",
  "type": "scenario",
  "keyword": "Scenario Outline",
  "tags": [
    {
      "line": 113,
      "name": "@ab"
    },
    {
      "line": 113,
      "name": "@peekAndConsume"
    },
    {
      "line": 113,
      "name": "@regression"
    },
    {
      "line": 113,
      "name": "@pull5"
    },
    {
      "line": 113,
      "name": "@pull"
    }
  ]
});
formatter.step({
  "comments": [
    {
      "line": 115,
      "value": "#When Add Group Services of CADM is called for the group \u0027\u003cGroupID\u003e\u0027 to disable the group"
    },
    {
      "line": 116,
      "value": "#Then APIBanking should be disabled in CADM for the group \u0027\u003cGroupID\u003e\u0027"
    }
  ],
  "line": 117,
  "name": "\u0027activationKey and activate\u0027 API",
  "keyword": "Given "
});
formatter.step({
  "line": 118,
  "name": "user has valid SSL certificate",
  "keyword": "And "
});
formatter.step({
  "line": 119,
  "name": "user has already generated the JWT token for the group \u0027INDGRP\u0027",
  "matchedColumns": [
    3
  ],
  "keyword": "And "
});
formatter.step({
  "line": 120,
  "name": "a POST request is made to axway endpoint for the group \u0027INDGRP\u0027",
  "matchedColumns": [
    3
  ],
  "keyword": "When "
});
formatter.step({
  "comments": [
    {
      "line": 121,
      "value": "#Then user should be registered successfully"
    },
    {
      "line": 122,
      "value": "#And APIBanking should be enabled in CADM for the group \u0027\u003cGroupIDA\u003e\u0027"
    },
    {
      "line": 123,
      "value": "#Given user has already generated the JWT token for the group \u0027\u003cGroupIDB\u003e\u0027"
    },
    {
      "line": 124,
      "value": "#When a POST request is made to axway endpoint for the group \u0027\u003cGroupIDB\u003e\u0027"
    },
    {
      "line": 125,
      "value": "#Then user should be registered successfully"
    },
    {
      "line": 126,
      "value": "#And APIBanking should be enabled in CADM for the group \u0027\u003cGroupIDB\u003e\u0027"
    },
    {
      "line": 127,
      "value": "#When user modifies Stub with amount \u0027\u003cAmount\u003e\u0027 account number \u0027\u003cAccountNo\u003e\u0027 transaction type \u0027\u003cCreditDebit\u003e\u0027 Currency Code \u0027INR\u0027 BIC \u0027SCBLINBBXXX\u0027"
    }
  ],
  "line": 128,
  "name": "Consume response should be displayed with amount \u00277744\u0027 accountNo \u002722205269504\u0027 transactionType \u0027C\u0027 the expected value for the group \u0027INDGRP\u0027",
  "matchedColumns": [
    0,
    1,
    2,
    3
  ],
  "keyword": "Then "
});
formatter.step({
  "line": 129,
  "name": "Consume response should be displayed with amount \u00277744\u0027 accountNo \u002722205269504\u0027 transactionType \u0027C\u0027 the expected value for the group \u0027INDGROUP\u0027",
  "matchedColumns": [
    0,
    1,
    2,
    4
  ],
  "keyword": "Then "
});
formatter.match({
  "arguments": [
    {
      "val": "activationKey and activate",
      "offset": 1
    }
  ],
  "location": "commonApiMethods.an_API(String)"
});
formatter.result({
  "duration": 282997267,
  "status": "passed"
});
formatter.match({
  "location": "activationKey.user_has_valid_SSL_certificate()"
});
formatter.result({
  "duration": 4398440,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "INDGRP",
      "offset": 56
    }
  ],
  "location": "activationKey.user_has_already_generated_the_JWT_token_for_the_group(String)"
});
formatter.result({
  "duration": 559353265,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "INDGRP",
      "offset": 56
    }
  ],
  "location": "activationKey.a_POST_request_is_made_to_axway_endpoint(String)"
});
formatter.result({
  "duration": 4426410425,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "7744",
      "offset": 50
    },
    {
      "val": "22205269504",
      "offset": 67
    },
    {
      "val": "C",
      "offset": 97
    },
    {
      "val": "INDGRP",
      "offset": 134
    }
  ],
  "location": "PeekAndConsume.consumeValueTest(String,String,String,String)"
});
formatter.result({
  "duration": 975686432,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "7744",
      "offset": 50
    },
    {
      "val": "22205269504",
      "offset": 67
    },
    {
      "val": "C",
      "offset": 97
    },
    {
      "val": "INDGROUP",
      "offset": 134
    }
  ],
  "location": "PeekAndConsume.consumeValueTest(String,String,String,String)"
});
formatter.result({
  "duration": 1074195403,
  "status": "passed"
});
});