$(document).ready(function() {var formatter = new CucumberHTML.DOMFormatter($('.cucumber-report'));formatter.uri("features/api/endToEnd.feature");
formatter.feature({
  "line": 1,
  "name": "End to End Scenarios for APIBanking",
  "description": "",
  "id": "end-to-end-scenarios-for-apibanking",
  "keyword": "Feature"
});
formatter.scenarioOutline({
  "line": 126,
  "name": "TC_007 - When information services is turned off, Peek consume, recover and webhook messages should not be displayed.",
  "description": "",
  "id": "end-to-end-scenarios-for-apibanking;tc-007---when-information-services-is-turned-off,-peek-consume,-recover-and-webhook-messages-should-not-be-displayed.",
  "type": "scenario_outline",
  "keyword": "Scenario Outline",
  "tags": [
    {
      "line": 125,
      "name": "@ab"
    },
    {
      "line": 125,
      "name": "@tc7"
    },
    {
      "line": 125,
      "name": "@regression"
    }
  ]
});
formatter.step({
  "line": 127,
  "name": "\u0027activationKey and activate\u0027 API",
  "keyword": "Given "
});
formatter.step({
  "line": 128,
  "name": "user has valid SSL certificate",
  "keyword": "And "
});
formatter.step({
  "line": 129,
  "name": "user has already generated the JWT token for the group \u0027\u003cGroupID\u003e\u0027",
  "keyword": "And "
});
formatter.step({
  "comments": [
    {
      "line": 130,
      "value": "#When Add Group Services of CADM is called for the group \u0027\u003cGroupID\u003e\u0027 to disable the group"
    },
    {
      "line": 131,
      "value": "#Then APIBanking should be disabled in CADM for the group \u0027\u003cGroupID\u003e\u0027"
    }
  ],
  "line": 132,
  "name": "a POST request is made to axway endpoint for the group \u0027\u003cGroupID\u003e\u0027",
  "keyword": "When "
});
formatter.step({
  "comments": [
    {
      "line": 133,
      "value": "#Then user should be registered successfully"
    },
    {
      "line": 134,
      "value": "#Then APIBanking should be enabled in CADM for the group \u0027\u003cGroupID\u003e\u0027"
    },
    {
      "line": 135,
      "value": "#When the webhook is turned off"
    },
    {
      "line": 136,
      "value": "#When user modifies Stub with amount \u0027\u003cAmount\u003e\u0027 account number \u0027\u003cAccountNo\u003e\u0027 transaction type \u0027\u003cCreditDebit\u003e\u0027 Currency Code \u0027INR\u0027 BIC \u0027SCBLINBBXXX\u0027"
    }
  ],
  "line": 137,
  "name": "Peek response should be displayed with the deactivate error message for the group \u0027\u003cGroupID\u003e\u0027",
  "keyword": "Then "
});
formatter.step({
  "line": 138,
  "name": "Consume response should be displayed with the deactivate error message for the group \u0027\u003cGroupID\u003e\u0027",
  "keyword": "And "
});
formatter.step({
  "line": 139,
  "name": "Recover response should be displayed with the deactivate error message for the group \u0027\u003cGroupID\u003e\u0027",
  "keyword": "And "
});
formatter.examples({
  "comments": [
    {
      "line": 140,
      "value": "#When the Webhook is turned on"
    },
    {
      "line": 141,
      "value": "#Then Webhook should be displayed with the empty message"
    }
  ],
  "line": 142,
  "name": "",
  "description": "",
  "id": "end-to-end-scenarios-for-apibanking;tc-007---when-information-services-is-turned-off,-peek-consume,-recover-and-webhook-messages-should-not-be-displayed.;",
  "rows": [
    {
      "cells": [
        "Amount",
        "AccountNo",
        "CreditDebit",
        "GroupID"
      ],
      "line": 143,
      "id": "end-to-end-scenarios-for-apibanking;tc-007---when-information-services-is-turned-off,-peek-consume,-recover-and-webhook-messages-should-not-be-displayed.;;1"
    },
    {
      "cells": [
        "3260",
        "22505806238",
        "D",
        "INRCMS02"
      ],
      "line": 144,
      "id": "end-to-end-scenarios-for-apibanking;tc-007---when-information-services-is-turned-off,-peek-consume,-recover-and-webhook-messages-should-not-be-displayed.;;2"
    }
  ],
  "keyword": "Examples"
});
formatter.before({
  "duration": 640880911,
  "status": "passed"
});
formatter.scenario({
  "line": 144,
  "name": "TC_007 - When information services is turned off, Peek consume, recover and webhook messages should not be displayed.",
  "description": "",
  "id": "end-to-end-scenarios-for-apibanking;tc-007---when-information-services-is-turned-off,-peek-consume,-recover-and-webhook-messages-should-not-be-displayed.;;2",
  "type": "scenario",
  "keyword": "Scenario Outline",
  "tags": [
    {
      "line": 125,
      "name": "@ab"
    },
    {
      "line": 125,
      "name": "@regression"
    },
    {
      "line": 125,
      "name": "@tc7"
    }
  ]
});
formatter.step({
  "line": 127,
  "name": "\u0027activationKey and activate\u0027 API",
  "keyword": "Given "
});
formatter.step({
  "line": 128,
  "name": "user has valid SSL certificate",
  "keyword": "And "
});
formatter.step({
  "line": 129,
  "name": "user has already generated the JWT token for the group \u0027INRCMS02\u0027",
  "matchedColumns": [
    3
  ],
  "keyword": "And "
});
formatter.step({
  "comments": [
    {
      "line": 130,
      "value": "#When Add Group Services of CADM is called for the group \u0027\u003cGroupID\u003e\u0027 to disable the group"
    },
    {
      "line": 131,
      "value": "#Then APIBanking should be disabled in CADM for the group \u0027\u003cGroupID\u003e\u0027"
    }
  ],
  "line": 132,
  "name": "a POST request is made to axway endpoint for the group \u0027INRCMS02\u0027",
  "matchedColumns": [
    3
  ],
  "keyword": "When "
});
formatter.step({
  "comments": [
    {
      "line": 133,
      "value": "#Then user should be registered successfully"
    },
    {
      "line": 134,
      "value": "#Then APIBanking should be enabled in CADM for the group \u0027\u003cGroupID\u003e\u0027"
    },
    {
      "line": 135,
      "value": "#When the webhook is turned off"
    },
    {
      "line": 136,
      "value": "#When user modifies Stub with amount \u0027\u003cAmount\u003e\u0027 account number \u0027\u003cAccountNo\u003e\u0027 transaction type \u0027\u003cCreditDebit\u003e\u0027 Currency Code \u0027INR\u0027 BIC \u0027SCBLINBBXXX\u0027"
    }
  ],
  "line": 137,
  "name": "Peek response should be displayed with the deactivate error message for the group \u0027INRCMS02\u0027",
  "matchedColumns": [
    3
  ],
  "keyword": "Then "
});
formatter.step({
  "line": 138,
  "name": "Consume response should be displayed with the deactivate error message for the group \u0027INRCMS02\u0027",
  "matchedColumns": [
    3
  ],
  "keyword": "And "
});
formatter.step({
  "line": 139,
  "name": "Recover response should be displayed with the deactivate error message for the group \u0027INRCMS02\u0027",
  "matchedColumns": [
    3
  ],
  "keyword": "And "
});
formatter.match({
  "arguments": [
    {
      "val": "activationKey and activate",
      "offset": 1
    }
  ],
  "location": "commonApiMethods.an_API(String)"
});
formatter.result({
  "duration": 249320826,
  "status": "passed"
});
formatter.match({
  "location": "activationKey.user_has_valid_SSL_certificate()"
});
formatter.result({
  "duration": 10551121,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "INRCMS02",
      "offset": 56
    }
  ],
  "location": "activationKey.user_has_already_generated_the_JWT_token_for_the_group(String)"
});
formatter.result({
  "duration": 597774010,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "INRCMS02",
      "offset": 56
    }
  ],
  "location": "activationKey.a_POST_request_is_made_to_axway_endpoint(String)"
});
formatter.result({
  "duration": 4198268112,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "INRCMS02",
      "offset": 83
    }
  ],
  "location": "PeekAndConsume.verifyDeactivateErrorMessageForPeek(String)"
});
formatter.result({
  "duration": 733272694,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "INRCMS02",
      "offset": 86
    }
  ],
  "location": "PeekAndConsume.verifyDeactivateErrorMessageForConsume(String)"
});
formatter.result({
  "duration": 707149381,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "INRCMS02",
      "offset": 86
    }
  ],
  "location": "PeekAndConsume.verifyDeactivateErrorMessageForRecover(String)"
});
formatter.result({
  "duration": 773247184,
  "status": "passed"
});
});