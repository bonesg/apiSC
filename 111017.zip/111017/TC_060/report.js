$(document).ready(function() {var formatter = new CucumberHTML.DOMFormatter($('.cucumber-report'));formatter.uri("features/api/pull.feature");
formatter.feature({
  "line": 1,
  "name": "Pull Mechanism scenarios",
  "description": "",
  "id": "pull-mechanism-scenarios",
  "keyword": "Feature"
});
formatter.scenarioOutline({
  "line": 72,
  "name": "TC_PULL_004 - When both webhook is down, verify messages for Peek of Group A and Group B",
  "description": "",
  "id": "pull-mechanism-scenarios;tc-pull-004---when-both-webhook-is-down,-verify-messages-for-peek-of-group-a-and-group-b",
  "type": "scenario_outline",
  "keyword": "Scenario Outline",
  "tags": [
    {
      "line": 71,
      "name": "@ab"
    },
    {
      "line": 71,
      "name": "@peekAndConsume"
    },
    {
      "line": 71,
      "name": "@regression"
    },
    {
      "line": 71,
      "name": "@pull"
    },
    {
      "line": 71,
      "name": "@pull4"
    }
  ]
});
formatter.step({
  "comments": [
    {
      "line": 73,
      "value": "#When Add Group Services of CADM is called for the group \u0027\u003cGroupID\u003e\u0027 to disable the group"
    },
    {
      "line": 74,
      "value": "#Then APIBanking should be disabled in CADM for the group \u0027\u003cGroupID\u003e\u0027"
    }
  ],
  "line": 75,
  "name": "\u0027activationKey and activate\u0027 API",
  "keyword": "Given "
});
formatter.step({
  "comments": [
    {
      "line": 76,
      "value": "#And user has valid SSL certificate"
    }
  ],
  "line": 77,
  "name": "user has already generated the JWT token for the group \u0027\u003cGroupIDA\u003e\u0027",
  "keyword": "And "
});
formatter.step({
  "line": 78,
  "name": "a POST request is made to axway endpoint for the group \u0027\u003cGroupIDA\u003e\u0027",
  "keyword": "When "
});
formatter.step({
  "line": 79,
  "name": "user should be registered successfully",
  "keyword": "Then "
});
formatter.step({
  "comments": [
    {
      "line": 80,
      "value": "#And APIBanking should be enabled in CADM for the group \u0027\u003cGroupIDA\u003e\u0027"
    },
    {
      "line": 81,
      "value": "#Given user has already generated the JWT token for the group \u0027\u003cGroupIDB\u003e\u0027"
    },
    {
      "line": 82,
      "value": "#When a POST request is made to axway endpoint for the group \u0027\u003cGroupIDB\u003e\u0027"
    },
    {
      "line": 83,
      "value": "#Then user should be registered successfully"
    },
    {
      "line": 84,
      "value": "#And APIBanking should be enabled in CADM for the group \u0027\u003cGroupIDB\u003e\u0027"
    },
    {
      "line": 85,
      "value": "# When user modifies Stub with amount \u0027\u003cAmount\u003e\u0027 account number \u0027\u003cAccountNo\u003e\u0027 transaction type \u0027\u003cCreditDebit\u003e\u0027 Currency Code \u0027INR\u0027 BIC \u0027SCBLINBBXXX\u0027"
    }
  ],
  "line": 86,
  "name": "Consume response should be displayed with amount \u0027\u003cAmount\u003e\u0027 accountNo \u0027\u003cAccountNo\u003e\u0027 transactionType \u0027\u003cCreditDebit\u003e\u0027 the expected value for the group \u0027\u003cGroupIDA\u003e\u0027",
  "keyword": "Then "
});
formatter.step({
  "line": 87,
  "name": "Peek response should be displayed with amount \u0027\u003cAmount\u003e\u0027 accountNo \u0027\u003cAccountNo\u003e\u0027 transactionType \u0027\u003cCreditDebit\u003e\u0027 the expected value for the group \u0027\u003cGroupIDB\u003e\u0027",
  "keyword": "Then "
});
formatter.examples({
  "line": 88,
  "name": "",
  "description": "",
  "id": "pull-mechanism-scenarios;tc-pull-004---when-both-webhook-is-down,-verify-messages-for-peek-of-group-a-and-group-b;",
  "rows": [
    {
      "cells": [
        "Amount",
        "AccountNo",
        "CreditDebit",
        "GroupIDA",
        "GroupIDB"
      ],
      "line": 89,
      "id": "pull-mechanism-scenarios;tc-pull-004---when-both-webhook-is-down,-verify-messages-for-peek-of-group-a-and-group-b;;1"
    },
    {
      "cells": [
        "4321",
        "22205269504",
        "D",
        "INDGRP",
        "INDGROUP"
      ],
      "line": 90,
      "id": "pull-mechanism-scenarios;tc-pull-004---when-both-webhook-is-down,-verify-messages-for-peek-of-group-a-and-group-b;;2"
    }
  ],
  "keyword": "Examples"
});
formatter.before({
  "duration": 479968389,
  "status": "passed"
});
formatter.scenario({
  "line": 90,
  "name": "TC_PULL_004 - When both webhook is down, verify messages for Peek of Group A and Group B",
  "description": "",
  "id": "pull-mechanism-scenarios;tc-pull-004---when-both-webhook-is-down,-verify-messages-for-peek-of-group-a-and-group-b;;2",
  "type": "scenario",
  "keyword": "Scenario Outline",
  "tags": [
    {
      "line": 71,
      "name": "@ab"
    },
    {
      "line": 71,
      "name": "@peekAndConsume"
    },
    {
      "line": 71,
      "name": "@regression"
    },
    {
      "line": 71,
      "name": "@pull4"
    },
    {
      "line": 71,
      "name": "@pull"
    }
  ]
});
formatter.step({
  "comments": [
    {
      "line": 73,
      "value": "#When Add Group Services of CADM is called for the group \u0027\u003cGroupID\u003e\u0027 to disable the group"
    },
    {
      "line": 74,
      "value": "#Then APIBanking should be disabled in CADM for the group \u0027\u003cGroupID\u003e\u0027"
    }
  ],
  "line": 75,
  "name": "\u0027activationKey and activate\u0027 API",
  "keyword": "Given "
});
formatter.step({
  "comments": [
    {
      "line": 76,
      "value": "#And user has valid SSL certificate"
    }
  ],
  "line": 77,
  "name": "user has already generated the JWT token for the group \u0027INDGRP\u0027",
  "matchedColumns": [
    3
  ],
  "keyword": "And "
});
formatter.step({
  "line": 78,
  "name": "a POST request is made to axway endpoint for the group \u0027INDGRP\u0027",
  "matchedColumns": [
    3
  ],
  "keyword": "When "
});
formatter.step({
  "line": 79,
  "name": "user should be registered successfully",
  "keyword": "Then "
});
formatter.step({
  "comments": [
    {
      "line": 80,
      "value": "#And APIBanking should be enabled in CADM for the group \u0027\u003cGroupIDA\u003e\u0027"
    },
    {
      "line": 81,
      "value": "#Given user has already generated the JWT token for the group \u0027\u003cGroupIDB\u003e\u0027"
    },
    {
      "line": 82,
      "value": "#When a POST request is made to axway endpoint for the group \u0027\u003cGroupIDB\u003e\u0027"
    },
    {
      "line": 83,
      "value": "#Then user should be registered successfully"
    },
    {
      "line": 84,
      "value": "#And APIBanking should be enabled in CADM for the group \u0027\u003cGroupIDB\u003e\u0027"
    },
    {
      "line": 85,
      "value": "# When user modifies Stub with amount \u0027\u003cAmount\u003e\u0027 account number \u0027\u003cAccountNo\u003e\u0027 transaction type \u0027\u003cCreditDebit\u003e\u0027 Currency Code \u0027INR\u0027 BIC \u0027SCBLINBBXXX\u0027"
    }
  ],
  "line": 86,
  "name": "Consume response should be displayed with amount \u00274321\u0027 accountNo \u002722205269504\u0027 transactionType \u0027D\u0027 the expected value for the group \u0027INDGRP\u0027",
  "matchedColumns": [
    0,
    1,
    2,
    3
  ],
  "keyword": "Then "
});
formatter.step({
  "line": 87,
  "name": "Peek response should be displayed with amount \u00274321\u0027 accountNo \u002722205269504\u0027 transactionType \u0027D\u0027 the expected value for the group \u0027INDGROUP\u0027",
  "matchedColumns": [
    0,
    1,
    2,
    4
  ],
  "keyword": "Then "
});
formatter.match({
  "arguments": [
    {
      "val": "activationKey and activate",
      "offset": 1
    }
  ],
  "location": "commonApiMethods.an_API(String)"
});
formatter.result({
  "duration": 189527491,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "INDGRP",
      "offset": 56
    }
  ],
  "location": "activationKey.user_has_already_generated_the_JWT_token_for_the_group(String)"
});
formatter.result({
  "duration": 458641864,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "INDGRP",
      "offset": 56
    }
  ],
  "location": "activationKey.a_POST_request_is_made_to_axway_endpoint(String)"
});
formatter.result({
  "duration": 6551468997,
  "status": "passed"
});
formatter.match({
  "location": "activationKey.user_should_be_registered_successfully()"
});
formatter.result({
  "duration": 64189,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "4321",
      "offset": 50
    },
    {
      "val": "22205269504",
      "offset": 67
    },
    {
      "val": "D",
      "offset": 97
    },
    {
      "val": "INDGRP",
      "offset": 134
    }
  ],
  "location": "PeekAndConsume.consumeValueTest(String,String,String,String)"
});
formatter.result({
  "duration": 909621857,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "4321",
      "offset": 47
    },
    {
      "val": "22205269504",
      "offset": 64
    },
    {
      "val": "D",
      "offset": 94
    },
    {
      "val": "INDGROUP",
      "offset": 131
    }
  ],
  "location": "PeekAndConsume.peekValueTest(String,String,String,String)"
});
formatter.result({
  "duration": 859928811,
  "status": "passed"
});
formatter.scenarioOutline({
  "line": 93,
  "name": "TC_PULL_004 - When both webhook is down, verify messages for Peek of Group B",
  "description": "",
  "id": "pull-mechanism-scenarios;tc-pull-004---when-both-webhook-is-down,-verify-messages-for-peek-of-group-b",
  "type": "scenario_outline",
  "keyword": "Scenario Outline",
  "tags": [
    {
      "line": 92,
      "name": "@ab"
    },
    {
      "line": 92,
      "name": "@peekAndConsume"
    },
    {
      "line": 92,
      "name": "@regression"
    },
    {
      "line": 92,
      "name": "@pull"
    },
    {
      "line": 92,
      "name": "@pull4"
    }
  ]
});
formatter.step({
  "comments": [
    {
      "line": 94,
      "value": "#When Add Group Services of CADM is called for the group \u0027\u003cGroupID\u003e\u0027 to disable the group"
    },
    {
      "line": 95,
      "value": "#Then APIBanking should be disabled in CADM for the group \u0027\u003cGroupID\u003e\u0027"
    }
  ],
  "line": 96,
  "name": "\u0027activationKey and activate\u0027 API",
  "keyword": "Given "
});
formatter.step({
  "comments": [
    {
      "line": 97,
      "value": "#And user has valid SSL certificate"
    }
  ],
  "line": 98,
  "name": "user has already generated the JWT token for the group \u0027\u003cGroupIDA\u003e\u0027",
  "keyword": "And "
});
formatter.step({
  "line": 99,
  "name": "a POST request is made to axway endpoint for the group \u0027\u003cGroupIDA\u003e\u0027",
  "keyword": "When "
});
formatter.step({
  "line": 100,
  "name": "user should be registered successfully",
  "keyword": "Then "
});
formatter.step({
  "comments": [
    {
      "line": 101,
      "value": "#And APIBanking should be enabled in CADM for the group \u0027\u003cGroupIDA\u003e\u0027"
    },
    {
      "line": 102,
      "value": "#Given user has already generated the JWT token for the group \u0027\u003cGroupIDB\u003e\u0027"
    },
    {
      "line": 103,
      "value": "#When a POST request is made to axway endpoint for the group \u0027\u003cGroupIDB\u003e\u0027"
    },
    {
      "line": 104,
      "value": "#Then user should be registered successfully"
    },
    {
      "line": 105,
      "value": "#And APIBanking should be enabled in CADM for the group \u0027\u003cGroupIDB\u003e\u0027"
    },
    {
      "line": 106,
      "value": "#When user modifies Stub with amount \u0027\u003cAmount\u003e\u0027 account number \u0027\u003cAccountNo\u003e\u0027 transaction type \u0027\u003cCreditDebit\u003e\u0027 Currency Code \u0027INR\u0027 BIC \u0027SCBLINBBXXX\u0027"
    }
  ],
  "line": 107,
  "name": "Consume response should be displayed with amount \u0027\u003cAmount\u003e\u0027 accountNo \u0027\u003cAccountNo\u003e\u0027 transactionType \u0027\u003cCreditDebit\u003e\u0027 the expected value for the group \u0027\u003cGroupIDA\u003e\u0027",
  "keyword": "Then "
});
formatter.step({
  "line": 108,
  "name": "Peek response should be displayed with the empty message for the group \u0027\u003cGroupIDB\u003e\u0027",
  "keyword": "Then "
});
formatter.examples({
  "line": 109,
  "name": "",
  "description": "",
  "id": "pull-mechanism-scenarios;tc-pull-004---when-both-webhook-is-down,-verify-messages-for-peek-of-group-b;",
  "rows": [
    {
      "cells": [
        "Amount",
        "AccountNo",
        "CreditDebit",
        "GroupIDA",
        "GroupIDB"
      ],
      "line": 110,
      "id": "pull-mechanism-scenarios;tc-pull-004---when-both-webhook-is-down,-verify-messages-for-peek-of-group-b;;1"
    },
    {
      "cells": [
        "4321",
        "22205269504",
        "D",
        "INDGROUP",
        "INDGROUP"
      ],
      "line": 111,
      "id": "pull-mechanism-scenarios;tc-pull-004---when-both-webhook-is-down,-verify-messages-for-peek-of-group-b;;2"
    }
  ],
  "keyword": "Examples"
});
formatter.before({
  "duration": 29091476,
  "status": "passed"
});
formatter.scenario({
  "line": 111,
  "name": "TC_PULL_004 - When both webhook is down, verify messages for Peek of Group B",
  "description": "",
  "id": "pull-mechanism-scenarios;tc-pull-004---when-both-webhook-is-down,-verify-messages-for-peek-of-group-b;;2",
  "type": "scenario",
  "keyword": "Scenario Outline",
  "tags": [
    {
      "line": 92,
      "name": "@ab"
    },
    {
      "line": 92,
      "name": "@peekAndConsume"
    },
    {
      "line": 92,
      "name": "@regression"
    },
    {
      "line": 92,
      "name": "@pull4"
    },
    {
      "line": 92,
      "name": "@pull"
    }
  ]
});
formatter.step({
  "comments": [
    {
      "line": 94,
      "value": "#When Add Group Services of CADM is called for the group \u0027\u003cGroupID\u003e\u0027 to disable the group"
    },
    {
      "line": 95,
      "value": "#Then APIBanking should be disabled in CADM for the group \u0027\u003cGroupID\u003e\u0027"
    }
  ],
  "line": 96,
  "name": "\u0027activationKey and activate\u0027 API",
  "keyword": "Given "
});
formatter.step({
  "comments": [
    {
      "line": 97,
      "value": "#And user has valid SSL certificate"
    }
  ],
  "line": 98,
  "name": "user has already generated the JWT token for the group \u0027INDGROUP\u0027",
  "matchedColumns": [
    3
  ],
  "keyword": "And "
});
formatter.step({
  "line": 99,
  "name": "a POST request is made to axway endpoint for the group \u0027INDGROUP\u0027",
  "matchedColumns": [
    3
  ],
  "keyword": "When "
});
formatter.step({
  "line": 100,
  "name": "user should be registered successfully",
  "keyword": "Then "
});
formatter.step({
  "comments": [
    {
      "line": 101,
      "value": "#And APIBanking should be enabled in CADM for the group \u0027\u003cGroupIDA\u003e\u0027"
    },
    {
      "line": 102,
      "value": "#Given user has already generated the JWT token for the group \u0027\u003cGroupIDB\u003e\u0027"
    },
    {
      "line": 103,
      "value": "#When a POST request is made to axway endpoint for the group \u0027\u003cGroupIDB\u003e\u0027"
    },
    {
      "line": 104,
      "value": "#Then user should be registered successfully"
    },
    {
      "line": 105,
      "value": "#And APIBanking should be enabled in CADM for the group \u0027\u003cGroupIDB\u003e\u0027"
    },
    {
      "line": 106,
      "value": "#When user modifies Stub with amount \u0027\u003cAmount\u003e\u0027 account number \u0027\u003cAccountNo\u003e\u0027 transaction type \u0027\u003cCreditDebit\u003e\u0027 Currency Code \u0027INR\u0027 BIC \u0027SCBLINBBXXX\u0027"
    }
  ],
  "line": 107,
  "name": "Consume response should be displayed with amount \u00274321\u0027 accountNo \u002722205269504\u0027 transactionType \u0027D\u0027 the expected value for the group \u0027INDGROUP\u0027",
  "matchedColumns": [
    0,
    1,
    2,
    3
  ],
  "keyword": "Then "
});
formatter.step({
  "line": 108,
  "name": "Peek response should be displayed with the empty message for the group \u0027INDGROUP\u0027",
  "matchedColumns": [
    4
  ],
  "keyword": "Then "
});
formatter.match({
  "arguments": [
    {
      "val": "activationKey and activate",
      "offset": 1
    }
  ],
  "location": "commonApiMethods.an_API(String)"
});
formatter.result({
  "duration": 154054,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "INDGROUP",
      "offset": 56
    }
  ],
  "location": "activationKey.user_has_already_generated_the_JWT_token_for_the_group(String)"
});
formatter.result({
  "duration": 22910099,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "INDGROUP",
      "offset": 56
    }
  ],
  "location": "activationKey.a_POST_request_is_made_to_axway_endpoint(String)"
});
formatter.result({
  "duration": 2153174002,
  "status": "passed"
});
formatter.match({
  "location": "activationKey.user_should_be_registered_successfully()"
});
formatter.result({
  "duration": 185015,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "4321",
      "offset": 50
    },
    {
      "val": "22205269504",
      "offset": 67
    },
    {
      "val": "D",
      "offset": 97
    },
    {
      "val": "INDGROUP",
      "offset": 134
    }
  ],
  "location": "PeekAndConsume.consumeValueTest(String,String,String,String)"
});
formatter.result({
  "duration": 839393318,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "INDGROUP",
      "offset": 72
    }
  ],
  "location": "PeekAndConsume.peekEmptyTest(String)"
});
formatter.result({
  "duration": 1095535521,
  "status": "passed"
});
});