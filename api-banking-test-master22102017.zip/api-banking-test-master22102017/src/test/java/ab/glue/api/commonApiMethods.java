package ab.glue.api;

import ab.utils.ExcelReader;
import common.RestAssuredConfig;
import cucumber.api.Scenario;
import cucumber.api.java.Before;
import cucumber.api.java.en.Given;

import java.util.ArrayList;
import java.util.HashMap;


/**
 * Created by 1556780 on 2/27/2017.
 * This class contains common methods used across all the api glue-code classes
 */
public class commonApiMethods {

    public static ArrayList<HashMap> data = new ArrayList<>();
    public static String scenarioName = "";

    //Setting up rest configuration: BaseURI, BasePath, Port
    @Before
    public void setup_API_Configurations(Scenario scenario) throws Throwable {
        RestAssuredConfig.RestConfig();
        String testcaseID = scenario.getName().split(" -")[0];
        System.out.println(testcaseID);
        data = ExcelReader.getTestDataByTestCaseId(testcaseID, "APIBanking");
        scenarioName = scenario.getName();
    }

    @Given("^'(.+)' API$")
    public void an_API(String apiName) throws Throwable {
        System.out.println("Validating: "+apiName+" API. ");
    }

    @Given("^I get the test data for '(.+)'$")
    public void getTestData(String testCaseID){
        System.out.println("Given :"+scenarioName);

    }
}
