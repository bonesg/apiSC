package ab.glue.api;

import ab.common.CADMConfig;
import common.RestAssuredConfig;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import junit.framework.Assert;

import javax.jms.JMSException;
import javax.ws.rs.core.MediaType;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Scanner;

/**
 * Created by 1571168 on 8/3/2017.
 */
public class CADMMethods {
public static String CADM_URL = "https://10.20.166.89:756";
public static String cadmResponse = "";
public static int cadmStatus;

    @When("^Add Group Services of CADM is called for the group '(.+)'$")
    public void postAddGroupServices(String group) throws JMSException, IOException {
        String content = new Scanner(new File("./src/test/resources/test-data/activationKeyBody" + group + ".json")).useDelimiter("\\Z").next();
        content = content.replaceAll(" ", "");
        //String expectedWebookURL = content.split("\"webhookUrl\":\"")[1].split("\",)[0];
        String expectedFingerprint = content.split("\"certificateThumbprint\":\"")[1].split("\",")[0];
        String expectedPublickey = content.split("\"publicKey\":\"")[1].split("\",")[0];
        String expectedWebookURL = RestAssuredConfig.webhookURL.get(group);
        String input = "{\"groupId\":\""+group+"\",\"apiservice\":{\"publicKey\":\""+expectedPublickey+"\",\"certificateFingerprint\":\""+expectedFingerprint+"\",\"webhookUrl\":\""+expectedWebookURL+"\",\"apiBankingEnabled\":\"Y\"}}";
        final com.sun.jersey.api.client.Client client = com.sun.jersey.api.client.Client.create(CADMConfig.configureClient());
        final com.sun.jersey.api.client.WebResource webResource = client
                .resource(CADM_URL+"/cadmapi/service/group");
        try {
            com.sun.jersey.api.client.ClientResponse response = webResource.type(MediaType.APPLICATION_JSON_TYPE)
                    .accept(MediaType.APPLICATION_JSON_TYPE).post(com.sun.jersey.api.client.ClientResponse.class, input);
            System.out.println(response.toString());
            //  if(response.getStatus() ==200) {

            String output = response.getEntity(String.class);
            System.out.println("Output from Server .... \n");
            System.out.println(output);
            //   }
        } catch (com.sun.jersey.api.client.ClientHandlerException che) {
            che.printStackTrace();
        }
    }

    @When("^Add Group Services of CADM is called for group '(.*)' with publicKey '(.*)' certificateFingerprint '(.*)' webhookUrl '(.*)'$")
    public void postAddGroupServiceswithAllDetails(String group,String publicKey, String certificate,String webhookUrl) throws JMSException, IOException {
        //String expectedWebookURL = content.split("\"webhookUrl\":\"")[1].split("\",)[0];
        String input = "{\"groupId\":\""+group+"\",\"apiservice\":{\"publicKey\":\""+publicKey+"\",\"certificateFingerprint\":\""+certificate+"\",\"webhookUrl\":\""+webhookUrl+"\",\"apiBankingEnabled\":\"Y\"}}";
        final com.sun.jersey.api.client.Client client = com.sun.jersey.api.client.Client.create(CADMConfig.configureClient());
        final com.sun.jersey.api.client.WebResource webResource = client
                .resource(CADM_URL+"/cadmapi/service/group");
        try {
            com.sun.jersey.api.client.ClientResponse response = webResource.type(MediaType.APPLICATION_JSON_TYPE)
                    .accept(MediaType.APPLICATION_JSON_TYPE).post(com.sun.jersey.api.client.ClientResponse.class, input);
            System.out.println(response.toString());
            //  if(response.getStatus() ==200) {

            cadmResponse = response.getEntity(String.class);
            cadmStatus = response.getStatus();
            System.out.println("Output from Server .... \n");
            System.out.println(cadmResponse);
            //   }
        } catch (com.sun.jersey.api.client.ClientHandlerException che) {
            che.printStackTrace();
        }
    }


    @Then("^There should be 400 error for CADM$")
    public void cadmErrorVerification(){
        System.out.println(cadmResponse);
        System.out.println(cadmStatus);
        Assert.assertTrue(cadmStatus==400);
        Assert.assertTrue(cadmResponse.contains("{\"statusMessage\":\"FAILED TO PROCESS DUE TO INVALID DATA\","));
    }

    @Then("^There should be 500 error for CADM$")
    public void cadm500ErrorVerification(){
        System.out.println(cadmResponse);
        System.out.println(cadmStatus);
        Assert.assertTrue(cadmStatus==500);
        Assert.assertTrue(cadmResponse.contains("Error updating database"));
    }
    @When("^Add Group Services of CADM is called for the group '(.+)' to disable the group$")
    public void postDisableAddGroupServices(String group) throws JMSException, IOException {
        String content = new Scanner(new File("./src/test/resources/test-data/activationKeyBody" + group + ".json")).useDelimiter("\\Z").next();
        content = content.replaceAll(" ", "");
        //String expectedWebookURL = content.split("\"webhookUrl\":\"")[1].split("\",)[0];
        String expectedFingerprint = content.split("\"certificateThumbprint\":\"")[1].split("\",")[0];
        String expectedPublickey = content.split("\"publicKey\":\"")[1].split("\",")[0];
        String expectedWebookURL = RestAssuredConfig.webhookURL.get(group);
        String input = "{\"groupId\":\""+group+"\",\"apiservice\":{\"publicKey\":\""+expectedPublickey+"\",\"certificateFingerprint\":\""+expectedFingerprint+"\",\"webhookUrl\":\""+expectedWebookURL+"\",\"apiBankingEnabled\":\"N\"}}";
        final com.sun.jersey.api.client.Client client = com.sun.jersey.api.client.Client.create(CADMConfig.configureClient());
        final com.sun.jersey.api.client.WebResource webResource = client
                .resource(CADM_URL+"/cadmapi/service/group");
        try {
            com.sun.jersey.api.client.ClientResponse response = webResource.type(MediaType.APPLICATION_JSON_TYPE)
                    .accept(MediaType.APPLICATION_JSON_TYPE).post(com.sun.jersey.api.client.ClientResponse.class, input);
            System.out.println(response.toString());
            //  if(response.getStatus() ==200) {

            String output = response.getEntity(String.class);
            System.out.println("Output from Server .... \n");
            System.out.println(output);
            //   }
        } catch (com.sun.jersey.api.client.ClientHandlerException che) {
            che.printStackTrace();
        }
    }

    @Then("^Get group Services should return with service for the group '(.+)'$")
    public String getGroupServices(String group){
        String output="";
        final com.sun.jersey.api.client.Client client = com.sun.jersey.api.client.Client.create(CADMConfig.configureClient());
        final com.sun.jersey.api.client.WebResource webResource = client
                .resource(CADM_URL+"/cadmapi/service/group/"+group);
        try {
            com.sun.jersey.api.client.ClientResponse response = webResource.type(MediaType.APPLICATION_JSON_TYPE)
                    .accept(MediaType.APPLICATION_JSON_TYPE).get(com.sun.jersey.api.client.ClientResponse.class);
            System.out.println(response.toString());
            if(response.getStatus() ==200) {
                output = response.getEntity(String.class);
                System.out.println("Output from Server .... \n");
                System.out.println(output);
            }

        } catch (com.sun.jersey.api.client.ClientHandlerException che) {
            che.printStackTrace();
        }
        return output;
    }

    @When("^I clear the cache for the '(.+)' group$")
    public void clearCacheForGroup(String groupID){
        CADMConfig cadmConfig = new CADMConfig();
        //Call Get API of Get group services
        cadmConfig.getCADMResponse("/cadmapi/service/group/",groupID);
        //Call Get API of Get Account services
        cadmConfig.getCADMResponse("/cadmapi/service/group/accounts/",groupID);
        //Call Get API of Get BOBAI
        cadmConfig.getCADMResponse("/cadmapi/service/refdata/bosysbaicode/","IN");
    }

    @Then("^APIBanking should be enabled in CADM for the group '(.+)'$")
    public void verifyServiceAvailableInCADM(String groupID) throws FileNotFoundException {
        CADMConfig cadmConfig = new CADMConfig();
        //Call Get API of Get group services
        String response = cadmConfig.getCADMResponse("/cadmapi/service/group/", groupID);
        String actualWebookURL = response.split("\"webhookUrl\":\"")[1].split("\",\"")[0];

        String actualfingerprint = response.split("certificateFingerprint\":\"")[1].split("\",\"")[0];
        String actualpublickey = response.split("\"publicKey\":\"")[1].split("\"}}")[0];
        String actualAPIBankingEnabled = response.split("\"apiBankingEnabled\":\"")[1].split("\",\"")[0];
        String content = new Scanner(new File("./src/test/resources/test-data/activationKeyBody" + groupID + ".json")).useDelimiter("\\Z").next();
        content = content.replaceAll(" ", "");
        //String expectedWebookURL = content.split("\"webhookUrl\":\"")[1].split("\",)[0];
        String expectedFingerprint = content.split("\"certificateThumbprint\":\"")[1].split("\",")[0];
        String expectedPublickey = content.split("\"publicKey\":\"")[1].split("\",")[0];
        String expectedWebookURL = RestAssuredConfig.webhookURL.get(groupID);
        //Assert.assertTrue(response.contains(""));
        Assert.assertTrue("The API Banking service is not enabled in CADM for the group" + groupID, response.contains("{\"productCode\":\"OTH\",\"productName\":\"Other Services\",\"services\":[{\"serviceCode\":\"API\",\"serviceName\":\"API Banking\"}]}]"));
        Assert.assertTrue("The value of fingerprint is not displayed as expected in CADM for the group" + groupID, expectedFingerprint.equals(actualfingerprint));
        Assert.assertTrue("The value of public key is not displayed as expected in CADM for the group" + groupID, expectedPublickey.equals(actualpublickey));
        Assert.assertTrue("The value of webhook URL is not displayed as expected in CADM for the group" + groupID, expectedWebookURL.equals(actualWebookURL));
        Assert.assertTrue("The value of apienabled is not displayed as expected in CADM for the group" + groupID, actualAPIBankingEnabled.equals("Y"));
    }
    @Then("^APIBanking should be disabled in CADM for the group '(.+)'$")
    public void verifyServiceUnavailableInCADM(String groupID){
        CADMConfig cadmConfig = new CADMConfig();
        //Call Get API of Get group services
        String response = cadmConfig.getCADMResponse("/cadmapi/service/group/",groupID);
        Assert.assertFalse("The API Banking service is not enabled in CADM for the group" + groupID, response.contains("{\"productCode\":\"OTH\",\"productName\":\"Other Services\",\"services\":[{\"serviceCode\":\"API\",\"serviceName\":\"API Banking\"}]}]"));

    }

    @Then("^Get group account Services should return with response for the group '(.+)'")
    public void getGroupAccountServices(String group){
        final com.sun.jersey.api.client.Client client = com.sun.jersey.api.client.Client.create(CADMConfig.configureClient());
        final com.sun.jersey.api.client.WebResource webResource = client
                .resource(CADM_URL+"/cadmapi/service/group/accounts/"+group);
        //.resource("https://10.20.166.89:756/cadmapi/service/accounts/GHEBBS01");
        try {
            com.sun.jersey.api.client.ClientResponse response = webResource.type(MediaType.APPLICATION_JSON_TYPE)
                    .accept(MediaType.APPLICATION_JSON_TYPE).get(com.sun.jersey.api.client.ClientResponse.class);
            System.out.println(response.toString());
            // if((response.getStatus() ==200)||(response.getStatus() ==400)){
            String output = response.getEntity(String.class);
            System.out.println("Output from Server .... \n");
            System.out.println(output);
            //   }
        } catch (com.sun.jersey.api.client.ClientHandlerException che) {
            che.printStackTrace();
        }
    }

    @Then("^Get BOBAI Code Mapping Services should return with response for the group country '(.+)'")
    public void getBOBAICodeMappingServices(String grpCountry){
        final com.sun.jersey.api.client.Client client = com.sun.jersey.api.client.Client.create(CADMConfig.configureClient());
        final com.sun.jersey.api.client.WebResource webResource = client
                .resource(CADM_URL+"/cadmapi/service/refdata/bosysbaicode/"+grpCountry);
        //.resource("https://10.20.166.89:756/cadmapi/service/accounts/GHEBBS01");
        try {
            com.sun.jersey.api.client.ClientResponse response = webResource.type(MediaType.APPLICATION_JSON_TYPE)
                    .accept(MediaType.APPLICATION_JSON_TYPE).get(com.sun.jersey.api.client.ClientResponse.class);
            if(response.getStatus() ==200){
                String output = response.getEntity(String.class);
                System.out.println("Output from Server .... \n");
                System.out.println(output);
            }
        } catch (com.sun.jersey.api.client.ClientHandlerException che) {
            che.printStackTrace();
        }
    }
}
