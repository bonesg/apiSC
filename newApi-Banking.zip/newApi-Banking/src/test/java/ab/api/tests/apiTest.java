package ab.api.tests;

import cucumber.api.CucumberOptions;
import cucumber.api.junit.Cucumber;
import org.junit.runner.RunWith;

@RunWith(Cucumber.class)
@CucumberOptions(
        features = {"classpath:features"},
        glue = {
        "classpath:ab.glue",
        },
        tags = {"@akamai","~@ignore"},
        strict = true

        //createActivationkey: http://uklvadapp007:8080/api/createActivationkey
        //Activate: apitest.standardchartered.com:443/api/v1/activate

)
public class apiTest {

}
