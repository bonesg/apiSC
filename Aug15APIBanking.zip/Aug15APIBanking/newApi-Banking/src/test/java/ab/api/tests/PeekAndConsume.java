package ab.api.tests;

import io.restassured.RestAssured;
import io.restassured.config.SSLConfig;
import org.junit.Test;

import java.io.FileInputStream;
import java.security.KeyStore;
import java.security.KeyStoreException;

import static io.restassured.RestAssured.given;

/**
 * Created by 1571168 on 7/31/2017.
 */
public class PeekAndConsume {

    @Test
    public void peekTest(){
        KeyStore keyStore = null;
        try {
            keyStore = KeyStore.getInstance("PKCS12");
            keyStore.load(new FileInputStream("./src/test/resources/test-data/certificate.pfx"), "123456".toCharArray());
            org.apache.http.conn.ssl.SSLSocketFactory clientAuthFactory = null;
            clientAuthFactory = new org.apache.http.conn.ssl.SSLSocketFactory(keyStore, "123456");
            SSLConfig config = null;
            config = new SSLConfig().with().sslSocketFactory(clientAuthFactory).and().allowAllHostnames();
            RestAssured.config = RestAssured.config().sslConfig(config);
            String data = given()
                    //.proxy("10.23.210.60", 8080)
                    .header("JWTToken","eyJhbGciOiJSUzI1NiJ9.eyJpc3MiOiJTQ0IiLCJhdWQiOiJTQ0ItQVBJQmFua2luZyIsImlhdCI6MTUwMjY4MDQyMCwiZXhwIjozMDAwMDE1MDI2ODA0MjAsInBheWxvYWQiOnsiZW5hYmxlV2ViSG9vayI6InRydWUiLCJ3ZWJIb29rVXJsIjoiaHR0cDovLzEwLjIzLjIxMC41OTo4NDQzIiwiYWN0aXZhdGlvbktleSI6eyJjb250ZW50IjoidHh4S1ZVMWdURUN5U0tKM2dNanVrR3JWQTQ1OEdrdUQwbkdSRGY2MkZUVXRtN3krVXBZelpxMnRvSXhRSUZmaFpXZVNtU3hsZy9qa2tNQ0NzMHY0Vk56ZWJTSm05TmwwV2VFNlJldk5vT3M0T1dpVHRNZjk2RktkWjY3RWZ5aFN2bVFLUnBHeHc0YjVUU2c4enV1Q05LbVEveHFRRG1XNEx4UkpkV0tlOTVoWVBnZDY5ZUhaWWxJbENuSlZEWTA4ZkRtZFhUc2hlRVVJTVgwWlh1N0JNZDZ2MStPQi90ZUVYenpISDlJcE1ES3llcnVEZndRbUp2dWozR1NkeHVJVUpwZmxMZG5WelZSaUVOb2plajVzTmRsbGcvNEx6N0paNFBuT2VDZ0tJQytMdUVwcjU4dmRtQmxDeGYzcXRrYmRYM3BhR2FSSkRWTzE3ekM0cjh6a3BPbWF5dHpPKzZpTXU2TEdQK3RtTTVMbmNjN1UyQThiOFNCMlhaUFB2YkNSOVF1WlFMREphT1NFOTdRdG8xaDMvTzZmeXVJc1NqRm1iZFAvYnRtLzl4VE5zZW9RNllRUWIvaTB6akI0cXRTckQyT0QwRGF0R1AyQ09LaWZBK2VVL0sybnFKRlZTM1FMRUZuQis5Qm8xQi9saXoyUUZ6bmtaNTdPMmJWcStsbGFxd1ZYSTlSSFZ1NklFTnFsejJHYW1BVmJPWGtGY1d4a0FsMXMzRTk5YzFKTGtrNU9Xb1h4V1dlZitPQUxaZ1ZFemlxWUJ1UkgvRVJUdGo4bVVTcEloWlhjZHlPS3dseTlMWlhkVXI4Y2RwN2Z6Z3RzNndkUUJLZmJUWUVKcEJnRUVYK1B5TFBxUE9zbFN2S05OOHdIQU16MlZqeEI5YXRoeGI5Q2dwY3F2NFR3L0lEaUdNQjAwQ2c0R1k0TzdmYXRJaHVsaStYeUc3Q3B2VCtJNnZQWEdHMXFISklyQk5BaFl1L1diOFhXR2VSc1ZKdE1YVGxhQmhtQnkvR0hxNU9uMGhUajliaWJnQU1WVC9mQmlPc29XdFFrWDdEcWd3cFI1SjdZWnc2aWw0SXFuVll0aHEranYxdFB0QUJOUlM0QyIsImtleSI6IjB1bXkvZ2huS0JGR1pvUXB3dmEySmZWK2JOMGdVdlNheWplUEcrOTdVTE42UWowWkMrcVYzT1RNS0QwdlNZeEMrVjZ2V3YzcWc0dFM1U3hwaXpSdk4xd2RVamM0NkpEcDhLLzZ3ZjU3UWsvbzZCeGRkNi8yZGU4OGlVazI4RWRqaWhUTU1pQUNkTkJWTmRJY3Arc2JEdXh2WE9PemQ1RlU1VS8vMG92eUxFbXpzT1YxRG10UDg0UjJGeUJ4cXBncnRpc3ptd2txaW5IMnVOSjJEcXVpbGU2ekpYMko0N1E5bjQvT0Nobm9qWVRvK0I3bWRwU3lwZnp0YmZlL3o2c2x5UnRRWGZrTVRwNDMrZG9oRnVhcC9rNEhXV280NytOWHFrTGFLMlVYQnFuSGdyTC93Q1YyZ1lZNmJHaUVyL1BZNEE3T1VLL0FDMzlNUkVDbkQzaEtKUVx1MDAzZFx1MDAzZCJ9fX0.oij290vwdaPoz01llYwk866BPOywgJpvjWZuUj7bjvayVsprBubzPRGizyW0vyuGsNNxmsfRcSsQO1tWUCTkROmOOTl0rlH-4PXi3ZuSJsRPFPrgSuPVs0kzOI7lw6v135U46Grmts1EEsmhn4jkPOv1aVPuvlzUrqUrWSh7Pkzkd7wLfZBxwtW_luGAZXZ-wQ9TE70Ar__0HlulEqjwTETvAVui8YhiIp2XCMiR-5CWRMtbSWHbwD3WjjLDpsjTjA8SvQ5L8zGNfjmXYQ5FcEW-68DsxzpOkBwbAu5E8WBJkPv8BlWNp-pPBUzJzkdaPfjt_CrCkkI3aQC_IrtBOQ")
                    //.contentType(ContentType.TEXT)
                    .when()
                    .get("https://apitest.standardchartered.com/core/event/peek")
                    .thenReturn()
                    .asString();
            System.out.println("Peek Value "+data.toString());
            } catch (Exception e) {
                e.printStackTrace();
            }
    }

    @Test
    public void consumeTest(){
        KeyStore keyStore = null;
        try {
            keyStore = KeyStore.getInstance("PKCS12");
            keyStore.load(new FileInputStream("./src/test/resources/test-data/certificate.pfx"), "123456".toCharArray());
            org.apache.http.conn.ssl.SSLSocketFactory clientAuthFactory = null;
            clientAuthFactory = new org.apache.http.conn.ssl.SSLSocketFactory(keyStore, "123456");
            SSLConfig config = null;
            config = new SSLConfig().with().sslSocketFactory(clientAuthFactory).and().allowAllHostnames();
            RestAssured.config = RestAssured.config().sslConfig(config);
            String data = given()
                    //.proxy("10.23.210.60", 8080)
                    .header("JWTToken","eyJhbGciOiJSUzI1NiJ9.eyJpc3MiOiJTQ0IiLCJhdWQiOiJTQ0ItQVBJQmFua2luZyIsImlhdCI6MTUwMjY4MDQyMCwiZXhwIjozMDAwMDE1MDI2ODA0MjAsInBheWxvYWQiOnsiZW5hYmxlV2ViSG9vayI6InRydWUiLCJ3ZWJIb29rVXJsIjoiaHR0cDovLzEwLjIzLjIxMC41OTo4NDQzIiwiYWN0aXZhdGlvbktleSI6eyJjb250ZW50IjoidHh4S1ZVMWdURUN5U0tKM2dNanVrR3JWQTQ1OEdrdUQwbkdSRGY2MkZUVXRtN3krVXBZelpxMnRvSXhRSUZmaFpXZVNtU3hsZy9qa2tNQ0NzMHY0Vk56ZWJTSm05TmwwV2VFNlJldk5vT3M0T1dpVHRNZjk2RktkWjY3RWZ5aFN2bVFLUnBHeHc0YjVUU2c4enV1Q05LbVEveHFRRG1XNEx4UkpkV0tlOTVoWVBnZDY5ZUhaWWxJbENuSlZEWTA4ZkRtZFhUc2hlRVVJTVgwWlh1N0JNZDZ2MStPQi90ZUVYenpISDlJcE1ES3llcnVEZndRbUp2dWozR1NkeHVJVUpwZmxMZG5WelZSaUVOb2plajVzTmRsbGcvNEx6N0paNFBuT2VDZ0tJQytMdUVwcjU4dmRtQmxDeGYzcXRrYmRYM3BhR2FSSkRWTzE3ekM0cjh6a3BPbWF5dHpPKzZpTXU2TEdQK3RtTTVMbmNjN1UyQThiOFNCMlhaUFB2YkNSOVF1WlFMREphT1NFOTdRdG8xaDMvTzZmeXVJc1NqRm1iZFAvYnRtLzl4VE5zZW9RNllRUWIvaTB6akI0cXRTckQyT0QwRGF0R1AyQ09LaWZBK2VVL0sybnFKRlZTM1FMRUZuQis5Qm8xQi9saXoyUUZ6bmtaNTdPMmJWcStsbGFxd1ZYSTlSSFZ1NklFTnFsejJHYW1BVmJPWGtGY1d4a0FsMXMzRTk5YzFKTGtrNU9Xb1h4V1dlZitPQUxaZ1ZFemlxWUJ1UkgvRVJUdGo4bVVTcEloWlhjZHlPS3dseTlMWlhkVXI4Y2RwN2Z6Z3RzNndkUUJLZmJUWUVKcEJnRUVYK1B5TFBxUE9zbFN2S05OOHdIQU16MlZqeEI5YXRoeGI5Q2dwY3F2NFR3L0lEaUdNQjAwQ2c0R1k0TzdmYXRJaHVsaStYeUc3Q3B2VCtJNnZQWEdHMXFISklyQk5BaFl1L1diOFhXR2VSc1ZKdE1YVGxhQmhtQnkvR0hxNU9uMGhUajliaWJnQU1WVC9mQmlPc29XdFFrWDdEcWd3cFI1SjdZWnc2aWw0SXFuVll0aHEranYxdFB0QUJOUlM0QyIsImtleSI6IjB1bXkvZ2huS0JGR1pvUXB3dmEySmZWK2JOMGdVdlNheWplUEcrOTdVTE42UWowWkMrcVYzT1RNS0QwdlNZeEMrVjZ2V3YzcWc0dFM1U3hwaXpSdk4xd2RVamM0NkpEcDhLLzZ3ZjU3UWsvbzZCeGRkNi8yZGU4OGlVazI4RWRqaWhUTU1pQUNkTkJWTmRJY3Arc2JEdXh2WE9PemQ1RlU1VS8vMG92eUxFbXpzT1YxRG10UDg0UjJGeUJ4cXBncnRpc3ptd2txaW5IMnVOSjJEcXVpbGU2ekpYMko0N1E5bjQvT0Nobm9qWVRvK0I3bWRwU3lwZnp0YmZlL3o2c2x5UnRRWGZrTVRwNDMrZG9oRnVhcC9rNEhXV280NytOWHFrTGFLMlVYQnFuSGdyTC93Q1YyZ1lZNmJHaUVyL1BZNEE3T1VLL0FDMzlNUkVDbkQzaEtKUVx1MDAzZFx1MDAzZCJ9fX0.oij290vwdaPoz01llYwk866BPOywgJpvjWZuUj7bjvayVsprBubzPRGizyW0vyuGsNNxmsfRcSsQO1tWUCTkROmOOTl0rlH-4PXi3ZuSJsRPFPrgSuPVs0kzOI7lw6v135U46Grmts1EEsmhn4jkPOv1aVPuvlzUrqUrWSh7Pkzkd7wLfZBxwtW_luGAZXZ-wQ9TE70Ar__0HlulEqjwTETvAVui8YhiIp2XCMiR-5CWRMtbSWHbwD3WjjLDpsjTjA8SvQ5L8zGNfjmXYQ5FcEW-68DsxzpOkBwbAu5E8WBJkPv8BlWNp-pPBUzJzkdaPfjt_CrCkkI3aQC_IrtBOQ")
                    //.contentType(ContentType.TEXT)
                    .when()
                    .get("https://apitest.standardchartered.com/core/event/consume")
                    .thenReturn()
                    .asString();
            System.out.println("Peek Value "+data.toString());
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}