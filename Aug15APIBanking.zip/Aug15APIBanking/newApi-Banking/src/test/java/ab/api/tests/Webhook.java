package ab.api.tests;

import java.io.BufferedReader;
import java.io.File;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.concurrent.TimeUnit;

/**
 * Created by maneesh on 11/8/17.
 */
@SuppressWarnings("Since15")
public class Webhook {

    public static void main(String args[]) throws IOException {
        File instFolder = new File("/Users/maneesh/Downloads/AWSUbuntuPrivateKey.pem");
        String os = instFolder.toString();
        File instFolder1 = new File("/home/ubuntu/webhook/webhook");
        String os1 = instFolder1.toString();

        String[] commands = {//"ls",os
                "ssh","-i",os, "ubuntu@ec2-18-220-156-2.us-east-2.compute.amazonaws.com","sudo docker start -i",os1
                };

        String[] cmd = { "/bin/sh", "-c", "cd /Users/maneesh/Downloads; ssh -i AWSUbuntuPrivateKey.pem ubuntu@ec2-18-220-156-2.us-east-2.compute.amazonaws.com;" };
        Process p = Runtime.getRuntime().exec(cmd);
        ProcessBuilder builder = new ProcessBuilder(//"ls",os
                "ssh","-i",os, "ubuntu@ec2-18-220-156-2.us-east-2.compute.amazonaws.com",  "sudo docker start -i /home/ubuntu/webhook/webhook"

        );
        builder.redirectOutput(ProcessBuilder.Redirect.INHERIT);
        builder.redirectError(ProcessBuilder.Redirect.INHERIT);
        builder.redirectErrorStream(true);
        Process proc = builder.start();

        //proc = builder.start();
        /*Process proc = null;
        try {
            proc = rt.exec(commands);
            //proc.waitFor();
            final boolean alive;
            if (proc.isAlive()) alive = true;
            else alive = false;
            System.out.println("Alive value " + alive);
            int exitVal =  proc.exitValue();


            System.out.println("ExitValue: " + exitVal);

        } catch (Exception e) {
            e.printStackTrace();
        }*/
        try

        {

        BufferedReader stdInput = new BufferedReader(new
                InputStreamReader(proc.getInputStream()));

        BufferedReader stdError = new BufferedReader(new
                InputStreamReader(proc.getErrorStream()));

        // read the output from the command
        System.out.println("Here is the standard output of the command:\n");
        String s = null;
        while((s =stdInput.readLine())!=null)

        {
            System.out.println(s);
        }

        // read any errors from the attempted command
        System.out.println("Here is the standard error of the command (if any):\n");
        while((s =stdError.readLine())!=null)

        {
            System.out.println(s);
        }
            int exitVal =  proc.waitFor();


            System.out.println("ExitValue: " + exitVal);
    }catch(Exception e) {
        e.printStackTrace();
    }
    }
}
