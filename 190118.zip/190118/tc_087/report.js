$(document).ready(function() {var formatter = new CucumberHTML.DOMFormatter($('.cucumber-report'));formatter.uri("api/endToEnd.feature");
formatter.feature({
  "line": 1,
  "name": "End to End Scenarios for APIBanking",
  "description": "",
  "id": "end-to-end-scenarios-for-apibanking",
  "keyword": "Feature"
});
formatter.scenarioOutline({
  "line": 146,
  "name": "TC_008,TC-019  - When Api banking is disabled, Peek consume, recover and webhook messages should not be displayed.",
  "description": "",
  "id": "end-to-end-scenarios-for-apibanking;tc-008,tc-019----when-api-banking-is-disabled,-peek-consume,-recover-and-webhook-messages-should-not-be-displayed.",
  "type": "scenario_outline",
  "keyword": "Scenario Outline",
  "tags": [
    {
      "line": 145,
      "name": "@ab"
    },
    {
      "line": 145,
      "name": "@tc8"
    },
    {
      "line": 145,
      "name": "@regression"
    },
    {
      "line": 145,
      "name": "@tc08"
    },
    {
      "line": 145,
      "name": "@tc19"
    }
  ]
});
formatter.step({
  "comments": [
    {
      "line": 147,
      "value": "#Given \u0027activationKey and activate\u0027 API"
    },
    {
      "line": 148,
      "value": "#And user has valid SSL certificate"
    },
    {
      "line": 149,
      "value": "#And user has already generated the JWT token for the group \u0027\u003cGroupID\u003e\u0027"
    },
    {
      "line": 150,
      "value": "#When a POST request is made to axway endpoint for the group \u0027\u003cGroupID\u003e\u0027"
    },
    {
      "line": 151,
      "value": "# Then user should be registered successfully"
    },
    {
      "line": 152,
      "value": "#And APIBanking should be enabled in CADM for the group \u0027\u003cGroupID\u003e\u0027"
    },
    {
      "line": 153,
      "value": "#When Add Group Services of CADM is called for the group \u0027\u003cGroupID\u003e\u0027 to disable the group"
    },
    {
      "line": 154,
      "value": "#And I clear the cache for the \u0027\u003cGroupID\u003e\u0027 group"
    },
    {
      "line": 155,
      "value": "# Then APIBanking should be disabled in CADM for the group \u0027\u003cGroupID\u003e\u0027"
    },
    {
      "line": 156,
      "value": "# I consume all the previous messages"
    },
    {
      "line": 157,
      "value": "#When the webhook is turned off"
    },
    {
      "line": 158,
      "value": "#When user modifies Stub with amount \u0027\u003cAmount\u003e\u0027 account number \u0027\u003cAccountNo\u003e\u0027 transaction type \u0027\u003cCreditDebit\u003e\u0027 Currency Code \u0027INR\u0027 BIC \u0027SCBLINBBXXX\u0027"
    }
  ],
  "line": 159,
  "name": "Peek response should be displayed with the deactivate error message for the group \u0027\u003cGroupID\u003e\u0027",
  "keyword": "Then "
});
formatter.step({
  "line": 160,
  "name": "Consume response should be displayed with the deactivate error message for the group \u0027\u003cGroupID\u003e\u0027",
  "keyword": "And "
});
formatter.step({
  "line": 161,
  "name": "Recover response should be displayed with the deactivate error message for the group \u0027\u003cGroupID\u003e\u0027",
  "keyword": "And "
});
formatter.examples({
  "comments": [
    {
      "line": 162,
      "value": "#When the Webhook is turned on"
    },
    {
      "line": 163,
      "value": "#Then Webhook should be displayed with the empty message"
    }
  ],
  "line": 164,
  "name": "",
  "description": "",
  "id": "end-to-end-scenarios-for-apibanking;tc-008,tc-019----when-api-banking-is-disabled,-peek-consume,-recover-and-webhook-messages-should-not-be-displayed.;",
  "rows": [
    {
      "cells": [
        "Amount",
        "AccountNo",
        "CreditDebit",
        "GroupID"
      ],
      "line": 165,
      "id": "end-to-end-scenarios-for-apibanking;tc-008,tc-019----when-api-banking-is-disabled,-peek-consume,-recover-and-webhook-messages-should-not-be-displayed.;;1"
    },
    {
      "cells": [
        "2213.89",
        "22205269504",
        "D",
        "INDUPI01"
      ],
      "line": 166,
      "id": "end-to-end-scenarios-for-apibanking;tc-008,tc-019----when-api-banking-is-disabled,-peek-consume,-recover-and-webhook-messages-should-not-be-displayed.;;2"
    }
  ],
  "keyword": "Examples"
});
formatter.before({
  "duration": 1008972445,
  "status": "passed"
});
formatter.scenario({
  "line": 166,
  "name": "TC_008,TC-019  - When Api banking is disabled, Peek consume, recover and webhook messages should not be displayed.",
  "description": "",
  "id": "end-to-end-scenarios-for-apibanking;tc-008,tc-019----when-api-banking-is-disabled,-peek-consume,-recover-and-webhook-messages-should-not-be-displayed.;;2",
  "type": "scenario",
  "keyword": "Scenario Outline",
  "tags": [
    {
      "line": 145,
      "name": "@ab"
    },
    {
      "line": 145,
      "name": "@regression"
    },
    {
      "line": 145,
      "name": "@tc8"
    },
    {
      "line": 145,
      "name": "@tc08"
    },
    {
      "line": 145,
      "name": "@tc19"
    }
  ]
});
formatter.step({
  "comments": [
    {
      "line": 147,
      "value": "#Given \u0027activationKey and activate\u0027 API"
    },
    {
      "line": 148,
      "value": "#And user has valid SSL certificate"
    },
    {
      "line": 149,
      "value": "#And user has already generated the JWT token for the group \u0027\u003cGroupID\u003e\u0027"
    },
    {
      "line": 150,
      "value": "#When a POST request is made to axway endpoint for the group \u0027\u003cGroupID\u003e\u0027"
    },
    {
      "line": 151,
      "value": "# Then user should be registered successfully"
    },
    {
      "line": 152,
      "value": "#And APIBanking should be enabled in CADM for the group \u0027\u003cGroupID\u003e\u0027"
    },
    {
      "line": 153,
      "value": "#When Add Group Services of CADM is called for the group \u0027\u003cGroupID\u003e\u0027 to disable the group"
    },
    {
      "line": 154,
      "value": "#And I clear the cache for the \u0027\u003cGroupID\u003e\u0027 group"
    },
    {
      "line": 155,
      "value": "# Then APIBanking should be disabled in CADM for the group \u0027\u003cGroupID\u003e\u0027"
    },
    {
      "line": 156,
      "value": "# I consume all the previous messages"
    },
    {
      "line": 157,
      "value": "#When the webhook is turned off"
    },
    {
      "line": 158,
      "value": "#When user modifies Stub with amount \u0027\u003cAmount\u003e\u0027 account number \u0027\u003cAccountNo\u003e\u0027 transaction type \u0027\u003cCreditDebit\u003e\u0027 Currency Code \u0027INR\u0027 BIC \u0027SCBLINBBXXX\u0027"
    }
  ],
  "line": 159,
  "name": "Peek response should be displayed with the deactivate error message for the group \u0027INDUPI01\u0027",
  "matchedColumns": [
    3
  ],
  "keyword": "Then "
});
formatter.step({
  "line": 160,
  "name": "Consume response should be displayed with the deactivate error message for the group \u0027INDUPI01\u0027",
  "matchedColumns": [
    3
  ],
  "keyword": "And "
});
formatter.step({
  "line": 161,
  "name": "Recover response should be displayed with the deactivate error message for the group \u0027INDUPI01\u0027",
  "matchedColumns": [
    3
  ],
  "keyword": "And "
});
formatter.match({
  "arguments": [
    {
      "val": "INDUPI01",
      "offset": 83
    }
  ],
  "location": "PeekAndConsume.verifyDeactivateErrorMessageForPeek(String)"
});
formatter.result({
  "duration": 4176136385,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "INDUPI01",
      "offset": 86
    }
  ],
  "location": "PeekAndConsume.verifyDeactivateErrorMessageForConsume(String)"
});
formatter.result({
  "duration": 806996339,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "INDUPI01",
      "offset": 86
    }
  ],
  "location": "PeekAndConsume.verifyDeactivateErrorMessageForRecover(String)"
});
formatter.result({
  "duration": 1718328361,
  "status": "passed"
});
});