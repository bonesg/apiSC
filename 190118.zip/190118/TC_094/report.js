$(document).ready(function() {var formatter = new CucumberHTML.DOMFormatter($('.cucumber-report'));formatter.uri("api/pull.feature");
formatter.feature({
  "line": 1,
  "name": "Pull Mechanism scenarios",
  "description": "",
  "id": "pull-mechanism-scenarios",
  "keyword": "Feature"
});
formatter.scenarioOutline({
  "line": 245,
  "name": "TC_PULL_008, TC_062, TC_083 - When both webhook is down, verify messages for Recover of Group A and Consume of Group B",
  "description": "",
  "id": "pull-mechanism-scenarios;tc-pull-008,-tc-062,-tc-083---when-both-webhook-is-down,-verify-messages-for-recover-of-group-a-and-consume-of-group-b",
  "type": "scenario_outline",
  "keyword": "Scenario Outline",
  "tags": [
    {
      "line": 244,
      "name": "@ab"
    },
    {
      "line": 244,
      "name": "@peekAndConsume"
    },
    {
      "line": 244,
      "name": "@regression"
    },
    {
      "line": 244,
      "name": "@pull"
    },
    {
      "line": 244,
      "name": "@pull8"
    },
    {
      "line": 244,
      "name": "@tc62"
    },
    {
      "line": 244,
      "name": "@tc94genie"
    }
  ]
});
formatter.step({
  "comments": [
    {
      "line": 246,
      "value": "#When Add Group Services of CADM is called for the group \u0027\u003cGroupID\u003e\u0027 to disable the group"
    },
    {
      "line": 247,
      "value": "#Then APIBanking should be disabled in CADM for the group \u0027\u003cGroupID\u003e\u0027"
    },
    {
      "line": 248,
      "value": "#    Given \u0027activationKey and activate\u0027 API"
    },
    {
      "line": 249,
      "value": "#    And user has valid SSL certificate"
    },
    {
      "line": 250,
      "value": "#    And user has already generated the JWT token for the group \u0027\u003cGroupIDA\u003e\u0027"
    },
    {
      "line": 251,
      "value": "#    When a POST request is made to axway endpoint for the group \u0027\u003cGroupIDA\u003e\u0027"
    },
    {
      "line": 252,
      "value": "#    Then user should be registered successfully"
    },
    {
      "line": 253,
      "value": "#    And APIBanking should be enabled in CADM for the group \u0027\u003cGroupIDA\u003e\u0027"
    },
    {
      "line": 254,
      "value": "#    Given user has already generated the JWT token for the group \u0027\u003cGroupIDB\u003e\u0027"
    },
    {
      "line": 255,
      "value": "#    When a POST request is made to axway endpoint for the group \u0027\u003cGroupIDB\u003e\u0027"
    },
    {
      "line": 256,
      "value": "#    Then user should be registered successfully"
    },
    {
      "line": 257,
      "value": "#    And APIBanking should be enabled in CADM for the group \u0027\u003cGroupIDB\u003e\u0027"
    },
    {
      "line": 258,
      "value": "#When user modifies Stub with amount \u0027\u003cAmount\u003e\u0027 account number \u0027\u003cAccountNo\u003e\u0027 transaction type \u0027\u003cCreditDebit\u003e\u0027 Currency Code \u0027INR\u0027 BIC \u0027SCBLINBBXXX\u0027"
    }
  ],
  "line": 259,
  "name": "Recover response should be displayed with amount \u0027\u003cAmount\u003e\u0027 accountNo \u0027\u003cAccountNo\u003e\u0027 transactionType \u0027\u003cCreditDebit\u003e\u0027 the expected value for the group \u0027\u003cGroupIDA\u003e\u0027",
  "keyword": "Then "
});
formatter.step({
  "line": 260,
  "name": "Peek response should be displayed with amount \u0027\u003cAmount1\u003e\u0027 accountNo \u0027\u003cAccountNo\u003e\u0027 transactionType \u0027\u003cCreditDebit\u003e\u0027 the expected value for the group \u0027\u003cGroupIDB\u003e\u0027",
  "keyword": "Then "
});
formatter.step({
  "line": 261,
  "name": "Consume response should be displayed with amount \u0027\u003cAmount1\u003e\u0027 accountNo \u0027\u003cAccountNo\u003e\u0027 transactionType \u0027\u003cCreditDebit\u003e\u0027 the expected value for the group \u0027\u003cGroupIDB\u003e\u0027",
  "keyword": "Then "
});
formatter.examples({
  "line": 262,
  "name": "",
  "description": "",
  "id": "pull-mechanism-scenarios;tc-pull-008,-tc-062,-tc-083---when-both-webhook-is-down,-verify-messages-for-recover-of-group-a-and-consume-of-group-b;",
  "rows": [
    {
      "cells": [
        "Amount",
        "AccountNo",
        "CreditDebit",
        "GroupIDA",
        "GroupIDB",
        "Amount1"
      ],
      "line": 263,
      "id": "pull-mechanism-scenarios;tc-pull-008,-tc-062,-tc-083---when-both-webhook-is-down,-verify-messages-for-recover-of-group-a-and-consume-of-group-b;;1"
    },
    {
      "cells": [
        "85.36",
        "22205269504",
        "D",
        "INDGRP1",
        "INDGRP1",
        "7210"
      ],
      "line": 264,
      "id": "pull-mechanism-scenarios;tc-pull-008,-tc-062,-tc-083---when-both-webhook-is-down,-verify-messages-for-recover-of-group-a-and-consume-of-group-b;;2"
    }
  ],
  "keyword": "Examples"
});
formatter.before({
  "duration": 963830433,
  "status": "passed"
});
formatter.scenario({
  "line": 264,
  "name": "TC_PULL_008, TC_062, TC_083 - When both webhook is down, verify messages for Recover of Group A and Consume of Group B",
  "description": "",
  "id": "pull-mechanism-scenarios;tc-pull-008,-tc-062,-tc-083---when-both-webhook-is-down,-verify-messages-for-recover-of-group-a-and-consume-of-group-b;;2",
  "type": "scenario",
  "keyword": "Scenario Outline",
  "tags": [
    {
      "line": 244,
      "name": "@ab"
    },
    {
      "line": 244,
      "name": "@peekAndConsume"
    },
    {
      "line": 244,
      "name": "@pull8"
    },
    {
      "line": 244,
      "name": "@regression"
    },
    {
      "line": 244,
      "name": "@tc62"
    },
    {
      "line": 244,
      "name": "@pull"
    },
    {
      "line": 244,
      "name": "@tc94genie"
    }
  ]
});
formatter.step({
  "comments": [
    {
      "line": 246,
      "value": "#When Add Group Services of CADM is called for the group \u0027\u003cGroupID\u003e\u0027 to disable the group"
    },
    {
      "line": 247,
      "value": "#Then APIBanking should be disabled in CADM for the group \u0027\u003cGroupID\u003e\u0027"
    },
    {
      "line": 248,
      "value": "#    Given \u0027activationKey and activate\u0027 API"
    },
    {
      "line": 249,
      "value": "#    And user has valid SSL certificate"
    },
    {
      "line": 250,
      "value": "#    And user has already generated the JWT token for the group \u0027\u003cGroupIDA\u003e\u0027"
    },
    {
      "line": 251,
      "value": "#    When a POST request is made to axway endpoint for the group \u0027\u003cGroupIDA\u003e\u0027"
    },
    {
      "line": 252,
      "value": "#    Then user should be registered successfully"
    },
    {
      "line": 253,
      "value": "#    And APIBanking should be enabled in CADM for the group \u0027\u003cGroupIDA\u003e\u0027"
    },
    {
      "line": 254,
      "value": "#    Given user has already generated the JWT token for the group \u0027\u003cGroupIDB\u003e\u0027"
    },
    {
      "line": 255,
      "value": "#    When a POST request is made to axway endpoint for the group \u0027\u003cGroupIDB\u003e\u0027"
    },
    {
      "line": 256,
      "value": "#    Then user should be registered successfully"
    },
    {
      "line": 257,
      "value": "#    And APIBanking should be enabled in CADM for the group \u0027\u003cGroupIDB\u003e\u0027"
    },
    {
      "line": 258,
      "value": "#When user modifies Stub with amount \u0027\u003cAmount\u003e\u0027 account number \u0027\u003cAccountNo\u003e\u0027 transaction type \u0027\u003cCreditDebit\u003e\u0027 Currency Code \u0027INR\u0027 BIC \u0027SCBLINBBXXX\u0027"
    }
  ],
  "line": 259,
  "name": "Recover response should be displayed with amount \u002785.36\u0027 accountNo \u002722205269504\u0027 transactionType \u0027D\u0027 the expected value for the group \u0027INDGRP1\u0027",
  "matchedColumns": [
    0,
    1,
    2,
    3
  ],
  "keyword": "Then "
});
formatter.step({
  "line": 260,
  "name": "Peek response should be displayed with amount \u00277210\u0027 accountNo \u002722205269504\u0027 transactionType \u0027D\u0027 the expected value for the group \u0027INDGRP1\u0027",
  "matchedColumns": [
    1,
    2,
    4,
    5
  ],
  "keyword": "Then "
});
formatter.step({
  "line": 261,
  "name": "Consume response should be displayed with amount \u00277210\u0027 accountNo \u002722205269504\u0027 transactionType \u0027D\u0027 the expected value for the group \u0027INDGRP1\u0027",
  "matchedColumns": [
    1,
    2,
    4,
    5
  ],
  "keyword": "Then "
});
formatter.match({
  "arguments": [
    {
      "val": "85.36",
      "offset": 50
    },
    {
      "val": "22205269504",
      "offset": 68
    },
    {
      "val": "D",
      "offset": 98
    },
    {
      "val": "INDGRP1",
      "offset": 135
    }
  ],
  "location": "PeekAndConsume.recoverValueTest(String,String,String,String)"
});
formatter.result({
  "duration": 4916689133,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "7210",
      "offset": 47
    },
    {
      "val": "22205269504",
      "offset": 64
    },
    {
      "val": "D",
      "offset": 94
    },
    {
      "val": "INDGRP1",
      "offset": 131
    }
  ],
  "location": "PeekAndConsume.peekValueTest(String,String,String,String)"
});
formatter.result({
  "duration": 1799906134,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "7210",
      "offset": 50
    },
    {
      "val": "22205269504",
      "offset": 67
    },
    {
      "val": "D",
      "offset": 97
    },
    {
      "val": "INDGRP1",
      "offset": 134
    }
  ],
  "location": "PeekAndConsume.consumeValueTest(String,String,String,String)"
});
formatter.result({
  "duration": 1666473345,
  "status": "passed"
});
});