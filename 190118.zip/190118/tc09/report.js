$(document).ready(function() {var formatter = new CucumberHTML.DOMFormatter($('.cucumber-report'));formatter.uri("api/encryption.feature");
formatter.feature({
  "line": 1,
  "name": "Encryption scenario",
  "description": "",
  "id": "encryption-scenario",
  "keyword": "Feature"
});
formatter.scenarioOutline({
  "line": 4,
  "name": "TC_050-TC_052 Verify Encrypted Value displayed for Pull requests. On decrypting the value with correct private key expected message should be displayed",
  "description": "",
  "id": "encryption-scenario;tc-050-tc-052-verify-encrypted-value-displayed-for-pull-requests.-on-decrypting-the-value-with-correct-private-key-expected-message-should-be-displayed",
  "type": "scenario_outline",
  "keyword": "Scenario Outline",
  "tags": [
    {
      "line": 3,
      "name": "@ab"
    },
    {
      "line": 3,
      "name": "@peekAndConsume"
    },
    {
      "line": 3,
      "name": "@regression"
    },
    {
      "line": 3,
      "name": "@encryption"
    },
    {
      "line": 3,
      "name": "@tc50-tc52"
    }
  ]
});
formatter.step({
  "line": 5,
  "name": "\u0027activationKey and activate\u0027 API",
  "keyword": "Given "
});
formatter.step({
  "line": 6,
  "name": "user has valid SSL certificate",
  "keyword": "And "
});
formatter.step({
  "line": 7,
  "name": "user has already generated the JWT token for the group \u0027\u003cGroupID\u003e\u0027",
  "keyword": "And "
});
formatter.step({
  "comments": [
    {
      "line": 8,
      "value": "#When Add Group Services of CADM is called for the group \u0027\u003cGroupID\u003e\u0027 to disable the group"
    },
    {
      "line": 9,
      "value": "#Then APIBanking should be disabled in CADM for the group \u0027\u003cGroupID\u003e\u0027"
    }
  ],
  "line": 10,
  "name": "a POST request is made to axway endpoint for the group \u0027\u003cGroupID\u003e\u0027",
  "keyword": "When "
});
formatter.step({
  "line": 11,
  "name": "user should be registered successfully",
  "keyword": "Then "
});
formatter.step({
  "comments": [
    {
      "line": 12,
      "value": "#And APIBanking should be enabled in CADM for the group \u0027\u003cGroupID\u003e\u0027"
    },
    {
      "line": 13,
      "value": "#When user modifies Stub with amount \u0027\u003cAmount\u003e\u0027 account number \u0027\u003cAccountNo\u003e\u0027 transaction type \u0027\u003cCreditDebit\u003e\u0027 Currency Code \u0027INR\u0027 BIC \u0027SCBLINBBXXX\u0027"
    }
  ],
  "line": 14,
  "name": "Peek response should be displayed with encrypted value for amount \u0027\u003cAmount\u003e\u0027 accountNo \u0027\u003cAccountNo\u003e\u0027 transactionType \u0027\u003cCreditDebit\u003e\u0027 the expected value for the group \u0027\u003cGroupID\u003e\u0027",
  "keyword": "Then "
});
formatter.step({
  "line": 15,
  "name": "The messages should be decrypted as expected when using privateKey of group \u0027\u003cGroupID\u003e\u0027 for \u0027peek\u0027",
  "keyword": "Then "
});
formatter.examples({
  "comments": [
    {
      "line": 16,
      "value": "#And Consume response should be displayed with encrypted value for amount \u0027\u003cAmount\u003e\u0027 accountNo \u0027\u003cAccountNo\u003e\u0027 transactionType \u0027\u003cCreditDebit\u003e\u0027 the expected value for the group \u0027\u003cGroupID\u003e\u0027"
    },
    {
      "line": 17,
      "value": "#And The messages should be decrypted as expected when using privateKey of group \u0027\u003cGroupID\u003e\u0027 for \u0027consume\u0027"
    },
    {
      "line": 18,
      "value": "#And Recover response should be displayed with encrypted value for amount \u0027\u003cAmount\u003e\u0027 accountNo \u0027\u003cAccountNo\u003e\u0027 transactionType \u0027\u003cCreditDebit\u003e\u0027 the expected value for the group \u0027\u003cGroupID\u003e\u0027"
    },
    {
      "line": 19,
      "value": "#And The messages should be decrypted as expected when using privateKey of group \u0027\u003cGroupID\u003e\u0027 for \u0027recover\u0027"
    }
  ],
  "line": 20,
  "name": "",
  "description": "",
  "id": "encryption-scenario;tc-050-tc-052-verify-encrypted-value-displayed-for-pull-requests.-on-decrypting-the-value-with-correct-private-key-expected-message-should-be-displayed;",
  "rows": [
    {
      "cells": [
        "Amount",
        "AccountNo",
        "CreditDebit",
        "GroupID"
      ],
      "line": 21,
      "id": "encryption-scenario;tc-050-tc-052-verify-encrypted-value-displayed-for-pull-requests.-on-decrypting-the-value-with-correct-private-key-expected-message-should-be-displayed;;1"
    },
    {
      "cells": [
        "42.36",
        "22205269504",
        "C",
        "INDGRP1"
      ],
      "line": 22,
      "id": "encryption-scenario;tc-050-tc-052-verify-encrypted-value-displayed-for-pull-requests.-on-decrypting-the-value-with-correct-private-key-expected-message-should-be-displayed;;2"
    }
  ],
  "keyword": "Examples"
});
formatter.before({
  "duration": 879847472,
  "status": "passed"
});
formatter.scenario({
  "line": 22,
  "name": "TC_050-TC_052 Verify Encrypted Value displayed for Pull requests. On decrypting the value with correct private key expected message should be displayed",
  "description": "",
  "id": "encryption-scenario;tc-050-tc-052-verify-encrypted-value-displayed-for-pull-requests.-on-decrypting-the-value-with-correct-private-key-expected-message-should-be-displayed;;2",
  "type": "scenario",
  "keyword": "Scenario Outline",
  "tags": [
    {
      "line": 3,
      "name": "@encryption"
    },
    {
      "line": 3,
      "name": "@ab"
    },
    {
      "line": 3,
      "name": "@peekAndConsume"
    },
    {
      "line": 3,
      "name": "@regression"
    },
    {
      "line": 3,
      "name": "@tc50-tc52"
    }
  ]
});
formatter.step({
  "line": 5,
  "name": "\u0027activationKey and activate\u0027 API",
  "keyword": "Given "
});
formatter.step({
  "line": 6,
  "name": "user has valid SSL certificate",
  "keyword": "And "
});
formatter.step({
  "line": 7,
  "name": "user has already generated the JWT token for the group \u0027INDGRP1\u0027",
  "matchedColumns": [
    3
  ],
  "keyword": "And "
});
formatter.step({
  "comments": [
    {
      "line": 8,
      "value": "#When Add Group Services of CADM is called for the group \u0027\u003cGroupID\u003e\u0027 to disable the group"
    },
    {
      "line": 9,
      "value": "#Then APIBanking should be disabled in CADM for the group \u0027\u003cGroupID\u003e\u0027"
    }
  ],
  "line": 10,
  "name": "a POST request is made to axway endpoint for the group \u0027INDGRP1\u0027",
  "matchedColumns": [
    3
  ],
  "keyword": "When "
});
formatter.step({
  "line": 11,
  "name": "user should be registered successfully",
  "keyword": "Then "
});
formatter.step({
  "comments": [
    {
      "line": 12,
      "value": "#And APIBanking should be enabled in CADM for the group \u0027\u003cGroupID\u003e\u0027"
    },
    {
      "line": 13,
      "value": "#When user modifies Stub with amount \u0027\u003cAmount\u003e\u0027 account number \u0027\u003cAccountNo\u003e\u0027 transaction type \u0027\u003cCreditDebit\u003e\u0027 Currency Code \u0027INR\u0027 BIC \u0027SCBLINBBXXX\u0027"
    }
  ],
  "line": 14,
  "name": "Peek response should be displayed with encrypted value for amount \u002742.36\u0027 accountNo \u002722205269504\u0027 transactionType \u0027C\u0027 the expected value for the group \u0027INDGRP1\u0027",
  "matchedColumns": [
    0,
    1,
    2,
    3
  ],
  "keyword": "Then "
});
formatter.step({
  "line": 15,
  "name": "The messages should be decrypted as expected when using privateKey of group \u0027INDGRP1\u0027 for \u0027peek\u0027",
  "matchedColumns": [
    3
  ],
  "keyword": "Then "
});
formatter.match({
  "arguments": [
    {
      "val": "activationKey and activate",
      "offset": 1
    }
  ],
  "location": "commonApiMethods.an_API(String)"
});
formatter.result({
  "duration": 179296734,
  "status": "passed"
});
formatter.match({
  "location": "activationKey.user_has_valid_SSL_certificate()"
});
formatter.result({
  "duration": 9684940,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "INDGRP1",
      "offset": 56
    }
  ],
  "location": "activationKey.user_has_already_generated_the_JWT_token_for_the_group(String)"
});
formatter.result({
  "duration": 570963230,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "INDGRP1",
      "offset": 56
    }
  ],
  "location": "activationKey.a_POST_request_is_made_to_axway_endpoint(String)"
});
formatter.result({
  "duration": 4636550470,
  "status": "passed"
});
formatter.match({
  "location": "activationKey.user_should_be_registered_successfully()"
});
formatter.result({
  "duration": 43421,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "42.36",
      "offset": 67
    },
    {
      "val": "22205269504",
      "offset": 85
    },
    {
      "val": "C",
      "offset": 115
    },
    {
      "val": "INDGRP1",
      "offset": 152
    }
  ],
  "location": "PeekAndConsume.peekValueEncryptedTest(String,String,String,String)"
});
formatter.result({
  "duration": 1976761809,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "INDGRP1",
      "offset": 77
    },
    {
      "val": "peek",
      "offset": 91
    }
  ],
  "location": "PeekAndConsume.verifyDecryptedValueGivesActualContent(String,String)"
});
formatter.result({
  "duration": 11937962,
  "status": "passed"
});
});