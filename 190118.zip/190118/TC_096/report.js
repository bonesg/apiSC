$(document).ready(function() {var formatter = new CucumberHTML.DOMFormatter($('.cucumber-report'));formatter.uri("api/encryption.feature");
formatter.feature({
  "line": 1,
  "name": "Encryption scenario",
  "description": "",
  "id": "encryption-scenario",
  "keyword": "Feature"
});
formatter.scenarioOutline({
  "line": 25,
  "name": "TC_053-TC_055 -Verify Encrypted Value displayed for Pull requests. On decrypting the value with different private key expected message should not be displayed",
  "description": "",
  "id": "encryption-scenario;tc-053-tc-055--verify-encrypted-value-displayed-for-pull-requests.-on-decrypting-the-value-with-different-private-key-expected-message-should-not-be-displayed",
  "type": "scenario_outline",
  "keyword": "Scenario Outline",
  "tags": [
    {
      "line": 24,
      "name": "@ab"
    },
    {
      "line": 24,
      "name": "@peekAndConsume"
    },
    {
      "line": 24,
      "name": "@regression"
    },
    {
      "line": 24,
      "name": "@encryption1"
    },
    {
      "line": 24,
      "name": "@tc53-tc55"
    }
  ]
});
formatter.step({
  "comments": [
    {
      "line": 26,
      "value": "#Given \u0027activationKey and activate\u0027 API"
    },
    {
      "line": 27,
      "value": "#And user has valid SSL certificate"
    },
    {
      "line": 28,
      "value": "#And user has already generated the JWT token for the group \u0027\u003cGroupID\u003e\u0027"
    },
    {
      "line": 29,
      "value": "#When Add Group Services of CADM is called for the group \u0027\u003cGroupID\u003e\u0027 to disable the group"
    },
    {
      "line": 30,
      "value": "#Then APIBanking should be disabled in CADM for the group \u0027\u003cGroupID\u003e\u0027"
    },
    {
      "line": 31,
      "value": "#When a POST request is made to axway endpoint for the group \u0027\u003cGroupID\u003e\u0027"
    },
    {
      "line": 32,
      "value": "#Then user should be registered successfully"
    },
    {
      "line": 33,
      "value": "#And APIBanking should be enabled in CADM for the group \u0027\u003cGroupID\u003e\u0027"
    },
    {
      "line": 34,
      "value": "#When user modifies Stub with amount \u0027\u003cAmount\u003e\u0027 account number \u0027\u003cAccountNo\u003e\u0027 transaction type \u0027\u003cCreditDebit\u003e\u0027 Currency Code \u0027INR\u0027 BIC \u0027SCBLINBBXXX\u0027"
    }
  ],
  "line": 35,
  "name": "Peek response should be displayed with encrypted value for amount \u0027\u003cAmount\u003e\u0027 accountNo \u0027\u003cAccountNo\u003e\u0027 transactionType \u0027\u003cCreditDebit\u003e\u0027 the expected value for the group \u0027\u003cGroupID\u003e\u0027",
  "keyword": "Then "
});
formatter.step({
  "line": 36,
  "name": "The messages should not be decrypted as expected when using privateKey of group \u0027\u003cDifferentGroupID\u003e\u0027 for \u0027peek\u0027",
  "keyword": "Then "
});
formatter.step({
  "line": 37,
  "name": "Consume response should be displayed with encrypted value for amount \u0027\u003cAmount\u003e\u0027 accountNo \u0027\u003cAccountNo\u003e\u0027 transactionType \u0027\u003cCreditDebit\u003e\u0027 the expected value for the group \u0027\u003cGroupID\u003e\u0027",
  "keyword": "And "
});
formatter.step({
  "line": 38,
  "name": "The messages should not be decrypted as expected when using privateKey of group \u0027\u003cDifferentGroupID\u003e\u0027 for \u0027consume\u0027",
  "keyword": "And "
});
formatter.step({
  "line": 39,
  "name": "Recover response should be displayed with encrypted value for amount \u0027\u003cAmount\u003e\u0027 accountNo \u0027\u003cAccountNo\u003e\u0027 transactionType \u0027\u003cCreditDebit\u003e\u0027 the expected value for the group \u0027\u003cGroupID\u003e\u0027",
  "keyword": "And "
});
formatter.step({
  "line": 40,
  "name": "The messages should not be decrypted as expected when using privateKey of group \u0027\u003cDifferentGroupID\u003e\u0027 for \u0027recover\u0027",
  "keyword": "And "
});
formatter.examples({
  "line": 41,
  "name": "",
  "description": "",
  "id": "encryption-scenario;tc-053-tc-055--verify-encrypted-value-displayed-for-pull-requests.-on-decrypting-the-value-with-different-private-key-expected-message-should-not-be-displayed;",
  "rows": [
    {
      "cells": [
        "Amount",
        "AccountNo",
        "CreditDebit",
        "GroupID",
        "DifferentGroupID"
      ],
      "line": 42,
      "id": "encryption-scenario;tc-053-tc-055--verify-encrypted-value-displayed-for-pull-requests.-on-decrypting-the-value-with-different-private-key-expected-message-should-not-be-displayed;;1"
    },
    {
      "cells": [
        "7836",
        "17082017",
        "C",
        "INDGRP1",
        "INDSEGSE"
      ],
      "line": 43,
      "id": "encryption-scenario;tc-053-tc-055--verify-encrypted-value-displayed-for-pull-requests.-on-decrypting-the-value-with-different-private-key-expected-message-should-not-be-displayed;;2"
    }
  ],
  "keyword": "Examples"
});
formatter.before({
  "duration": 868979196,
  "status": "passed"
});
formatter.scenario({
  "line": 43,
  "name": "TC_053-TC_055 -Verify Encrypted Value displayed for Pull requests. On decrypting the value with different private key expected message should not be displayed",
  "description": "",
  "id": "encryption-scenario;tc-053-tc-055--verify-encrypted-value-displayed-for-pull-requests.-on-decrypting-the-value-with-different-private-key-expected-message-should-not-be-displayed;;2",
  "type": "scenario",
  "keyword": "Scenario Outline",
  "tags": [
    {
      "line": 24,
      "name": "@ab"
    },
    {
      "line": 24,
      "name": "@peekAndConsume"
    },
    {
      "line": 24,
      "name": "@regression"
    },
    {
      "line": 24,
      "name": "@encryption1"
    },
    {
      "line": 24,
      "name": "@tc53-tc55"
    }
  ]
});
formatter.step({
  "comments": [
    {
      "line": 26,
      "value": "#Given \u0027activationKey and activate\u0027 API"
    },
    {
      "line": 27,
      "value": "#And user has valid SSL certificate"
    },
    {
      "line": 28,
      "value": "#And user has already generated the JWT token for the group \u0027\u003cGroupID\u003e\u0027"
    },
    {
      "line": 29,
      "value": "#When Add Group Services of CADM is called for the group \u0027\u003cGroupID\u003e\u0027 to disable the group"
    },
    {
      "line": 30,
      "value": "#Then APIBanking should be disabled in CADM for the group \u0027\u003cGroupID\u003e\u0027"
    },
    {
      "line": 31,
      "value": "#When a POST request is made to axway endpoint for the group \u0027\u003cGroupID\u003e\u0027"
    },
    {
      "line": 32,
      "value": "#Then user should be registered successfully"
    },
    {
      "line": 33,
      "value": "#And APIBanking should be enabled in CADM for the group \u0027\u003cGroupID\u003e\u0027"
    },
    {
      "line": 34,
      "value": "#When user modifies Stub with amount \u0027\u003cAmount\u003e\u0027 account number \u0027\u003cAccountNo\u003e\u0027 transaction type \u0027\u003cCreditDebit\u003e\u0027 Currency Code \u0027INR\u0027 BIC \u0027SCBLINBBXXX\u0027"
    }
  ],
  "line": 35,
  "name": "Peek response should be displayed with encrypted value for amount \u00277836\u0027 accountNo \u002717082017\u0027 transactionType \u0027C\u0027 the expected value for the group \u0027INDGRP1\u0027",
  "matchedColumns": [
    0,
    1,
    2,
    3
  ],
  "keyword": "Then "
});
formatter.step({
  "line": 36,
  "name": "The messages should not be decrypted as expected when using privateKey of group \u0027INDSEGSE\u0027 for \u0027peek\u0027",
  "matchedColumns": [
    4
  ],
  "keyword": "Then "
});
formatter.step({
  "line": 37,
  "name": "Consume response should be displayed with encrypted value for amount \u00277836\u0027 accountNo \u002717082017\u0027 transactionType \u0027C\u0027 the expected value for the group \u0027INDGRP1\u0027",
  "matchedColumns": [
    0,
    1,
    2,
    3
  ],
  "keyword": "And "
});
formatter.step({
  "line": 38,
  "name": "The messages should not be decrypted as expected when using privateKey of group \u0027INDSEGSE\u0027 for \u0027consume\u0027",
  "matchedColumns": [
    4
  ],
  "keyword": "And "
});
formatter.step({
  "line": 39,
  "name": "Recover response should be displayed with encrypted value for amount \u00277836\u0027 accountNo \u002717082017\u0027 transactionType \u0027C\u0027 the expected value for the group \u0027INDGRP1\u0027",
  "matchedColumns": [
    0,
    1,
    2,
    3
  ],
  "keyword": "And "
});
formatter.step({
  "line": 40,
  "name": "The messages should not be decrypted as expected when using privateKey of group \u0027INDSEGSE\u0027 for \u0027recover\u0027",
  "matchedColumns": [
    4
  ],
  "keyword": "And "
});
formatter.match({
  "arguments": [
    {
      "val": "7836",
      "offset": 67
    },
    {
      "val": "17082017",
      "offset": 84
    },
    {
      "val": "C",
      "offset": 111
    },
    {
      "val": "INDGRP1",
      "offset": 148
    }
  ],
  "location": "PeekAndConsume.peekValueEncryptedTest(String,String,String,String)"
});
formatter.result({
  "duration": 3967235077,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "INDSEGSE",
      "offset": 81
    },
    {
      "val": "peek",
      "offset": 96
    }
  ],
  "location": "PeekAndConsume.verifyMessageNotDecrptedForWrongPrivateKey(String,String)"
});
formatter.result({
  "duration": 14223835,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "7836",
      "offset": 70
    },
    {
      "val": "17082017",
      "offset": 87
    },
    {
      "val": "C",
      "offset": 114
    },
    {
      "val": "INDGRP1",
      "offset": 151
    }
  ],
  "location": "PeekAndConsume.consumeValueEncryptedTest(String,String,String,String)"
});
formatter.result({
  "duration": 1277295859,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "INDSEGSE",
      "offset": 81
    },
    {
      "val": "consume",
      "offset": 96
    }
  ],
  "location": "PeekAndConsume.verifyMessageNotDecrptedForWrongPrivateKey(String,String)"
});
formatter.result({
  "duration": 8085886,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "7836",
      "offset": 70
    },
    {
      "val": "17082017",
      "offset": 87
    },
    {
      "val": "C",
      "offset": 114
    },
    {
      "val": "INDGRP1",
      "offset": 151
    }
  ],
  "location": "PeekAndConsume.recoverValueEncryptedTest(String,String,String,String)"
});
formatter.result({
  "duration": 931478205,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "INDSEGSE",
      "offset": 81
    },
    {
      "val": "recover",
      "offset": 96
    }
  ],
  "location": "PeekAndConsume.verifyMessageNotDecrptedForWrongPrivateKey(String,String)"
});
formatter.result({
  "duration": 11777490,
  "status": "passed"
});
});