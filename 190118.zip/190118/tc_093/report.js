$(document).ready(function() {var formatter = new CucumberHTML.DOMFormatter($('.cucumber-report'));formatter.uri("api/pull.feature");
formatter.feature({
  "line": 1,
  "name": "Pull Mechanism scenarios",
  "description": "",
  "id": "pull-mechanism-scenarios",
  "keyword": "Feature"
});
formatter.scenarioOutline({
  "line": 91,
  "name": "TC_PULL_004, TC-060, TC_079 - When both webhook is down, verify messages for Consume of Group A and Peek of Group B",
  "description": "",
  "id": "pull-mechanism-scenarios;tc-pull-004,-tc-060,-tc-079---when-both-webhook-is-down,-verify-messages-for-consume-of-group-a-and-peek-of-group-b",
  "type": "scenario_outline",
  "keyword": "Scenario Outline",
  "tags": [
    {
      "line": 90,
      "name": "@ab"
    },
    {
      "line": 90,
      "name": "@peekAndConsume"
    },
    {
      "line": 90,
      "name": "@regression"
    },
    {
      "line": 90,
      "name": "@pull"
    },
    {
      "line": 90,
      "name": "@pull4"
    },
    {
      "line": 90,
      "name": "@tc60genie"
    }
  ]
});
formatter.step({
  "comments": [
    {
      "line": 92,
      "value": "#When Add Group Services of CADM is called for the group \u0027\u003cGroupID\u003e\u0027 to disable the group"
    },
    {
      "line": 93,
      "value": "#Then APIBanking should be disabled in CADM for the group \u0027\u003cGroupID\u003e\u0027"
    },
    {
      "line": 94,
      "value": "#Given \u0027activationKey and activate\u0027 API"
    },
    {
      "line": 95,
      "value": "#And user has valid SSL certificate"
    },
    {
      "line": 96,
      "value": "#And user has already generated the JWT token for the group \u0027\u003cGroupIDA\u003e\u0027"
    },
    {
      "line": 97,
      "value": "#When a POST request is made to axway endpoint for the group \u0027\u003cGroupIDA\u003e\u0027"
    },
    {
      "line": 98,
      "value": "#Then user should be registered successfully"
    },
    {
      "line": 99,
      "value": "#And APIBanking should be enabled in CADM for the group \u0027\u003cGroupIDA\u003e\u0027"
    },
    {
      "line": 100,
      "value": "#Given user has already generated the JWT token for the group \u0027\u003cGroupIDB\u003e\u0027"
    },
    {
      "line": 101,
      "value": "#When a POST request is made to axway endpoint for the group \u0027\u003cGroupIDB\u003e\u0027"
    },
    {
      "line": 102,
      "value": "#Then user should be registered successfully"
    },
    {
      "line": 103,
      "value": "#And APIBanking should be enabled in CADM for the group \u0027\u003cGroupIDB\u003e\u0027"
    },
    {
      "line": 104,
      "value": "# When user modifies Stub with amount \u0027\u003cAmount\u003e\u0027 account number \u0027\u003cAccountNo\u003e\u0027 transaction type \u0027\u003cCreditDebit\u003e\u0027 Currency Code \u0027INR\u0027 BIC \u0027SCBLINBBXXX\u0027"
    }
  ],
  "line": 105,
  "name": "Consume response should be displayed with amount \u0027\u003cAmount\u003e\u0027 accountNo \u0027\u003cAccountNo\u003e\u0027 transactionType \u0027\u003cCreditDebit\u003e\u0027 the expected value for the group \u0027\u003cGroupIDA\u003e\u0027",
  "keyword": "Then "
});
formatter.step({
  "line": 106,
  "name": "Peek response should be displayed with the empty message for the group \u0027\u003cGroupIDB\u003e\u0027",
  "keyword": "Then "
});
formatter.examples({
  "line": 107,
  "name": "",
  "description": "",
  "id": "pull-mechanism-scenarios;tc-pull-004,-tc-060,-tc-079---when-both-webhook-is-down,-verify-messages-for-consume-of-group-a-and-peek-of-group-b;",
  "rows": [
    {
      "cells": [
        "Amount",
        "AccountNo",
        "CreditDebit",
        "GroupIDA",
        "GroupIDB"
      ],
      "line": 108,
      "id": "pull-mechanism-scenarios;tc-pull-004,-tc-060,-tc-079---when-both-webhook-is-down,-verify-messages-for-consume-of-group-a-and-peek-of-group-b;;1"
    },
    {
      "cells": [
        "85.36",
        "22205269504",
        "D",
        "INDGRP1",
        "INDGRP1"
      ],
      "line": 109,
      "id": "pull-mechanism-scenarios;tc-pull-004,-tc-060,-tc-079---when-both-webhook-is-down,-verify-messages-for-consume-of-group-a-and-peek-of-group-b;;2"
    }
  ],
  "keyword": "Examples"
});
formatter.before({
  "duration": 945238370,
  "status": "passed"
});
formatter.scenario({
  "line": 109,
  "name": "TC_PULL_004, TC-060, TC_079 - When both webhook is down, verify messages for Consume of Group A and Peek of Group B",
  "description": "",
  "id": "pull-mechanism-scenarios;tc-pull-004,-tc-060,-tc-079---when-both-webhook-is-down,-verify-messages-for-consume-of-group-a-and-peek-of-group-b;;2",
  "type": "scenario",
  "keyword": "Scenario Outline",
  "tags": [
    {
      "line": 90,
      "name": "@ab"
    },
    {
      "line": 90,
      "name": "@peekAndConsume"
    },
    {
      "line": 90,
      "name": "@tc60genie"
    },
    {
      "line": 90,
      "name": "@regression"
    },
    {
      "line": 90,
      "name": "@pull4"
    },
    {
      "line": 90,
      "name": "@pull"
    }
  ]
});
formatter.step({
  "comments": [
    {
      "line": 92,
      "value": "#When Add Group Services of CADM is called for the group \u0027\u003cGroupID\u003e\u0027 to disable the group"
    },
    {
      "line": 93,
      "value": "#Then APIBanking should be disabled in CADM for the group \u0027\u003cGroupID\u003e\u0027"
    },
    {
      "line": 94,
      "value": "#Given \u0027activationKey and activate\u0027 API"
    },
    {
      "line": 95,
      "value": "#And user has valid SSL certificate"
    },
    {
      "line": 96,
      "value": "#And user has already generated the JWT token for the group \u0027\u003cGroupIDA\u003e\u0027"
    },
    {
      "line": 97,
      "value": "#When a POST request is made to axway endpoint for the group \u0027\u003cGroupIDA\u003e\u0027"
    },
    {
      "line": 98,
      "value": "#Then user should be registered successfully"
    },
    {
      "line": 99,
      "value": "#And APIBanking should be enabled in CADM for the group \u0027\u003cGroupIDA\u003e\u0027"
    },
    {
      "line": 100,
      "value": "#Given user has already generated the JWT token for the group \u0027\u003cGroupIDB\u003e\u0027"
    },
    {
      "line": 101,
      "value": "#When a POST request is made to axway endpoint for the group \u0027\u003cGroupIDB\u003e\u0027"
    },
    {
      "line": 102,
      "value": "#Then user should be registered successfully"
    },
    {
      "line": 103,
      "value": "#And APIBanking should be enabled in CADM for the group \u0027\u003cGroupIDB\u003e\u0027"
    },
    {
      "line": 104,
      "value": "# When user modifies Stub with amount \u0027\u003cAmount\u003e\u0027 account number \u0027\u003cAccountNo\u003e\u0027 transaction type \u0027\u003cCreditDebit\u003e\u0027 Currency Code \u0027INR\u0027 BIC \u0027SCBLINBBXXX\u0027"
    }
  ],
  "line": 105,
  "name": "Consume response should be displayed with amount \u002785.36\u0027 accountNo \u002722205269504\u0027 transactionType \u0027D\u0027 the expected value for the group \u0027INDGRP1\u0027",
  "matchedColumns": [
    0,
    1,
    2,
    3
  ],
  "keyword": "Then "
});
formatter.step({
  "line": 106,
  "name": "Peek response should be displayed with the empty message for the group \u0027INDGRP1\u0027",
  "matchedColumns": [
    4
  ],
  "keyword": "Then "
});
formatter.match({
  "arguments": [
    {
      "val": "85.36",
      "offset": 50
    },
    {
      "val": "22205269504",
      "offset": 68
    },
    {
      "val": "D",
      "offset": 98
    },
    {
      "val": "INDGRP1",
      "offset": 135
    }
  ],
  "location": "PeekAndConsume.consumeValueTest(String,String,String,String)"
});
formatter.result({
  "duration": 3959288140,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "INDGRP1",
      "offset": 72
    }
  ],
  "location": "PeekAndConsume.peekEmptyTest(String)"
});
formatter.result({
  "duration": 1451582477,
  "status": "passed"
});
});