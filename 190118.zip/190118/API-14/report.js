$(document).ready(function() {var formatter = new CucumberHTML.DOMFormatter($('.cucumber-report'));formatter.uri("api/endToEnd.feature");
formatter.feature({
  "line": 1,
  "name": "End to End Scenarios for APIBanking",
  "description": "",
  "id": "end-to-end-scenarios-for-apibanking",
  "keyword": "Feature"
});
formatter.scenarioOutline({
  "line": 4,
  "name": "TC_001 - When group is activated, messages should be displayed for Peek, Consume and recover",
  "description": "",
  "id": "end-to-end-scenarios-for-apibanking;tc-001---when-group-is-activated,-messages-should-be-displayed-for-peek,-consume-and-recover",
  "type": "scenario_outline",
  "keyword": "Scenario Outline",
  "tags": [
    {
      "line": 3,
      "name": "@ab"
    },
    {
      "line": 3,
      "name": "@peekAndConsume"
    },
    {
      "line": 3,
      "name": "@regression"
    },
    {
      "line": 3,
      "name": "@tc01"
    },
    {
      "line": 3,
      "name": "@genie"
    }
  ]
});
formatter.step({
  "comments": [
    {
      "line": 5,
      "value": "#When Add Group Services of CADM is called for the group \u0027\u003cGroupID\u003e\u0027 to disable the group"
    },
    {
      "line": 6,
      "value": "#Then APIBanking should be disabled in CADM for the group \u0027\u003cGroupID\u003e\u0027"
    },
    {
      "line": 7,
      "value": "#Given \u0027activationKey and activate\u0027 API"
    },
    {
      "line": 8,
      "value": "#And user has valid SSL certificate"
    }
  ],
  "line": 9,
  "name": "user has already generated the JWT token for the group \u0027\u003cGroupID\u003e\u0027",
  "keyword": "And "
});
formatter.step({
  "line": 10,
  "name": "a POST request is made to axway endpoint for the group \u0027\u003cGroupID\u003e\u0027",
  "keyword": "When "
});
formatter.step({
  "comments": [
    {
      "line": 11,
      "value": "#Then Get group Services should return with service for the group \u0027\u003cGroupID\u003e\u0027"
    },
    {
      "line": 12,
      "value": "#Then user should be registered successfully"
    },
    {
      "line": 13,
      "value": "#And APIBanking should be enabled in CADM for the group \u0027\u003cGroupID\u003e\u0027"
    },
    {
      "line": 14,
      "value": "#When user modifies Stub with amount \u0027\u003cAmount\u003e\u0027 account number \u0027\u003cAccountNo\u003e\u0027 transaction type \u0027\u003cCreditDebit\u003e\u0027 Currency Code \u0027INR\u0027 BIC \u0027SCBLINBBXXX\u0027"
    }
  ],
  "line": 15,
  "name": "Peek response should be displayed with amount \u0027\u003cAmount\u003e\u0027 accountNo \u0027\u003cAccountNo\u003e\u0027 transactionType \u0027\u003cCreditDebit\u003e\u0027 the expected value for the group \u0027\u003cGroupID\u003e\u0027",
  "keyword": "Then "
});
formatter.step({
  "line": 16,
  "name": "Consume response should be displayed with amount \u0027\u003cAmount\u003e\u0027 accountNo \u0027\u003cAccountNo\u003e\u0027 transactionType \u0027\u003cCreditDebit\u003e\u0027 the expected value for the group \u0027\u003cGroupID\u003e\u0027",
  "keyword": "And "
});
formatter.step({
  "line": 17,
  "name": "Recover response should be displayed with amount \u0027\u003cAmount\u003e\u0027 accountNo \u0027\u003cAccountNo\u003e\u0027 transactionType \u0027\u003cCreditDebit\u003e\u0027 the expected value for the group \u0027\u003cGroupID\u003e\u0027",
  "keyword": "And "
});
formatter.examples({
  "line": 18,
  "name": "",
  "description": "",
  "id": "end-to-end-scenarios-for-apibanking;tc-001---when-group-is-activated,-messages-should-be-displayed-for-peek,-consume-and-recover;",
  "rows": [
    {
      "cells": [
        "Amount",
        "AccountNo",
        "CreditDebit",
        "GroupID"
      ],
      "line": 19,
      "id": "end-to-end-scenarios-for-apibanking;tc-001---when-group-is-activated,-messages-should-be-displayed-for-peek,-consume-and-recover;;1"
    },
    {
      "cells": [
        "8745843500000",
        "22205269504",
        "D",
        "INDSEGSE"
      ],
      "line": 20,
      "id": "end-to-end-scenarios-for-apibanking;tc-001---when-group-is-activated,-messages-should-be-displayed-for-peek,-consume-and-recover;;2"
    }
  ],
  "keyword": "Examples"
});
formatter.before({
  "duration": 947608066,
  "status": "passed"
});
formatter.scenario({
  "line": 20,
  "name": "TC_001 - When group is activated, messages should be displayed for Peek, Consume and recover",
  "description": "",
  "id": "end-to-end-scenarios-for-apibanking;tc-001---when-group-is-activated,-messages-should-be-displayed-for-peek,-consume-and-recover;;2",
  "type": "scenario",
  "keyword": "Scenario Outline",
  "tags": [
    {
      "line": 3,
      "name": "@ab"
    },
    {
      "line": 3,
      "name": "@peekAndConsume"
    },
    {
      "line": 3,
      "name": "@regression"
    },
    {
      "line": 3,
      "name": "@tc01"
    },
    {
      "line": 3,
      "name": "@genie"
    }
  ]
});
formatter.step({
  "comments": [
    {
      "line": 5,
      "value": "#When Add Group Services of CADM is called for the group \u0027\u003cGroupID\u003e\u0027 to disable the group"
    },
    {
      "line": 6,
      "value": "#Then APIBanking should be disabled in CADM for the group \u0027\u003cGroupID\u003e\u0027"
    },
    {
      "line": 7,
      "value": "#Given \u0027activationKey and activate\u0027 API"
    },
    {
      "line": 8,
      "value": "#And user has valid SSL certificate"
    }
  ],
  "line": 9,
  "name": "user has already generated the JWT token for the group \u0027INDSEGSE\u0027",
  "matchedColumns": [
    3
  ],
  "keyword": "And "
});
formatter.step({
  "line": 10,
  "name": "a POST request is made to axway endpoint for the group \u0027INDSEGSE\u0027",
  "matchedColumns": [
    3
  ],
  "keyword": "When "
});
formatter.step({
  "comments": [
    {
      "line": 11,
      "value": "#Then Get group Services should return with service for the group \u0027\u003cGroupID\u003e\u0027"
    },
    {
      "line": 12,
      "value": "#Then user should be registered successfully"
    },
    {
      "line": 13,
      "value": "#And APIBanking should be enabled in CADM for the group \u0027\u003cGroupID\u003e\u0027"
    },
    {
      "line": 14,
      "value": "#When user modifies Stub with amount \u0027\u003cAmount\u003e\u0027 account number \u0027\u003cAccountNo\u003e\u0027 transaction type \u0027\u003cCreditDebit\u003e\u0027 Currency Code \u0027INR\u0027 BIC \u0027SCBLINBBXXX\u0027"
    }
  ],
  "line": 15,
  "name": "Peek response should be displayed with amount \u00278745843500000\u0027 accountNo \u002722205269504\u0027 transactionType \u0027D\u0027 the expected value for the group \u0027INDSEGSE\u0027",
  "matchedColumns": [
    0,
    1,
    2,
    3
  ],
  "keyword": "Then "
});
formatter.step({
  "line": 16,
  "name": "Consume response should be displayed with amount \u00278745843500000\u0027 accountNo \u002722205269504\u0027 transactionType \u0027D\u0027 the expected value for the group \u0027INDSEGSE\u0027",
  "matchedColumns": [
    0,
    1,
    2,
    3
  ],
  "keyword": "And "
});
formatter.step({
  "line": 17,
  "name": "Recover response should be displayed with amount \u00278745843500000\u0027 accountNo \u002722205269504\u0027 transactionType \u0027D\u0027 the expected value for the group \u0027INDSEGSE\u0027",
  "matchedColumns": [
    0,
    1,
    2,
    3
  ],
  "keyword": "And "
});
formatter.match({
  "arguments": [
    {
      "val": "INDSEGSE",
      "offset": 56
    }
  ],
  "location": "activationKey.user_has_already_generated_the_JWT_token_for_the_group(String)"
});
formatter.result({
  "duration": 781305009,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "INDSEGSE",
      "offset": 56
    }
  ],
  "location": "activationKey.a_POST_request_is_made_to_axway_endpoint(String)"
});
formatter.result({
  "duration": 4441172961,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "8745843500000",
      "offset": 47
    },
    {
      "val": "22205269504",
      "offset": 73
    },
    {
      "val": "D",
      "offset": 103
    },
    {
      "val": "INDSEGSE",
      "offset": 140
    }
  ],
  "location": "PeekAndConsume.peekValueTest(String,String,String,String)"
});
formatter.result({
  "duration": 993000791,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "8745843500000",
      "offset": 50
    },
    {
      "val": "22205269504",
      "offset": 76
    },
    {
      "val": "D",
      "offset": 106
    },
    {
      "val": "INDSEGSE",
      "offset": 143
    }
  ],
  "location": "PeekAndConsume.consumeValueTest(String,String,String,String)"
});
formatter.result({
  "duration": 856168646,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "8745843500000",
      "offset": 50
    },
    {
      "val": "22205269504",
      "offset": 76
    },
    {
      "val": "D",
      "offset": 106
    },
    {
      "val": "INDSEGSE",
      "offset": 143
    }
  ],
  "location": "PeekAndConsume.recoverValueTest(String,String,String,String)"
});
formatter.result({
  "duration": 1043988126,
  "status": "passed"
});
});