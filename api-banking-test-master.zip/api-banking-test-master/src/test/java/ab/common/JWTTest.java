package ab.common;

import com.google.common.collect.ImmutableMap;
import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import common.EncryptDecrypt;
import common.JWT;
import org.apache.commons.io.IOUtils;
import org.junit.Test;

import java.io.InputStream;
import java.net.URL;
import java.util.Map;

/**
 * Created by 1409314 on 6/7/2017.
 */
public class JWTTest {


    @Test
    public void createToken_handles_invalid_key() throws Exception {

        try(InputStream is = new URL("https://apitest.standardchartered.com").openStream()) {
            System.out.println(IOUtils.toString(is, "utf-8"));
        }
        JWT.createToken(Lists.newArrayList(), null);
    }

//    @Test

    public static String createToken(String activateKeyContent, String activateKey) throws Exception {
        Map<String,Object> activationRequest = Maps.newHashMap();
        activationRequest.put("webHookUrl", "http://10.23.210.59:8443");
                activationRequest.put("enableWebHook", "true");
        activationRequest.put("activationKey",
                ImmutableMap.of("content", activateKeyContent,
                        "key", activateKey));
        String token = JWT.createToken(activationRequest, new EncryptDecrypt().convertStringToPrivateKey(
                IOUtils.toString(JWTTest.class.getClassLoader().getResourceAsStream("privateKey.txt"))
        ));
        System.out.println("token is "+token);
        return token;

        //System.out.println(token);
    }

    /*public static void main(String args[]){
        final String content = "SFcP3zxu0P8jOjgjC1r68ZhGnep/p0dzCynH3eblETtPHkSTFhbglHRXamhQhDnruos7FXOzwZ9gAyFJM2JSiv/pstMlM6s/VvpSmzQxB7FEQGyNLki0v4wzMO0jNVROFXnZA/o7+gSjd87VJYic21jLrFeLXM+lw2/3DT5c29QTNldlB5GuOay12g1ce40ZSSrZ83XrvU7oShVHvYxwW9//LzOJLr8h0NaKqbyMU2vAwxJ1Lr/FT4vCT5YoEalLiDLvjSKnP+JE+YqhSbyMrvVDj9X1tQ2Mn2+zLnSsbGE6lPVZgI+0t4vlfwaQ3z3V2mp9HPg6Hhu/jJoziLWB2Di4HvHciEHvYCufInjbvdOMctFCWTmItz7kpTrfGBOPdnEdwEByL0FOXU304gOxTfqeSGxmjie0IXcOel6yzLoUWF7A3k1G0cPfDHPebarsL4QQVBh77pf7r8kiUGF2ziVFUWjqoQ5tT6cZy8ZU/pITamp6hzDKHIhsz312FVTdw7IMNF62XGhRh/BxDgLiFLyH0VVo6xrc+oefqZIZ13xG5BaPGQRjHt+/N+J9cWr/iwEYhsS9a3kE5dXeVO+JiII6+S7qm/9ZmCXqIUskTV4GfeacS8EJTxz98J5/UYBZOWvWQvi0kRMEOxWQinAcYDE128fynO+X2Y+jbQxQn56CZfvFgiAv71xbZE7LUSE6rypYu2WViuKiHJlO8VdPvtb1rcv9dt0nUHrzgL3pr2Kvqvom7k8dW3h8+/6E7vtvcrklBFO50Z+6LEYFNSN9X1oVRcZ8jlHRZ2vR+8Gfx5qjAFo4WHlv8aTyLs3X9mxf";
        final String key = "yqE2O5UI9Z4rev2as0P7kBaz+hJGtuG3DXVJRivikkzRxuSiMtEaEhSaEEuh5bI4AfQAMMKRG6Wy6Tc6/4awJB9FygMKJMUmM53+jQanHztm6rW2XsD9v1uEqFf3IR646awyjNE2LnhOgmvFNREUPySK+YF8Z2G8W4CX4LyhsVXO6rwcchl5peN7hCgiYrLSghjqbvSjYD8bHWRGwZmGOAYhXumBb2Nd+oX2vRxDrNbs+8IBN9RunYaoiuQg2LyAahUJc6vwzEOahvqEnnJ9tJpWNcNRm1e++pLph+/pmzCfoQv0HcKqmOc3TlFjE1XZcWkuGx5y66pF35ZwFftacQ==";
        try{
            String token = createToken(content, key);
            System.out.println(token);
        }
        catch(Exception e){
            e.printStackTrace();
        }
    }*/
}