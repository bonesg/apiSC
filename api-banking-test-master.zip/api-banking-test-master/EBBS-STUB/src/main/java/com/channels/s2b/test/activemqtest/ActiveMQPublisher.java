package com.channels.s2b.test.activemqtest;

import org.apache.activemq.ActiveMQConnectionFactory;
import org.apache.activemq.command.ActiveMQTopic;
import org.apache.commons.io.IOUtils;
import org.springframework.core.io.ClassPathResource;
import sun.plugin2.message.Message;

import javax.jms.*;
import java.io.FileInputStream;
import java.io.IOException;
import java.sql.Connection;
import java.sql.SQLException;

public class ActiveMQPublisher {

    public static void main(String[] args) throws JMSException, IOException, SQLException {

        ActiveMQConnectionFactory connectionFactory = new ActiveMQConnectionFactory("tcp://10.23.210.60:61616");

        Connection con = (Connection) connectionFactory.createConnection();
        Session session = con.createSession(true,Session.AUTO_ACKNOWLEDGE);

        MessageProducer producer = session.createProducer(new ActiveMQTopic("scbCoreBankingTxnAlertCorpFinTxnNotifyV1T"));
        producer.send((javax.jms.Message) createTextMessage(session, new FileInputStream(new ClassPathResource("rta-template.xml").getFile())));
        session.commit();
        producer.close();
        session.close();
        con.close();
        System.out.println("Message published");
    }

    private static TextMessage createTextMessage(Session session, FileInputStream fileInputStream) throws IOException, JMSException {
        TextMessage txt = session.createTextMessage();
        txt.setText(IOUtils.toString(fileInputStream));
        return txt;
    }

}


