package ab.utils;

public class PropertyBag implements java.io.Serializable {
    private static final long serialVersionUID = -2852438400771352494L;

    private String supportContactName;
    private String supportEmailAddress;

    public String getSupportContactName() {
        return this.supportContactName;
    }

    public void setSupportContactName(String supportContactName) {
        this.supportContactName = supportContactName;
    }

    public String getSupportEmailAddress() {
        return this.supportEmailAddress;
    }

    public void setSupportEmailAddress(String supportEmailAddress) {
        this.supportEmailAddress = supportEmailAddress;
    }
}
