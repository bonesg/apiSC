package ab.utils;


import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;

public class paymentInitiationDataClass {
   GenericUtils genericUtils = new GenericUtils();
 @Data(name = "openAPIPaymentAmount", xpath = "", jsonpath = "instruction.amount")
 String openAPIPaymentAmount = null;

 @Data(name = "openAPIPaymentCurrency", xpath = "", jsonpath = "instruction.currency")
 String openAPIPaymentCurrency= null;

 @Data(name = "openAPIPaymentDebitAccountNumber", xpath = "", jsonpath = "instruction.debtor.account.id")
 String openAPIPaymentDebitAccountNumber= null;

 @Data(name = "openAPIPaymentCreditAccountNumber", xpath = "", jsonpath = "instruction.creditor.account.id")
 String openAPIPaymentCreditAccountNumber= null;

 @Data(name = "openAPIPaymentDebitBIC", xpath = "", jsonpath = "instruction.debtorAgent.financialInstitution.BIC")
 String openAPIPaymentDebitBIC= null;

 @Data(name = "openAPIPaymentCreditBIC", xpath = "", jsonpath = "instruction.creditorAgent.financialInstitution.BIC")
 String openAPIPaymentCreditBIC= null;

 @Data(name = "openAPIPaymentdebitName", xpath = "", jsonpath = "instruction.debtor.name")
 String openAPIPaymentdebitName= null;

 @Data(name = "openAPIPaymentcreditName", xpath = "", jsonpath = "instruction.creditor.name")
 String openAPIPaymentcreditName= null;

 @Data(name = "openAPIPaymentdebitCountry", xpath = "", jsonpath = "instruction.debtorAgent.financialInstitution.postalAddress.country")
 String openAPIPaymentdebitCountry= null;

 @Data(name = "openAPIPaymentcreditCountry", xpath = "", jsonpath = "instruction.creditorAgent.financialInstitution.postalAddress.country")
 String openAPIPaymentcreditCountry= null;

 @Data(name = "openAPIPaymentType", xpath = "", jsonpath = "instruction.paymentType")
 String openAPIPaymentType= null;

 @Data(name = "openAPIPaymentMessageID", xpath = "", jsonpath = "header.messageId")
 String openAPIPaymentMessageID= null;

 @Data(name = "openAPIPaymentReferenceID", xpath = "", jsonpath = "instruction.referenceId")
 String openAPIPaymentReferenceID= null;


    @Retention(RetentionPolicy.RUNTIME)
    public @interface Data {
        String name();

        String xpath();

        String jsonpath();


    }
}