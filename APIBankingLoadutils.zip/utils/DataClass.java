package ab.utils;


import org.apache.xpath.jaxp.XPathFactoryImpl;
import org.junit.Assert;
import org.w3c.dom.Document;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import javax.xml.xpath.*;
import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.StringWriter;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.reflect.Field;
import java.nio.charset.StandardCharsets;
import java.util.Arrays;
import java.util.Map;

public class DataClass {
    static XPathFactory factory;
    static XPath xPath;

    static {
        factory = new XPathFactoryImpl();
        xPath=factory.newXPath();
    }

    public String getAccountNumber() {
        return accountNumber;
    }

    public void setAccountNumber(String accountNumber) {
        this.accountNumber = accountNumber;
    }

    GenericUtils genericUtils = new GenericUtils();
    @Data(name = "AccountNumber", xpath = "//Payer/Ac/Detail", jsonpath = "[0].number")
    String accountNumber;

    //ns2:Payer/Ac/Detail/text()

    @Data(name = "Currency", xpath = "//Payer/Amount/attribute::curr", jsonpath = "[0].currency")
    String currency;

    @Data(name = "GroupID", xpath = "//Head/attribute::orgId", jsonpath = "[0].groupId")
    String groupID;

    @Data(name = "Country", xpath = "//Payer/Country", jsonpath = "[0].country")
    String country;

    @Data(name = "AccountType", xpath = "//Payer/attribute::type", jsonpath = "[0].type")
    String accountType;

    @Data(name = "Balance", xpath = "//Payer/Bal/AvailableBal", jsonpath = "[0].balance.amount")
    String accountBalance;

    @Data(name = "OpeningAvailiableBalance", xpath = "//Payer/Bal/OpeningBal", jsonpath = "[0].balance.opening")
    String openingBalance;

    @Data(name = "ClosingLedgerBalance", xpath = "//Payer/Bal/ClosingLedgerBal", jsonpath = "[0].balance.closingLedger")
    String closingLedgeraccountBalance;

    @Data(name = "BIC", xpath = "//Payer/attribute::addr", jsonpath = "[0].swiftBic")
    String swift_bic;

//    @Data(name = "BankID", xpath = "//Payer/Bal/OpeningLedgerBal", jsonpath = "balance[1].bank_id")
//    String bank_id;

    @Data(name = "OpeningLedgerBalance", xpath = "//Payer/Bal/OpeningLedgerBal", jsonpath = "[0].balance.openingLedger")
    String openingLedgeraccountBalance;

    @Data(name = "CreditDebitAmount", xpath = "//TransactionDetails/TransactionEntry//TrnAmount", jsonpath = "content[0].transactionAmount.amount")
    String creditDebitccountBalance;

    @Data(name = "CreditDebitAccountNo", xpath = "//TransactionDetails/TransactionEntry//AccountNo", jsonpath = "content[0].accountIdentifier.accountId")
    String creditDebitAccountNo;

    @Data(name = "CreditDebitCorrelationID", xpath = "//Header/originationDetails//correlationID", jsonpath = "content[0].accountIdentifier.accountId")
    String creditDebitCorrelationID;

    @Data(name = "CreditDebitFlag", xpath = "//TransactionDetails/TransactionEntry//CreditDebitFlag", jsonpath = "content[0].adviceType")
    String creditDebitFlag;


    @Data(name = "CreditDebitFlag1", xpath = "//TransactionDetails/TransactionEntry//CreditDebitFlag", jsonpath = "content[0].adviceType")
    String creditDebitFlag1;

    @Data(name = "CreditDebitCurrency", xpath = "//TransactionDetails/TransactionEntry//Account//CurrencyCode", jsonpath = "content[0].transactionAmount.currencyCode")
    String creditDebitCurrency;

    @Data(name = "CreditDebitBIC", xpath = "//TransactionDetails/TransactionEntry//SwiftAddress", jsonpath = "content[0].accountIdentifier.bankCode")
    String creditDebitBIC;

    @Data(name = "CreditDebitTransactionCode", xpath = "//TransactionDetails/TransactionEntry//TrnCode//Code", jsonpath = "content[0].transactionCode")
    String creditDebitTransactionCode;

    @Data(name = "CreditDebitCountryCode", xpath = "//header//countryCode", jsonpath = "content[0].transactionCode")
    String creditDebitCountryCode;

    @Data(name = "CreditDebitTransactionIdentifier", xpath = "//TransactionDetails/TransactionEntry//ApprvSeqno", jsonpath = "content[0].transactionIdentifier.identifier")
    String creditDebitTransactionIdentifier;

    @Data(name = "CreditDebitClientIdentifier", xpath = "//TransactionDetails/TransactionEntry//Paydtl//SenderRefno", jsonpath = "content[0].clientIdentifier.identifier")
    String creditDebitClientIdentifier;

     @Data(name = "CreditDebitValueDate", xpath = "//TransactionDetails/TransactionEntry//ValueDate", jsonpath = "content[0].valueDate")
    String creditDebitValueDate;


    @Data(name = "CreditDebitTransactionDescription", xpath = "//TransactionDetails/TransactionEntry//TrnCode//Desc", jsonpath = "content[0].transactionDescription")
    String creditDebitTransactionDescription;

    @Data(name = "CreditDebitPreTransactionBalance", xpath = "//TransactionDetails/TransactionEntry//BalanceDetails//Ledger", jsonpath = "content[0].preExecutionBalance.amount")
    String CreditDebitPreTransactionBalance;

    @Data(name = "CreditDebitVirtualaccountnumber", xpath = "//TransactionDetails/TransactionEntry//VirtualAccountNo", jsonpath = "content[0].virtualAccountId")
    String CreditDebitVirtualaccountnumber;

    @Data(name = "CreditDebitBAICode", xpath = "//TransactionDetails/TransactionEntry//VirtualAccountNo", jsonpath = "content[0].baiCode")
    String creditDebitBAICode;

    @Data(name = "CreditDebitNarration1", xpath = "//TransactionDetails/TransactionEntry//Narrations/Narration1", jsonpath = "")
    String creditDebitNarration1;


    @Data(name = "CreditDebitNarration2", xpath = "//TransactionDetails/TransactionEntry//Narrations/Narration2", jsonpath = "")
    String creditDebitNarration2;

    @Data(name = "CreditDebitNarration3", xpath = "//TransactionDetails/TransactionEntry//Narrations/Narration3", jsonpath = "")
    String CreditDebitNarration3;

    @Data(name = "CreditDebitNarration4", xpath = "//TransactionDetails/TransactionEntry//Narrations/Narration4", jsonpath = "")
    String CreditDebitNarration4;

    @Data(name = "CreditDebitExternalIdentifier", xpath = "", jsonpath = "content[0].externalIdentifier.identifier")
    String CreditDebitExternalIdentifier;

    @Data(name = "CreditDebitTransactionFreeText1", xpath = "", jsonpath = "content[0].transactionFreeText[0]")
    String CreditDebitTransactionFreeText1;

    @Data(name = "CreditDebitTransactionFreeText2", xpath = "", jsonpath = "content[0].transactionFreeText[1]")
    String CreditDebitTransactionFreeText2;
    @Data(name = "CreditDebitTransactionFreeText3", xpath = "", jsonpath = "content[0].transactionFreeText[2]")
    String CreditDebitTransactionFreeText3;
    @Data(name = "CreditDebitTransactionFreeText4", xpath = "", jsonpath = "content[0].transactionFreeText[3]")
    String CreditDebitTransactionFreeText4;


    @Data(name = "inimegRequestAmount", xpath = "", jsonpath = "request.body.amount.value")
    String inimegRequestAmount;
    @Data(name = "inimegRequestClientId", xpath = "", jsonpath = "request.head.clientId")
    String inimegRequestClientId;

    @Data(name = "inimegResponseResultCode", xpath = "", jsonpath = "response.body.resultInfo.resultCode")
    String inimegResponseResultCode;
    @Data(name = "inimegResponseClientId", xpath = "", jsonpath = "response.head.clientId")
    String inimegResponseClientId;


    @Data(name = "inimegRequestCurrency", xpath = "", jsonpath = "request.body.amount.currency")
    String inimegRequestCurrency;
    @Data(name = "inimegRequestAccountNumber", xpath = "", jsonpath = "request.body.accountInfo.accountNo")
    String inimegRequestAccountNumber;
    @Data(name = "inimegRequestSignature", xpath = "", jsonpath = "signature")
    String inimegRequestSignature;

    @Data(name = "inimegResponseCurrency", xpath = "", jsonpath = "response.body.resultInfo.resultCode")
    String inimegResponseCurrency;

    @Data(name = "inimegResponseResultStatus", xpath = "", jsonpath = "response.body.resultInfo.resultStatus")
    String inimegResponseResultStatus;

    @Data(name = "inimegRequestMsgId", xpath = "", jsonpath = "request.head.reqMsgId")
    String inimegRequestMsgId;

    @Data(name = "inimegManageTrustlineRequestAmount", xpath = "", jsonpath = "request.body.limitAmount.value")
    String inimegManageTrustlineRequestAmount;

    @Data(name = "inimegManageTrustlineRequestCurrency", xpath = "", jsonpath = "request.body.limitAmount.currency")
    String inimegManageTrustlineRequestCurrency;

    @Data(name = "inimegResponseMsgId", xpath = "", jsonpath = "response.head.reqMsgId")
    String inimegResponseMsgId;

    @Data(name = "inimegRequestAccountId", xpath = "", jsonpath = "request.body.accountId")
    String inimegRequestAccountId;

    @Data(name = "inimegQueryBCTrustlineRequestCurrency", xpath = "", jsonpath = "request.body.currency")
    String inimegQueryBCTrustlineRequestCurrency;

    @Data(name = "inimegQueryManageTrustlineResponseCurrency", xpath = "", jsonpath = "response.body.queryBcBalanceResponse.balanceInfos[0].amount.currency")
    String    inimegQueryManageTrustlineResponseCurrency;

    @Data(name = "inimegQueryManageTrustlineResponseAmount", xpath = "", jsonpath = "response.body.queryBcBalanceResponse.balanceInfos[0].amount.value")
    String    inimegQueryManageTrustlineResponseAmount;

    @Data(name = "inimegQueryBCOperationType", xpath = "", jsonpath = "request.body.operationType")
    String    inimegQueryBCOperationType;

    @Data(name = "inimegQueryBCOperationID", xpath = "", jsonpath = "request.body.bcOperationId")
    String inimegQueryBCOperationID;

    @Data(name = "inimegQueryBCOperationResponseResultStatus", xpath = "", jsonpath = "response.body.bcOperationResponse.resultInfo.resultStatus")
    String inimegQueryBCOperationResponseResultStatus;

    @Data(name = "inimegQueryBCOperationResponseBCOperationId", xpath = "", jsonpath = "response.body.bcOperationResponse.bcOperationId")
    String inimegQueryBCOperationResponseBCOperationId;

    @Data(name = "inimegQueryBCOperationResponseBCOperationMId", xpath = "", jsonpath = "response.body.bcOperationResponse.bcOperatorMid")
    String inimegQueryBCOperationResponseBCOperationMId;

    @Data(name = "inimegQueryBCOperationResponseResultCode", xpath = "", jsonpath = "response.body.bcOperationResponse.resultInfo.resultCode")
    String inimegQueryBCOperationResponseResultCode;

    @Data(name = "inimegQueryBCOperationResponseResultCode", xpath = "", jsonpath = "response.body.bcOperationResponse.resultInfo.resultCode")
    String inimegQueryBCOperationResponseResult;

    @Data(name = "openAPIPaymentAmount", xpath = "", jsonpath = "instruction.amount")
    String openAPIPaymentAmount = null;

    @Data(name = "openAPIPaymentCurrency", xpath = "", jsonpath = "instruction.currency")
    String openAPIPaymentCurrency= null;

    @Data(name = "openAPIPaymentDebitAccountNumber", xpath = "", jsonpath = "instruction.debtor.account.id")
    String openAPIPaymentDebitAccountNumber= null;

    @Data(name = "openAPIPaymentCreditAccountNumber", xpath = "", jsonpath = "instruction.creditor.account.id")
    String openAPIPaymentCreditAccountNumber= null;

    @Data(name = "openAPIPaymentDebitBIC", xpath = "", jsonpath = "instruction.debtorAgent.financialInstitution.BIC")
    String openAPIPaymentDebitBIC= null;

    @Data(name = "openAPIPaymentCreditBIC", xpath = "", jsonpath = "instruction.creditorAgent.financialInstitution.BIC")
    String openAPIPaymentCreditBIC= null;

    @Data(name = "openAPIPaymentdebitName", xpath = "", jsonpath = "instruction.debtor.name")
    String openAPIPaymentdebitName= null;

    @Data(name = "openAPIPaymentcreditName", xpath = "", jsonpath = "instruction.creditor.name")
    String openAPIPaymentcreditName= null;

    @Data(name = "openAPIPaymentdebitCountry", xpath = "", jsonpath = "instruction.debtorAgent.financialInstitution.postalAddress.country")
    String openAPIPaymentdebitCountry= null;

    @Data(name = "openAPIPaymentcreditCountry", xpath = "", jsonpath = "instruction.creditorAgent.financialInstitution.postalAddress.country")
    String openAPIPaymentcreditCountry= null;

    @Data(name = "openAPIPaymentType", xpath = "", jsonpath = "instruction.paymentType")
    String openAPIPaymentType= null;

    @Data(name = "openAPIPaymentMessageID", xpath = "", jsonpath = "header.messageId")
    String openAPIPaymentMessageID= null;

    @Data(name = "openAPIPaymentReferenceID", xpath = "", jsonpath = "instruction.referenceId")
    String openAPIPaymentReferenceID= null;



    public static DataClass getValueFromMap(Map<String, String> map) {
        DataClass expected = new DataClass();
        for (Field field : expected.getClass().getDeclaredFields()) {

            if(!field.isAnnotationPresent(Data.class))
                continue;
            Data data = field.getAnnotation(Data.class);
            try {
                field.set(expected, map.get(data.name()));
            } catch (IllegalAccessException e) {
                e.printStackTrace();
            }
        }
        return expected;
    }

    public static DataClass getValueFromXml(String xml,Map<String,String> value) throws ParserConfigurationException, SAXException, XPathExpressionException, IOException {
        DataClass xmlData = new DataClass();
        for (Field field : xmlData.getClass().getDeclaredFields()) {
            if(!field.isAnnotationPresent(Data.class))
                continue;
            Data data = field.getAnnotation(Data.class);
            if(value.get(data.name())==null)
                continue;
            try {
                field.set(xmlData, getXpathValue(data.xpath(),xml));
            } catch (IllegalAccessException e) {
                e.printStackTrace();
            }
        }
        return xmlData;
    }

    public static DataClass getValueFromJSON(String json, Map<String, String> value) throws ParserConfigurationException, SAXException, XPathExpressionException, IOException {
        DataClass xmlData = new DataClass();
        for (Field field : xmlData.getClass().getDeclaredFields()) {
            if(!field.isAnnotationPresent(Data.class))
                continue;
            Data data = field.getAnnotation(Data.class);
            if(value.get(data.name())==null)
                continue;
            try {
                field.set(xmlData, GenericUtils.getJsonValue(data.jsonpath(),json));
            } catch (IllegalAccessException e) {
                e.printStackTrace();
            }
        }
        return xmlData;
    }

    public static DataClass getValueFromXml(String xml) throws ParserConfigurationException, SAXException, XPathExpressionException, IOException {
        DataClass xmlData = new DataClass();
        for (Field field : xmlData.getClass().getDeclaredFields()) {
            if(!field.isAnnotationPresent(Data.class))
                continue;
            Data data = field.getAnnotation(Data.class);
            try {
                field.set(xmlData, getXpathValue(data.xpath(),xml));
            } catch (IllegalAccessException e) {
                e.printStackTrace();
            }
        }
        return xmlData;
    }

    public static String modifyValueFromJSON(String json,Map<String, String> map) throws ParserConfigurationException, SAXException, XPathExpressionException, IOException {
        DataClass jsonData = new DataClass();
        for (Field field : jsonData.getClass().getDeclaredFields()) {
            if(!field.isAnnotationPresent(Data.class))
                continue;
            Data data = field.getAnnotation(Data.class);
            try {
                if(map.get(data.name())!=null)
                field.set(jsonData, GenericUtils.getJsonValue(map.get(data.name()),json));
            } catch (IllegalAccessException e) {
                e.printStackTrace();
            }
        }
        return jsonData.toString();
    }

    public static DataClass modifyStub(String xml,Map<String, String> map) throws ParserConfigurationException, SAXException, XPathExpressionException, IOException, TransformerException {
        DataClass xmlData = new DataClass();
        for (Field field : xmlData.getClass().getDeclaredFields()) {
            if(!field.isAnnotationPresent(Data.class))
                continue;
            Data data = field.getAnnotation(Data.class);
            try {
                if(map.get(data.name())!=null)
                field.set(xmlData, modifyXMLValues(data.xpath(), xml, map.get(data.name())));
            } catch (IllegalAccessException e) {
                e.printStackTrace();
            }
        }
        return xmlData;
    }
    public static String modifyXMLValues(String xpath, String xml, String valueToBeModified) throws XPathExpressionException, ParserConfigurationException, IOException, SAXException, TransformerException {
        String value = "";
        XPathExpression expr =
                xPath.compile(xpath);
        DocumentBuilderFactory docFactory = DocumentBuilderFactory.newInstance();
        DocumentBuilder docBuilder = docFactory.newDocumentBuilder();
        // System.out.println(filepath);
        Document doc = docBuilder.parse(new ByteArrayInputStream(xml.getBytes(StandardCharsets.UTF_8)));
        //value = (String) expr.evaluate(doc, XPathConstants.STRING);
        NodeList myNodeList = (NodeList)expr
                .evaluate(doc, XPathConstants.NODESET);
        myNodeList.item(0).setTextContent(valueToBeModified);
        StringWriter writer = new StringWriter();
        value = myNodeList.toString();
        TransformerFactory transformerFactory = TransformerFactory.newInstance();
        Transformer transformer = transformerFactory.newTransformer();
        DOMSource source = new DOMSource(doc);
        StreamResult result = new StreamResult(writer);
        transformer.transform(source, result);
        value = writer.toString();
        return value;
    }

    public static String getXMLWithNewCorrelationID(String xml) throws XPathExpressionException, ParserConfigurationException, IOException, SAXException, TransformerException {
        String value = "";
        XPathExpression expr =
                xPath.compile("//header/originationDetails/correlationID");
        DocumentBuilderFactory docFactory = DocumentBuilderFactory.newInstance();
        DocumentBuilder docBuilder = docFactory.newDocumentBuilder();
        // System.out.println(filepath);
        Document doc = docBuilder.parse(new ByteArrayInputStream(xml.getBytes(StandardCharsets.UTF_8)));
        //value = (String) expr.evaluate(doc, XPathConstants.STRING);
        NodeList myNodeList = (NodeList)expr
                .evaluate(doc, XPathConstants.NODESET);
        int correlationID = Integer.parseInt(myNodeList.item(0).getTextContent());
        myNodeList.item(0).setTextContent(""+(correlationID+1));
        StringWriter writer = new StringWriter();
        value = myNodeList.toString();
        TransformerFactory transformerFactory = TransformerFactory.newInstance();
        Transformer transformer = transformerFactory.newTransformer();
        DOMSource source = new DOMSource(doc);
        StreamResult result = new StreamResult(writer);
        transformer.transform(source, result);
        value = writer.toString();

        return value;
    }

    public static void verifyValues(DataClass expectedClass, DataClass actualClass) throws IllegalAccessException {

        for(Field field : expectedClass.getClass().getDeclaredFields()){
            Object object = field.get(expectedClass);
            if(object!=null){
                try {
                    if(field.isAnnotationPresent(Data.class))
                    Assert.assertEquals(object.toString(),field.get(actualClass).toString());
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }

        }

    }

    public static String getXpathValue(String xpath, String xml) throws XPathExpressionException, ParserConfigurationException, IOException, SAXException {
        String value = "";
        XPathExpression expr =
                xPath.compile(xpath);
        DocumentBuilderFactory docFactory = DocumentBuilderFactory.newInstance();
        DocumentBuilder docBuilder = docFactory.newDocumentBuilder();
        // System.out.println(filepath);
        Document doc = docBuilder.parse(new ByteArrayInputStream(xml.getBytes(StandardCharsets.UTF_8)));
        value = (String) expr.evaluate(doc, XPathConstants.STRING);
        return value;
    }



    public static String modifyJSON(String json,Map<String, String> map) throws ParserConfigurationException, TransformerException, SAXException, XPathExpressionException, IOException, IllegalAccessException {
        DataClass xmlData = new DataClass();
        for (Field field : xmlData.getClass().getDeclaredFields()) {
            if (!field.isAnnotationPresent(Data.class))
                continue;
            Data data = field.getAnnotation(Data.class);

            if (map.get(data.name()) != null)
                return "";
            field.set(xmlData, GenericUtils.modifyJSONValues(data.jsonpath(), json, map.get(data.name())));


        }
        return "";
    }




    public static String getXpath(String key) {
        return Arrays.asList(DataClass.class.getDeclaredFields())
                .stream().map(field1 -> field1.getAnnotation(Data.class)).filter(field -> field!=null && field.name().equals(key))
                .findFirst().get().xpath();
    }

    public static String getJSonPath(String fieldName) {
        return Arrays.asList(DataClass.class.getDeclaredFields())
                .stream().map(field1 -> field1.getAnnotation(Data.class)).filter(field -> field!=null && field.name().equals(fieldName))
                .findFirst().get().jsonpath();
    }

    @Retention(RetentionPolicy.RUNTIME)
    public @interface Data {
        String name();

        String xpath();

        String jsonpath();


    }
}