package ab.utils;

import java.sql.*;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

/**
 * Created by 1571168 on 3/22/2018.
 */
public class DBUtils {
    protected Connection con;
    protected Statement statement;
    protected ResultSet resultSet;

    public static String    DB_QUERY = "select * from ds_oa_balances where OABACCNUM = '${accountNumber}' order by OABBUSINESSDATE desc";
    public Connection getConnection() throws ClassNotFoundException, SQLException {
        Class.forName("oracle.jdbc.driver.OracleDriver");
        String url = "jdbc:oracle:thin:@10.128.52.72:1591:IMINT1";
        if (connectionIsClosed())
            con = DriverManager.getConnection(url, "infouser", "infouser");
        return con ;
    }

    /** Close open Statements, ResultSets and the Connection */
    public void close() throws SQLException {
        try {
            closeResultSet();
            closeStatement();
        } finally {
            closeConnection();
        }
    }

    /**
     * Close the connection
     *
     */
    public void closeConnection() throws SQLException {
        if (!connectionIsClosed()) {
            con.close();
            con = null;
        }
    }

        /**
         * Verify connection closed
         *
         * @return true/false
         */
        public boolean connectionIsClosed() throws SQLException {
            return (con == null || con.isClosed());
        }

    /**
     * Close the result set
     *
     */
    public void closeResultSet() throws SQLException {

        if (resultSet != null) {
            resultSet.close();
            resultSet = null;
        }
    }

    /**
     * Close the statement
     *
     */
    public void closeStatement() throws SQLException {
        if (statement != null) {
            statement.close();
            statement = null;
        }
    }

    /**
     * get the result set
     *
     * @param queryCommand
     * @return resultSet - the values in the result set
     * @throws Exception
     */
    public ResultSet getResultSet(String queryCommand) throws Exception {
        System.out.println("Executing query : " + queryCommand);
        con = getConnection();
        statement = createStatement();
        resultSet = executeQuery(queryCommand);
        closeStatement();
        closeConnection();
        return resultSet;
    }

    /**
     * Execute a query
     *
     * @param query
     * @return result
     * @throws Exception
     */
    public ResultSet executeQuery(String query) throws Exception {
        System.out.println("Executing query : " + query);
        con = getConnection();
        statement = createStatement();
        return statement.executeQuery(query);
    }

    /**
     * Create a statement
     *
     * @return createdStament
     */
    public Statement createStatement() throws SQLException {
        return con.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_UPDATABLE);
    }

    /**
     * Execute a query and get all the results
     *
     * @param queryCommand
     *
     * @return result - all the values in the result set
     */
    public ArrayList<String> executeQueryReturnAllResults(String queryCommand) throws Exception {
        ArrayList<String> result = new ArrayList<String>();
        con = getConnection();
        statement = createStatement();
        resultSet = executeQuery(queryCommand);
        while (!resultSet.next()) {
            result.add(resultSet.getString(0));
        }
        closeResultSet();
        closeStatement();
        closeConnection();
        return result;
    }

    /**
     * Execute a query and get all the results
     *
     *
     * @return result - all the values in the result set
     */
    public ArrayList<String> executeQueryReturnNecessaryResults(ResultSet rs, String columnName) throws Exception {
        ArrayList<String> result = new ArrayList<String>();
        con = getConnection();
        statement = createStatement();
        rs.beforeFirst();
        while (rs.next()) {
            if(rs.getString(columnName)==null)
                result.add("");
            else
                result.add(rs.getString(columnName));
        }

        return result;
    }
    /**
     * This method is used execute the query and store the data in Map as key value pair
     * @param rs
     * @param firstColumn
     * @param firstColumnIndex
     * @param secondColumnIndex
     * @return
     * @throws Exception
     */
    public Map<Integer,Map<String,Integer>> executeQueryReturnNecessaryResultsWithKey(ResultSet rs, String firstColumn, int firstColumnIndex, int secondColumnIndex) throws Exception {
        Map<String,Integer> innerResult = null;
        Map<Integer,Map<String,Integer>> outerResult = new HashMap<Integer,Map<String,Integer>>();
        con = getConnection();
        statement = createStatement();
        rs.beforeFirst();
        while(rs.next()){
            innerResult = new HashMap<String, Integer>();
            innerResult.put(rs.getString(firstColumn),rs.getInt(secondColumnIndex));
            outerResult.put(rs.getInt(firstColumnIndex), innerResult);
        }
        return outerResult;
    }
    /**
     * Execute a query and get all the results
     *

     *
     * @return result - all the values in the result set
     */
    public String executeQueryReturnNecessaryResult(ResultSet rs, String columnName) throws Exception {
        String result = "";
        con = getConnection();
        statement = createStatement();
        rs.beforeFirst();
        if (rs.next())
            result = rs.getString(columnName);
        return result;
    }

    public void db() throws ClassNotFoundException, SQLException {
        Class.forName("oracle.jdbc.driver.OracleDriver");
        String url = "jdbc:oracle:thin:@10.128.52.72:1591:IMINT1";
        con = DriverManager.getConnection(url, "infouser", "infouser");
        boolean value = con.isClosed();
        Statement stmt = null;
        String query = "select * from ds_oa_balances where OABACCNUM = '22510603706'";
        try {
            stmt = con.createStatement();
            ResultSet rs = stmt.executeQuery(query);
            while (rs.next()) {
                String actualClosingBalance = rs.getString("OABCLOSINGACTUALBAL");

                System.out.println("actualClosingBalance - " + actualClosingBalance);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            if (stmt != null) {
                stmt.close();
            }
        }
    }
    }
