package ab.utils;

import ab.glue.api.NewStub;
import ab.glue.api.commonApiMethods;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.github.wnameless.json.flattener.JsonFlattener;
import com.github.wnameless.json.unflattener.JsonUnflattener;
import common.EncryptDecrypt;
import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.response.Response;
import io.restassured.specification.ProxySpecification;
import org.apache.commons.io.IOUtils;
import org.apache.xpath.jaxp.XPathFactoryImpl;
import org.w3c.dom.Document;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

import javax.crypto.NoSuchPaddingException;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import javax.xml.xpath.*;
import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.StringWriter;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.reflect.Field;
import java.math.BigDecimal;
import java.nio.charset.StandardCharsets;
import java.security.*;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.util.*;
import java.util.concurrent.atomic.AtomicInteger;

import static io.restassured.RestAssured.given;

public class GenericUtils {
    public static Response response1 = null;

    static XPathFactory factory;
    static XPath xPath;

    static {
        factory = new XPathFactoryImpl();
        xPath = factory.newXPath();
    }

    /**
     * This method will trim the value of the expected Peek/Consume/Recover response
     *
     * @param value - The value to be trimmed
     * @return value - The value that is trimmed for the verification
     */
    public String peekConsumeTrim(String value) {
        String data = "";
        String[] actualData = value.split("\"externalIdentifier\":\\{\"type\":\"Other\",\"identifier\":\"\"}}");
        String finalData = "";
        for (int i = 0; i < actualData.length - 1; i++) {
            value = actualData[i] + "\"externalIdentifier\":{\"type\":\"Other\",\"identifier\":\"\"}}";
            data = value.split("identifier")[0] + "identifier" + "creditDate" + value.split("creditDate")[1].replaceAll("\\.000", "").replaceAll("\\.00", "");
            finalData = finalData + data.replaceAll(" ", "");
        }
        return finalData + "]";
    }

    /**
     * @param headerMap   - Map variable which has the HeaderTitles as Keys and HeaderValues as Values
     * @param body        - String variable which represents the request body
     * @param endPoint    - String variable which represents the URLendpoint to be hit by the POST request
     * @param contentType - ContentType variable which represents the content type of the request.
     * @return response1 - String variable which represents response to the POST request
     * @throws Throwable
     */
    public Response getPOSTResponse(Map<String, String> headerMap, String body, String endPoint, ContentType contentType) throws Throwable {
        //Hit the Post request with URL with the config and print the response
        if(!endPoint.contains("https://apitest.standardchartered.com")){
            RestAssured.reset();
            RestAssured.useRelaxedHTTPSValidation();
        }
        response1 = given()
                .contentType(contentType)
                .headers(headerMap)
                .body(body)
                .when()
                .post(endPoint);
        if(!endPoint.contains("https://apitest.standardchartered.com")){
            ProxySpecification proxySpecification = new ProxySpecification("10.192.191.25",8080,"HTTP");
            RestAssured.proxy(proxySpecification);
        }
        return response1;
    }


    /**
     * @param headerMap   - Map variable with HeaderTitles as Keys and HeaderValue as Values
     * @param endPoint    - String variable which is the URL endpoint for which the GET request is to be passed
     * @param contentType - ContentType variable which is the content type of the request
     * @return response1 - The response of the GET request will be returned as String variable.
     * @throws Throwable
     */
    public Response getGETResponse(Map<String, String> headerMap, String endPoint, ContentType contentType) throws Throwable {
        //Hit the GET request with URL with the config and print the response
        if(!endPoint.contains("https://apitest.standardchartered.com")){
            RestAssured.reset();
            RestAssured.useRelaxedHTTPSValidation();
        }
        response1 = given()
                .contentType(contentType)
                .headers(headerMap)
                .when()
                .get(endPoint);
        if(!endPoint.contains("https://apitest.standardchartered.com")){
            ProxySpecification proxySpecification = new ProxySpecification("10.192.191.25",8080,"HTTP");
            RestAssured.proxy(proxySpecification);
        }
        System.out.println(response1.thenReturn().asString());
        return response1;
    }

    /**
     * @param headerMap   - Map variable with HeaderTitles as Keys and HeaderValue as Values
     * @param endPoint    - String variable which is the URL endpoint for which the GET request is to be passed
     * @param contentType - ContentType variable which is the content type of the request
     * @return response1 - The response of the GET request will be returned as String variable.
     * @throws Throwable
     */
    public Response getGETResponseWithParam(Map<String, String> headerMap, Map<String, String> param, String endPoint, ContentType contentType) throws Throwable {
        //Hit the GET request with URL with the config and print the response
        if(!endPoint.contains("https://apitest.standardchartered.com")){
            RestAssured.reset();
            RestAssured.useRelaxedHTTPSValidation();
        }
        if (contentType == null)
            contentType = ContentType.ANY;
        response1 = given()
                .contentType(contentType)
                .headers(headerMap)
                .params(param)
                .when()
                .get(endPoint);
        if(!endPoint.contains("https://apitest.standardchartered.com")){
            ProxySpecification proxySpecification = new ProxySpecification("10.192.191.25",8080,"HTTP");
            RestAssured.proxy(proxySpecification);
        }
        System.out.println(response1.thenReturn().asString());
        return response1;
    }

    public String[] generatePublicPrivateKey() throws NoSuchAlgorithmException {
        String[] publicPrivateKey = new String[2];
        KeyPairGenerator keyGen = KeyPairGenerator.getInstance("RSA");
        keyGen.initialize(2048);
        KeyPair pair = keyGen.generateKeyPair();
        PrivateKey priv = pair.getPrivate();
        PublicKey pub = pair.getPublic();
        Base64.Encoder encoder = Base64.getEncoder();
        String privateKeyBase64Str = encoder.encodeToString(priv.getEncoded()).trim().replaceAll("[\\t\\n\\r]+", "").replaceAll("\\s+", "");

        System.out.println("Private key in Base64 format:\n" + privateKeyBase64Str.trim().replaceAll("[\\t\\n\\r]+", "").replaceAll("\\s+", ""));//it creates 1623 chars or 1620 chars
        String publicKeyBase64Str = encoder.encodeToString(pub.getEncoded()).trim().replaceAll("[\\t\\n\\r]+", "").replaceAll("\\s+", "");
        System.out.println("Public key in Base64 format:\n" + publicKeyBase64Str.trim().replaceAll("[\\t\\n\\r]+", "").replaceAll("\\s+", ""));
        publicPrivateKey[0] = publicKeyBase64Str;
        publicPrivateKey[1] = privateKeyBase64Str;

        return publicPrivateKey;
    }

    /**
     * The method will modify and trim the expected value that is to be verified with actual value.
     *
     * @param value     - The value that is to trimmed
     * @param group     - The group ID value which is to be added to verification
     * @param amount    - The amount value which is to be added to verification
     * @param accountNo - The account number value which is to be added for verification.
     * @param trxType   - The transaction type value which is to be added for verification.
     * @return - The trimmed/modified data that is to be returned
     */
    public String expectedValueTrim(String value, String group, String amount, String accountNo, String trxType) {
        String data = "";
        try {
            data = IOUtils.toString(new InputStreamReader(getClass().getResourceAsStream("/test-data/MessageFormat.json")));
            BigDecimal pretransaction = new BigDecimal("99805844");
            BigDecimal trxAmount = new BigDecimal(amount).abs();
            BigDecimal posttransaction = pretransaction.add(trxAmount);
            String finaldata = "";
            String eventDate = LocalDate.now().toString();
            if (trxType.equals("C")) {
                trxType = "Credit";
                posttransaction = pretransaction.add(trxAmount);
            } else {
                trxType = "Debit";
                posttransaction = pretransaction.subtract(trxAmount);
            }
            data = data.split("/EMAILSLOWNESS/\",\"")[0] + "/EMAILSLOWNESS/\",\"" + "\"],\"transactionAmount\":" + data.split("/EMAILSLOWNESS/\",\"")[1].split("\"],\"transactionAmount\":")[1];
            data = data.split("/EMAILSLOWNESS/\",\"")[0] + "/EMAILSLOWNESS/\",\"" + "\"],\"transactionAmount\":" + data.split("/EMAILSLOWNESS/\",\"")[1].split("\"],\"transactionAmount\":")[1];
            data = IOUtils.toString(new InputStreamReader(getClass().getResourceAsStream("/test-data/MessageFormat.json")));
            data = org.apache.commons.lang3.StringUtils.replace(data, "${groupId}", group);
            data = org.apache.commons.lang3.StringUtils.replace(data, "${trxType}", trxType);
            data = org.apache.commons.lang3.StringUtils.replace(data, "${accountNumber}", accountNo);
            data = org.apache.commons.lang3.StringUtils.replace(data, "${preTxnBalance}", "" + pretransaction);
            data = org.apache.commons.lang3.StringUtils.replace(data, "${txnAmount}", "" + amount);
            data = org.apache.commons.lang3.StringUtils.replace(data, "${postTxnBalance}", "" + posttransaction);
            data = org.apache.commons.lang3.StringUtils.replace(data, "${eventDate}", eventDate);
            data = org.apache.commons.lang3.StringUtils.replace(data, "${currency}", "INR");
            data = org.apache.commons.lang3.StringUtils.replace(data, "${BIC}", "SCBLINBBXXX");
            data = org.apache.commons.lang3.StringUtils.replace(data, "${baiCode}", "467");
            data = org.apache.commons.lang3.StringUtils.replace(data, "${transactionIdentifier}", "201723162336509");
            return data;
        } catch (IOException e) {
            e.printStackTrace();
        }
        return data;
    }



    /**
     * The method will modify and trim the expected value that is to be verified with actual value.
     *
     * @param value     - The value that is to trimmed
     * @param group     - The group ID value which is to be added to verification
     * @param amount    - The amount value which is to be added to verification
     * @param accountNo - The account number value which is to be added for verification.
     * @param trxType   - The transaction type value which is to be added for verification.
     * @return - The trimmed/modified data that is to be returned
     */
    public String expectedValueTrimWithRandomTransaction(String value, String group, String amount, String accountNo, String trxType, String currency, String bic, String ledger, String baiCode) throws IOException {
        String data = "";
        try {
            data = IOUtils.toString(new InputStreamReader(getClass().getResourceAsStream("/test-data/MessageFormat.json")));
            BigDecimal posttransaction;
            BigDecimal trxAmount = new BigDecimal(amount).abs();
            BigDecimal pretransaction ;
            if(currency.equals("HKD")) {
                posttransaction = new BigDecimal(ledger);
                if (trxType.equals("C")) {
                    trxType = "Credit";
                    pretransaction = posttransaction.subtract(trxAmount);
                } else {
                    trxType = "Debit";
                    pretransaction = posttransaction.add(trxAmount);
                }
            }else{
                pretransaction = new BigDecimal(ledger);
                if (trxType.equals("C")) {
                    trxType = "Credit";
                    posttransaction = pretransaction.add(trxAmount);
                } else {
                    trxType = "Debit";
                    posttransaction = pretransaction.subtract(trxAmount);
                }
           }
            String finaldata = "";
            String eventDate = LocalDate.now().toString();
            data = data.split("/EMAILSLOWNESS/\",\"")[0] + "/EMAILSLOWNESS/\",\"" + "\"],\"transactionAmount\":" + data.split("/EMAILSLOWNESS/\",\"")[1].split("\"],\"transactionAmount\":")[1];
            data = data.split("/EMAILSLOWNESS/\",\"")[0] + "/EMAILSLOWNESS/\",\"" + "\"],\"transactionAmount\":" + data.split("/EMAILSLOWNESS/\",\"")[1].split("\"],\"transactionAmount\":")[1];
            data = IOUtils.toString(new InputStreamReader(getClass().getResourceAsStream("/test-data/MessageFormat.json")));
            data = org.apache.commons.lang3.StringUtils.replace(data, "${groupId}", group);
            data = org.apache.commons.lang3.StringUtils.replace(data, "${trxType}", trxType);
            data = org.apache.commons.lang3.StringUtils.replace(data, "${accountNumber}", accountNo);
            data = org.apache.commons.lang3.StringUtils.replace(data, "${preTxnBalance}", "" + pretransaction);
            data = org.apache.commons.lang3.StringUtils.replace(data, "${txnAmount}", "" + amount);
            data = org.apache.commons.lang3.StringUtils.replace(data, "${postTxnBalance}", "" + posttransaction);
            data = org.apache.commons.lang3.StringUtils.replace(data, "${eventDate}", eventDate);
            data = org.apache.commons.lang3.StringUtils.replace(data, "${currency}", currency);
            data = org.apache.commons.lang3.StringUtils.replace(data, "${BIC}", bic);
            data = org.apache.commons.lang3.StringUtils.replace(data, "${baiCode}", baiCode);
            //data = org.apache.commons.lang3.StringUtils.replace(data, "${processingSystem}", processinSystem);
            data = org.apache.commons.lang3.StringUtils.replace(data, "${transactionIdentifier}", NewStub.modifiedapprvSeqNo.toString());
              return data;
        } catch (IOException e) {
            e.printStackTrace();
        }
        return data;
    }

    public String multipleTransaction(String amount, String value) {
        int counter = 0;
        if (amount.contains(",")) {
            String[] trx = amount.split(",");
            counter = counter + trx.length;
        }
        for (int i = 1; i < counter; i++) {
            value = value + value;
        }
        return value;
    }


    public int verifyNumberOfTransactions(String response, String groupID) {
        int value = 0;
        String[] splitValue = response.split(groupID);
        value = splitValue.length - 1;
        return value;
    }


    public String decryptResponse(Response response, String groupID) throws IOException, NoSuchPaddingException, NoSuchAlgorithmException {
        String responseString = response.thenReturn().asString();
        try {
            String content = "";
            String key = "";
            if(responseString.contains("<content>")) {
                content = response.thenReturn().asString().split("<content>")[1].split("<")[0];
                key = response.thenReturn().asString().split("<key>")[1].split("<")[0];
            }else{
                content = response.thenReturn().asString().split("\"content\":\"")[1].split("\"")[0];
                key = response.thenReturn().asString().split("\"key\":\"")[1].split("\"")[0];
            }
            common.EncryptDecrypt encryptDecrypt = new common.EncryptDecrypt();
            PrivateKey privatekey = encryptDecrypt.convertStringToPrivateKey(commonApiMethods.prop.getProperty(groupID + "_PrivateKey"));
            responseString = encryptDecrypt.decryptWithPrivateKey(privatekey, new EncryptDecrypt.EncryptedContent(content, key));
        } catch (java.lang.RuntimeException e) {
            System.out.println("Could not decrypt with different private key");
        }
        return responseString;
    }

    public String getValueForXpath(String dataTable, String xml) throws XPathExpressionException, ParserConfigurationException, IOException, SAXException {
        String value = "";
        XPathExpression expr =
                xPath.compile("//correlationID/text()");
        DocumentBuilderFactory docFactory = DocumentBuilderFactory.newInstance();
        DocumentBuilder docBuilder = docFactory.newDocumentBuilder();
        // System.out.println(filepath);
        Document doc = docBuilder.parse(new ByteArrayInputStream(xml.getBytes(StandardCharsets.UTF_8)));
        value = (String) expr.evaluate(doc, XPathConstants.STRING);
        return value;
    }

    public String getXpathValue(String xpath, String xml) throws XPathExpressionException, ParserConfigurationException, IOException, SAXException {
        String value = "";
        XPathExpression expr =
                xPath.compile(xpath);
        DocumentBuilderFactory docFactory = DocumentBuilderFactory.newInstance();
        DocumentBuilder docBuilder = docFactory.newDocumentBuilder();
        // System.out.println(filepath);
        Document doc = docBuilder.parse(new ByteArrayInputStream(xml.getBytes(StandardCharsets.UTF_8)));
        value = (String) expr.evaluate(doc, XPathConstants.STRING);
        return value;
    }

    /**
     *
     * @param method
     */
    public void peekTest(String method) {
        RestAssured.useRelaxedHTTPSValidation();
        Response data = given()
                //.proxy("10.23.210.60", 8080)
                .header("GroupId", "INGRP999")
                .header("Content-Type", "text/plain")
                .contentType(ContentType.TEXT)
                .when()
                .get("https://10.23.210.60:9012/api-banking/core/event/" + method);
        String data1 = data.thenReturn().asString();
        System.out.println("Peek Value " + data1.toString());
        System.out.println("status is " + data.getStatusCode());
    }

    private static AtomicInteger counter = new AtomicInteger();

    /**
     *
     * @return
     */
    public static String generateRandomNumber() {
        Date dNow = new Date();
        SimpleDateFormat ft = new SimpleDateFormat("yyyyMMddhhmmssMs");
        String datetime = ft.format(dNow);
        datetime += (counter.incrementAndGet());
        System.out.println(datetime);
        return datetime;
    }


    public static String modifyJSONValues(String jsonPath, String json, Object valueToBeModified) throws XPathExpressionException, ParserConfigurationException, IOException, SAXException, TransformerException {

        Map<String, Object> flattenJson = JsonFlattener.flattenAsMap(json);
//        if(valueToBeModified.equals(""))
//           flattenJson.remove(jsonPath);
//        else
        if (valueToBeModified instanceof Collection) {
            flattenJson.put(jsonPath, valueToBeModified);
            flattenJson.remove(jsonPath +"[0]");
        } else {
            flattenJson.replace(jsonPath, valueToBeModified);
        }
        String jsonString = new ObjectMapper().writeValueAsString(flattenJson);
        json = JsonUnflattener.unflatten(jsonString);

        return json;
    }

    public static String getJsonValue(String jsonPath, String json) throws XPathExpressionException, ParserConfigurationException, IOException, SAXException {
        String value = "";
        Map<String, Object> flattenJson = JsonFlattener.flattenAsMap(json);
        value = flattenJson.get(jsonPath).toString();
        return value;
    }

    public static String modifyXMLValues(List<Map<String, String>> data, String xml, Class apiName) throws XPathExpressionException, ParserConfigurationException, IOException, SAXException, TransformerException, IllegalAccessException, ClassNotFoundException, NoSuchFieldException {
        DocumentBuilderFactory docFactory = DocumentBuilderFactory.newInstance();
        DocumentBuilder docBuilder = docFactory.newDocumentBuilder();
        // System.out.println(filepath);
        Document doc = docBuilder.parse(new ByteArrayInputStream(xml.getBytes(StandardCharsets.UTF_8)));
        for (Map<String, String> mapData : data) {
            for (Map.Entry<String, String> nowMap : mapData.entrySet()) {
                if(nowMap.getKey().equals("date")&&nowMap.getValue().equals("")) {
                    xml = xml.replaceAll(",\"date\":\"\"}","}");
                }else{
                    String xpath = GenericUtils.getXMLPath(nowMap.getKey(), apiName);
                    xml = GenericUtils.modifyXML(xpath, xml, nowMap.getValue());
                }
            }
        }

        return xml;
    }

    public static String modifyXMLValuesWithRandomNumber(List<Map<String, String>> data,Map<String, String> randomList, String xml, Class apiName) throws XPathExpressionException, ParserConfigurationException, IOException, SAXException, TransformerException, IllegalAccessException, ClassNotFoundException, NoSuchFieldException {
        DocumentBuilderFactory docFactory = DocumentBuilderFactory.newInstance();
        DocumentBuilder docBuilder = docFactory.newDocumentBuilder();
        // System.out.println(filepath);
        Document doc = docBuilder.parse(new ByteArrayInputStream(xml.getBytes(StandardCharsets.UTF_8)));
        for (Map<String, String> mapData : data) {
            for (Map.Entry<String, String> nowMap : mapData.entrySet()) {
                if(nowMap.getKey().equals("date")&&nowMap.getValue().equals("")) {
                    xml = xml.replaceAll(",\"date\":\"\"}","}");
                }else{
                    String xpath = GenericUtils.getXMLPath(nowMap.getKey(), apiName);
                    xml = modifyXML(xpath, xml, nowMap.getValue());
                }
            }

            for (Map.Entry<String, String> nowMap : randomList.entrySet()) {
                if(nowMap.getKey().equals("date")&&nowMap.getValue().equals("")) {
                    xml = xml.replaceAll(",\"date\":\"\"}","}");
                }else{
                    String xpath = GenericUtils.getXMLPath(nowMap.getKey(), apiName);
                    xml = modifyXML(xpath, xml, nowMap.getValue() );
                }
            }
        }

        return xml;
    }

    public static String modifyXML(String xpath, String xml, String valueToBeModified) throws XPathExpressionException, ParserConfigurationException, IOException, SAXException, TransformerException {
        String value = "";
        XPathExpression expr =
                xPath.compile(xpath);
        DocumentBuilderFactory docFactory = DocumentBuilderFactory.newInstance();
        DocumentBuilder docBuilder = docFactory.newDocumentBuilder();
        // System.out.println(filepath);
        Document doc = docBuilder.parse(new ByteArrayInputStream(xml.getBytes(StandardCharsets.UTF_8)));
        //value = (String) expr.evaluate(doc, XPathConstants.STRING);
        NodeList myNodeList = (NodeList)expr
                .evaluate(doc, XPathConstants.NODESET);
        myNodeList.item(0).setTextContent(valueToBeModified);
        StringWriter writer = new StringWriter();
        value = myNodeList.toString();
        TransformerFactory transformerFactory = TransformerFactory.newInstance();
        Transformer transformer = transformerFactory.newTransformer();
        DOMSource source = new DOMSource(doc);
        StreamResult result = new StreamResult(writer);
        transformer.transform(source, result);
        value = writer.toString();
        return value;
    }


    public static String modifyJSON(String json, Map<String, String> map, Class object) throws ParserConfigurationException, TransformerException, SAXException, XPathExpressionException, IOException, IllegalAccessException {
        DataClass xmlData = new DataClass();
        for (Field field : xmlData.getClass().getDeclaredFields()) {
            if (!field.isAnnotationPresent(object))
                continue;
            Data data = (Data) field.getAnnotation(object);
            if (map.get(data.name()) != null)
                return "";
            field.set(xmlData, GenericUtils.modifyJSONValues(data.jsonpath(), json, map.get(data.name())));
        }
        return "";
    }

    public static String getJSonPath(String fieldName, Class object) throws NoSuchFieldException {
        return Arrays.asList(object.getDeclaredFields()).stream().map(field1 -> field1.getAnnotation(Data.class)).filter(field -> field != null && field.name().equals(fieldName)).findFirst().get().jsonpath();
    }

    public static String getResponseJSonPath(String fieldName, Class object) throws NoSuchFieldException {
        return Arrays.asList(object.getDeclaredFields()).stream().map(field1 -> field1.getAnnotation(Data.class)).filter(field -> field != null && field.name().equals(fieldName)).findFirst().get().responseJSonPath();
    }


    public static String getXMLPath(String fieldName, Class object) throws NoSuchFieldException {
        return Arrays.asList(object.getDeclaredFields()).stream().map(field1 -> field1.getAnnotation(Data.class)).filter(field -> field != null && field.name().equals(fieldName)).findFirst().get().xpath();
    }

    @Retention(RetentionPolicy.RUNTIME)
    public @interface Data {
        String name();

        String xpath();

        String jsonpath();

        String responseJSonPath();

    }
}
