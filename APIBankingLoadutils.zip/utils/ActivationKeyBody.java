package ab.utils;

import com.google.gson.annotations.SerializedName;

public class ActivationKeyBody implements java.io.Serializable {
    private static final long serialVersionUID = -4084731014676665040L;
    @SerializedName("ActivationKeyBody")
    private String publicKey;
    private String groupId;
    private PropertyBag propertyBag;
    private String certificateThumbprint;

    public String getPublicKey() {
        return this.publicKey;
    }

    public void setPublicKey(String publicKey) {
        this.publicKey = publicKey;
    }

    public String getGroupId() {
        return this.groupId;
    }

    public void setGroupId(String groupId) {
        this.groupId = groupId;
    }

    public PropertyBag getPropertyBag() {
        return this.propertyBag;
    }

    public void setPropertyBag(PropertyBag propertyBag) {
        this.propertyBag = propertyBag;
    }

    public String getCertificateThumbprint() {
        return this.certificateThumbprint;
    }

    public void setCertificateThumbprint(String certificateThumbprint) {
        this.certificateThumbprint = certificateThumbprint;
    }
}
