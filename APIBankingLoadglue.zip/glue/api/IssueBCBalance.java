package ab.glue.api;

import ab.utils.DataClass;
import ab.utils.GenericUtils;
import common.EndPoint;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.response.Response;
import org.apache.commons.io.IOUtils;
import org.junit.Assert;
import org.xml.sax.SAXException;

import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.TransformerException;
import javax.xml.xpath.XPathExpressionException;
import java.io.IOException;
import java.math.BigDecimal;
import java.util.HashMap;
import java.util.List;
import java.util.Map;


/**
 * Created by 1571168 on 5/9/2018.
 */
public class IssueBCBalance {

    public static Response inimegResponse;
    public static String inimegResponseString;
    public static int inimegResponseStatus;
    public static String randomMessageID;
    public static String previousAmount;
    GenericUtils genericUtils= new GenericUtils();

    @When("user hits '(.*)' API with details")
    public void hitJSONAPIWithDetails(String apiName, List<Map<String, String>> data) throws Throwable {
        String json = IOUtils.toString(getClass().getResourceAsStream("/test-data/"+apiName+".json"));
        for (Map<String, String> mapData : data) {
            for (Map.Entry<String, String> nowMap : mapData.entrySet()) {
                String xpath = DataClass.getJSonPath(nowMap.getKey());
                json =  GenericUtils.modifyJSONValues(xpath, json,nowMap.getValue());
            }
        }
        GenericUtils genericUtils = new GenericUtils();
        Map<String, String> headerMap = new HashMap<String, String>();
        RestAssured.useRelaxedHTTPSValidation();
        System.out.println("The request passed is "+json);
        inimegResponse = genericUtils.getPOSTResponse(headerMap,json,  EndPoint.class.getDeclaredField(apiName).getAnnotation(EndPoint.Data.class).name(), ContentType.JSON);
        inimegResponseStatus = inimegResponse.statusCode();
        inimegResponseString = inimegResponse.thenReturn().asString();
        System.out.println("The response is "+inimegResponseString);
    }

    @When("user hits the '(.*)' API with details with random number for '(.*)'")
    public void hitJSONAPIWithDetailsWithRandomID(String apiName,String randomIDs, List<Map<String, String>> data) throws Throwable {
        String json = IOUtils.toString(getClass().getResourceAsStream("/test-data/"+apiName+".json"));
        randomMessageID = genericUtils.generateRandomNumber();
        for (Map<String, String> mapData : data) {
            for (Map.Entry<String, String> nowMap : mapData.entrySet()) {
                String xpath = DataClass.getJSonPath(nowMap.getKey());
                json =  GenericUtils.modifyJSONValues(xpath, json,nowMap.getValue());
            }
        }
        String[] randomIDsEntries = randomIDs.split("\\|");
        for(String randomEntry : randomIDsEntries){
            String xpath = DataClass.getJSonPath(randomEntry);
            json =  GenericUtils.modifyJSONValues(xpath, json,randomMessageID);
        }
        GenericUtils genericUtils = new GenericUtils();
        Map<String, String> headerMap = new HashMap<String, String>();
        headerMap.put("PreVerified","true");
        headerMap.put("GroupId","PRJX001");

        RestAssured.useRelaxedHTTPSValidation();
        System.out.println("The request passed is "+json);
            inimegResponse = genericUtils.getPOSTResponse(headerMap,json,  EndPoint.inimegURL, ContentType.JSON);
            //inimegResponse = genericUtils.getPOSTResponse(headerMap,json,  EndPoint.class.getDeclaredField(apiName).getAnnotation(EndPoint.Data.class).name(), ContentType.JSON);
        inimegResponseStatus = inimegResponse.statusCode();
        inimegResponseString = inimegResponse.thenReturn().asString();
        System.out.println("Response is "+inimegResponseString);
    }


    @When("user hits the '(.*)' API with below details and stores the amount")
    public void hitAPIAndStoreAmount(String apiName, List<Map<String, String>> data) throws Throwable {
        hitJSONAPIWithDetailsWithRandomID(apiName,"inimegRequestMsgId",data);
        previousAmount =  GenericUtils.getJsonValue(DataClass.getJSonPath("inimegQueryManageTrustlineResponseAmount"), inimegResponseString);
    }


    @Then("The '.*' API response should be displayed with '(.*)' amount '(.*)' to original value")
    public void verifyStoredAmout(String apiName,String amount, String addedOrSubtractedAmount) throws Throwable {
        String expectedAmount = "";
        String actualAmount = GenericUtils.getJsonValue(DataClass.getJSonPath("inimegQueryManageTrustlineResponseAmount"), inimegResponseString);
        if(addedOrSubtractedAmount.contains("add")) {
            expectedAmount =""+ (new BigDecimal(amount).add(new BigDecimal(previousAmount)));
        Assert.assertEquals(expectedAmount,actualAmount);
        }else{
            expectedAmount =""+ (new BigDecimal(previousAmount).subtract(new BigDecimal(amount)));
            Assert.assertEquals(expectedAmount,actualAmount);
        }

    }


    @Then("The '.*' API response should be displayed with initial amount")
    public void verifyStoredAmountNotPresent(String apiName,String amount, String addedOrSubtractedAmount) throws Throwable {
        String actualAmount = GenericUtils.getJsonValue(DataClass.getJSonPath("inimegQueryManageTrustlineResponseAmount"), inimegResponseString);
        Assert.assertEquals(previousAmount,actualAmount);
    }

    @When("user hits the '(.*)' API with details with same random number for '(.*)'")
    public void hitJSONAPIWithDetailsWithSameRandomID(String apiName,String randomIDs, List<Map<String, String>> data) throws Throwable {
        String json = IOUtils.toString(getClass().getResourceAsStream("/test-data/"+apiName+".json"));
               for (Map<String, String> mapData : data) {
            for (Map.Entry<String, String> nowMap : mapData.entrySet()) {
                String xpath = DataClass.getJSonPath(nowMap.getKey());
                json =  GenericUtils.modifyJSONValues(xpath, json,nowMap.getValue());
            }
        }
        String[] randomIDsEntries = randomIDs.split("\\|");
        for(String randomEntry : randomIDsEntries){
            String xpath = DataClass.getJSonPath(randomEntry);
            json =  GenericUtils.modifyJSONValues(xpath, json,randomMessageID);
        }
        GenericUtils genericUtils = new GenericUtils();
        Map<String, String> headerMap = new HashMap<String, String>();
        RestAssured.useRelaxedHTTPSValidation();
        System.out.println("The request passed is "+json);
        inimegResponse = genericUtils.getPOSTResponse(headerMap,json,  EndPoint.inimegURL, ContentType.JSON);
        inimegResponseStatus = inimegResponse.statusCode();
        inimegResponseString = inimegResponse.thenReturn().asString();
    }

    @Then("^'(.*)' response should be displayed with status code as '(.*)' and below details$")
    public void verifyInimegResponse(String apiName,int expectedStatusCode, List<Map<String, String>> map) throws ParserConfigurationException, SAXException, XPathExpressionException, IOException {
        for(Map<String,String> mapData : map){
            for(Map.Entry<String,String> data : mapData.entrySet())
            {
                    Assert.assertEquals(data.getValue(), GenericUtils.getJsonValue(DataClass.getJSonPath(data.getKey()), inimegResponseString));
            }
        }
        Assert.assertTrue("Expected Status Code is '"+expectedStatusCode+"'. Actual status code is "+inimegResponseStatus,expectedStatusCode==inimegResponseStatus);
    }


    @Then("^'(.*)' response should not be displayed with below details$")
    public void verifyInimegResponseNotDisplayed(String apiName, List<Map<String, String>> map) throws ParserConfigurationException, SAXException, XPathExpressionException, IOException {
        for(Map<String,String> mapData : map){
            for(Map.Entry<String,String> data : mapData.entrySet())
            {
                String jsonValue = GenericUtils.getJsonValue(DataClass.getJSonPath(data.getKey()), inimegResponseString);
                Assert.assertNotNull(jsonValue);
                Assert.assertFalse("The "+data.getKey()+"value is displayed as "+jsonValue, data.getValue().equals(jsonValue));
            }
        }
    }

    @Then("^the '(.*)' response should be displayed with with random reqMsgID")
    public void verifyInimegResponseWithRandom(String apiName) throws ParserConfigurationException, SAXException, XPathExpressionException, IOException {
                Assert.assertEquals(randomMessageID, GenericUtils.getJsonValue(DataClass.getJSonPath("inimegResponseMsgId"), inimegResponseString));
    }

    @Then("^'(.*)' response should be displayed with error code as '(.*)' and errorMessage '(.*)'$")
    public void verifyInimegNegativeResponse(String apiName, int expectedStatusCode,String errorMessage) throws ParserConfigurationException, SAXException, XPathExpressionException, IOException {
       String expectedErrorMessage = commonApiMethods.errorMessageProperties.getProperty(errorMessage);
        Assert.assertTrue("Expected Status Code is '"+expectedStatusCode+"'. Actual status code is "+inimegResponseStatus,expectedStatusCode==inimegResponseStatus);
        Assert.assertTrue("Expected error message is '"+expectedErrorMessage+"'. Actual error message is "+inimegResponseString,inimegResponseString.equals(expectedErrorMessage));
    }

    public String modifyJSONVaue(String apiName, List<Map<String, String>> data) throws IOException, ParserConfigurationException, SAXException, XPathExpressionException, TransformerException {
        String json = IOUtils.toString(getClass().getResourceAsStream("/test-data/" + apiName + ".json"));
        for (Map<String, String> mapData : data) {
            for (Map.Entry<String, String> nowMap : mapData.entrySet()) {
                String xpath = DataClass.getJSonPath(nowMap.getKey());
                json = GenericUtils.modifyJSONValues(xpath, json, nowMap.getValue());
            }
        }
    return json;
    }
}
