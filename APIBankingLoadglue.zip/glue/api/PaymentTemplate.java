package ab.glue.api;

import ab.utils.GenericUtils;

/**
 * Created by 1571168 on 8/7/2018.
 */
public class PaymentTemplate extends GenericUtils {
    GenericUtils genericUtils = new GenericUtils();
    activationKey activationKey = new activationKey();

    @Data(name = "paymentTemplateTransactionType", xpath = "", jsonpath = "transactionType",responseJSonPath ="")
    String paymentTemplateTransactionType = null;

    @Data(name = "paymentTemplateLocalInstrumentType", xpath = "", jsonpath = "localInstrumentType",responseJSonPath ="")
    String paymentTemplateLocalInstrumentType = null;

    @Data(name = "paymentTemplatecountryCode", xpath = "", jsonpath = "countryCode",responseJSonPath ="")
    String paymentTemplatecountryCode = null;

    @Data(name = "paymentTemplateDefaultCity", xpath = "", jsonpath = "defaultCity",responseJSonPath ="")
    String paymentTemplateDefaultCity = null;



}
