package ab.glue.api;

import ab.utils.GenericUtils;
import com.github.wnameless.json.flattener.JsonFlattener;
import com.google.common.collect.Lists;
import common.EndPoint;
import cucumber.api.DataTable;
import cucumber.api.java.en.When;
import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.response.Response;
import org.junit.Assert;

import java.math.BigDecimal;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Created by 1571168 on 7/20/2018.
 */
public class CustodyHolding {
    GenericUtils genericUtils = new GenericUtils();
    activationKey activationKey = new activationKey();
    public static Response response;
    private List<String> custodyHoldingResponses = Lists.newLinkedList();
    @GenericUtils.Data(name = "custodyHoldingBPID", xpath = "", jsonpath = "businessPartnerId",responseJSonPath ="")
    String custodyHoldingBPID = null;

    @GenericUtils.Data(name = "custodyHoldingSCAID", xpath = "", jsonpath = "scaId",responseJSonPath ="")
    String custodyHoldingSCAID = null;

    @GenericUtils.Data(name = "custodyHoldingDate", xpath = "", jsonpath ="date",responseJSonPath ="")
    String custodyHoldingDate= null;

    @When("Custody holdings response should be displayed based on the direct holdings response")
    public void hitJSONAPIWithDetailsWithRandomID(DataTable dataTable) throws Throwable {

        getDirectCustodyResponse(dataTable);
        String apiBankingResponse = GenericGlue.response.thenReturn().asString();
        String securityServicesResponse = "" + custodyHoldingResponses.get(0);
        compareAPIAndCustodyResponse(apiBankingResponse, securityServicesResponse);
    }

    public void getDirectCustodyResponse(DataTable dataTable) throws Throwable {
        List<List<String>> content = dataTable.asLists(String.class);
        List<String> values = content.get(1);
        Map<String, String> paramMap = new HashMap<>();
        Map<String, String> headerMap = new HashMap<>();
        RestAssured.useRelaxedHTTPSValidation();
        String token = new JsonFlattener(genericUtils.getGETResponseWithParam(headerMap,paramMap, EndPoint.directCustodyOauthURL, ContentType.JSON).thenReturn().asString()).flattenAsMap().get("access_token").toString();
        headerMap.put("Authorization","Bearer "+token);
        paramMap.put("entity",values.get(1));
        paramMap.put("bpid",values.get(2));
        paramMap.put("sacid",values.get(3));
        custodyHoldingResponses.add(genericUtils.getGETResponseWithParam(headerMap,paramMap,EndPoint.directCustodyHoldingsURL,ContentType.JSON).thenReturn().asString());
   System.out.println("The custody holdings response is "+custodyHoldingResponses.get(0));
    }

    public boolean compareAPIAndCustodyResponse(String apiBankingResponse,String custodyHoldingsResponse){
        boolean compareStatus=false;
        Map<String, Object> expectedJsonMap = new JsonFlattener(custodyHoldingsResponse).flattenAsMap();
        Map<String, Object> actualJsonMap = new JsonFlattener(apiBankingResponse).flattenAsMap();
        Object[] keys = expectedJsonMap.keySet().toArray();
        int size = expectedJsonMap.size();
        int holdingCount =0;
        for(int i=0;i<size;i++){
            if(keys[i].toString().contains("bizPrtrId"))
                holdingCount++;
        }
        if(holdingCount==0)
            Assert.fail("There are no holdings present for the search");
        for(int j=0;j< holdingCount;j++){
            Assert.assertEquals(expectedJsonMap.get("data.clientHolding["+j+"].bizPrtrId"),actualJsonMap.get("holdings["+j+"].businessPartnerId"));
            Assert.assertEquals(expectedJsonMap.get("data.clientHolding["+j+"].sfkpgAcct"),actualJsonMap.get("holdings["+j+"].accountId"));
            Assert.assertEquals(expectedJsonMap.get("data.clientHolding["+j+"].sfkpgAcctNm"),actualJsonMap.get("holdings["+j+"].accountName"));
//            Assert.assertEquals(expectedJsonMap.get("data.clientHolding["+j+"].sfkpgOldAcctNm"),actualJsonMap.get("holdings["+j+"].oldAccountName"));
            Assert.assertEquals(expectedJsonMap.get("data.clientHolding["+j+"].dpstry"),actualJsonMap.get("holdings["+j+"].placeOfSettlement"));
            Assert.assertEquals(expectedJsonMap.get("data.clientHolding["+j+"].finInstrmId"),actualJsonMap.get("holdings["+j+"].security.isin"));
            Assert.assertEquals(expectedJsonMap.get("data.clientHolding["+j+"].finInstrmNm"), actualJsonMap.get("holdings["+j+"].security.name"));
            Assert.assertTrue(new BigDecimal(expectedJsonMap.get("data.clientHolding["+j+"].settBal").toString()).equals(new BigDecimal(actualJsonMap.get("holdings["+j+"].position.settled").toString())));
            Assert.assertTrue(new BigDecimal(expectedJsonMap.get("data.clientHolding["+j+"].netBal").toString()).equals(new BigDecimal(actualJsonMap.get("holdings["+j+"].position.net").toString())));
            Assert.assertTrue(new BigDecimal(expectedJsonMap.get("data.clientHolding["+j+"].pendRcptBal").toString()).equals(new BigDecimal(actualJsonMap.get("holdings["+j+"].position.pendingReceive").toString())));
            Assert.assertTrue((new BigDecimal(expectedJsonMap.get("data.clientHolding["+j+"].pendDelBal").toString())).equals(new BigDecimal(actualJsonMap.get("holdings["+j+"].position.pendingDeliver").toString())));
            Assert.assertTrue(new BigDecimal(expectedJsonMap.get("data.clientHolding["+j+"].blckBal").toString()).equals(new BigDecimal(actualJsonMap.get("holdings["+j+"].position.blocked").toString())));
        }

        compareStatus = true;
        return compareStatus;
    }
}
