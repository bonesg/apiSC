package ab.glue.api;

import cucumber.api.DataTable;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import io.restassured.http.ContentType;
import io.restassured.path.json.JsonPath;
import io.restassured.response.ValidatableResponse;
import junit.framework.Assert;

import java.io.File;
import java.util.List;
import java.util.Random;
import java.util.Scanner;
import static io.restassured.RestAssured.given;

/**
 * Created by 1556780 on 5/14/2018.
 */
public class remitOnBCNotify {

    private String SendMid = null;
    private String RecMid = null;
    private String cltId = null;
    private static ValidatableResponse validatableResponse = null;
    private static ValidatableResponse validatableResponse2 = null;
    private static JsonPath jsonPath = null;
    private static String response;
    private static String content;
    private static int reqId, oprId, remId, qId;

    private static String url = "https://10.23.210.60:9012/api-banking/inimeg/transaction/generic";

    @Given("^A valid Sender Receiver and Client Id:$")
    public void a_valid_Sender_Receiver_and_Client_Id(DataTable dataTable) throws Throwable {
        content = new Scanner(new File(".\\\\src\\\\test\\\\resources\\\\test-data\\\\remitOnBCNotify.json")).useDelimiter("\\Z").next();
        List<List<String>> userDetails = dataTable.raw();
        SendMid = userDetails.get(0).get(0);
        RecMid = userDetails.get(0).get(1);
        cltId = userDetails.get(0).get(2);
        content = content.replace("SendMid", SendMid);
        content = content.replace("RecMid", RecMid);
        content = content.replace("CltId", cltId);
    }

    @When("^'remitOnBCNotify' request is sent:$")
    public void remitonbcnotify_request_is_sent(DataTable dataTable) throws Throwable {
        List<List<String>> requestParams = dataTable.raw();
        String sendCurr = requestParams.get(0).get(0);
        String sendAmount = requestParams.get(0).get(1);
        String recCurr = requestParams.get(0).get(2);
        String recAmount = requestParams.get(0).get(3);

        Random rand = new Random();
        reqId = rand.nextInt(999999999);
        oprId = rand.nextInt(999999999);
        remId = rand.nextInt(999999999);
        qId = rand.nextInt(999999999);

        content = content.replace("SendCurr", sendCurr);
        content = content.replace("SendAmount", sendAmount);
        content = content.replace("RecCurr", recCurr);
        content = content.replace("RecAmount", recAmount);
        content = content.replace("MessageId",Integer.toString(reqId));
        content=content.replace("QId",Integer.toString(qId));
        content = content.replace("RemId",Integer.toString(remId));
        //System.out.println(content);

        validatableResponse =
                given()
                        .contentType(ContentType.JSON)
                        .relaxedHTTPSValidation()
                        .when()
                        .body(content)
                        .post(url)
                        .then();
        //capturing API response as String
        response =
                given()
                        .contentType(ContentType.JSON)
                        .relaxedHTTPSValidation()
                        .when()
                        .body(content)
                        .post(url)
                        .thenReturn()
                        .asString();
    }

    @Then("^'remitOnBCNotify' response should be Success$")
    public void remitonbcnotify_response_should_be_Success() throws Throwable {
        validatableResponse.statusCode(200);
        jsonPath = new JsonPath(response);
        Assert.assertTrue(jsonPath.getString("response.head.reqMsgId").equals(Integer.toString(reqId)));
    }

}
