package ab.glue.api;

import ab.utils.GenericUtils;

/**
 * Created by 1571168 on 9/24/2018.
 */
public class Statistics {

    @GenericUtils.Data(name = "messageCount", xpath = "", jsonpath = "messageCount", responseJSonPath = "messageCount")
    String messageCount= null;
}
