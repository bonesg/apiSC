package ab.glue.api;

/**
 * Created by 1556780 on 4/17/2018.
 */
public interface EndPoints {

    String ep_createActivationKey = "https://10.20.164.88:443/uaasv2/services/jwt/createActivationKey";
    String ep_activate = "https://apitest.standardchartered.com/activate";
}
