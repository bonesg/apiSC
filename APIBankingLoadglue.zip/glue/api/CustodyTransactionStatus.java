package ab.glue.api;

import ab.utils.GenericUtils;
import com.google.common.collect.Lists;
import cucumber.api.java.en.Then;
import io.restassured.response.Response;
import org.junit.Assert;
import org.xml.sax.SAXException;

import javax.crypto.NoSuchPaddingException;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.xpath.XPathExpressionException;
import java.io.IOException;
import java.security.NoSuchAlgorithmException;
import java.util.List;

/**
 * Created by 1571168 on 7/23/2018.
 */
public class CustodyTransactionStatus {
    GenericUtils genericUtils = new GenericUtils();
    activationKey activationKey = new activationKey();
    public static Response response;
    private List<String> custodyHoldingResponses = Lists.newLinkedList();
    @GenericUtils.Data(name = "BPID", xpath = "//Business_Partner_ID/text()", jsonpath = "businessPartnerId",responseJSonPath ="status[0].businessPartnerId")
    String BPID = null;

    @GenericUtils.Data(name = "scaAccountNumber", xpath = "//Securities_Account/text()", jsonpath = "securityAccountIds[0]",responseJSonPath ="status[0].securitiesAccount")
    String scaAccountNumber = null;

    @GenericUtils.Data(name = "clientTransactionStatusReference", xpath = "//Client_Transaction_Reference/text()", jsonpath ="transactionReference",responseJSonPath ="status[0].transactionReference.clientTransactionIdentifier")
    String clientTransactionStatusReference= null;

    @GenericUtils.Data(name = "transactionStatusReference", xpath = "//Transaction_Reference/text()", jsonpath ="transactionReference",responseJSonPath ="status[0].transactionReference.transactionIdentifier")
    String transactionStatusReference= null;

    @GenericUtils.Data(name = "status", xpath = "//Status/text()", jsonpath ="transactionStatus",responseJSonPath ="status[0].status")
    String status= null;

    @GenericUtils.Data(name = "tradeDate", xpath = "//Trade_Date/text()", jsonpath ="tradeDates[0]",responseJSonPath ="status[0].tradeDate")
    String tradeDate= null;

    @GenericUtils.Data(name = "settlementDate", xpath = "//Settlement_Date/text()", jsonpath ="settlementDates",responseJSonPath ="status[0].settlementDate")
    String settlementDate= null;

    @GenericUtils.Data(name = "securitiesMovementType", xpath = "//Securities_Movement_Type/text()", jsonpath ="date",responseJSonPath ="status[0].securitiesMovementType")
    String securitiesMovementType= null;

    @GenericUtils.Data(name = "securityIdentifier", xpath = "//Security_Identifier/text()", jsonpath ="date",responseJSonPath ="status[0].security.isin")
    String securityIdentifier= null;

    @GenericUtils.Data(name = "securityName", xpath = "//Security_Name/text()", jsonpath ="date",responseJSonPath ="status[0].security.name")
    String securityName= null;

    @GenericUtils.Data(name = "settlementQuantity", xpath = "//Settlement_Quantity/text()", jsonpath ="date",responseJSonPath ="status[0].settlementQuantity")
    String settlementQuantity= null;

    @GenericUtils.Data(name = "settlementAmount", xpath = "//Settlement_Amount/text()", jsonpath ="date",responseJSonPath ="status[0].settlementAmount")
    String settlementAmount= null;

    @GenericUtils.Data(name = "currencyCode", xpath = "//Settlement_Amount/text()", jsonpath ="date",responseJSonPath ="status[0].currencyCode.isoCode")
    String currencyCode= null;

    @GenericUtils.Data(name = "counterpartyName", xpath = "//Counterparty_Name/text()", jsonpath ="date",responseJSonPath ="status[0].counterpartyName")
    String counterpartyName= null;

    @GenericUtils.Data(name = "correspondenceMode", xpath = "//Correspondence_Mode/text()", jsonpath ="date",responseJSonPath ="status[0].correspondenceMode")
    String correspondenceMode= null;

    @Then("^Custody Transaction response should not be displayed with empty payload value")
    public void verifyResponseNotDisplayedWithCreditDebitAdvice() throws ParserConfigurationException, SAXException, XPathExpressionException, IOException, ClassNotFoundException, NoSuchFieldException, NoSuchAlgorithmException, NoSuchPaddingException {
        Assert.assertTrue("Response is displayed with credit debit advice. Actual response - ", !GenericGlue.responseString.trim().equals("{\"status\":[]}"));
    }

}
