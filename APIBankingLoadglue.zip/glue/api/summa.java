package ab.glue.api;

/**
 * Created by 1571168 on 8/29/2018.
 */
public class summa {
    String json =  "{" +
            "  \"header\":{" +
            "    \"messageSender\":\"NTUC\"," +
            "    \"messageId\":\"20180827092210820\"," +
            "    \"countryCode\":\"SG\"," +
            "    \"timestamp\":1534850835" +
            "  }," +
            "  \"instruction\":{" +
            "    \"paymentTypePreference\":\"Fastest\"," +
            "    \"paymentTimestamp\":\"1531995120\"," +
            "    \"requiredExecutionDate\":\"2018-07-19\"," +
            "    \"amount\":{" +
            "      \"currencyCode\":\"SGD\"," +
            "      \"amount\":\"9\"" +
            "    }," +
            "    \"referenceId\":\"20180827092210828\"," +
            "    \"purpose\":\"CASH\"," +
            "    \"paymentType\":\"IBFT\"," +
            "    \"debtor\":{" +
            "      \"name\":\"NTUC Income\"" +
            "    }," +
            "    \"debtorAccount\":{" +
            "      \"id\":\"0100000142\"," +
            "      \"identifierType\":\"Other\"" +
            "    }," +
            "    \"debtorAgent\":{" +
            "      \"financialInstitution\":{" +
            "        \"BIC\":\"SCBLSGS0XXX\"," +
            "        \"postalAddress\":{" +
            "          \"country\":\"SG\"" +
            "        }," +
            "        \"name\":\"STANDARD CHARTERED BANK\"" +
            "      }" +
            "    }," +
            "    \"creditor\":{" +
            "      \"identity\":{" +
            "        \"id\":\"S2345678H\"," +
            "        \"identityType\":\"RetNRIC\"" +
            "      }" +
            "    }" +
            "  }" +
            "}";
}
