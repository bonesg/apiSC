package ab.glue.api;

import ab.utils.GenericUtils;
import com.github.wnameless.json.flattener.JsonFlattener;
import com.github.wnameless.json.unflattener.JsonUnflattener;
import com.google.common.collect.ImmutableMap;
import com.google.common.collect.Maps;
import com.google.gson.Gson;
import com.google.gson.JsonObject;
import common.EncryptDecrypt;
import cucumber.api.DataTable;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import io.restassured.RestAssured;
import io.restassured.config.SSLConfig;
import io.restassured.http.ContentType;
import io.restassured.response.Response;
import net.oauth.jsontoken.JsonToken;
import net.oauth.jsontoken.crypto.RsaSHA256Signer;
import org.joda.time.Instant;

import java.io.File;
import java.io.InputStream;
import java.security.InvalidKeyException;
import java.security.KeyStore;
import java.security.PrivateKey;
import java.security.SignatureException;
import java.security.interfaces.RSAPrivateKey;
import java.util.*;

import static java.lang.System.currentTimeMillis;
import static org.joda.time.Instant.now;

/**
 * Created by 1556780 on 4/10/2018.
 */
public class apiBanking {

    public static String activationContent = "";
    public static String key = "";
    public static int activationKeyResponseStatus;
    public static String activationKeyResponseString = "";
    public static Response response1;
    public static String token = "";
    public static HashMap<String, String> activKey = new HashMap<String, String>();
    private static final String ISSUER = "SCB";
    private static final String AUDIENCE = "SCB-APIBanking";
    private static final long TOKEN_TIMEOUT_DURATION = 1000L * 30L;
    public static Properties prop = new Properties();
    private static String group = null;
    private static String response;
    private static Response axwayResponse;



    @Given("^a new user group requesting for API Banking Service:$")
    public void a_new_user_requesting_for_API_Banking_Service(DataTable dataTable) throws Throwable {
        List<List<String>> groups = dataTable.raw();
        group = groups.get(0).get(0);
    }

    public static String createTokenForGroup(long timeout, String activateKeyContent, String activateKey, String group) throws Exception {
        Map<String, Object> activationRequest = Maps.newHashMap();
        activationRequest.put("webHookUrl", "");
        activationRequest.put("enableWebHook", "true");
        activationRequest.put("activationKey",
                ImmutableMap.of("content", activateKeyContent, "key", activateKey));
        String privateKey = prop.getProperty(group + "_PrivateKey");
        String token = createToken(timeout, activationRequest, new EncryptDecrypt().convertStringToPrivateKey(privateKey)
        );
        System.out.println("token is " + token);
        return token;
    }

    public static <T> String createToken(long timeout, T payload, PrivateKey privateKey) throws SignatureException, InvalidKeyException {
        RsaSHA256Signer signer;
        signer = new RsaSHA256Signer(ISSUER, null, (RSAPrivateKey) privateKey);
        //Configure JSON token
        JsonToken token = new JsonToken(signer);
        token.setAudience(AUDIENCE);
        token.setIssuedAt(now());
        token.setExpiration(new Instant(currentTimeMillis() + (timeout * 1000L)));

        //Configure request object, which provides information of the item
        JsonObject payloadO = token.getPayloadAsJsonObject();
        payloadO.add("payload", new Gson().toJsonTree(payload));
        return token.serializeAndSign();
    }

    public static String getActivationKey(String groupID, Properties prop) throws Throwable {
        String activationKey = "";
        RestAssured.useRelaxedHTTPSValidation();
        activationKey = new Scanner(new File(".\\src\\test\\resources\\test-Data\\activationKeyBody.json")).useDelimiter("\\Z").next();
        Map<String, Object> flattenJson = JsonFlattener.flattenAsMap(activationKey);
        System.out.println(flattenJson.toString().replaceAll("\\\\/", "\\/"));
        flattenJson.replace("ActivationKeyBody.groupId", groupID);
        flattenJson.replace("ActivationKeyBody.propertyBag.supportEmailAddress", prop.getProperty(groupID + "_Email"));
        flattenJson.replace("ActivationKeyBody.propertyBag.supportContactName", prop.getProperty(groupID + "_Name"));
        flattenJson.replace("ActivationKeyBody.publicKey", prop.getProperty(groupID + "_PublicKey"));
        flattenJson.replace("ActivationKeyBody.certificateThumbprint", prop.getProperty(groupID + "_Certificate"));
        String body = JsonUnflattener.unflatten(flattenJson.toString()).replaceAll("\\\\/", "\\/");
        System.out.println("request passed is " + body);
        HashMap<String, String> headerMap1 = new HashMap<String, String>();
        //Response response = getPOSTResponse(headerMap1, unflattenJson, "https://10.20.164.88:443/uaasv2/services/jwt/createActivationKey", ContentType.JSON);

        String url= EndPoints.ep_createActivationKey;

        //********** hawks-rest lib usage***********************
        GenericUtils genericUtils = new GenericUtils();
        HashMap<String, String> headerMap = new HashMap<>();
        Response response=genericUtils.getPOSTResponse(headerMap,url,body,ContentType.JSON);

        //*************End of hawks-rest lib usage***************

        activationKeyResponseStatus = response.getStatusCode();
        activationKeyResponseString = response.thenReturn().asString();
        activationKey = response.thenReturn().asString();
        System.out.println("The activation key is " + activationKey);
        String[] parts = activationKey.split("\"");
        activationContent = parts[5];
        key = parts[9];

        return activationKey;
    }

    @Given("^an activation key is generated for the group:$")
    public void an_activation_key_is_generated_for_the_group(DataTable dataTable) throws Throwable {
        List<List<String>> groups = dataTable.raw();
        group = groups.get(0).get(0);

        InputStream input = getClass().getResourceAsStream("/test-data/activationKeyRequest.properties");
        prop.load(input);
        String[] parts = getActivationKey(group, prop).split("\"");
        activationContent = parts[5];
        key = parts[9];

    }

    @Given("^the user has already generated the JWT token using the activation key:$")
    public void the_user_has_already_generated_the_JWT_token_using_the_activation_key(DataTable dataTable) throws Throwable {
        List<List<String>> groups = dataTable.raw();
        group = groups.get(0).get(0);

        token = createTokenForGroup(30L, activationContent, key, group);
        activKey.put(group, token);
    }

    @When("^a request is made to api gateway for the user group for Activation$")
    public void a_request_is_made_to_Axway_endpoint_for_the_user_group_for_Activation(DataTable dataTable) throws Throwable {
        List<List<String>> groups = dataTable.raw();
        group = groups.get(0).get(0);

        //Configuration to add the token and certificate
        KeyStore keyStore = null;
        String token = null;
        System.out.println("Current time is " + now());
        token = activKey.get(group);
        keyStore = KeyStore.getInstance("PKCS12");
        keyStore.load(getClass().getResourceAsStream("/test-data/bny-cert.pfx"), "bny123".toCharArray());
        org.apache.http.conn.ssl.SSLSocketFactory clientAuthFactory = null;
        clientAuthFactory = new org.apache.http.conn.ssl.SSLSocketFactory(keyStore, "bny123");
        SSLConfig config = null;
        config = new SSLConfig().with().sslSocketFactory(clientAuthFactory).and().allowAllHostnames();
        RestAssured.config = RestAssured.config().sslConfig(config);
        //Hit the Post request with URL with the config and print the response

        Map<String, String> headerMap = new HashMap<String, String>();
        //String url = "https://apitest.standardchartered.com/activate";
        String url = EndPoints.ep_activate;

        //********** hawks-rest lib usage***********************
        GenericUtils genericUtils = new GenericUtils();
        Response response=genericUtils.getPOSTResponse(headerMap,url,token,ContentType.JSON);


        //*************End of hawks-rest lib usage***************

    }

    @Then("^user should be successfully activated$")
    public void user_should_be_successfully_activated() throws Throwable {
        response = axwayResponse.thenReturn().asString();
        int status = axwayResponse.getStatusCode();

        System.out.println(response);
        System.out.println("Status code is " + status);
    }

}
