package ab.glue.api;

import ab.common.PeekAndConsumeConfig;
import ab.utils.DataClass;
import ab.utils.GenericUtils;
import com.github.wnameless.json.flattener.JsonFlattener;
import common.EncryptDecrypt;
import common.EndPoint;
import cucumber.api.DataTable;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import io.restassured.RestAssured;
import io.restassured.config.SSLConfig;
import io.restassured.http.ContentType;
import io.restassured.response.Response;
import io.restassured.specification.ProxySpecification;
import org.junit.Assert;
import org.junit.Test;
import org.xml.sax.SAXException;

import javax.crypto.NoSuchPaddingException;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.xpath.XPathExpressionException;
import java.io.IOException;
import java.io.InputStream;
import java.security.KeyStore;
import java.security.NoSuchAlgorithmException;
import java.security.PrivateKey;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Properties;

import static io.restassured.RestAssured.given;

/**
 * Created by 1571168 on 7/31/2017.
 */
public class PeekAndConsume {


    //public static String activationKey = "eyJhbGciOiJSUzI1NiJ9.eyJpc3MiOiJTQ0IiLCJhdWQiOiJTQ0ItQVBJQmFua2luZyIsImlhdCI6MTUwMjk0MTc5NywiZXhwIjozMDAwMDE1MDI5NDE3OTcsInBheWxvYWQiOnsiZW5hYmxlV2ViSG9vayI6InRydWUiLCJ3ZWJIb29rVXJsIjoiaHR0cDovLzE4LjIyMC4xNTYuMi93ZWJob29rIiwiYWN0aXZhdGlvbktleSI6eyJjb250ZW50IjoiZ2UyT2F5dWZNNnV2Z3ZZYzBWdkxlOTRTYmt5NzdveXJlenhSSzJpL3hocndkRitiQVZicldJcUNZeWFWYXpOZjRScWFlTkJhTkZNSW9BSGdZenhWTFYzdmRoNnVod2V3dGJHelpnNFo0RDVjd2dtZUtiZFpYd2tvOUNEMGE4S3F0TmRENDBVbkRVRU1NK0RZYVZtTlQ0c0dJMEI4K3pJZE0wVDFoVkE5NzdJVDYzYzJaYjNyR29EZGJZWG9xaGRmRWxLL2hJMU5NUDZzUXUzRWdXSlh5UEJjWnNrTkpoeDQ0WWkvV3BVSkNtaU5mcGliREJlWUllKzExNWEyTTJvZzdRcnlrQ0dVQ2RXdUwrYVlJYXlaT200eHgxZmFscUJvNE80NlVnaHp5bUNhN0pJc0lLN0pRMUdZK0RXbDRuN204V3NTVlRpOUVPaithTzlCT0dYeUtmZWdqRXNPcU8wZDlPVFlkbWpFRHNUWHlhWVlQV2JpcnpnYWcwcEJQVXdNaUZodFVOdE9ZSENSV3FVVDdEM1U5Qk81UDN2VmF4ajVjNHUxMHM1elRPR1BRd1d3S291QzBmS01sdldsTXByMDdJamd4djdlNDI5QkF6ZkdlVk1mekt4OGM4QUFWaWVXNndlQ2NYMVB2WlFOWE9FZTJHNmRpdzRyQ0lEQnpnRmwwdGpZVmRwUkhqZDJtWjRJakt1MklTMHE2bk9pNjRRYmVkQXNGckVMZUowYm5xZE9udGk5SnR5N3c0dk43ZWNuQUZVZTlGSHB6Vk9uMnAva0thSVQ3ZUxFUytkcVZ3Tk8vN3YyZkhsbnpyWlVWY3didXplbXdEek9HZXlCYUtCZnpSeVJERENGVFU4SkhueGtrZnArM25RNE5aOU9iQTVscHJWdis4VlhhdW5rWGcreGRRMGRiU3RkOXIzbTBwUjhkQVBOUGs5czFOYUtXRXdWUWpJVFZOelRvZTFlaWxobVpGRis0NEdMS0JFME1zaXI3WVZVV1pUbmtvcld2dzVHMjZkeU1DV3E0a2JwRUxkazczZjd5OU1ubDluM1phYzEwZ0pzcFNOcGJRWDBMTWd5MUwrdENyYlMrcnJRK0ZpZyIsImtleSI6IlpSU3IrSzVBcWR1QTZ3aVk2S21NSS9LTVE2d2NRem5HTzg1ZWJCVVZjdnlqOXZDVEpsRDdQdDNCdHlPUktPQ2grYnNLUi9iRVpBWlNqcG1OTzVlZ0JkRDBzZXdhNkRGaEpNQ0hENG1DS2hDT2RrQ2VreXlST2VtVHUycGx0cWNoNnUwc281a3F2TTBVYmVMcHF0RFRDZ3lKc3ZqdmVjTUNKK0MyZ1ZDZWJhc05lckVmZzM0UXN1ZUVSQlRiZlN6dFpMelVZRUtDaWI4Q2I4L0xtcFN3dFBxam5Nd1M1ckw5TkY2Q0kwS09vQVhtMXRCN0pUMFc1SXR1akNST3FJM2JGUTFlSDlIbzljeFAzWmt4cTJxc2RZYlNkS0phRnZ5eGlDeGQwRE8vOHphVjJoRzMxRStaSVFhTER0MHBORWtScEFaRHgrN1VpbWY5WHpyeXNJTENqQVx1MDAzZFx1MDAzZCJ9fX0.IvSNfIrsitDimWf9cfkCOnSEIYPxgU7o2LrUfdl026XqR7R_UM-SY24SwiOKaHuFFrggeeRQ8DLFhKGWcMiW1daadOxc_l1gY82U7Nerj6Y-9Wluz7Szdj_BmgplAqmAHrf2WvfQVTNnnbrID68cCw0K2fzPYT6ZKfFgGefYg86j6wF9FEeebSDm27l8d0_gB5JoPmDPkZPPLQzhIFByW294Ts1PeSxzLkhdP4dJ3ZvSK2BvNKzZQj8S-4aTB4C1O248cS8dFyUBxCjrCYld_XHOUi_76WkUZ2knAC8bVkXJTjIL3IRfQDs4k9Th50Qhma1-CnjAubTReK233zA0YA";
    //public static String activationKey = "eyJhbGciOiJSUzI1NiJ9.eyJpc3MiOiJTQ0IiLCJhdWQiOiJTQ0ItQVBJQmFua2luZyIsImlhdCI6MTUwMzE1MDk4NiwiZXhwIjozMDAwMDE1MDMxNTA5ODYsInBheWxvYWQiOnsiZW5hYmxlV2ViSG9vayI6InRydWUiLCJ3ZWJIb29rVXJsIjoiaHR0cDovLzEwLjIzLjIxMC41OTo4NDQzIiwiYWN0aXZhdGlvbktleSI6eyJjb250ZW50Ijoib0MyR1cwTXZpcHA4SXdudVlZb2VKVnlVQTVZQ0FDUUZkVVBHNWNVK01WanFTK3UzdWNDTnhBUWYzQWdxdkZVWnNFNDRZR2lEK01uUzFMdzZBbVdLZTh2MXJMS1d3RDU3L0NaSW15M0FmYzZGSkg0ZzRleGlRcWVlbE9zVUhKbGlPc2d1ZEhZM2MwdjVYTWRjZ05jN2xKTUVCWHFMa29rZnJTWU0xaGZkdFVrd0o4QUVQVk5hK0lqTlp2OVo4M2hSVXVNWmwrcnduTUhVb1dNZkx3SmI5T2J5N3lUUmszWnRMcGp2OUovM2h5cHU0ditVY05aRDZiMjNyOTZQZXQvZi94ckpySEFZNWY2VFFYd3NYZHNnMVh2NGRXb3RMMHJnTnFHMEhsbXkwVjNkUmJKMXYxWnJDTk9sZFAwVVRkbjdpZGREaFBTdElmRWU2aXdKcnFacTExeGtWbHRSbDR2bkNZM3I4eTNjckI5V1VaT1ZNNWczZnVxNEhidVM0WWk1WFkvQkc2aWVScUF0TU9QNHIxOVF2TWtVTUJpeEpzVVZMcFJkSkZaTHFNaG91TTMvenRKS1U5Smp0c1RjRUIwRVZBZVUwYkZ3WkFUV3R2WUEzMFZ5a1I2cU95Y0loZ0tEZmwyWWk1OUpFeTdOeUdBSnc5MWd3eG8vb3R6UDcvNy82TU1VNFFmUmsySmFMeEFyWUhGYzA1WEdNa2N5ZDR6a2djRzRxbDVWdjduekpPcFZhTVhtRHYrMEt6Y2pWSnlqTWtORTMzUnUyNkZpMVdhSU5FWEtZdTFacmN4Zm9GdHhGTkNVUzVMWitoRGRaQTM0ZFBUTEFWUmxMV2FYTjU1cDRERGNuYXpERkVqVFovallNdXdvU2QwVHpvMk5HMWtVdEM3Q0ZmYzhDVHV3NmozOEF0MWNEYmxPaVRtUUZ2SXNQYVRFV2Z4SU82UWRiRE9wREx3cS9zZDJmNEhLQTVxR1NpTDdpbVJNUkZIZWhPVjF2RXBlL2ZtZGRwK0dpaDA3UUZ4UXM5ZnhYeGRYa2tRR2ozVWJkUUt0elVTMjBoT0swUTV1cGd1L1U5aUdUZzIzVlErZzRDWkpXSExXZTJ6RyIsImtleSI6IkY4c01aQWEvYUFwejUwak02THplcWF3Q0hmRlMvSUVjQlFKVWl3ZU85VXpZNW9qcmNHY1hZSmp5bm4yUHlRdk5Gams1dkprZ3dhMm9lcVFuZTh6aFJnL0R0Zm9DRjFqSnlXaVBaYitKckVVek5IQzgyRXJJQng0V05EbHFxRzFaZ3VqUUhacDBMVmhkSWdVdVhCdUJtUldWeUUvWHJ3RVZERlVHOEhTaUpDUEZmUGhQd01DNXd5a0xMeWRLRnpTR2lvZVk5OW05bWlITTV6Mkg2TG1OWmpySlV0K3B3Q2k5MStwVUN4Vmc5OEZkSkh1a3hMOHA2aGttN1pMejBOeDFxS0F2dXVqdmduNGdDL1pIam5JcFhodkpJcjAvR3VtVmpOTlRlOFg2VFF4YnY4cGIvQlNSRGVxZnpybUJ0eXhWRWlkKzBzRWVCTTZET3dkME5XdzhBQVx1MDAzZFx1MDAzZCJ9fX0.IyF2f2Ln1j8k0VwUiavG5e4TmTXhS2J3GERjBDBla-KnaRgC13yMX1rCZEKU_Qs7UrYZLouoCu3np8Odw-1-ImSBHNJ1mEihCZ8_5tHG0yGGfbCx0HQLlQSUwT5C-vzM9cx7Vcu-y7uEmd3UqwHgRjsLV1BrGa2JV-WL900vGAkCkow4QLGQgCFRq67pHNqfEtIKj8li8etvLzu1JkXSmzDTjssIsbfEIr9PMa1pOetyJE1pXRk2LOH2cQShZAWbIvUUcPxmOZsk1glpU8OcPb3zaiIjK9YJ1JdrAlvKe6HxDWsKBin2a3f6GZXuEbdr4N6Ug_srheqYh9rmsNIv-Q";
    public static String activationKey = ab.glue.api.activationKey.token;
    public static HashMap<String , String > activKey = new HashMap<String , String >();
    public static String response = "{\n" +
            "    \"content\": \"4zsajyKPZ8LpSNLglyHtvg==\",\n" +
            "    \"key\": \"MrZV9elu/YX9qFIkmNP7vIOJl0nBpjoYPf9rGscxNgwURUv1BN8jvVKXyaEXgtOEuHyXV5tSJ7Zax2kfiZkxKMchOQWTP4EZakzyCILFHFxdPf5sglQ2agXAww2Hg8r0lW6RxkWhIfFG666nKa5phbcfhIi8OwgWQsGWTQBarENqvPhN8EhN3HB6odfd2HDPeyTS6IooTZw+s1c7rWT94yokYfKxxFEF/kuuouDNFzjGzcp2Tr6ksVhRP2WKKST/wR32B0siYGNRYd4k1/7PDbN02Wb7nlX58oEeWI7XQdYM+HQ7GQPzOLIQfyT6u/5IiHwvF7SsH4UNbSOifjQfJg==\"\n" +
            "}\n";
    public static String expectResponse ="";
    public static String consumedResponse = "";
    public static String apiResponse = "";
    public static int apiStatusCode = 0;
    public void PeekAndConsume(){
        activKey.put("INDGROUP","eyJhbGciOiJSUzI1NiJ9.eyJpc3MiOiJTQ0IiLCJhdWQiOiJTQ0ItQVBJQmFua2luZyIsImlhdCI6MTUwMjk0MTc5NywiZXhwIjozMDAwMDE1MDI5NDE3OTcsInBheWxvYWQiOnsiZW5hYmxlV2ViSG9vayI6InRydWUiLCJ3ZWJIb29rVXJsIjoiaHR0cDovLzE4LjIyMC4xNTYuMi93ZWJob29rIiwiYWN0aXZhdGlvbktleSI6eyJjb250ZW50IjoiZ2UyT2F5dWZNNnV2Z3ZZYzBWdkxlOTRTYmt5NzdveXJlenhSSzJpL3hocndkRitiQVZicldJcUNZeWFWYXpOZjRScWFlTkJhTkZNSW9BSGdZenhWTFYzdmRoNnVod2V3dGJHelpnNFo0RDVjd2dtZUtiZFpYd2tvOUNEMGE4S3F0TmRENDBVbkRVRU1NK0RZYVZtTlQ0c0dJMEI4K3pJZE0wVDFoVkE5NzdJVDYzYzJaYjNyR29EZGJZWG9xaGRmRWxLL2hJMU5NUDZzUXUzRWdXSlh5UEJjWnNrTkpoeDQ0WWkvV3BVSkNtaU5mcGliREJlWUllKzExNWEyTTJvZzdRcnlrQ0dVQ2RXdUwrYVlJYXlaT200eHgxZmFscUJvNE80NlVnaHp5bUNhN0pJc0lLN0pRMUdZK0RXbDRuN204V3NTVlRpOUVPaithTzlCT0dYeUtmZWdqRXNPcU8wZDlPVFlkbWpFRHNUWHlhWVlQV2JpcnpnYWcwcEJQVXdNaUZodFVOdE9ZSENSV3FVVDdEM1U5Qk81UDN2VmF4ajVjNHUxMHM1elRPR1BRd1d3S291QzBmS01sdldsTXByMDdJamd4djdlNDI5QkF6ZkdlVk1mekt4OGM4QUFWaWVXNndlQ2NYMVB2WlFOWE9FZTJHNmRpdzRyQ0lEQnpnRmwwdGpZVmRwUkhqZDJtWjRJakt1MklTMHE2bk9pNjRRYmVkQXNGckVMZUowYm5xZE9udGk5SnR5N3c0dk43ZWNuQUZVZTlGSHB6Vk9uMnAva0thSVQ3ZUxFUytkcVZ3Tk8vN3YyZkhsbnpyWlVWY3didXplbXdEek9HZXlCYUtCZnpSeVJERENGVFU4SkhueGtrZnArM25RNE5aOU9iQTVscHJWdis4VlhhdW5rWGcreGRRMGRiU3RkOXIzbTBwUjhkQVBOUGs5czFOYUtXRXdWUWpJVFZOelRvZTFlaWxobVpGRis0NEdMS0JFME1zaXI3WVZVV1pUbmtvcld2dzVHMjZkeU1DV3E0a2JwRUxkazczZjd5OU1ubDluM1phYzEwZ0pzcFNOcGJRWDBMTWd5MUwrdENyYlMrcnJRK0ZpZyIsImtleSI6IlpSU3IrSzVBcWR1QTZ3aVk2S21NSS9LTVE2d2NRem5HTzg1ZWJCVVZjdnlqOXZDVEpsRDdQdDNCdHlPUktPQ2grYnNLUi9iRVpBWlNqcG1OTzVlZ0JkRDBzZXdhNkRGaEpNQ0hENG1DS2hDT2RrQ2VreXlST2VtVHUycGx0cWNoNnUwc281a3F2TTBVYmVMcHF0RFRDZ3lKc3ZqdmVjTUNKK0MyZ1ZDZWJhc05lckVmZzM0UXN1ZUVSQlRiZlN6dFpMelVZRUtDaWI4Q2I4L0xtcFN3dFBxam5Nd1M1ckw5TkY2Q0kwS09vQVhtMXRCN0pUMFc1SXR1akNST3FJM2JGUTFlSDlIbzljeFAzWmt4cTJxc2RZYlNkS0phRnZ5eGlDeGQwRE8vOHphVjJoRzMxRStaSVFhTER0MHBORWtScEFaRHgrN1VpbWY5WHpyeXNJTENqQVx1MDAzZFx1MDAzZCJ9fX0.IvSNfIrsitDimWf9cfkCOnSEIYPxgU7o2LrUfdl026XqR7R_UM-SY24SwiOKaHuFFrggeeRQ8DLFhKGWcMiW1daadOxc_l1gY82U7Nerj6Y-9Wluz7Szdj_BmgplAqmAHrf2WvfQVTNnnbrID68cCw0K2fzPYT6ZKfFgGefYg86j6wF9FEeebSDm27l8d0_gB5JoPmDPkZPPLQzhIFByW294Ts1PeSxzLkhdP4dJ3ZvSK2BvNKzZQj8S-4aTB4C1O248cS8dFyUBxCjrCYld_XHOUi_76WkUZ2knAC8bVkXJTjIL3IRfQDs4k9Th50Qhma1-CnjAubTReK233zA0YA");
        activKey.put("INDGRP","eyJhbGciOiJSUzI1NiJ9.eyJpc3MiOiJTQ0IiLCJhdWQiOiJTQ0ItQVBJQmFua2luZyIsImlhdCI6MTUwMzE1MDk4NiwiZXhwIjozMDAwMDE1MDMxNTA5ODYsInBheWxvYWQiOnsiZW5hYmxlV2ViSG9vayI6InRydWUiLCJ3ZWJIb29rVXJsIjoiaHR0cDovLzEwLjIzLjIxMC41OTo4NDQzIiwiYWN0aXZhdGlvbktleSI6eyJjb250ZW50Ijoib0MyR1cwTXZpcHA4SXdudVlZb2VKVnlVQTVZQ0FDUUZkVVBHNWNVK01WanFTK3UzdWNDTnhBUWYzQWdxdkZVWnNFNDRZR2lEK01uUzFMdzZBbVdLZTh2MXJMS1d3RDU3L0NaSW15M0FmYzZGSkg0ZzRleGlRcWVlbE9zVUhKbGlPc2d1ZEhZM2MwdjVYTWRjZ05jN2xKTUVCWHFMa29rZnJTWU0xaGZkdFVrd0o4QUVQVk5hK0lqTlp2OVo4M2hSVXVNWmwrcnduTUhVb1dNZkx3SmI5T2J5N3lUUmszWnRMcGp2OUovM2h5cHU0ditVY05aRDZiMjNyOTZQZXQvZi94ckpySEFZNWY2VFFYd3NYZHNnMVh2NGRXb3RMMHJnTnFHMEhsbXkwVjNkUmJKMXYxWnJDTk9sZFAwVVRkbjdpZGREaFBTdElmRWU2aXdKcnFacTExeGtWbHRSbDR2bkNZM3I4eTNjckI5V1VaT1ZNNWczZnVxNEhidVM0WWk1WFkvQkc2aWVScUF0TU9QNHIxOVF2TWtVTUJpeEpzVVZMcFJkSkZaTHFNaG91TTMvenRKS1U5Smp0c1RjRUIwRVZBZVUwYkZ3WkFUV3R2WUEzMFZ5a1I2cU95Y0loZ0tEZmwyWWk1OUpFeTdOeUdBSnc5MWd3eG8vb3R6UDcvNy82TU1VNFFmUmsySmFMeEFyWUhGYzA1WEdNa2N5ZDR6a2djRzRxbDVWdjduekpPcFZhTVhtRHYrMEt6Y2pWSnlqTWtORTMzUnUyNkZpMVdhSU5FWEtZdTFacmN4Zm9GdHhGTkNVUzVMWitoRGRaQTM0ZFBUTEFWUmxMV2FYTjU1cDRERGNuYXpERkVqVFovallNdXdvU2QwVHpvMk5HMWtVdEM3Q0ZmYzhDVHV3NmozOEF0MWNEYmxPaVRtUUZ2SXNQYVRFV2Z4SU82UWRiRE9wREx3cS9zZDJmNEhLQTVxR1NpTDdpbVJNUkZIZWhPVjF2RXBlL2ZtZGRwK0dpaDA3UUZ4UXM5ZnhYeGRYa2tRR2ozVWJkUUt0elVTMjBoT0swUTV1cGd1L1U5aUdUZzIzVlErZzRDWkpXSExXZTJ6RyIsImtleSI6IkY4c01aQWEvYUFwejUwak02THplcWF3Q0hmRlMvSUVjQlFKVWl3ZU85VXpZNW9qcmNHY1hZSmp5bm4yUHlRdk5Gams1dkprZ3dhMm9lcVFuZTh6aFJnL0R0Zm9DRjFqSnlXaVBaYitKckVVek5IQzgyRXJJQng0V05EbHFxRzFaZ3VqUUhacDBMVmhkSWdVdVhCdUJtUldWeUUvWHJ3RVZERlVHOEhTaUpDUEZmUGhQd01DNXd5a0xMeWRLRnpTR2lvZVk5OW05bWlITTV6Mkg2TG1OWmpySlV0K3B3Q2k5MStwVUN4Vmc5OEZkSkh1a3hMOHA2aGttN1pMejBOeDFxS0F2dXVqdmduNGdDL1pIam5JcFhodkpJcjAvR3VtVmpOTlRlOFg2VFF4YnY4cGIvQlNSRGVxZnpybUJ0eXhWRWlkKzBzRWVCTTZET3dkME5XdzhBQVx1MDAzZFx1MDAzZCJ9fX0.IyF2f2Ln1j8k0VwUiavG5e4TmTXhS2J3GERjBDBla-KnaRgC13yMX1rCZEKU_Qs7UrYZLouoCu3np8Odw-1-ImSBHNJ1mEihCZ8_5tHG0yGGfbCx0HQLlQSUwT5C-vzM9cx7Vcu-y7uEmd3UqwHgRjsLV1BrGa2JV-WL900vGAkCkow4QLGQgCFRq67pHNqfEtIKj8li8etvLzu1JkXSmzDTjssIsbfEIr9PMa1pOetyJE1pXRk2LOH2cQShZAWbIvUUcPxmOZsk1glpU8OcPb3zaiIjK9YJ1JdrAlvKe6HxDWsKBin2a3f6GZXuEbdr4N6Ug_srheqYh9rmsNIv-Q");
    }
    public static String peekConsumeRecoverString = "";
    public static int peekConsumeRecoverStatus = 0;
    /**
     * This method is used to hit the Peek api and verify the response with the expected response
     */
    @Then("^Peek response should be displayed with the expected value$")
    public void peekTest() {
        GenericUtils utils = new GenericUtils();
        String expectedResponse = commonApiMethods.data.get(0).get("PeekResponse").toString().trim().replaceAll(" ","");
        expectedResponse = utils.peekConsumeTrim(expectedResponse);
        PeekAndConsumeConfig peekAndConsumeConfig = new PeekAndConsumeConfig();
        String actualResponse = peekAndConsumeConfig.getPeekConsumeResponseAsString(ab.glue.api.activationKey.activKey.get(""), "peek").trim();
        System.out.println("Peek response : "+actualResponse);
        actualResponse = utils.peekConsumeTrim(expectedResponse);
        Assert.assertTrue("Peek Response is not displayed as expected. Expected Response - " + expectedResponse + ". Actual Response - " + actualResponse, expectedResponse.equals(actualResponse));
    }

    /**
     * This method is used to hit the Peek api and verify the response with the expected response
     */
    @Then("^Peek response should be displayed with amount '(.+)' accountNo '(.+)' transactionType '(.+)' the expected value for the group '(.+)'$")
    public void peekValueTest(String amount, String accountNo, String trxType, String groupID) throws Throwable {
        GenericUtils utils = new GenericUtils();
        String expectedResponse = EndPoint.WEBHOOK_MESSAGE.replaceAll(" ","");
        expectedResponse = utils.expectedValueTrim(expectedResponse,groupID,amount, accountNo,trxType).replaceAll("\\.00","");;
        verifyResponse(groupID, expectedResponse, "peek","bny-cert.pfx","bny123");
    }


    /**
     * This method is used to hit the Peek api and verify the response with the expected response
     */
    @Then("^'(.+)' response when called with certificate '(.+)' and password '(.+)' should be displayed with amount '(.+)' accountNo '(.+)' transactionType '(.+)' the expected value for the group '(.+)'$")
    public void peekValueTest(String peekConsume, String certificateName, String password, String amount, String accountNo, String trxType, String groupID) throws Throwable {
        GenericUtils utils = new GenericUtils();
        String expectedResponse = EndPoint.WEBHOOK_MESSAGE.replaceAll(" ","");
        expectedResponse = utils.expectedValueTrim(expectedResponse,groupID,amount, accountNo,trxType).replaceAll("\\.00","");;
        verifyResponse(groupID, expectedResponse, peekConsume,certificateName,password);
    }

    @Then("^'(.*)' response should be displayed with amount '(.+)' accountNo '(.+)' transactionType '(.+)' currency '(.+)' BIC '(.+)' BAICode '(.+)' and ledger '(.*)' for the group '(.+)'$")
    public void verifypeekValueTest(String peekConsumeRecover, String amount, String accountNo, String trxType, String currency, String bic, String baiCode, String ledger, String groupID) throws Throwable {
        GenericUtils utils = new GenericUtils();
        String expectedResponse = EndPoint.WEBHOOK_MESSAGE.replaceAll(" ","");
        expectedResponse = utils.expectedValueTrimWithRandomTransaction(expectedResponse,groupID,amount, accountNo,trxType,currency,bic,ledger, baiCode).replaceAll("\\.00","");
        String certName = "bny-cert.pfx";
        String certPassword = "bny123";
        if(commonApiMethods.prop.getProperty(groupID+"_CertName")!=null) {
            certName = commonApiMethods.prop.getProperty(groupID + "_CertName");
            certPassword =commonApiMethods.prop.getProperty(groupID + "_CertPassword");
        }
        verifyResponse(groupID, expectedResponse, peekConsumeRecover.toLowerCase(),certName,certPassword);
    }

    public void verifyResponse(String groupID, String expectedResponse, String peekConsumeRecoverString, String certificate, String password) throws Throwable {
        PeekAndConsumeConfig peekAndConsumeConfig = new PeekAndConsumeConfig();
        activationKey activationKey1 = new activationKey();
        activationKey1.a_POST_request_is_made_to_the_activationKey_API_for_Group(groupID);
        activationKey1.generated_content_and_key_is_passed_to_the_create_token_method_for_the_group(groupID);
        //Thread.sleep(4000);

        String actualResponse = peekAndConsumeConfig.getPeekConsumeStringWithCertificate(ab.glue.api.activationKey.activKey.get(groupID), "peek",certificate,password).trim();
        //String actualResponse = peekAndConsumeConfig.getPeekConsumeResponseAsString(activationKey, "peek").trim();
        System.out.println(peekConsumeRecoverString+" response : "+actualResponse);
        //actualResponse = utils.peekConsumeTrim(actualResponse);
        System.out.println("actualResponse : "+actualResponse);
        System.out.println("expectedResponse : "+expectedResponse);
        Assert.assertTrue(peekConsumeRecoverString+" Response is not displayed as expected. Expected Response - " + expectedResponse + ". Actual Response - " + actualResponse,actualResponse.contains(expectedResponse));

    }

    /**
     * This method is used to hit the Peek api and verify the response with the expected response
     */
    @Then("^Peek response should be displayed with encrypted value for amount '(.+)' accountNo '(.+)' transactionType '(.+)' the expected value for the group '(.+)'$")
    public void peekValueEncryptedTest(String amount, String accountNo, String trxType, String groupID) throws Throwable {
        GenericUtils utils = new GenericUtils();
        //String expectedResponse = commonApiMethods.data.get(0).get("PeekResponse").toString().trim().replaceAll(" ","");
        expectResponse = EndPoint.WEBHOOK_MESSAGE.replaceAll(" ","");
        int counter = 1;
        if(amount.contains(",")){
            String[] trx = amount.split(",");
            counter = counter+trx.length;
        }
        expectResponse = utils.expectedValueTrim(expectResponse,groupID,amount, accountNo,trxType);
        activationKey activationKey1 = new activationKey();
        activationKey1.generated_content_and_key_is_passed_to_the_create_token_method_for_the_group(groupID);
        activationKey1.user_has_already_generated_the_JWT_token_for_the_group(groupID);
        PeekAndConsumeConfig peekAndConsumeConfig = new PeekAndConsumeConfig();
        response = peekAndConsumeConfig.getPeekConsumeResponseAsEncryptedString(ab.glue.api.activationKey.activKey.get(groupID), "peek").trim();
        System.out.println("Peek response is : "+response);
        Assert.assertFalse("Peek Response is not displayed as encrypted content. Actual Response - "  + response, expectResponse.equals(response));
        Assert.assertTrue("Peek Response is not displayed as encrypted content. Actual Response - "  + response,response.contains("\"content\"")&&response.contains("\"key\""));
        Assert.assertFalse("Peek Response is displayed as empty response when trying to get encrypted content",response.equals(""));

    }

@Then("^The messages should be decrypted as expected when using privateKey of group '(.+)' for '(.+)'$")
    public void verifyDecryptedValueGivesActualContent(String privateKey,String pull) throws NoSuchPaddingException, NoSuchAlgorithmException, IOException {
    String content = response.split("\"content\":\"")[1].split("\"")[0];
    String key = response.split("\"key\":\"")[1].split("\"")[0];
    common.EncryptDecrypt encryptDecrypt = new common.EncryptDecrypt();
    PrivateKey privatekey = encryptDecrypt.convertStringToPrivateKey(commonApiMethods.prop.getProperty(privateKey + "_PrivateKey"));
    response = encryptDecrypt.decryptWithPrivateKey(privatekey, new EncryptDecrypt.EncryptedContent(content, key));
    System.out.println("Peek response : " + response);
    GenericUtils utils = new GenericUtils();
    // response = utils.peekConsumeTrim(response);
    System.out.println("actualResponse : "+response);
    System.out.println("expectedResponse : "+expectResponse);
    if(pull.equals("recover"))
        Assert.assertTrue("Decrypted Response is not displayed as expected. Expected Response - " + expectResponse + ". Actual Response - " + response, response.contains(expectResponse));
    else
        Assert.assertTrue("Decrypted Response is not displayed as expected. Expected Response - " + expectResponse + ". Actual Response - " + response, response.contains(expectResponse));

}

    @Then("^The messages should not be decrypted as expected when using privateKey of group '(.+)' for '(.+)'$")
    public void verifyMessageNotDecrptedForWrongPrivateKey(String privateKey, String pull) throws NoSuchPaddingException, NoSuchAlgorithmException, IOException {
     try{
        String content = response.split("content\":\"")[1].split("\"")[0];
        String key = response.split("key\":\"")[1].split("\"")[0];
        common.EncryptDecrypt encryptDecrypt = new common.EncryptDecrypt();
        PrivateKey privatekey = encryptDecrypt.convertStringToPrivateKey(commonApiMethods.prop.getProperty(privateKey + "_PrivateKey"));
        response = encryptDecrypt.decryptWithPrivateKey(privatekey, new EncryptDecrypt.EncryptedContent(content, key));
        System.out.println("Peek response : " + response);
        GenericUtils utils = new GenericUtils();
        response = utils.peekConsumeTrim(response);
        System.out.println("actualResponse : " + response);
        System.out.println("expectedResponse : " + expectResponse);
        if (pull.equals("recover"))
            Assert.assertFalse("Able to decrypt message with different private key- " + privateKey, expectResponse.contains(response));
        else
            Assert.assertFalse("Able to decrypt message with different private key- " + privateKey, expectResponse.equals(response));
    }catch(java.lang.RuntimeException e){
            System.out.println("Could not decrypt with different private key");
        }
    }


    /**
     * This method is used to hit the Consume api and verify the response with the expected response
     */
    @Then("^Consume response should be displayed with amount '(.+)' accountNo '(.+)' transactionType '(.+)' the expected value for the group '(.+)'$")
    public void consumeValueTest(String amount, String accountNo, String trxType, String groupID) throws Throwable {
        GenericUtils utils = new GenericUtils();
        String expectedResponse = EndPoint.WEBHOOK_MESSAGE.trim().replaceAll(" ","");
        expectedResponse = utils.expectedValueTrim(expectedResponse,groupID,amount, accountNo,trxType).replaceAll("\\.00","");
        activationKey activationKey1 = new activationKey();
        //Thread.sleep(1000);
        activationKey1.generated_content_and_key_is_passed_to_the_create_token_method_for_the_group(groupID);
        PeekAndConsumeConfig peekAndConsumeConfig = new PeekAndConsumeConfig();
        System.out.println("The token confirmation is "+ab.glue.api.activationKey.activKey.get(groupID));
        String actualResponse = peekAndConsumeConfig.getPeekConsumeResponseAsString(ab.glue.api.activationKey.activKey.get(groupID), "consume").trim();
        System.out.println("Consume response : "+actualResponse);
        //actualResponse = utils.peekConsumeTrim(actualResponse);
        Assert.assertTrue("Consume Response is not displayed as expected. Expected Response - " + expectedResponse + ". Actual Response - " + actualResponse, actualResponse.contains(expectedResponse));
        //Assert.assertTrue("Consume Response is not displayed as expected. Expected Response - " + expectedResponse + ". Actual Response - " + actualResponse, actualResponse.startsWith("[{\"groupId\":\""+groupID+"\""));
    }

    /**
     * This method is used to hit the Peek api and verify the response with the expected response
     */
    @Then("^Consume response should be displayed with encrypted value for amount '(.+)' accountNo '(.+)' transactionType '(.+)' the expected value for the group '(.+)'$")
    public void consumeValueEncryptedTest(String amount, String accountNo, String trxType, String groupID) throws Throwable {
        GenericUtils utils = new GenericUtils();
        //String expectedResponse = commonApiMethods.data.get(0).get("PeekResponse").toString().trim().replaceAll(" ","");
        String expectedResponse = EndPoint.WEBHOOK_MESSAGE.replaceAll(" ","");
        int counter = 1;
        if(amount.contains(",")){
            String[] trx = amount.split(",");
            counter = counter+trx.length;
        }
        expectedResponse = utils.expectedValueTrim(expectedResponse,groupID,amount, accountNo,trxType).replaceAll("\\.00","");
        activationKey activationKey1 = new activationKey();
        activationKey1.a_POST_request_is_made_to_the_activationKey_API_for_Group(groupID);
        activationKey1.generated_content_and_key_is_passed_to_the_create_token_method_for_the_group(groupID);
        PeekAndConsumeConfig peekAndConsumeConfig = new PeekAndConsumeConfig();
        String actualResponse = peekAndConsumeConfig.getPeekConsumeResponseAsEncryptedString(ab.glue.api.activationKey.activKey.get(groupID), "consume").trim();
        System.out.println("Consume response : "+actualResponse);
        response = actualResponse;
        Assert.assertFalse("Consume Response is not displayed as encrypted content. Actual Response - "  + actualResponse, expectedResponse.equals(actualResponse));
        Assert.assertTrue("Consume Response is not displayed as encrypted content. Actual Response - "  + response,response.contains("\"content\"")&&response.contains("\"key\""));
        Assert.assertFalse("Consume Response is displayed as empty response when trying to get encrypted content",response.equals(""));
    }


    /**
     * This method is used to hit the Recover api and verify the response with the expected response
     */
    @Then("^Recover response should be displayed with amount '(.+)' accountNo '(.+)' transactionType '(.+)' the expected value for the group '(.+)'$")
    public void recoverValueTest(String amount, String accountNo, String trxType, String groupID) throws Throwable {
        GenericUtils utils = new GenericUtils();
        String expectedResponse = EndPoint.WEBHOOK_MESSAGE.trim().replaceAll(" ","");
        expectedResponse = utils.expectedValueTrim(expectedResponse,groupID,amount, accountNo,trxType).replaceAll("\\.00","");
        activationKey activationKey1 = new activationKey();
        activationKey1.a_POST_request_is_made_to_the_activationKey_API_for_Group(groupID);
        activationKey1.generated_content_and_key_is_passed_to_the_create_token_method_for_the_group(groupID);
        PeekAndConsumeConfig peekAndConsumeConfig = new PeekAndConsumeConfig();
        //Thread.sleep(1000);
        String actualResponse = peekAndConsumeConfig.getPeekConsumeResponseAsString(ab.glue.api.activationKey.activKey.get(groupID), "recover").trim();
        System.out.println("Recover response : "+actualResponse);
        // actualResponse = utils.peekConsumeTrim(actualResponse);
        Assert.assertTrue("Recover Response is not displayed as expected. Expected Response - " + expectedResponse + ". Actual Response - " + actualResponse, actualResponse.contains(expectedResponse));
    }

    /**
     * This method is used to hit the Peek api and verify the response with the expected response
     */
    @Then("^Recover response should be displayed with encrypted value for amount '(.+)' accountNo '(.+)' transactionType '(.+)' the expected value for the group '(.+)'$")
    public void recoverValueEncryptedTest(String amount, String accountNo, String trxType, String groupID) throws Throwable {
        GenericUtils utils = new GenericUtils();
        //String expectedResponse = commonApiMethods.data.get(0).get("PeekResponse").toString().trim().replaceAll(" ","");
        String expectedResponse = EndPoint.WEBHOOK_MESSAGE.replaceAll(" ","");
        int counter = 1;
        if(amount.contains(",")){
            String[] trx = amount.split(",");
            counter = counter+trx.length;
        }
        expectedResponse = utils.expectedValueTrim(expectedResponse,groupID,amount, accountNo,trxType).replace("\\.00","");
        activationKey activationKey1 = new activationKey();
        activationKey1.a_POST_request_is_made_to_the_activationKey_API_for_Group(groupID);
        activationKey1.generated_content_and_key_is_passed_to_the_create_token_method_for_the_group(groupID);
        PeekAndConsumeConfig peekAndConsumeConfig = new PeekAndConsumeConfig();
        String actualResponse = peekAndConsumeConfig.getPeekConsumeResponseAsEncryptedString(ab.glue.api.activationKey.activKey.get(groupID), "recover").trim();
        System.out.println("Recover response : "+actualResponse);
        response = actualResponse;
        Assert.assertFalse("Recover Response is not displayed as encrypted content. Actual Response - "  + actualResponse, actualResponse.contains(expectedResponse));
        Assert.assertTrue("Recover Response is not displayed as encrypted content. Actual Response - "  + response,response.contains("\"content\"")&&response.contains("\"key\""));
        Assert.assertFalse("Recover Response is displayed as empty response when trying to get encrypted content",response.equals(""));
    }

    /**
     * This method is used to hit the Consume api and verify the response with the expected response
     */
    @Then("^Consume response should be displayed with the expected value$")
    public void consumeTest() {
        GenericUtils utils = new GenericUtils();
        String expectedResponse = EndPoint.WEBHOOK_MESSAGE.trim().replaceAll(" ","");
        expectedResponse = utils.peekConsumeTrim(expectedResponse);
        PeekAndConsumeConfig peekAndConsumeConfig = new PeekAndConsumeConfig();
        String actualResponse = peekAndConsumeConfig.getPeekConsumeResponseAsString(activationKey, "consume").trim().replaceAll(" ","");
        System.out.println("Consume response : "+actualResponse);
        actualResponse = utils.peekConsumeTrim(actualResponse);
        Assert.assertTrue("Consume Response is not displayed as expected. Expected Response - " + expectedResponse + ". Actual Response - " + actualResponse,expectedResponse.equals(actualResponse));
    }

    /**
     * This method is used to hit the Recover api and verify the response with the expected response
     */
    @Then("^Recover response should be displayed with the expected value$")
    public void recoverTest() {
        GenericUtils utils = new GenericUtils();
        String expectedResponse = EndPoint.WEBHOOK_MESSAGE.trim().replaceAll(" ","");
        expectedResponse = utils.peekConsumeTrim(expectedResponse);
        PeekAndConsumeConfig peekAndConsumeConfig = new PeekAndConsumeConfig();
        String actualResponse = peekAndConsumeConfig.getPeekConsumeResponseAsString(activationKey, "recover").trim().replaceAll(" ","");
        System.out.println("Recover response : "+actualResponse);
        actualResponse = utils.peekConsumeTrim(actualResponse);
        Assert.assertTrue("Recover Response is not displayed as expected. Expected Response - " + expectedResponse + ". Actual Response - " + actualResponse,actualResponse.startsWith(expectedResponse));
    }

    /**
     * This method is used to hit the Peek api and verify the response with the expected response
     */
    @Then("^Peek response should be displayed with the empty message for the group '(.+)'$")
    public void peekEmptyTest(String group) throws Throwable {
        PeekAndConsumeConfig peekAndConsumeConfig = new PeekAndConsumeConfig();
        activationKey activationKey1 = new activationKey();
        activationKey1.generated_content_and_key_is_passed_to_the_create_token_method_for_the_group(group);
        String actualResponse = peekAndConsumeConfig.getPeekConsumeResponseAsString(ab.glue.api.activationKey.activKey.get(group), "peek");
        System.out.println("Peek response : "+actualResponse);
        Assert.assertTrue("Peek Response is not displayed as expected. Expected Response - {\"messageId\":\"\",\"content\":[]}. Actual Response - " + actualResponse,"{\"messageId\":\"\",\"content\":[]}".equals(actualResponse));
    }

    /**
     * This method is used to hit the Peek api and verify the response with the expected response
     */
    @Then("^Peek response should be displayed with the deactivate error message for the group '(.+)'$")
    public void verifyDeactivateErrorMessageForPeek(String group) throws Throwable {
        ProxySpecification proxySpecification = new ProxySpecification("10.65.128.43",8080,"HTTP");
        RestAssured.proxy(proxySpecification);
        PeekAndConsumeConfig peekAndConsumeConfig = new PeekAndConsumeConfig();
        activationKey activationKey1 = new activationKey();
        activationKey1.a_POST_request_is_made_to_the_activationKey_API_for_Group(group);
        activationKey1.generated_content_and_key_is_passed_to_the_create_token_method_for_the_group(group);
        String actualResponse = peekAndConsumeConfig.getPeekConsumeResponseAsString(ab.glue.api.activationKey.activKey.get(group), "peek");
        System.out.println("Peek response : "+actualResponse);
        String expectedResponse = commonApiMethods.errorMessageProperties.getProperty("DisabledErrorMessage");
        Assert.assertTrue("Peek Response is not displayed as expected. Expected Response - "+expectedResponse+". Actual Response - " + actualResponse,expectedResponse.equals(actualResponse));
    }



    /**
     * This method is used to hit the Peek api and verify the response with the expected response
     */
    @Then("^Peek response should be displayed with the token not authenticated error message for the group '(.+)'$")
    public void verifyNotAuthenticatedErrorMessageForPeek(String group) throws Throwable {
        PeekAndConsumeConfig peekAndConsumeConfig = new PeekAndConsumeConfig();
        activationKey activationKey1 = new activationKey();
        activationKey1.a_POST_request_is_made_to_the_activationKey_API_for_Group(group);
        activationKey1.generated_content_and_key_is_passed_to_the_create_token_method_for_the_group(group);
        String actualResponse = peekAndConsumeConfig.getPeekConsumeResponseAsString(ab.glue.api.activationKey.activKey.get(group), "peek");
        System.out.println("Peek response : "+actualResponse);
        Assert.assertTrue("Peek Response is not displayed as expected. Expected Response - {\"errorCode\": \"403\", \"errorMessage\" : \"Failed to authenticate JWT token.\" }. Actual Response - " + actualResponse,"{\"errorCode\": \"403\", \"errorMessage\" : \"Failed to authenticate JWT token.\" }".equals(actualResponse));
    }

    /**
     * This method is used to hit the Peek api and verify the response with the expected response
     */
    @Then("^Consume response should be displayed with the token not authenticated error message for the group '(.+)'$")
    public void verifyNotAuthenticatedErrorMessageForConsume(String group) throws Throwable {
        PeekAndConsumeConfig peekAndConsumeConfig = new PeekAndConsumeConfig();
        activationKey activationKey1 = new activationKey();
        activationKey1.a_POST_request_is_made_to_the_activationKey_API_for_Group(group);
        activationKey1.generated_content_and_key_is_passed_to_the_create_token_method_for_the_group(group);
        String actualResponse = peekAndConsumeConfig.getPeekConsumeResponseAsString(ab.glue.api.activationKey.activKey.get(group), "consume");
        System.out.println("Peek response : "+actualResponse);
        Assert.assertTrue("Peek Response is not displayed as expected. Expected Response - {\"errorCode\": \"403\", \"errorMessage\" : \"Failed to authenticate JWT token.\" }. Actual Response - " + actualResponse,"{\"errorCode\": \"403\", \"errorMessage\" : \"Failed to authenticate JWT token.\" }".equals(actualResponse));
    }
    /**
     * This method is used to hit the Peek api and verify the response with the expected response
     */
    @Then("^Recover response should be displayed with the token not authenticated error message for the group '(.+)'$")
    public void verifyNotAuthenticatedErrorMessageForRecover(String group) throws Throwable {
        PeekAndConsumeConfig peekAndConsumeConfig = new PeekAndConsumeConfig();
        activationKey activationKey1 = new activationKey();
        activationKey1.a_POST_request_is_made_to_the_activationKey_API_for_Group(group);
        activationKey1.generated_content_and_key_is_passed_to_the_create_token_method_for_the_group(group);
        String actualResponse = peekAndConsumeConfig.getPeekConsumeResponseAsString(ab.glue.api.activationKey.activKey.get(group), "recover");
        System.out.println("Peek response : "+actualResponse);
        Assert.assertTrue("Peek Response is not displayed as expected. Expected Response - {\"errorCode\": \"403\", \"errorMessage\" : \"Failed to authenticate JWT token.\" }. Actual Response - " + actualResponse,"{\"errorCode\": \"403\", \"errorMessage\" : \"Failed to authenticate JWT token.\" }".equals(actualResponse));
    }

    /**
     * This method is used to hit the Peek api and store the status and string in variable
     */
    @When("^a '(.*)' request is made for the group '(.*)'$")
    public void hitPeekConsumeRecoverWithoutVerification(String methodName, String group) throws Throwable {
        //Thread.sleep(5000);
        PeekAndConsumeConfig peekAndConsumeConfig = new PeekAndConsumeConfig();
        Response actualResponse = peekAndConsumeConfig.getPeekConsumeResponse(ab.glue.api.activationKey.activKey.get(group), methodName.toLowerCase());
        peekConsumeRecoverStatus =actualResponse.getStatusCode();
        peekConsumeRecoverString = actualResponse.thenReturn().asString();
        System.out.println(methodName+"response : "+peekConsumeRecoverString);
    }

    /**
     * This method is used to hit the Peek api and store the status and string in variable
     */
    @Then("^'(.*)' request made for the group '(.*)' for '(.+)' times should always return a response status code as '(.+)'$")
    public void hitPeekConsumeRecoverMultipleTimesAndVerifyStatus(String methodName, String group,int numberOfTimes, int statuCode  ) throws Throwable {

        PeekAndConsumeConfig peekAndConsumeConfig = new PeekAndConsumeConfig();
        Response actualResponse = peekAndConsumeConfig.getPeekConsumeResponse(ab.glue.api.activationKey.activKey.get(group), methodName.toLowerCase());
        peekConsumeRecoverStatus =actualResponse.getStatusCode();
        peekConsumeRecoverString = actualResponse.thenReturn().asString();
        System.out.println(methodName+"response : "+peekConsumeRecoverString);
        Assert.assertTrue("Expected status code - "+statuCode+". Actual Status code - "+peekConsumeRecoverStatus,statuCode==peekConsumeRecoverStatus);
    }

    @Then("'(.*)' response should contain '(.*)' with status code as '(.*)'")
    public void verifyResponseStringAndStatus(String methodName, String expectResponse, int expectedStatusCode){
        Assert.assertTrue("The "+methodName+" response is not displayed as expected. Expected "+expectResponse+".Actual - "+peekConsumeRecoverString,peekConsumeRecoverString.contains(expectResponse));
        Assert.assertTrue("The "+methodName+" response is not displayed with expected status code - Expected "+expectedStatusCode+". Actual - "+peekConsumeRecoverStatus,expectedStatusCode==peekConsumeRecoverStatus);
    }

    @Then("^The response should be displayed with the details$")
    public void assertValuesWithXpath(DataTable dataTable) throws ParserConfigurationException, SAXException, XPathExpressionException, IOException {
        Map<String, Object> flattenJson = JsonFlattener.flattenAsMap(peekConsumeRecoverString);
        List<List<String>> rows = dataTable.asLists(String.class);
        boolean first = true;
        for(List<String> row : rows) {
            if (first) {
                first = false;
                continue;
            }
            String xpath = row.get(0);
            String expectedValue = row.get(1);
            String actualValue = flattenJson.get(row.get(0)).toString();
            Assert.assertTrue("Expected - "+expectedValue+". Actual Value - "+actualValue,expectedValue.equals(actualValue));
        }
    }
    /**
     * This method is used to hit the Consume api and verify the response with the expected response
     */
    @Then("^Consume response should be displayed with the empty message for the group '(.+)'$")
    public void consumeEmptyTest(String group) throws Throwable {
        PeekAndConsumeConfig peekAndConsumeConfig = new PeekAndConsumeConfig();
        activationKey activationKey1 = new activationKey();
        activationKey1.a_POST_request_is_made_to_the_activationKey_API_for_Group(group);
        activationKey1.generated_content_and_key_is_passed_to_the_create_token_method_for_the_group(group);
        String actualResponse = peekAndConsumeConfig.getPeekConsumeResponseAsString(ab.glue.api.activationKey.activKey.get(group), "consume");
        System.out.println("Consume response : "+actualResponse);
        Assert.assertTrue("Consume Response is not displayed as expected. Expected Response - {\"messageId\":\"\",\"content\":[]}. Actual Response - " + actualResponse,"{\"messageId\":\"\",\"content\":[]}".equals(actualResponse));
    }

    /**
     * This method is used to hit the Consume api and verify the response with the expected response
     */
    @Then("^Consume response should be displayed with the deactivate error message for the group '(.+)'$")
    public void verifyDeactivateErrorMessageForConsume(String group) throws Throwable {
        PeekAndConsumeConfig peekAndConsumeConfig = new PeekAndConsumeConfig();
        activationKey activationKey1 = new activationKey();
        activationKey1.a_POST_request_is_made_to_the_activationKey_API_for_Group(group);
        activationKey1.generated_content_and_key_is_passed_to_the_create_token_method_for_the_group(group);
        String actualResponse = peekAndConsumeConfig.getPeekConsumeResponseAsString(ab.glue.api.activationKey.activKey.get(group), "consume");
        System.out.println("Consume response : "+actualResponse);
        String expectedResponse = commonApiMethods.errorMessageProperties.getProperty("DisabledErrorMessage");
        Assert.assertTrue("Consume Response is not displayed as expected. Expected Response - "+expectedResponse+". Actual Response - " + actualResponse,expectedResponse.equals(actualResponse));
    }

    /**
     * This method is used to hit the Consume api and verify the response with the expected response
     */
    @Then("^Recover response should be displayed with the empty message for the group '(.+)'$")
    public void recoverEmptyTest(String group) throws Throwable {
        PeekAndConsumeConfig peekAndConsumeConfig = new PeekAndConsumeConfig();
        activationKey activationKey1 = new activationKey();
        activationKey1.a_POST_request_is_made_to_the_activationKey_API_for_Group(group);
        activationKey1.generated_content_and_key_is_passed_to_the_create_token_method_for_the_group(group);
        String actualResponse = peekAndConsumeConfig.getPeekConsumeResponseAsString(ab.glue.api.activationKey.activKey.get(group), "recover");
        System.out.println("Recover response : "+actualResponse);
        Assert.assertTrue("Recover Response is not displayed as expected. Expected Response - {\"messageId\":\"\",\"content\":[]}. Actual Response - " + actualResponse,"{\"messageId\":\"\",\"content\":[]}".equals(actualResponse));
    }


    /**
     * This method is used to hit the Consume api and verify the response with the expected response
     */
    @Then("^Recover response should be displayed with the deactivate error message for the group '(.+)'$")
    public void verifyDeactivateErrorMessageForRecover(String group) throws Throwable {
        PeekAndConsumeConfig peekAndConsumeConfig = new PeekAndConsumeConfig();
        activationKey activationKey1 = new activationKey();
        activationKey1.a_POST_request_is_made_to_the_activationKey_API_for_Group(group);
        activationKey1.generated_content_and_key_is_passed_to_the_create_token_method_for_the_group(group);
        String actualResponse = peekAndConsumeConfig.getPeekConsumeResponseAsString(ab.glue.api.activationKey.activKey.get(group), "recover");
        System.out.println("Recover response : "+actualResponse);
        String expectedResponse = commonApiMethods.errorMessageProperties.getProperty("DisabledErrorMessage");
        Assert.assertTrue("Recover Response is not displayed as expected. Expected Response - "+expectedResponse+". Actual Response - " + actualResponse,expectedResponse.equals(actualResponse));
    }

    /**
     * This method is used to hit the Consume api and verify the response with the expected response
     */
    @Then("^I consume all the previous messages for the group '(.*)'$")
    public void consumePreviousMessages(String group) throws Throwable {
        //Thread.sleep(5000);
        PeekAndConsumeConfig peekAndConsumeConfig = new PeekAndConsumeConfig();
        activationKey activationKey1 = new activationKey();
        activationKey1.a_POST_request_is_made_to_the_activationKey_API_for_Group(group);
        activationKey1.generated_content_and_key_is_passed_to_the_create_token_method_for_the_group(group);
        consumedResponse = peekAndConsumeConfig.getPeekConsumeResponseAsString(ab.glue.api.activationKey.activKey.get(group), "consume");
        System.out.println("Consumed the messages : "+consumedResponse);
    }

    /**
     * This method is used to hit the Consume api and verify the response with the expected response
     */
    @Then("^I consume all previous messages for the group '(.*)' with certificate '(.*)' and password '(.*)'$")
    public void consumePreviousMessagesOfGroupWithDifferentCert(String group,String certificate,String password) throws Throwable {
        //Thread.sleep(5000);
        PeekAndConsumeConfig peekAndConsumeConfig = new PeekAndConsumeConfig();
        activationKey activationKey1 = new activationKey();
        activationKey1.a_POST_request_is_made_to_the_activationKey_API_for_Group(group);
        activationKey1.generated_content_and_key_is_passed_to_the_create_token_method_for_the_group(group);
        consumedResponse = peekAndConsumeConfig.getPeekConsumeStringWithCertificate(ab.glue.api.activationKey.activKey.get(group), "consume",certificate,password);
        System.out.println("Consumed the messages : "+consumedResponse);
    }


    /**
     * This method will verify all the consumed messages are recovered
     */
    @Then("The recover response should be displayed with all the consumed messages for the group '(.*)'")
    public void verifyAllConsumedMessagesAreRecovered(String group) throws Throwable {
        PeekAndConsumeConfig peekAndConsumeConfig = new PeekAndConsumeConfig();
        activationKey activationKey1 = new activationKey();
        activationKey1.a_POST_request_is_made_to_the_activationKey_API_for_Group(group);
        activationKey1.generated_content_and_key_is_passed_to_the_create_token_method_for_the_group(group);
        String recoveredMessages = peekAndConsumeConfig.getPeekConsumeResponseAsString(ab.glue.api.activationKey.activKey.get(group), "recover");
        System.out.println("Recovered the messages : "+recoveredMessages);
        Assert.assertTrue("The recover response does not match consumed response. Recover response - "+recoveredMessages+". Consume response - "+consumedResponse,recoveredMessages.equals(consumedResponse));
    }

    /**
     *
     * @param groupID - Group ID for which the token should be generated to hit the Consume API
     * @throws Throwable
     */
    @Then("^Consume response should be displayed with '(.*)' transactions for the group '(.+)'$")
    public void consumeNumberTest(int count, String groupID) throws Throwable {
        GenericUtils utils = new GenericUtils();
        activationKey activationKey1 = new activationKey();
        //Thread.sleep(1000);
        activationKey1.a_POST_request_is_made_to_the_activationKey_API_for_Group(groupID);
        activationKey1.generated_content_and_key_is_passed_to_the_create_token_method_for_the_group(groupID);
        PeekAndConsumeConfig peekAndConsumeConfig = new PeekAndConsumeConfig();
        System.out.println("The token confirmation is "+ab.glue.api.activationKey.activKey.get(groupID));
        Response response = peekAndConsumeConfig.getPeekConsumeResponse(ab.glue.api.activationKey.activKey.get(groupID), "consume");
        String actualResponse = response.thenReturn().asString();
        int status = response.getStatusCode();
        System.out.println("Consume response : "+actualResponse);
        int numberOfTransactions = utils.verifyNumberOfTransactions(actualResponse,groupID);
        System.out.println("Expected no of transactions for Consume response - "+count);
        System.out.println(". Actual number of transactions for Consume response - "+numberOfTransactions);
        Assert.assertTrue("The status code should be displayed as 200. But it is displayed as "+status,status==200);
        Assert.assertTrue("Expected no of transactions - "+count+". Actual number of transactions - "+numberOfTransactions, numberOfTransactions==count);
        //Assert.assertTrue("Consume Response is not displayed as expected. Expected Response - " + expectedResponse + ". Actual Response - " + actualResponse, actualResponse.startsWith("[{\"groupId\":\""+groupID+"\""));
    }

    /**
     *
     * @param groupID - Group ID for which the token should be generated to hit the Consume API
     * @throws Throwable
     */
    @Then("^Peek response should be displayed with '(.*)' transactions for the group '(.+)'$")
    public void peekNumberTest(int count, String groupID) throws Throwable {
        GenericUtils utils = new GenericUtils();
        activationKey activationKey1 = new activationKey();
        //Thread.sleep(1000);
        activationKey1.a_POST_request_is_made_to_the_activationKey_API_for_Group(groupID);
        activationKey1.generated_content_and_key_is_passed_to_the_create_token_method_for_the_group(groupID);
        PeekAndConsumeConfig peekAndConsumeConfig = new PeekAndConsumeConfig();
        System.out.println("The token confirmation is "+ab.glue.api.activationKey.activKey.get(groupID));
        String actualResponse = peekAndConsumeConfig.getPeekConsumeResponseAsString(ab.glue.api.activationKey.activKey.get(groupID), "peek").trim();
        System.out.println("Peek response : "+actualResponse);
        int numberOfTransactions = utils.verifyNumberOfTransactions(actualResponse,groupID);
        System.out.println("Expected no of transactions for Peek response - "+count);
        System.out.println("Actual number of transactions for Peek response - "+numberOfTransactions);
        Assert.assertTrue("Expected no of transactions - "+count+". Actual number of transactions - "+numberOfTransactions, numberOfTransactions==count);
        //Assert.assertTrue("Consume Response is not displayed as expected. Expected Response - " + expectedResponse + ". Actual Response - " + actualResponse, actualResponse.contains(expectedResponse));
        //Assert.assertTrue("Consume Response is not displayed as expected. Expected Response - " + expectedResponse + ". Actual Response - " + actualResponse, actualResponse.startsWith("[{\"groupId\":\""+groupID+"\""));
    }

    /**
     *
     * @param groupID - Group ID for which the token should be generated to hit the Consume API
     * @throws Throwable
     */
    @Then("^Recover response should be displayed with '(.*)' transactions for the group '(.+)'$")
    public void recoverNumberTest(int count, String groupID) throws Throwable {
        GenericUtils utils = new GenericUtils();
        activationKey activationKey1 = new activationKey();
        //Thread.sleep(1000);
        activationKey1.a_POST_request_is_made_to_the_activationKey_API_for_Group(groupID);
        activationKey1.generated_content_and_key_is_passed_to_the_create_token_method_for_the_group(groupID);
        PeekAndConsumeConfig peekAndConsumeConfig = new PeekAndConsumeConfig();
        System.out.println("The token confirmation is "+ab.glue.api.activationKey.activKey.get(groupID));
        String actualResponse = peekAndConsumeConfig.getPeekConsumeResponseAsString(ab.glue.api.activationKey.activKey.get(groupID), "recover").trim();
        System.out.println("Recover response : "+actualResponse);
        int numberOfTransactions = utils.verifyNumberOfTransactions(actualResponse,groupID);
        System.out.println("Expected no of transactions for Recover response - "+count);
        System.out.println("Actual number of transactions for Recover response - "+numberOfTransactions);
        Assert.assertTrue("Expected no of transactions - "+count+". Actual number of transactions - "+numberOfTransactions, numberOfTransactions==count);
        //Assert.assertTrue("Consume Response is not displayed as expected. Expected Response - " + expectedResponse + ". Actual Response - " + actualResponse, actualResponse.contains(expectedResponse));
        //Assert.assertTrue("Consume Response is not displayed as expected. Expected Response - " + expectedResponse + ". Actual Response - " + actualResponse, actualResponse.startsWith("[{\"groupId\":\""+groupID+"\""));
    }

    /**
     * This method will verify the Depth API's count and id
     * @param groupID - Group ID for which the token should be generated to hit the Consume API
     * @throws Throwable
     */
    @Then("^Depth response should be displayed with '(.*)' transactions for the group '(.+)'$")
    public void DepthNumberTest(int count, String groupID) throws Throwable {
        GenericUtils utils = new GenericUtils();
        activationKey activationKey1 = new activationKey();
        //Thread.sleep(1000);
        activationKey1.a_POST_request_is_made_to_the_activationKey_API_for_Group(groupID);
        activationKey1.generated_content_and_key_is_passed_to_the_create_token_method_for_the_group(groupID);
        PeekAndConsumeConfig peekAndConsumeConfig = new PeekAndConsumeConfig();
        System.out.println("The token confirmation is "+ab.glue.api.activationKey.activKey.get(groupID));
        String actualResponse = peekAndConsumeConfig.getPeekConsumeResponseAsString(ab.glue.api.activationKey.activKey.get(groupID), "statistics").trim();
        System.out.println("Peek response : "+actualResponse);
        int numberOfTransactions = utils.verifyNumberOfTransactions(actualResponse,groupID);
        System.out.println("Expected no of transactions for Peek response - "+count);
        System.out.println("Actual number of transactions for Peek response - "+numberOfTransactions);
        Assert.assertTrue("Expected no of transactions - "+count+". Actual number of transactions - "+numberOfTransactions, numberOfTransactions==count);
        //Assert.assertTrue("Consume Response is not displayed as expected. Expected Response - " + expectedResponse + ". Actual Response - " + actualResponse, actualResponse.contains(expectedResponse));
        //Assert.assertTrue("Consume Response is not displayed as expected. Expected Response - " + expectedResponse + ". Actual Response - " + actualResponse, actualResponse.startsWith("[{\"groupId\":\""+groupID+"\""));
    }


    /**
     *
     * @param groupID - Group ID for which the token should be generated to hit the Consume API
     * @throws Throwable
     */
    @Then("^Consume POST API response should be displayed for the group '(.*)' with '(.*)' messages when called with batchsize '(.*)', certificate '(.*)' and password '(.*)'$")
    public void consumePOSTAPI(String groupID, int expectedNoOfMessages, int batchSize,String certificate, String password) throws Throwable {
        GenericUtils utils = new GenericUtils();
        activationKey activationKey1 = new activationKey();
        //Thread.sleep(1000);
        activationKey1.a_POST_request_is_made_to_the_activationKey_API_for_Group(groupID);
        activationKey1.generateTokenWithBatchSize(groupID,batchSize);
        PeekAndConsumeConfig peekAndConsumeConfig = new PeekAndConsumeConfig();
        System.out.println("The token confirmation is "+ab.glue.api.activationKey.activKey.get(groupID));
        Map<String, String> headers = new HashMap<String, String>();

        //headers.put("JWTToken",ab.glue.api.activationKey.activKey.get(groupID));
        //String requestBody = "{\"batchSize\" : \"0\", \"JWTToken\" :\""+ab.glue.api.activationKey.activKey.get(groupID)+"\"}";
        //String actualResponse = peekAndConsumeConfig.getConsumePOSTAPIResponse(headers,requestBody , "consume").thenReturn().asString();
        String actualResponse = peekAndConsumeConfig.getConsumePOSTAPIResponse(headers,ab.glue.api.activationKey.activKey.get(groupID) , "consume",certificate,password).thenReturn().asString();
        System.out.println("Consume POST response : "+actualResponse);
        int numberOfTransactions = utils.verifyNumberOfTransactions(actualResponse,groupID);
        if(expectedNoOfMessages==0)
        Assert.assertTrue("Expected response - {\"messageId\":\"\",\"content\":[]}. Actual response - "+actualResponse,actualResponse.equals("{\"messageId\":\"\",\"content\":[]}"));
        Assert.assertTrue("Posted transactions = "+expectedNoOfMessages+". Actual Transactions displayed - "+numberOfTransactions,expectedNoOfMessages==numberOfTransactions);
       }

    /**
     * This method is used to hit the Consume api and verify the response with the expected response
     */
    @Then("^Consume POST API response should be displayed with amount '(.+)' accountNo '(.+)' transactionType '(.+)' the expected value for the group '(.+)' when called with certificate '(.*)' and password as '(.*)'$")
    public void consumePOSTAPIValueTest(String amount, String accountNo, String trxType, String groupID, String certificate, String password) throws Throwable {
        GenericUtils utils = new GenericUtils();
        String expectedResponse = EndPoint.WEBHOOK_MESSAGE.trim().replaceAll(" ","");
        expectedResponse = utils.expectedValueTrim(expectedResponse,groupID,amount, accountNo,trxType).replaceAll("\\.00","");
        activationKey activationKey1 = new activationKey();
        activationKey1.generateTokenWithBatchSize(groupID,1);
        PeekAndConsumeConfig peekAndConsumeConfig = new PeekAndConsumeConfig();
        Map<String,String> headersMap = new HashMap<String, String>();
        System.out.println("The token confirmation is "+ab.glue.api.activationKey.activKey.get(groupID));
        String actualResponse = peekAndConsumeConfig.getConsumePOSTAPIResponse(headersMap,ab.glue.api.activationKey.activKey.get(groupID), "consume",certificate,password).thenReturn().asString();
        System.out.println("Consume response : "+actualResponse);
        Assert.assertTrue("Consume Response is not displayed as expected. Expected Response - " + expectedResponse + ". Actual Response - " + actualResponse, actualResponse.contains(expectedResponse));
    }

    /**
     * This method is used to hit the Consume api and verify the response with the expected response
     */
    @Then("^the user hits '(.*)' with '(.*)' value for the group '(.*)'$")
    public void hitAPI(String apiName, String value, String groupID ) throws Throwable {
        GenericUtils utils = new GenericUtils();
        activationKey activationKey1 = new activationKey();
        activationKey1.a_POST_request_is_made_to_the_activationKey_API_for_Group(groupID);
        KeyStore keyStore = null;
        String data = null;
        RestAssured.useRelaxedHTTPSValidation();
        Map<String, String> headerMap = new HashMap<String, String>();
        Map<String, String> paramMap = new HashMap<String, String>();
        Response response1 = null;
        String requestBody = "";
        ContentType contentType = null;
        if(value.equals("ValidValues")) {
            if(apiName.equals("ConsumePOSTAPI")){
                activationKey1.generateTokenWithBatchSize(groupID,1);
            }else{
                activationKey1.user_has_already_generated_the_JWT_token_for_the_group(groupID);
            }
            setCertificate(keyStore, "ValidCert");
        }else if(value.equals("ExpiredToken")) {
            if(apiName.equals("ConsumePOSTAPI")){
                activationKey1.generateTokenWithBatchSize(groupID,1);
                Thread.sleep(30000);
            }else{
                activationKey1.user_has_already_generated_the_JWT_token_for_the_group(groupID);
                Thread.sleep(30000);
            }
            setCertificate(keyStore, "ValidCert");
        }else if(value.equals("DuplicateToken")) {
            if(apiName.equals("ConsumePOSTAPI")){
                activationKey1.generateTokenWithBatchSize(groupID,1);
               activationKey1.a_POST_request_is_made_to_axway_endpoint(groupID);
            }else{
                activationKey1.user_has_already_generated_the_JWT_token_for_the_group(groupID);
                activationKey1.a_POST_request_is_made_to_axway_endpoint(groupID);
            }
            setCertificate(keyStore, "ValidCert");
        }else if(value.equals("InvalidToken")){
            ab.glue.api.activationKey.activKey.put(groupID,"eyhjierieurieirujlkjdfjwureiurie");
            setCertificate(keyStore, "ValidCert");
        }else if(value.equals("EmptyToken")){
            ab.glue.api.activationKey.activKey.put(groupID,"");
            setCertificate(keyStore, "ValidCert");
        }
        else if(value.equals("DifferentGroupToken")){
            if(apiName.equals("ConsumePOSTAPI")){
                activationKey1.a_POST_request_is_made_to_the_activationKey_API_for_Group("INDGRP1");
                activationKey1.generateTokenWithBatchSize("INDGRP1",1);

                ab.glue.api.activationKey.activKey.put(groupID,ab.glue.api.activationKey.activKey.get("INDGRP1"));
            }else{
                activationKey1.a_POST_request_is_made_to_the_activationKey_API_for_Group("INDGRP1");
                activationKey1.user_has_already_generated_the_JWT_token_for_the_group("INDGRP1");
                ab.glue.api.activationKey.activKey.put(groupID,ab.glue.api.activationKey.activKey.get("INDGRP1"));
            }
                        setCertificate(keyStore, "ValidCert");
        }else if(value.equals("DifferentCert")){
            if(apiName.equals("ConsumePOSTAPI")){
                activationKey1.generateTokenWithBatchSize(groupID,1);
            }else{
                activationKey1.user_has_already_generated_the_JWT_token_for_the_group(groupID);
            }
            setCertificate(keyStore, "DifferentCert");
        }else if(value.equals("InvalidCert")){
            if(apiName.equals("ConsumePOSTAPI")){
                activationKey1.generateTokenWithBatchSize(groupID,1);
            }else{
                activationKey1.user_has_already_generated_the_JWT_token_for_the_group(groupID);
            }
            setCertificate(keyStore, "InvalidCert");
        }

          if(apiName.contains("POST")){
              contentType = ContentType.TEXT;
              requestBody = ab.glue.api.activationKey.activKey.get(groupID);
              response1 = utils.getPOSTResponse(headerMap,requestBody,commonApiMethods.endPointProp.getProperty(apiName),contentType);
          }else{
              headerMap.put("JWTToken",ab.glue.api.activationKey.activKey.get(groupID) );
              response1 = utils.getGETResponseWithParam(headerMap,paramMap,commonApiMethods.endPointProp.getProperty(apiName),contentType);
          }
       apiResponse = response1.thenReturn().asString();
        apiStatusCode = response1.getStatusCode();
        System.out.println("API response is "+apiResponse);
        System.out.println("API status code is "+apiStatusCode);
    }

    @Then("^the user should see error message '(.+)' with status code as '(\\d+)'$")
    public void verifyErrorMessage(String error, int expectedStatusCode) throws IOException {
        // Write code here that turns the phrase above into concrete actions
        String expectedErrorMessage = commonApiMethods.errorMessageProperties.getProperty(error);
        Assert.assertTrue("Status code of the response should be displayed as "+expectedStatusCode+". But it is getting displayed as "+apiStatusCode,expectedStatusCode==apiStatusCode);
        Assert.assertTrue("The expected error message is "+expectedErrorMessage+". But actual error message is displayed as "+apiResponse, apiResponse.contains(expectedErrorMessage));
    }

    public void setCertificate(KeyStore keyStore, String value){
        String certificateName = "";
        String password = "";
        if(value.equals("ValidCert")){
            certificateName ="bny-cert.pfx";
            password = "bny123";
        }else if(value.equals("DifferentCert")){
            certificateName ="inicert.pfx";
            password = "123456";
        }else{
            certificateName ="invalidcert.pfx";
            password = "123456";
        }
        try {
            keyStore = KeyStore.getInstance("PKCS12");

        keyStore.load(getClass().getResourceAsStream("/test-data/"+certificateName), password.toCharArray());
        org.apache.http.conn.ssl.SSLSocketFactory clientAuthFactory = null;
        clientAuthFactory = new org.apache.http.conn.ssl.SSLSocketFactory(keyStore, password);
        SSLConfig config = null;
        config = new SSLConfig().with().sslSocketFactory(clientAuthFactory).and().allowAllHostnames();
        RestAssured.config = RestAssured.config().sslConfig(config);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /**
     * This method is used to hit the Consume api and verify the response with the expected response
     */
    @Then("^Statistics API response should be displayed with count as '(.*)' for the group '(.*)'$")
    public void statisticsPOSTAPIValueTest(String count, String groupID) throws Throwable {
        GenericUtils utils = new GenericUtils();
        activationKey activationKey1 = new activationKey();
        activationKey1.a_POST_request_is_made_to_the_activationKey_API_for_Group(groupID);
        activationKey1.user_has_already_generated_the_JWT_token_for_the_group(groupID);
        PeekAndConsumeConfig peekAndConsumeConfig = new PeekAndConsumeConfig();
        Map<String,String> headersMap = new HashMap<String, String>();
        System.out.println("The token confirmation is "+ab.glue.api.activationKey.activKey.get(groupID));
        String actualResponse = peekAndConsumeConfig.getPeekConsumeResponse(ab.glue.api.activationKey.activKey.get(groupID), "statistics").thenReturn().asString();
        System.out.println("Statistics response : "+actualResponse);
        JsonFlattener jsonFlattener = new JsonFlattener(actualResponse);
        Map<String, Object> flattenedMap = jsonFlattener.flattenAsMap();
        Assert.assertTrue("Expected - "+". Actual - "+count+flattenedMap.get("messageCount").toString(),flattenedMap.get("messageCount").toString().equals(count));
        if(!count.equals("0"))
            Assert.assertFalse("Timestamp is displayed without any values.",flattenedMap.get("headOfBacklogTimestamp").toString().equals("0"));
        else
            Assert.assertTrue("Timestamp is displayed with values.",flattenedMap.get("headOfBacklogTimestamp").toString().equals(""));
    }

    /**
     * This method is used to hit the Consume api and verify the response with the expected response
     */
    @Then("^Statistics API response should be displayed with the count as '(.*)' for the group '(.*)' with certificate '(.*)' and password '(.*)'$")
    public void statisticsPOSTAPIValueTestForGroupWithDifferentCertificate(String count, String groupID, String certificate, String password) throws Throwable {
        GenericUtils utils = new GenericUtils();
        activationKey activationKey1 = new activationKey();
        activationKey1.a_POST_request_is_made_to_the_activationKey_API_for_Group(groupID);
        activationKey1.user_has_already_generated_the_JWT_token_for_the_group(groupID);
        PeekAndConsumeConfig peekAndConsumeConfig = new PeekAndConsumeConfig();
        Map<String,String> headersMap = new HashMap<String, String>();
        System.out.println("The token confirmation is "+ab.glue.api.activationKey.activKey.get(groupID));
        String actualResponse = peekAndConsumeConfig.getPeekConsumeStringWithCertificate(ab.glue.api.activationKey.activKey.get(groupID), "statistics",certificate, password);
        System.out.println("Statistics response : "+actualResponse);
        JsonFlattener jsonFlattener = new JsonFlattener(actualResponse);
        Map<String, Object> flattenedMap = jsonFlattener.flattenAsMap();
        Assert.assertTrue("Expected - "+". Actual - "+count+flattenedMap.get("messageCount").toString(),flattenedMap.get("messageCount").toString().equals(count));
        if(!count.equals("0"))
            Assert.assertFalse("Timestamp is displayed without any values.",flattenedMap.get("headOfBacklogTimestamp").toString().equals("0"));
        else
            Assert.assertTrue("Timestamp is displayed with values.",flattenedMap.get("headOfBacklogTimestamp").toString().equals(""));
    }

    @Then("^transaction should be displayed with details$")
    public void transactionShouldBeDisplayedWithDetails(List<Map<String,String>> map) throws Throwable {
        String actualtransactionFreeText = "";
        String expectedtransactionFreeText = "";
        int count =0;
        for(Map<String,String> mapData : map){
            for(Map.Entry<String,String> data : mapData.entrySet())
            {
                if(data.getKey().contains("FreeText"))
                {
                    expectedtransactionFreeText = expectedtransactionFreeText+data.getValue();
                    if(!data.getValue().equals(""))
                    count++;
                }else {
                    Assert.assertEquals(data.getValue(), GenericUtils.getJsonValue(DataClass.getJSonPath(data.getKey()), peekConsumeRecoverString));
                }
                }
        }
        for(int i=1;i<=count;i++){
            actualtransactionFreeText = actualtransactionFreeText+GenericUtils.getJsonValue(DataClass.getJSonPath("CreditDebitTransactionFreeText"+i), peekConsumeRecoverString);
        }
       Assert.assertTrue("Expected Transaction Free Text - "+expectedtransactionFreeText+". Actual transaction free text - "+actualtransactionFreeText,expectedtransactionFreeText.equals(actualtransactionFreeText));
       Assert.assertTrue( "Expected Status Code - 200. Actual Status Code - "+peekConsumeRecoverStatus,peekConsumeRecoverStatus==200);

    }


//    @Then("^'(.*)' response should be displayed with status as '(.*)'$")
//    public void verifySuccessForPeekConsume(String peekConsumeRecover, String accountNo, String trxType, String groupID) throws Throwable {
//        GenericUtils utils = new GenericUtils();
//        //String expectedResponse = commonApiMethods.data.get(0).get("PeekResponse").toString().trim().replaceAll(" ","");
//         /*String expectedResponse = commonApiMethods.data.get(0).get("PeekResponse").toString().trim().replaceAll(" ","");*/String expectedResponse = EndPoint.WEBHOOK_MESSAGE.replaceAll(" ","");
//
//        expectedResponse = utils.expectedValueTrim(expectedResponse,groupID,amount, accountNo,trxType).replaceAll("\\.00","");;
//        PeekAndConsumeConfig peekAndConsumeConfig = new PeekAndConsumeConfig();
//        activationKey activationKey1 = new activationKey();
//        activationKey1.a_POST_request_is_made_to_the_activationKey_API_for_Group(groupID);
//        activationKey1.generated_content_and_key_is_passed_to_the_create_token_method_for_the_group(groupID);
//        //Thread.sleep(4000);
//        String actualResponse = peekAndConsumeConfig.getPeekConsumeResponseAsString(ab.glue.api.activationKey.activKey.get(groupID), "peek").trim();
//        //String actualResponse = peekAndConsumeConfig.getPeekConsumeResponseAsString(activationKey, "peek").trim();
//        System.out.println("Peek response : "+actualResponse);
//
//        //actualResponse = utils.peekConsumeTrim(actualResponse);
//        System.out.println("actualResponse : "+actualResponse);
//        System.out.println("expectedResponse : "+expectedResponse);
//        Assert.assertTrue("Peek Response is not displayed as expected. Expected Response - " + expectedResponse + ". Actual Response - " + actualResponse,actualResponse.contains(expectedResponse));
//    }


    /**
     * This method is used to hit the Consume api and verify the response with the expected response
     */
    //@After
@Test
    public void consumeAll() throws Throwable {
        //Thread.sleep(5000);
    Properties prop = new Properties();
    InputStream input1 = getClass().getResourceAsStream("/test-data/activationKeyRequest.properties");
    prop.load(input1);
    String groupID = "";
        for(Object key : prop.keySet())
        {
           if(key.toString().contains("_PublicKey")) {
               groupID = key.toString().split("_PublicKey")[0];
               consumeInternal(groupID);
           }
        }


    }

    public void consumeInternal(String groupID){
        RestAssured.useRelaxedHTTPSValidation();
        Response data = given()
                //.proxy("10.23.210.60", 8080)
                .header("GroupId",groupID)
                .header("Content-Type","text/plain")
                .contentType(ContentType.TEXT)
                .when()
                .get("https://10.23.210.60:9012/api-banking/core/event/consume");
        String apiResponse=  data.thenReturn().asString();
        System.out.println("Cleared values for group "+groupID);
    }


}