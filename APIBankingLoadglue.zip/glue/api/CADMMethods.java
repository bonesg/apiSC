package ab.glue.api;

import ab.common.CADMConfig;
import com.github.wnameless.json.flattener.JsonFlattener;
import com.sun.jersey.api.client.config.ClientConfig;
import com.sun.jersey.api.client.config.DefaultClientConfig;
import com.sun.jersey.client.urlconnection.HTTPSProperties;
import common.EndPoint;
import common.RestAssuredConfig;
import cucumber.api.DataTable;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import junit.framework.Assert;

import javax.jms.JMSException;
import javax.net.ssl.*;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.MultivaluedMap;
import java.io.*;
import java.security.SecureRandom;
import java.security.cert.CertificateException;
import java.security.cert.X509Certificate;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.Scanner;

/**
 * Created by 1571168 on 8/3/2017.
 */
public class CADMMethods extends RestAssuredConfig{
//public static String CADM_URL = "https://10.20.166.89:755";
    public static String cadmResponse = "";
    public static int cadmStatus;
    public static  MultivaluedMap<String, String> cadmHeaders;
    public static com.sun.jersey.api.client.ClientResponse response;
    public static Map<String, Object> cadmBAIData;

    @When("^Add Group Services of CADM is called for the group '(.+)'$")
    public void postAddGroupServices(String group) throws JMSException, IOException {
        InputStream input1 = getClass().getResourceAsStream("/test-data/activationKeyRequest.properties");
        Properties prop = new Properties();
        prop.load(input1);
        //String expectedWebookURL = content.split("\"webhookUrl\":\"")[1].split("\",)[0];
        String expectedFingerprint = prop.getProperty(group+"_Certificate");
        String expectedPublickey = prop.getProperty(group+"_PublicKey");
        String expectedWebookURL = RestAssuredConfig.webhookURL.get(group);
        String input = "{\"groupId\":\""+group+"\",\"apiservice\":{\"publicKey\":\""+expectedPublickey+"\",\"certificateFingerprint\":\""+expectedFingerprint+"\",\"webhookUrl\":\""+expectedWebookURL+"\",\"apiBankingEnabled\":\"Y\"}}";
        System.out.println("Input passed is "+input);
        final com.sun.jersey.api.client.Client client = com.sun.jersey.api.client.Client.create(configureClient());
        final com.sun.jersey.api.client.WebResource webResource = client
                .resource(EndPoint.CADM_URL+"/cadmapi/service/group");
        try {
            com.sun.jersey.api.client.ClientResponse response = webResource.type(MediaType.APPLICATION_JSON_TYPE)
                    .accept(MediaType.APPLICATION_JSON_TYPE).post(com.sun.jersey.api.client.ClientResponse.class, input);
            System.out.println(response.toString());
            //  if(response.getStatus() ==200) {

            String output = response.getEntity(String.class);
            System.out.println("Output from Server .... \n");
            System.out.println(output);
            //   }
        } catch (com.sun.jersey.api.client.ClientHandlerException che) {
            che.printStackTrace();
        }
    }

    @When("^Add Group Services of CADM is called for group '(.*)' with publicKey '(.*)' certificateFingerprint '(.*)' webhookUrl '(.*)'$")
    public void postAddGroupServiceswithAllDetails(String group,String publicKey, String certificate,String webhookUrl) throws JMSException, IOException {
        //String expectedWebookURL = content.split("\"webhookUrl\":\"")[1].split("\",)[0];
        String input = "{\"groupId\":\""+group+"\",\"apiservice\":{\"publicKey\":\""+publicKey+"\",\"certificateFingerprint\":\""+certificate+"\",\"webhookUrl\":\""+webhookUrl+"\",\"apiBankingEnabled\":\"Y\"}}";
        //final com.sun.jersey.api.client.Client client = com.sun.jersey.api.client.Client.create(CADMConfig.configureClient());
        final com.sun.jersey.api.client.Client client = com.sun.jersey.api.client.Client.create(configureClient());
        final com.sun.jersey.api.client.WebResource webResource = client
                .resource("https://10.20.166.89:755/cadmapi/service/group");
        try {
            com.sun.jersey.api.client.ClientResponse response = webResource.type(MediaType.APPLICATION_JSON_TYPE)
                    .accept(MediaType.APPLICATION_JSON_TYPE).post(com.sun.jersey.api.client.ClientResponse.class, input);
            System.out.println(response.toString());
            //  if(response.getStatus() ==200) {

            cadmResponse = response.getEntity(String.class);
            cadmStatus = response.getStatus();
            System.out.println("Output from Server .... \n");
            System.out.println(cadmResponse);
            //   }
        } catch (com.sun.jersey.api.client.ClientHandlerException che) {
            che.printStackTrace();
        }
    }



    @When("^Add Group Services of CADM is called with the values$")
    public void postAddGroupServiceswithAllDetails(DataTable dataTable) throws JMSException, IOException {
        //String expectedWebookURL = content.split("\"webhookUrl\":\"")[1].split("\",)[0];

        List<List<String>> dataList=dataTable.asLists(String.class);
        String publicKey = dataList.get(1).get(0);
        String certificate = dataList.get(1).get(1);
        String webhookURL = dataList.get(1).get(2);
        String group = dataList.get(1).get(3);
        String input = "{\"groupId\":\""+group+"\",\"apiservice\":{\"publicKey\":\""+publicKey+"\",\"certificateFingerprint\":\""+certificate+"\",\"webhookUrl\":\""+webhookURL+"\",\"apiBankingEnabled\":\"Y\"}}";
        String propertyBag = dataList.get(1).get(4);
        String clientContact = dataList.get(1).get(5);
        String csgContact = dataList.get(1).get(6);
        if(propertyBag.equals("Yes")){
            String clientType = dataList.get(1).get(7);
            String clientName = dataList.get(1).get(8);
            String clientPhoneNo = dataList.get(1).get(9);
            String clientPhoneISDCode = dataList.get(1).get(10);
            String clientMobileNo = dataList.get(1).get(11);
            String clientMobileISDCode = dataList.get(1).get(12);
            String clientEmpNo = dataList.get(1).get(13);
            String clientEmailId = dataList.get(1).get(14);
            String csgType = dataList.get(1).get(15);
            String csgName = dataList.get(1).get(16);
            String csgPhoneNo = dataList.get(1).get(17);
            String csgPhoneISDCode = dataList.get(1).get(18);
            String csgMobileNo = dataList.get(1).get(19);
            String csgMobileISDCode = dataList.get(1).get(20);
            String csgEmpNo = dataList.get(1).get(21);
            String csgEmailId = dataList.get(1).get(22);
            input = input.replaceFirst("}","");
            if(clientContact.equals("Yes")&&csgContact.equals("No")){
            input = input + ",\n" +
                    "\"groupApiContactsDetailList\":[{ \"type\":"+clientType+", \"name\":"+clientName+", \"phoneNo\":"+clientPhoneNo+", \"phoneISDCode\":"+clientPhoneISDCode+", \"mobileNo\":"+clientMobileNo+", \"mobileISDCode\":"+clientMobileISDCode+", \"emailId\":"+clientEmailId+",\"empNo\":"+clientEmpNo+"}]}";
            }
            else if(clientContact.equals("No")&&csgContact.equals("Yes")){
                input = input + ",\n" +
                        "\"groupApiContactsDetailList\":[{ \"type\":"+csgType+", \"name\":"+csgName+", \"phoneNo\":"+csgPhoneNo+", \"phoneISDCode\":"+csgPhoneISDCode+", \"mobileNo\":"+csgMobileNo+", \"mobileISDCode\":"+csgMobileISDCode+", \"emailId\":"+csgEmailId+",\"empNo\":"+csgEmpNo+"}]}";
            }else if(clientContact.equals("Yes")&&csgContact.equals("Yes")){
                input = input + "," +
                        " \"groupApiContactsDetailList\":[{ \"type\":"+csgType+", \"name\":"+csgName+", \"phoneNo\":"+csgPhoneNo+", \"phoneISDCode\":"+csgPhoneISDCode+", \"mobileNo\":"+csgMobileNo+", \"mobileISDCode\":"+csgMobileISDCode+", \"emailId\":"+csgEmailId+",\"empNo\":"+csgEmpNo+"},{ \"type\":"+clientType+", \"name\":"+clientName+", \"phoneNo\":"+clientPhoneNo+", \"phoneISDCode\":"+clientPhoneISDCode+", \"mobileNo\":"+clientMobileNo+", \"mobileISDCode\":"+clientMobileISDCode+", \"emailId\":"+clientEmailId+",\"empNo\":"+clientEmpNo+"}]}";
            }
        }
        System.out.println("Request is "+input);
        //final com.sun.jersey.api.client.Client client = com.sun.jersey.api.client.Client.create(CADMConfig.configureClient());
        final com.sun.jersey.api.client.Client client = com.sun.jersey.api.client.Client.create(configureClient());
        final com.sun.jersey.api.client.WebResource webResource = client
                .resource("https://10.20.166.89:755/cadmapi/service/group");
        try {
            response = webResource.type(MediaType.APPLICATION_JSON_TYPE)
                    .accept(MediaType.APPLICATION_JSON_TYPE).post(com.sun.jersey.api.client.ClientResponse.class, input);
            System.out.println(response.toString());
            //  if(response.getStatus() ==200) {

            cadmResponse = response.getEntity(String.class);
            cadmStatus = response.getStatus();
            System.out.println("Output from Server .... \n");
            System.out.println(cadmResponse);
            //   }
        } catch (com.sun.jersey.api.client.ClientHandlerException che) {
            che.printStackTrace();
        }
    }

    @Then("^The Add Group Services should return the status as '(.*)' and response should contain value '(.*)'$")
    public void verifyGetGroupDetails(int statusCode, String response) throws JMSException, IOException {
        Assert.assertTrue("Expected Status code : "+statusCode+". Actual Status code : "+cadmStatus,cadmStatus==statusCode);
        Assert.assertTrue("Response should contain the value"+response+". Actual Response : "+cadmResponse,cadmResponse.contains(response));
    }

    public static ClientConfig configureClient() {
        TrustManager[] certs = new TrustManager[] { new X509TrustManager() {
            public X509Certificate[] getAcceptedIssuers() {
                return null;
            }
            public void checkClientTrusted(X509Certificate[] arg0, String arg1) throws CertificateException {
            }
            public void checkServerTrusted(X509Certificate[] arg0, String arg1) throws CertificateException {
            }
        } };
        SSLContext ctx = null;
        try {
            ctx = SSLContext.getInstance("SSL");
            ctx.init(null, certs, new SecureRandom());
        } catch (java.security.GeneralSecurityException ex) {
        }
        HttpsURLConnection.setDefaultSSLSocketFactory(ctx.getSocketFactory());

        ClientConfig config = new DefaultClientConfig();
        try {
            ((DefaultClientConfig) config).getProperties().put(HTTPSProperties.PROPERTY_HTTPS_PROPERTIES,
                    new HTTPSProperties(new HostnameVerifier() {
                        public boolean verify(String arg0, SSLSession arg1) {
                            return true;
                        }
                    }, ctx));
        } catch (Exception e) {
        }

        return config;
    }
    @Then("^There should be 400 error for CADM$")
    public void cadmErrorVerification(){
        System.out.println(cadmResponse);
        System.out.println(cadmStatus);
        Assert.assertTrue("Expected Status code : 400. Actual Status code : "+cadmStatus,cadmStatus==400);
        Assert.assertTrue("Exepected error message {\"statusMessage\":\"FAILED TO PROCESS DUE TO INVALID DATA\\. Actual error message "+cadmResponse, cadmResponse.contains("{\"statusMessage\":\"FAILED TO PROCESS DUE TO INVALID DATA\","));
    }

    @When("^The Get Group services is called for group '(.+)'$")
    public void verifyGetGroupServices(String groupID){
        CADMConfig cadmConfig = new CADMConfig();
        com.sun.jersey.api.client.ClientResponse response = cadmConfig.getCADMResponse("/cadmapi/service/group/",groupID);
        cadmResponse = response.toString();
        cadmHeaders = response.getHeaders();
    }


    @When("^The Get Group Account services is called for the group '(.+)'$")
    public void verifyGetGroupAccountServices(String groupID){
        CADMConfig cadmConfig = new CADMConfig();
        //Call Get API of Get group services
        com.sun.jersey.api.client.ClientResponse response = cadmConfig.getCADMResponse("/cadmapi/service/group/accounts/",groupID);
        cadmResponse = response.toString();
        cadmHeaders = response.getHeaders();
    }

    @When("^The Get BOBAI services is called for the group '(.+)'$")
    public void verifyGetBOBAIServices(String groupID){
        CADMConfig cadmConfig = new CADMConfig();
        //Call Get API of Get group services
        com.sun.jersey.api.client.ClientResponse response = cadmConfig.getCADMResponse("/cadmapi/service/refdata/bosysbaicode/",groupID);
        cadmResponse = response.toString();
        cadmHeaders = response.getHeaders();
    }

    @Then("^The CADM response should be displayed with cached header$")
    public void verifyCachedHeader(){
        Assert.assertTrue("The cache control value is not set correctly",cadmHeaders.get("Cache-Control").get(0).equals("no-cache, no-store"));
    }
    @Then("^Error message should be displayed for the Get services$")
    public void verifyErrorMessagesForGetServices(){
        Assert.assertTrue("Expected error message should be displayed as \"returned a response status of 400 Bad Request\". Actual error message "+cadmResponse, cadmResponse.contains("returned a response status of 400 Bad Request"));
    }

    @Then("^There should be 500 error for CADM$")
    public void cadm500ErrorVerification(){
        System.out.println(cadmResponse);
        System.out.println(cadmStatus);
        Assert.assertTrue(cadmStatus==500);
        Assert.assertTrue(cadmResponse.contains("Error updating database"));
    }
    @When("^Add Group Services of CADM is called for the group '(.+)' to disable the group$")
    public void postDisableAddGroupServices(String group) throws JMSException, IOException {
        InputStream input1 = getClass().getResourceAsStream("/test-data/activationKeyRequest.properties");
        Properties prop = new Properties();
        prop.load(input1);
        //String expectedWebookURL = content.split("\"webhookUrl\":\"")[1].split("\",)[0];
        String expectedFingerprint = prop.getProperty(group+"_Certificate");
        String expectedPublickey = prop.getProperty(group+"_PublicKey");    String expectedWebookURL = RestAssuredConfig.webhookURL.get(group);
        String input = "{\"groupId\":\""+group+"\",\"apiservice\":{\"publicKey\":\""+expectedPublickey+"\",\"certificateFingerprint\":\""+expectedFingerprint+"\",\"webhookUrl\":\""+expectedWebookURL+"\",\"apiBankingEnabled\":\"N\"}}";
        final com.sun.jersey.api.client.Client client = com.sun.jersey.api.client.Client.create(configureClient());
        final com.sun.jersey.api.client.WebResource webResource = client
                .resource(EndPoint.CADM_URL+"/cadmapi/service/group");
        try {
            com.sun.jersey.api.client.ClientResponse response = webResource.type(MediaType.APPLICATION_JSON_TYPE)
                    .accept(MediaType.APPLICATION_JSON_TYPE).post(com.sun.jersey.api.client.ClientResponse.class, input);
            System.out.println(response.toString());
            //  if(response.getStatus() ==200) {

            String output = response.getEntity(String.class);
            System.out.println("Output from Server .... \n");
            System.out.println(output);
            //   }
        } catch (com.sun.jersey.api.client.ClientHandlerException che) {
            che.printStackTrace();
        }
    }


    @When("^Add Group Services of CADM is called with empty values for the group '(.+)' to disable")
    public void postDisableAddGroupServicesWithEmptyValues(String group) throws JMSException, IOException {

        String input = "{\"groupId\":\""+group+"\",\"apiservice\":{\"publicKey\":\"\",\"certificateFingerprint\":\",\"webhookUrl\":\"\",\"apiBankingEnabled\":\"N\"}}";
        final com.sun.jersey.api.client.Client client = com.sun.jersey.api.client.Client.create(configureClient());
        final com.sun.jersey.api.client.WebResource webResource = client
                .resource(EndPoint.CADM_URL+"/cadmapi/service/group");
        try {
            com.sun.jersey.api.client.ClientResponse response = webResource.type(MediaType.APPLICATION_JSON_TYPE)
                    .accept(MediaType.APPLICATION_JSON_TYPE).post(com.sun.jersey.api.client.ClientResponse.class, input);
            System.out.println(response.toString());
            //  if(response.getStatus() ==200) {

            String output = response.getEntity(String.class);
            System.out.println("Output from Server .... \n");
            System.out.println(output);
            //   }
        } catch (com.sun.jersey.api.client.ClientHandlerException che) {
            che.printStackTrace();
        }
    }

    @Then("^Get group Services should return with service for the group '(.+)'$")
    public String getGroupServices(String group){
        String output="";
        final com.sun.jersey.api.client.Client client = com.sun.jersey.api.client.Client.create(configureClient());
        final com.sun.jersey.api.client.WebResource webResource = client
                .resource(EndPoint.CADM_URL+"/cadmapi/service/group/"+group);
        try {
            com.sun.jersey.api.client.ClientResponse response = webResource.type(MediaType.APPLICATION_JSON_TYPE)
                    .accept(MediaType.APPLICATION_JSON_TYPE).get(com.sun.jersey.api.client.ClientResponse.class);
            System.out.println(response.toString());
            if(response.getStatus() ==200) {
                output = response.getEntity(String.class);
                System.out.println("Output from Server .... \n");
                System.out.println(output);
            }

        } catch (com.sun.jersey.api.client.ClientHandlerException che) {
            che.printStackTrace();
        }
        return output;
    }

    @When("^I clear the cache for the '(.+)' group$")
    public void clearCacheForGroup(String groupID){
        CADMConfig cadmConfig = new CADMConfig();
        //Call Get API of Get group services
        cadmConfig.getCADMResponse("/cadmapi/service/group/",groupID);
        //Call Get API of Get Account services
        cadmConfig.getCADMResponse("/cadmapi/service/group/accounts/",groupID);
        //Call Get API of Get BOBAI
        cadmConfig.getCADMResponse("/cadmapi/service/refdata/bosysbaicode/","IN");
    }

    @Then("^APIBanking should be enabled in CADM for the group '(.+)'$")
    public boolean verifyServiceAvailableInCADM(String groupID) throws IOException {
        try {
            CADMConfig cadmConfig = new CADMConfig();
            //Call Get API of Get group services
            String response = getCADMResponse("/cadmapi/service/group/", groupID);
            String actualWebookURL = "";
            if (!response.contains("\"webhookUrl\":null")) {
                actualWebookURL = response.split("\"webhookUrl\":\"")[1].split("\",\"")[0];
            }
            String actualfingerprint = response.split("certificateFingerprint\":\"")[1].split("\",\"")[0];
            String actualpublickey = response.split("\"publicKey\":\"")[1].split("\"}}")[0];
            String actualAPIBankingEnabled = response.split("\"apiBankingEnabled\":\"")[1].split("\",\"")[0];
            InputStream input = getClass().getResourceAsStream("/test-data/activationKeyRequest.properties");

            //String expectedWebookURL = content.split("\"webhookUrl\":\"")[1].split("\",)[0];
            String expectedFingerprint = commonApiMethods.prop.getProperty(groupID + "_Certificate");
            String expectedPublickey = commonApiMethods.prop.getProperty(groupID + "_PublicKey");
            String expectedWebookURL = "";
            if (commonApiMethods.prop.getProperty(groupID + "_Port") == null)
                expectedWebookURL = RestAssuredConfig.webhookURL.get(groupID);
            else
                expectedWebookURL = "http://10.23.210.60:"+commonApiMethods.prop.getProperty(groupID + "_Port")+"/webhook";
            //Assert.assertTrue(response.contains(""));
            Assert.assertTrue("The API Banking service is not enabled in CADM for the group" + groupID, response.contains("{\"serviceCode\":\"API\",\"serviceName\":\"API Banking\""));
            Assert.assertTrue("The value of fingerprint is not displayed as expected in CADM for the group" + groupID, expectedFingerprint.equalsIgnoreCase(actualfingerprint));
            Assert.assertTrue("The value of public key is not displayed as expected in CADM for the group" + groupID, expectedPublickey.equals(actualpublickey));
            if (actualWebookURL != "")
                Assert.assertTrue("The value of webhook URL is not displayed as expected in CADM for the group" + groupID, expectedWebookURL.equals(actualWebookURL));
            Assert.assertTrue("The value of apienabled is not displayed as expected in CADM for the group" + groupID, actualAPIBankingEnabled.equals("Y"));
        }catch(Exception e){
            return false;
        }
        return true;
    }

    @Then("^APIBanking should be activated for the Group '(.+)'$")
    public boolean verifyIfGroupActivated(String groupID) throws IOException {
        try {
            CADMConfig cadmConfig = new CADMConfig();
            //Call Get API of Get group services
            String response = getCADMResponse("/cadmapi/service/group/", groupID);
            String actualWebookURL = "";
            if (!response.contains("\"webhookUrl\":null")) {
                actualWebookURL = response.split("\"webhookUrl\":\"")[1].split("\",\"")[0];
            }
            String actualfingerprint = response.split("certificateFingerprint\":\"")[1].split("\",\"")[0];
            String actualpublickey = response.split("\"publicKey\":\"")[1].split("\"}}")[0];
            String actualAPIBankingEnabled = response.split("\"apiBankingEnabled\":\"")[1].split("\",\"")[0];
            InputStream input = getClass().getResourceAsStream("/test-data/activationKeyRequest.properties");

            Assert.assertTrue("The API Banking service is not enabled in CADM for the group" + groupID, response.contains("{\"serviceCode\":\"API\",\"serviceName\":\"API Banking\""));
            Assert.assertTrue("The API Banking service is not enabled in CADM for the group" + groupID, (!actualfingerprint.equals(""))&&actualfingerprint!=null);
            Assert.assertTrue("The API Banking service is not enabled in CADM for the group" + groupID, (!actualpublickey.equals(""))&&actualpublickey!=null);
            Assert.assertTrue("The API Banking service is not enabled in CADM for the group" + groupID, actualAPIBankingEnabled.equals("Y"));
        }catch(Exception e){
            return false;
        }
        return true;
    }


    @Then("^APIBanking should be enabled in CADM for the with modified '(.*)' for the group '(.+)'$")
    public void verifyServiceAvailableInCADMWithModifiedValues(String value, String groupID) throws IOException {
        CADMConfig cadmConfig = new CADMConfig();
        //Call Get API of Get group services
        String response = getCADMResponse("/cadmapi/service/group/", groupID);
        String actualWebookURL ="";
        if(!response.contains("\"webhookUrl\":null")){
            actualWebookURL = response.split("\"webhookUrl\":\"")[1].split("\",\"")[0];
        }
        String actualfingerprint = response.split("certificateFingerprint\":\"")[1].split("\",\"")[0];
        String actualpublickey = response.split("\"publicKey\":\"")[1].split("\"}}")[0];
        String actualAPIBankingEnabled = response.split("\"apiBankingEnabled\":\"")[1].split("\",\"")[0];
        String content = new Scanner(getClass().getResourceAsStream("/test-data/activationKeyBody" + groupID + ".json")).useDelimiter("\\Z").next();
        content = content.replaceAll(" ", "");
        InputStream input = getClass().getResourceAsStream("/test-data/activationKeyRequest.properties");
        Properties prop = new Properties();
        prop.load(input);
        //String expectedWebookURL = content.split("\"webhookUrl\":\"")[1].split("\",)[0];
        String expectedFingerprint ="";
        String expectedPublickey ="";
        if(value.equals("newCertificate")) {
             expectedFingerprint = prop.getProperty(groupID + "_NewCertificate");
             expectedPublickey = prop.getProperty(groupID + "_PublicKey");
        }else if(value.equals("newPublicKey")){
             expectedFingerprint = prop.getProperty(groupID + "_Certificate");
             expectedPublickey = prop.getProperty(groupID + "_NewPublicKey");
        }else{
             expectedFingerprint = prop.getProperty(groupID + "_Certificate");
             expectedPublickey = prop.getProperty(groupID + "_PublicKey");

        }
        String expectedWebookURL = RestAssuredConfig.webhookURL.get(groupID);
        //Assert.assertTrue(response.contains(""));
        Assert.assertTrue("The API Banking service is not enabled in CADM for the group" + groupID, response.contains("{\"serviceCode\":\"API\",\"serviceName\":\"API Banking\""));
        Assert.assertTrue("The value of fingerprint is not displayed as expected in CADM for the group" + groupID, expectedFingerprint.equals(actualfingerprint));
        Assert.assertTrue("The value of public key is not displayed as expected in CADM for the group" + groupID, expectedPublickey.equals(actualpublickey));
        if(actualWebookURL!="")
            Assert.assertTrue("The value of webhook URL is not displayed as expected in CADM for the group" + groupID, expectedWebookURL.equals(actualWebookURL));
        Assert.assertTrue("The value of apienabled is not displayed as expected in CADM for the group" + groupID, actualAPIBankingEnabled.equals("Y"));
    }


    @Then("^APIBanking should be enabled in CADM for the group '(.+)' with the details")
    public void verifyServiceAvailableInCADM(String groupID, DataTable dataTable) throws FileNotFoundException {
        CADMConfig cadmConfig = new CADMConfig();
        //Call Get API of Get group services
        String response = getCADMResponse("/cadmapi/service/group/", groupID);
        String actualWebookURL ="";
        if(!response.contains("\"webhookUrl\":null")){
            actualWebookURL = response.split("\"webhookUrl\":\"")[1].split("\",\"")[0];
        }
        String actualfingerprint = response.split("certificateFingerprint\":\"")[1].split("\",\"")[0];
        String actualpublickey = response.split("\"publicKey\":\"")[1].split("\"}}")[0];
        String actualAPIBankingEnabled = response.split("\"apiBankingEnabled\":\"")[1].split("\",\"")[0];
        String content = new Scanner(new File("./src/test/resources/test-data/activationKeyBody" + groupID + ".json")).useDelimiter("\\Z").next();
        content = content.replaceAll(" ", "");

        //String expectedWebookURL = content.split("\"webhookUrl\":\"")[1].split("\",)[0];
        List<List<String>> dataList = dataTable.asLists(String.class);
        String expectedPublickey =  dataList.get(1).get(0);
        String expectedFingerprint = dataList.get(1).get(1);
        String expectedWebhookURL =  dataList.get(1).get(2);
        String expectedGroupID =  dataList.get(1).get(3);
        String expectedPropertyBag =  dataList.get(1).get(4);
        String expectedClientContact =  dataList.get(1).get(5);
        String expectedCSGContact =  dataList.get(1).get(6);
        String expectedClientType =  dataList.get(1).get(7);
        String expectedClientName =  dataList.get(1).get(8);
        String expectedClientPhoneNo =  dataList.get(1).get(9);
        String expectedClientPhoneISDCode =  dataList.get(1).get(10);
        String expectedClientMobileNo =  dataList.get(1).get(11);
        String expectedClientMobileISDCode=  dataList.get(1).get(12);
        String expectedClientEmpNo=  dataList.get(1).get(13);
        String expectedClientEmailId=  dataList.get(1).get(14);
        String expectedCSGType =  dataList.get(1).get(15);
        String expectedCSGName =  dataList.get(1).get(16);
        String expectedCSGPhoneNo =  dataList.get(1).get(17);
        String expectedCSGPhoneISDCode =  dataList.get(1).get(18);
        String expectedCSGMobileNo =  dataList.get(1).get(19);
        String expectedCSGMobileISDCode=  dataList.get(1).get(20);
        String expectedCSGEmpNo=  dataList.get(1).get(21);
        String expectedCSGEmailId=  dataList.get(1).get(22);
        Assert.assertTrue("The API Banking service is not enabled in CADM for the group" + groupID+". Actual response is "+response, response.contains("{\"productCode\":\"OTH\",\"productName\":\"Other Services\",\"services\":[{\"serviceCode\":\"API\",\"serviceName\":\"API Banking\"}]}]"));
        Assert.assertTrue("The value of fingerprint is not displayed as expected in CADM for the group" + groupID, expectedFingerprint.equals(actualfingerprint));
        Assert.assertTrue("The value of public key is not displayed as expected in CADM for the group" + groupID, expectedPublickey.equals(actualpublickey));
        if(actualWebookURL!="")
            Assert.assertTrue("The value of webhook URL is not displayed as expected in CADM for the group" + groupID, expectedWebhookURL.equals(actualWebookURL));
          if(expectedPropertyBag.equals("Yes")) {
            if (expectedClientContact.equals("Yes") && expectedCSGContact.equals("No")) {
                Assert.assertTrue("The value of Client Type is not displayed as expected in CADM for the group. Expected Client type : " + expectedClientType+". Actual Response : "+response, response.contains(expectedClientType));
                Assert.assertTrue("The value of Client Name is not displayed as expected in CADM for the group. Expected Client Name : " + expectedClientName+". Actual Response : "+response, response.contains(expectedClientName));
                Assert.assertTrue("The value of Client Phone Number is not displayed as expected in CADM for the group. Expected Client Phone Number : " + expectedClientPhoneNo+". Actual Response : "+response, response.contains(expectedClientPhoneNo));
                Assert.assertTrue("The value of Client Phone ISD Code is not displayed as expected in CADM for the group. Expected Client Phone ISD Code : " + expectedClientPhoneISDCode+". Actual Response : "+response, response.contains(expectedClientPhoneISDCode));
                Assert.assertTrue("The value of Client Mobile Number is not displayed as expected in CADM for the group. Expected Client Mobile Number : " + expectedClientMobileNo+". Actual Response : "+response, response.contains(expectedClientMobileNo));
                Assert.assertTrue("The value of Client Mobile ISD Code is not displayed as expected in CADM for the group. Expected Client Mobile ISD Code : " + expectedClientMobileISDCode+". Actual Response : "+response, response.contains(expectedClientMobileISDCode));
                Assert.assertTrue("The value of Client Employee No is not displayed as expected in CADM for the group. Expected Client Employee Number : " + expectedClientEmpNo+". Actual Response : "+response, response.contains(expectedClientEmpNo));
                Assert.assertTrue("The value of Client Email Id is not displayed as expected in CADM for the group. Expected Client Email ID : " + expectedClientEmailId +". Actual Response : "+response, response.contains(expectedClientEmailId));
                Assert.assertFalse("The value of CSG Type is not displayed as expected in CADM for the group. Expected Client type : " + expectedCSGType+". Actual Response : "+response, response.contains(expectedCSGType));
                Assert.assertFalse("The value of CSG Name is not displayed as expected in CADM for the group. Expected Client Name : " + expectedCSGName+". Actual Response : "+response, response.contains(expectedCSGName));
                Assert.assertFalse("The value of CSG PhoneNo is not displayed as expected in CADM for the group. Expected  CSG PhoneNo : " + expectedCSGPhoneNo+". Actual Response : "+response, response.contains(expectedCSGPhoneNo));
                Assert.assertFalse("The value of CSG Phone ISD Code is not displayed as expected in CADM for the group. Expected CSG Phone ISD Code : " + expectedCSGPhoneISDCode+". Actual Response : "+response, response.contains(expectedCSGPhoneISDCode));
                Assert.assertFalse("The value of CSG Mobile Number is not displayed as expected in CADM for the group. Expected CSG Mobile Number : " + expectedCSGMobileNo+". Actual Response : "+response, response.contains(expectedCSGMobileNo));
                Assert.assertFalse("The value of CSG Mobile ISD Code is not displayed as expected in CADM for the group. Expected CSG Mobile ISD Code : " + expectedCSGMobileISDCode+". Actual Response : "+response, response.contains(expectedCSGMobileISDCode));
                Assert.assertFalse("The value of CSG Employee No is not displayed as expected in CADM for the group. Expected CSG Employee Number : " + expectedCSGEmpNo+". Actual Response : "+response, response.contains(expectedCSGEmpNo));
                Assert.assertFalse("The value of CSG Email Id is not displayed as expected in CADM for the group. Expected CSG Email ID : " + expectedCSGEmailId +". Actual Response : "+response, response.contains(expectedCSGEmailId));
            } else if (expectedClientContact.equals("No") && expectedCSGContact.equals("Yes")) {
                Assert.assertFalse("The value of Client Type is not displayed as expected in CADM for the group. Expected Client type : " + expectedClientType+". Actual Response : "+response, response.contains(expectedClientType));
                Assert.assertFalse("The value of Client Name is not displayed as expected in CADM for the group. Expected Client Name : " + expectedClientName+". Actual Response : "+response, response.contains(expectedClientName));
                Assert.assertFalse("The value of Client Phone Number is not displayed as expected in CADM for the group. Expected Client Phone Number : " + expectedClientPhoneNo+". Actual Response : "+response, response.contains(expectedClientPhoneNo));
                Assert.assertFalse("The value of Client Phone ISD Code is not displayed as expected in CADM for the group. Expected Client Phone ISD Code : " + expectedClientPhoneISDCode+". Actual Response : "+response, response.contains(expectedClientPhoneISDCode));
                Assert.assertFalse("The value of Client Mobile Number is not displayed as expected in CADM for the group. Expected Client Mobile Number : " + expectedClientMobileNo+". Actual Response : "+response, response.contains(expectedClientMobileNo));
                Assert.assertFalse("The value of Client Mobile ISD Code is not displayed as expected in CADM for the group. Expected Client Mobile ISD Code : " + expectedClientMobileISDCode+". Actual Response : "+response, response.contains(expectedClientMobileISDCode));
                Assert.assertFalse("The value of Client Employee No is not displayed as expected in CADM for the group. Expected Client Employee Number : " + expectedClientEmpNo+". Actual Response : "+response, response.contains(expectedClientEmpNo));
                Assert.assertFalse("The value of Client Email Id is not displayed as expected in CADM for the group. Expected Client Email ID : " + expectedClientEmailId +". Actual Response : "+response, response.contains(expectedClientEmailId));
                Assert.assertTrue("The value of CSG Type is not displayed as expected in CADM for the group. Expected Client type : " + expectedCSGType+". Actual Response : "+response, response.contains(expectedCSGType));
                Assert.assertTrue("The value of CSG Name is not displayed as expected in CADM for the group. Expected Client Name : " + expectedCSGName+". Actual Response : "+response, response.contains(expectedCSGName));
                Assert.assertTrue("The value of CSG PhoneNo is not displayed as expected in CADM for the group. Expected  CSG PhoneNo : " + expectedCSGPhoneNo+". Actual Response : "+response, response.contains(expectedCSGPhoneNo));
                Assert.assertTrue("The value of CSG Phone ISD Code is not displayed as expected in CADM for the group. Expected CSG Phone ISD Code : " + expectedCSGPhoneISDCode+". Actual Response : "+response, response.contains(expectedCSGPhoneISDCode));
                Assert.assertTrue("The value of CSG Mobile Number is not displayed as expected in CADM for the group. Expected CSG Mobile Number : " + expectedCSGMobileNo+". Actual Response : "+response, response.contains(expectedCSGMobileNo));
                Assert.assertTrue("The value of CSG Mobile ISD Code is not displayed as expected in CADM for the group. Expected CSG Mobile ISD Code : " + expectedCSGMobileISDCode+". Actual Response : "+response, response.contains(expectedCSGMobileISDCode));
                Assert.assertTrue("The value of CSG Employee No is not displayed as expected in CADM for the group. Expected CSG Employee Number : " + expectedCSGEmpNo+". Actual Response : "+response, response.contains(expectedCSGEmpNo));
                Assert.assertTrue("The value of CSG Email Id is not displayed as expected in CADM for the group. Expected CSG Email ID : " + expectedCSGEmailId +". Actual Response : "+response, response.contains(expectedCSGEmailId));
            } else if (expectedClientContact.equals("Yes") && expectedCSGContact.equals("Yes")) {
                Assert.assertTrue("The value of Client Type is not displayed as expected in CADM for the group. Expected Client type : " + expectedClientType+". Actual Response : "+response, response.contains(expectedClientType));
                Assert.assertTrue("The value of Client Name is not displayed as expected in CADM for the group. Expected Client Name : " + expectedClientName+". Actual Response : "+response, response.contains(expectedClientName));
                Assert.assertTrue("The value of Client Phone Number is not displayed as expected in CADM for the group. Expected Client Phone Number : " + expectedClientPhoneNo+". Actual Response : "+response, response.contains(expectedClientPhoneNo));
                Assert.assertTrue("The value of Client Phone ISD Code is not displayed as expected in CADM for the group. Expected Client Phone ISD Code : " + expectedClientPhoneISDCode+". Actual Response : "+response, response.contains(expectedClientPhoneISDCode));
                Assert.assertTrue("The value of Client Mobile Number is not displayed as expected in CADM for the group. Expected Client Mobile Number : " + expectedClientMobileNo+". Actual Response : "+response, response.contains(expectedClientMobileNo));
                Assert.assertTrue("The value of Client Mobile ISD Code is not displayed as expected in CADM for the group. Expected Client Mobile ISD Code : " + expectedClientMobileISDCode+". Actual Response : "+response, response.contains(expectedClientMobileISDCode));
                Assert.assertTrue("The value of Client Employee No is not displayed as expected in CADM for the group. Expected Client Employee Number : " + expectedClientEmpNo+". Actual Response : "+response, response.contains(expectedClientEmpNo));
                Assert.assertTrue("The value of Client Email Id is not displayed as expected in CADM for the group. Expected Client Email ID : " + expectedClientEmailId +". Actual Response : "+response, response.contains(expectedClientEmailId));
                Assert.assertTrue("The value of CSG Type is not displayed as expected in CADM for the group. Expected Client type : " + expectedCSGType+". Actual Response : "+response, response.contains(expectedCSGType));
                Assert.assertTrue("The value of CSG Name is not displayed as expected in CADM for the group. Expected Client Name : " + expectedCSGName+". Actual Response : "+response, response.contains(expectedCSGName));
                Assert.assertTrue("The value of CSG PhoneNo is not displayed as expected in CADM for the group. Expected  CSG PhoneNo : " + expectedCSGPhoneNo+". Actual Response : "+response, response.contains(expectedCSGPhoneNo));
                Assert.assertTrue("The value of CSG Phone ISD Code is not displayed as expected in CADM for the group. Expected CSG Phone ISD Code : " + expectedCSGPhoneISDCode+". Actual Response : "+response, response.contains(expectedCSGPhoneISDCode));
                Assert.assertTrue("The value of CSG Mobile Number is not displayed as expected in CADM for the group. Expected CSG Mobile Number : " + expectedCSGMobileNo+". Actual Response : "+response, response.contains(expectedCSGMobileNo));
                Assert.assertTrue("The value of CSG Mobile ISD Code is not displayed as expected in CADM for the group. Expected CSG Mobile ISD Code : " + expectedCSGMobileISDCode+". Actual Response : "+response, response.contains(expectedCSGMobileISDCode));
                Assert.assertTrue("The value of CSG Employee No is not displayed as expected in CADM for the group. Expected CSG Employee Number : " + expectedCSGEmpNo+". Actual Response : "+response, response.contains(expectedCSGEmpNo));
                Assert.assertTrue("The value of CSG Email Id is not displayed as expected in CADM for the group. Expected CSG Email ID : " + expectedCSGEmailId +". Actual Response : "+response, response.contains(expectedCSGEmailId));
            }
        }
    }

    @Then("^The response should be displayed with the error with status code as '(.*)' and error message '(.*)'")
    public void verifyErrorForGetGroupServices(int statusCode, String errorMessage) throws FileNotFoundException {
        Assert.assertTrue("The response is not displayed with the expected status code - "+statusCode+". Actual status code - "+cadmStatus,cadmStatus==statusCode);
        Assert.assertTrue("The response is not displayed as expected. Expected Response - Error 400: SRVE0295E: Error reported: 400\n Actual Response is -"+cadmResponse,cadmResponse.equals("Error 400: SRVE0295E: Error reported: 400\n")||cadmResponse.contains("{\"statusMessage\":\"FAILED TO PROCESS DUE TO INVALID DATA\""));
    }


    @Then("^APIBanking should be disabled in CADM for the group '(.+)'$")
    public void verifyServiceUnavailableInCADM(String groupID) throws InterruptedException {
        CADMConfig cadmConfig = new CADMConfig();
        //Call Get API of Get group services
        String response = cadmConfig.getCADMResponse("/cadmapi/service/group/",groupID).getEntity(String.class);
        Assert.assertFalse("The API Banking service is not enabled in CADM for the group" + groupID, response.contains("{\"productCode\":\"OTH\",\"productName\":\"Other Services\",\"services\":[{\"serviceCode\":\"API\",\"serviceName\":\"API Banking\"}]}]"));
        Thread.sleep(5000);
    }

    @Then("^Get group account Services should return with response for the group '(.+)'")
    public void getGroupAccountServices(String group){
        final com.sun.jersey.api.client.Client client = com.sun.jersey.api.client.Client.create(configureClient());
        final com.sun.jersey.api.client.WebResource webResource = client
                .resource(EndPoint.CADM_URL+"/cadmapi/service/group/accounts/"+group);
        //.resource("https://10.20.166.89:756/cadmapi/service/accounts/GHEBBS01");
        try {
            com.sun.jersey.api.client.ClientResponse response = webResource.type(MediaType.APPLICATION_JSON_TYPE)
                    .accept(MediaType.APPLICATION_JSON_TYPE).get(com.sun.jersey.api.client.ClientResponse.class);
            System.out.println(response.toString());
            // if((response.getStatus() ==200)||(response.getStatus() ==400)){
            String output = response.getEntity(String.class);
            System.out.println("Output from Server .... \n");
            System.out.println(output);
            //   }
        } catch (com.sun.jersey.api.client.ClientHandlerException che) {
            che.printStackTrace();
        }
    }

    @Then("^Get BOBAI Code Mapping Services should return with response for the group country '(.+)'")
    public String getBOBAICodeMappingServices(String grpCountry) {
        final com.sun.jersey.api.client.Client client = com.sun.jersey.api.client.Client.create(configureClient());
        final com.sun.jersey.api.client.WebResource webResource = client
                .resource(EndPoint.CADM_URL + "/cadmapi/service/refdata/bosysbaicode/" + grpCountry);
        //.resource("https://10.20.166.89:756/cadmapi/service/accounts/GHEBBS01");
        String output = null;
        try {
            com.sun.jersey.api.client.ClientResponse response = webResource.type(MediaType.APPLICATION_JSON_TYPE)
                    .accept(MediaType.APPLICATION_JSON_TYPE).get(com.sun.jersey.api.client.ClientResponse.class);
            if (response.getStatus() == 200) {
                output = response.getEntity(String.class);
                System.out.println("Output from Server .... \n");
                System.out.println(output);
            }
        } catch (Exception che) {
            che.printStackTrace();
        }


        return output;
    }

    /**
     * The method is configured to get the response for all the GET APIs of CADM
     * @param endpoint - The endpoint of the CADM GET API is to be called.
     * @param groupId  - The group ID for which, details are required
     * @return response - Return the response of the GET APIs
     */
    public String getCADMResponse(String endpoint, String groupId){
        String output="";
        final com.sun.jersey.api.client.Client client = com.sun.jersey.api.client.Client.create(configureClient());
        final com.sun.jersey.api.client.WebResource webResource = client
                .resource(EndPoint.CADM_URL+endpoint+groupId);
        try {
            com.sun.jersey.api.client.ClientResponse response = webResource.type(MediaType.APPLICATION_JSON_TYPE)
                    .accept(MediaType.APPLICATION_JSON_TYPE).get(com.sun.jersey.api.client.ClientResponse.class);
            System.out.println(response.toString());
            output = response.toString();
            if(response.getStatus() ==200) {
                output = response.getEntity(String.class);
                System.out.println(output);
            }

        } catch (com.sun.jersey.api.client.ClientHandlerException che) {
            che.printStackTrace();
        }
        return output;
    }

    @When("^user hits the CADM API and get the transaction code values for country '(.*)'$")
    public void storeCADMTransactionCodes(String country){
        CADMMethods cadmMethods = new CADMMethods();
        cadmResponse = cadmMethods.getBOBAICodeMappingServices(country);
        cadmBAIData = JsonFlattener.flattenAsMap(cadmResponse);
        System.out.println(cadmBAIData.toString().replaceAll("\\\\/", "\\/"));
    }
}
