package ab.glue.api;

import ab.common.JWTTest;
import ab.utils.GenericUtils;
import com.google.common.collect.Sets;
import common.EndPoint;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import io.restassured.RestAssured;
import io.restassured.config.SSLConfig;
import io.restassured.http.ContentType;
import io.restassured.response.Response;
import org.apache.commons.io.IOUtils;
import org.apache.commons.lang3.tuple.Pair;
import org.apache.http.conn.ssl.SSLSocketFactory;
import org.codehaus.jackson.map.ObjectMapper;
import org.junit.Assert;
import org.xml.sax.SAXException;

import javax.crypto.NoSuchPaddingException;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.TransformerException;
import javax.xml.xpath.XPathExpressionException;
import java.io.IOException;
import java.security.*;
import java.security.cert.CertificateException;
import java.util.*;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;
import java.util.function.Supplier;

import static org.junit.Assert.fail;

/**
 * Created by 1571168 on 6/29/2018.
 */
public class GenericGlue {
    public static Response response;
    public static String responseString;
    public static int responseStatus;
    public static boolean responseEncrypted;
    public static String randomMessageID;

    GenericUtils genericUtils = new GenericUtils();

    private static Set<String> pendingPaymentIds = Sets.newHashSet();

    @When("user hits the '(.*)' API with requestType '(.*)' with params '(.*)' with headers '(.*)' with random number for '(.*)' and group '(.*)'")
    public void hitJSONAPIWithDetailsWithRandomID(String apiName,String requestType,String params, String headers, String randomIDs, String groupID, List<Map<String, Object>> data) throws Throwable {

        data.stream().forEach(m -> {
            try{
                    SSLSocketFactory clientAuthFactory;
                    String cert = (String) m.get("certificate");
                    KeyStore keyStore = KeyStore.getInstance("PKCS12");
                    if (cert != null) {
                        keyStore.load(getClass().getResourceAsStream("/test-data/" + cert.split("-")[0]), cert.split("-")[1].toCharArray());
                        clientAuthFactory = new SSLSocketFactory(keyStore, cert.split("-")[1]);
                    } else {
                        keyStore.load(getClass().getResourceAsStream("/test-data/bny-cert.pfx"), "bny123".toCharArray());
                        clientAuthFactory = new SSLSocketFactory(keyStore, "bny123");
                    }

                    SSLConfig config = new SSLConfig().with().sslSocketFactory(clientAuthFactory).and().allowAllHostnames();
                    RestAssured.config = RestAssured.config().sslConfig(config);
            }catch(Throwable error){
                error.printStackTrace();
                }});
        executeApiCalls(data, ()->sendRequestFromTemplateAndDataTableToAPI(apiName, requestType, params, headers, randomIDs, groupID, data));
    }

    @When("user hits '(.*)' API with requestType '(.*)' with params '(.*)' with headers '(.*)' with random number for '(.*)' and group '(.*)' for '(\\d+)' times with value")
    public void hitJSONAPIWithDetailsWithRandomID(String apiName,String requestType,String params, String headers, String randomIDs, String groupID, int times, List<Map<String, Object>> data) throws Throwable {
        executeApiCalls(data, ()-> {
            pendingPaymentIds.clear();
            ExecutorService es = Executors.newFixedThreadPool(100);
            for(int i =0;i!=times;i++) {
                es.submit(() -> {
                    Pair<String,Integer> response = sendRequestFromTemplateAndDataTableToAPI(apiName, requestType, params, headers, randomIDs, groupID, data);
                    if (response.getValue() != 200) {
                        fail("Not all requests completed successfully.");
                    }
                    synchronized (pendingPaymentIds) {
                        pendingPaymentIds.add(response.getKey());
                    }
                });
            }
            es.shutdown();
            try {
                es.awaitTermination(1, TimeUnit.DAYS);
            } catch (InterruptedException ignored) {
            }
            return null;
        });
    }

    @Then("^the '(.*)' response should be displayed with status code as '(.+)'")
    public void verifyResponseStatusCode(String apiName, int expectedStatusCode) {
        Assert.assertEquals("Expected Status Code - " + expectedStatusCode + ". Actual Status Code - " + responseStatus, expectedStatusCode, responseStatus);
    }

    @Then("^the '(.*)' response should be displayed with status code '(.+)' and response message as '(.+)'")
    public void verifyResponseStatusCodeAndMessage(String apiName, int expectedStatusCode, String expectedResponse) {
        Assert.assertEquals("Expected Status Code - " + expectedStatusCode + ". Actual Status Code - " + responseStatus, expectedStatusCode, responseStatus);
        Assert.assertEquals("Expected Response is - " + expectedResponse + ". Actual Response is - " + responseString, expectedResponse, responseString);
    }


    @Then("^the '(.*)' response should be displayed with status code '(.+)' and error message as '(.+)'")
    public void verifyResponseStatusCodeAndErrorMessage(String apiName, int expectedStatusCode, String expectedResponse) {
        Assert.assertEquals("Expected Status Code - " + expectedStatusCode + ". Actual Status Code - " + responseStatus, expectedStatusCode, responseStatus);
        Assert.assertTrue("Expected Response is - " + commonApiMethods.errorMessageProperties.getProperty(expectedResponse) + ". Actual Response is - " + responseString, responseString.contains(commonApiMethods.errorMessageProperties.getProperty(expectedResponse)));
    }

    @And("^the error response body contains error message '(.+)' and error code '(.*)'")
    public void verifyResponseStatusCodeAndErrorMessage( String errorMessage, String errorCode) throws IOException {
        ObjectMapper objectMapper = new ObjectMapper();
        Map<String, Object> responseMap = objectMapper.readValue(responseString, Map.class);
        String actualErrorMessage = (String)responseMap.get("errorMessage");
        String actualErrorCode = (String)responseMap.get("errorCode");
        System.out.println("The actual error message is "+actualErrorMessage);
        String[] errorMessageKeys = errorMessage.split("-");
        String expectedErrorMessage = commonApiMethods.errorMessageProperties.getProperty(errorMessageKeys[0]);
        for(int i=0;i<errorMessageKeys.length;i++){
            expectedErrorMessage = expectedErrorMessage.replace("${String"+i+"}",errorMessageKeys[i]);
        }
        Assert.assertEquals("Expected Error Code - " + errorCode + ". Actual Error Code - " + actualErrorCode, errorCode, actualErrorCode);
        if(!errorMessage.equals("PaymentDuplicateErrorMessage"))
            Assert.assertEquals("Expected Response is - " +  expectedErrorMessage + ". Actual Response is - " + actualErrorMessage, expectedErrorMessage,actualErrorMessage);
        else
            Assert.assertTrue("Expected Response is - " +  expectedErrorMessage + ". Actual Response is - " + actualErrorMessage, actualErrorMessage.contains(expectedErrorMessage));
    }

    @Then("^the '(.*)' response should be displayed with same random '(.+)'")
    public void verifyInimegResponseWithRandom(String apiName, String jsonPath) throws ParserConfigurationException, SAXException, XPathExpressionException, IOException, ClassNotFoundException, NoSuchFieldException, InterruptedException {
        String values[] = jsonPath.split("\\|");
        if(apiName.equals("CustodyTransactionStatus")){
            randomMessageID = NewStub.randomNumber;
          if(apiName.equals("Consume")||apiName.equals("Recover"))
              apiName ="Peek";
            for (int i = 0; i < values.length; i++)
                Assert.assertEquals(randomMessageID, GenericUtils.getJsonValue(GenericUtils.getResponseJSonPath(values[i], Class.forName("ab.glue.api." + apiName)), responseString));
        }else if(apiName.equals("Peek")||apiName.equals("Consume")||apiName.equals("Recover")){
            if(apiName.equals("Consume")||apiName.equals("Recover"))
                apiName ="Peek";
            for (int i = 0; i < values.length; i++)
                Assert.assertEquals(randomMessageID, GenericUtils.getJsonValue(GenericUtils.getResponseJSonPath(values[i], Class.forName("ab.glue.api." + apiName)), responseString));
        }
        else {
            for (int i = 0; i < values.length; i++)
                Assert.assertEquals(randomMessageID, GenericUtils.getJsonValue(GenericUtils.getJSonPath(values[i], Class.forName("ab.glue.api." + apiName)), responseString));
        }
    }

    @Then("^On Decrypting with private key of group '(.*)', the '(.*)' response should be displayed with same random '(.+)'")
    public void verifyDecryptionWithValidPrivateKeyGivesValidResponse(String groupID, String apiName, String jsonPath) throws ParserConfigurationException, SAXException, XPathExpressionException, IOException, ClassNotFoundException, NoSuchFieldException, NoSuchAlgorithmException, NoSuchPaddingException {
        Assert.assertTrue("The response is not getting encrypted. Encrypted response - " + responseString, responseString.contains("\"content\":"));
        responseString = genericUtils.decryptResponse(response, groupID);
        Assert.assertEquals(randomMessageID, GenericUtils.getJsonValue(GenericUtils.getJSonPath(jsonPath, Class.forName("ab.glue.api." + apiName)), responseString));
    }

    @Then("^I Decrypt response with private key of group '(.*)'")
    public void verifyDecryptionWithValidPrivateKey(String groupID) throws ParserConfigurationException, SAXException, XPathExpressionException, IOException, ClassNotFoundException, NoSuchFieldException, NoSuchAlgorithmException, NoSuchPaddingException {
        System.out.println("The Encrypted response is " + responseString);
        Assert.assertTrue("The response is not getting encrypted. Encrypted response - " + responseString, responseString.contains("\"content\":"));
        responseString = genericUtils.decryptResponse(response, groupID);
        System.out.println("The Decrypted response is " + responseString);
    }

    @Then("^On Decrypting with private key of group '(.*)', the '(.*)' response should throw exception")
    public void verifyDecryptionWithInvalidPrivateKeyGivesException(String groupID, String apiName) throws ParserConfigurationException, SAXException, XPathExpressionException, IOException, ClassNotFoundException, NoSuchFieldException, NoSuchAlgorithmException, NoSuchPaddingException {
        Assert.assertTrue("The response is not getting encrypted. Encrypted response - " + responseString, responseString.contains("\"content\":"));
        responseString = genericUtils.decryptResponse(response, groupID);
        Assert.assertTrue("Response is getting decrypted with invalid private key.", responseString.contains("\"content\""));
    }

    @Then("^the '(.*)' response should be displayed with the details")
    public void verifyInimegResponseWithRandom(String apiName, List<Map<String, String>> data) throws ParserConfigurationException, SAXException, XPathExpressionException, IOException, ClassNotFoundException, NoSuchFieldException {
        String jsonPath = "";
        for (Map<String, String> mapData : data) {
            for (Map.Entry<String, String> nowMap : mapData.entrySet()) {
                if (apiName.equals("CustodyTransactionStatus")||apiName.equals("Peek")||apiName.equals("Consume")||apiName.equals("Recover")) {
                    if(apiName.equals("Consume")||apiName.equals("Recover")){
                        apiName = "Peek";
                    }
                    jsonPath = GenericUtils.getResponseJSonPath(nowMap.getKey(), Class.forName("ab.glue.api." + apiName));
                } else {
                    jsonPath = GenericUtils.getJSonPath(nowMap.getKey(), Class.forName("ab.glue.api." + apiName));
                }
                Assert.assertEquals(nowMap.getValue(), GenericUtils.getJsonValue(jsonPath, responseString));
            }
        }
    }

    @Then("^The '(.*)' response should not be displayed with Credit/Debit Advice")
    public void verifyResponseNotDisplayedWithCreditDebitAdvice(String apiName) throws ParserConfigurationException, SAXException, XPathExpressionException, IOException, ClassNotFoundException, NoSuchFieldException, NoSuchAlgorithmException, NoSuchPaddingException {
      Assert.assertTrue("Response is displayed with credit debit advice. Actual response - "+responseString, !responseString.contains("\"virtualAccountId\""));
    }

    @Then("^The '(.*)' response should not be displayed with Payments Message")
    public void verifyResponseNotDisplayedWithPaymentsMessages(String apiName) throws ParserConfigurationException, SAXException, XPathExpressionException, IOException, ClassNotFoundException, NoSuchFieldException, NoSuchAlgorithmException, NoSuchPaddingException {
        Assert.assertTrue("Response is displayed with credit debit advice. Actual response - "+responseString, !responseString.contains("\"paymentContainerId\""));
    }

    @Then("^The '(.*)' response should not be displayed with Custody Message")
    public void verifyResponseNotDisplayedWithCustodyMessages(String apiName) throws ParserConfigurationException, SAXException, XPathExpressionException, IOException, ClassNotFoundException, NoSuchFieldException, NoSuchAlgorithmException, NoSuchPaddingException {
        Assert.assertTrue("Response is displayed with credit debit advice. Actual response - "+responseString, !responseString.contains("\"businessPartnerId\""));
    }

    @Then("^The '(.*)' response should displayed with '(\\d+)' number of transactions for the group '(.*)'")
    public void verifyResponseNotDisplayedWithCustodyMessages(String apiName,int number, String groupID) throws ParserConfigurationException, SAXException, XPathExpressionException, IOException, ClassNotFoundException, NoSuchFieldException, NoSuchAlgorithmException, NoSuchPaddingException {
        int numberOfTransactions = genericUtils.verifyNumberOfTransactions(responseString,groupID);
        Assert.assertTrue("Response is not displayed with "+number+ " of transactions. Actual number of transactions is "+numberOfTransactions, numberOfTransactions==number);
    }

    private void executeApiCalls(List<Map<String, Object>> data, Supplier<Pair<String, Integer>> supplier) {
        //RestAssured.useRelaxedHTTPSValidation();
        data.stream().forEach(m -> {
            try {
                SSLSocketFactory clientAuthFactory;
                String cert = (String)m.get("certificate");
                KeyStore keyStore = KeyStore.getInstance("PKCS12");
                if (cert != null) {
                    keyStore.load(getClass().getResourceAsStream("/test-data/" + cert.split("-")[0]), cert.split("-")[1].toCharArray());
                    clientAuthFactory = new SSLSocketFactory(keyStore, cert.split("-")[1]);
                } else {
                    keyStore.load(getClass().getResourceAsStream("/test-data/bny-cert.pfx"), "bny123".toCharArray());
                    clientAuthFactory = new SSLSocketFactory(keyStore, "bny123");
                }

                SSLConfig config = new SSLConfig().with().sslSocketFactory(clientAuthFactory).and().allowAllHostnames();
                RestAssured.config = RestAssured.config().sslConfig(config);

                supplier.get();

            } catch (Throwable t) {
                throw new RuntimeException(t.getMessage(),t);
            }
        });
    }

    private Pair<String,Integer> sendRequestFromTemplateAndDataTableToAPI(String apiName, String requestType, String params, String headers, String randomIDs, String groupID, List<Map<String, Object>> data) {

        if(!apiName.equals("OpenAPIPaymentStatusEnquiry"))
           randomMessageID = genericUtils.generateRandomNumber();
        try {
            String similarAPIName = apiName;
            String endpoint = EndPoint.class.getDeclaredField(apiName).getAnnotation(EndPoint.Data.class).name();
            if (apiName.equals("Consume") || apiName.equals("Recover"))
                similarAPIName = "Peek";
            Map<String, String> headerMap = new HashMap<String, String>();
            Map<String, String> paramMap = new HashMap<String, String>();
            String[] value = headers.split("\\|");
            KeyStore keyStore = null;
            String[] paramValue = params.split("\\|");
            if (!params.equals(""))
                for (String header : paramValue) {
                    paramMap.put(header.split("=")[0], header.split("=")[1]);
                }
            //headerMap.put("ResponseEncryptionType", "non");
            String json = "";
            Map obj = new HashMap<>();
            String token = "";
            activationKey activKey = new activationKey();
            if (!headers.equals(""))
                for (String header : value) {
                    headerMap.put(header.split("-")[0], header.split("-")[1]);
                }
            if (requestType.equals("POST")) {
                json = IOUtils.toString(getClass().getResourceAsStream("/test-data/" + apiName + ".json"));

                int size = data.get(0).size();
                int count = 0;
                if (!data.get(0).containsKey("NothingtoPass")) {
                    TransformDataTableToRequestBody transformDataTableToRequestBody =
                            new TransformDataTableToRequestBody(data, similarAPIName, json, count).invoke();
                    json = transformDataTableToRequestBody.getJson();
                }
                if (!randomIDs.equals("")) {
                    String[] randomIDsEntries = randomIDs.split("\\|");
                    for (String randomEntry : randomIDsEntries) {
                        String xpath = GenericUtils.getJSonPath(randomEntry, Class.forName("ab.glue.api." + similarAPIName));
                        if(pendingPaymentIds.size()!=0)
                        {
                            String randomMessageID  = genericUtils.generateRandomNumber();
                            json = GenericUtils.modifyJSONValues(xpath, json, randomMessageID);
                        }else{
                            json = GenericUtils.modifyJSONValues(xpath, json, randomMessageID);
                        }

                    }
                }

                obj = new ObjectMapper().readValue(json, Map.class);
                token = JWTTest.createTokenForObject(30L, obj, groupID);
            } else {
                activKey.a_POST_request_is_made_to_the_activationKey_API_for_Group(groupID);
                token = JWTTest.createTokenForGroup(30L, activKey.activationContent, activKey.key, groupID);
            }

            System.out.println("The request payload passed is " + json);
            json = json.replaceAll("\\\\", "");
            json = json.replaceAll("\r\n", "");
            System.out.println("payload is " + json);
            SSLConfig config = null;
            if (requestType.equals("POST")) {
                System.out.println("Calling getPOST " + System.currentTimeMillis() + " end point " + endpoint);
                response = genericUtils.getPOSTResponse(headerMap, token, endpoint, ContentType.TEXT);
                System.out.println("Called getPOST " + System.currentTimeMillis());
            } else {
                headerMap.put("JWTToken", token);
                response = genericUtils.getGETResponseWithParam(headerMap, paramMap, endpoint, ContentType.TEXT);
            }
            responseStatus = response.statusCode();
            responseString = response.thenReturn().asString();
            System.out.println("Response is " + responseString);
            System.out.println("Response status code is " + responseStatus);
        } catch (Throwable e) {
            throw new RuntimeException(e.getMessage(),e);
        }
        return Pair.of(randomMessageID,responseStatus);
    }

    @Then("^All submitted payments are successful within '(\\d+)' milliseconds for Group '(.*)'$")
    public void allSubmittedPaymentsAreSuccessfulWithinMilliseconds(int timeout, String groupID) throws Throwable {
        long timeOutLimit = System.currentTimeMillis()+timeout;
        ObjectMapper om = new ObjectMapper();

        while(!pendingPaymentIds.isEmpty()&&System.currentTimeMillis()<timeOutLimit){
            Map<String,Object> clientReferenceMap = new HashMap<>();
            clientReferenceMap.put("openAPITransactionStatusClientReferenceID", pendingPaymentIds);
            List<Map<String,Object>> requestBody = new LinkedList<>();
            requestBody.add(0,clientReferenceMap);
            Pair<String,Integer> response;
            do {
                response = sendRequestFromTemplateAndDataTableToAPI("OpenAPIPaymentStatusEnquiry", "POST", "", "ResponseEncryptionType-non", "", groupID, requestBody);
                if (response.getValue() != 200 && response.getValue() != 404 && response.getValue() != 403) {
                    fail("Unexpected response status: " + response.getValue());
                }
            } while (response.getValue() != 200);

            Map<String,Object> obj = om.readValue(GenericGlue.responseString,Map.class);
            List<Map<String,Object>> sts = (List<Map<String,Object>>)obj.get("statuses");
            for(Map<String,Object> st : sts) {
                if (st.get("statusCode").equals("91")) {
                    pendingPaymentIds.remove(st.get("endToEndId"));
                }
            }
        }
        Assert.assertTrue("Payment IDs are not processed within the timeout period. Payment not processed are - "+String.join(",", pendingPaymentIds),pendingPaymentIds.isEmpty());
    }

    private class TransformDataTableToRequestBody {
        private List<Map<String, Object>> data;
        private String similarAPIName;
        private String json;
        private int count;

        public TransformDataTableToRequestBody(List<Map<String, Object>> data, String similarAPIName, String json, int count) {
            this.data = data;
            this.similarAPIName = similarAPIName;
            this.json = json;
            this.count = count;
        }

        public String getJson() {
            return json;
        }

        public TransformDataTableToRequestBody invoke() throws IOException, NoSuchAlgorithmException, CertificateException, KeyManagementException, KeyStoreException, UnrecoverableKeyException, NoSuchFieldException, ClassNotFoundException, XPathExpressionException, ParserConfigurationException, SAXException, TransformerException {
            for (Map<String, Object> mapData : data) {
                for (Map.Entry<String, Object> nowMap : mapData.entrySet()) {
                    count++;
                    if (nowMap.getKey().equals("date") && nowMap.getValue().equals("")) {
                        json = json.replaceAll(",\"date\":\"\"}", "}");
                    } else {
                        System.out.println("The key is " + nowMap.getKey());
                        String xpath = GenericUtils.getJSonPath(nowMap.getKey(), Class.forName("ab.glue.api." + similarAPIName));

                        json = GenericUtils.modifyJSONValues(xpath, json, nowMap.getValue());
                    }
                }
            }
            return this;
        }
    }
}
