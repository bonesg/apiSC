package ab.glue.api;

import ab.api.tests.PeekAndConsumeTest;
import ab.common.PeekAndConsumeConfig;
import ab.utils.DataClass;
import ab.utils.GenericUtils;
import com.webmethods.jms.WmTopic;
import com.webmethods.jms.impl.WmConnectionFactoryImpl;
import cucumber.api.DataTable;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import org.apache.commons.io.IOUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.xpath.jaxp.XPathFactoryImpl;
import org.junit.Assert;
import org.springframework.util.ResourceUtils;
import org.w3c.dom.Document;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

import javax.jms.*;
import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerConfigurationException;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import javax.xml.xpath.*;
import java.io.*;
import java.math.BigDecimal;
import java.nio.charset.StandardCharsets;
import java.util.*;

import static ab.utils.DataClass.modifyXMLValues;
import static org.joda.time.Instant.now;

public class NewStub {

    static String[] arrayValue = null;
    public static BigDecimal modifiedapprvSeqNo;

    public static void main(String[] args) {
        sendFspMessage();
    }

    static XPathFactory factory;
    static XPath xPath;

    static {
        factory = new XPathFactoryImpl();
        xPath = factory.newXPath();
    }
public static String randomNumber = "";
    public static void sendFspMessage() {
        Connection connection = null;
        String contextFactory = "com.webmethods.jms.naming.WmJmsNamingCtxFactory";
        String JNDIUrl = "wmjmsnaming://@10.20.160.24:6661/EDMIFramework";
        String clientGroup = "admin";

        String connectionFactory = "CoreBanking_API_ConnectionFactory";
        String topicName = "scbCoreBankingTxnAlertCorpFinTxnNotifyV1T";
        Context namingContext = null;

        try {
            Properties env = new Properties();
            env.setProperty("java.naming.factory.initial", contextFactory);
            env.setProperty("java.naming.provider.url", JNDIUrl);
            env.setProperty("com.webmethods.jms.naming.clientgroup", clientGroup);
            env.setProperty("com.webmethods.jms.clientIDSharing", "true");
            System.setProperty("com.webmethods.jms.clientIDSharing", "true");

            namingContext = new InitialContext(env);

            WmConnectionFactoryImpl wmConnectionFactory = (WmConnectionFactoryImpl) namingContext.lookup(connectionFactory);
            File trustStoreResource = ResourceUtils.getFile("" +
                    "classpath:edmicorebankingtruststore.jks");
            wmConnectionFactory.setSSLTruststore(trustStoreResource.toString());

            connection = wmConnectionFactory.createConnection("ccsuser", "abc12345");

            System.out.println("Connection created " + connection.toString());
            Session session = connection.createSession(false, Session.AUTO_ACKNOWLEDGE);
            WmTopic dest = (WmTopic) namingContext.lookup(topicName);
            MessageProducer producer = session.createProducer(dest);
            TextMessage message = session.createTextMessage();

            String request = readFile("rta-template.xml");
            System.out.println("Sending Message " + request);
            message.setText(request);
            producer.send(message);
            System.out.println("Message Sent Successfully");

        } catch (Exception e) {
            System.out.println(e.toString());
        } finally {
            if (connection != null)
                try {
                    connection.close();
                    System.out.println("Connection Terminated");
                } catch (JMSException e) {
                    e.printStackTrace();
                }
        }
    }

    public static  String readFile(String filename) {
        String data = "";
        try {
            BufferedReader bufferedReader = new BufferedReader(new FileReader(new File(filename)));

            StringBuilder stringBuilder = new StringBuilder();
            String line = bufferedReader.readLine();
            while (line != null) {
                stringBuilder.append(line);
                line = bufferedReader.readLine();
            }
            data = stringBuilder.toString();
        } catch (Exception exception) {
            exception.printStackTrace();
        }
        return data;
    }

    @Then("^user should see transaction code accordingly in the Consume response for the group '(.*)'$")
    public void user_modifies_Stub_country_IN_transaction_system_EBBS_transaction_code(String groupID) throws Throwable {
        try {
            Connection connection = null;
            String contextFactory = "com.webmethods.jms.naming.WmJmsNamingCtxFactory";
            String JNDIUrl = "wmjmsnaming://@10.20.160.24:6661/EDMIFramework";
            String clientGroup = "admin";
            String connectionFactory = "CoreBanking_API_ConnectionFactory";
            String topicName = "scbCoreBankingTxnAlertCorpFinTxnNotifyV1T";
            Context namingContext = null;
            Properties env = new Properties();
            env.setProperty("java.naming.factory.initial", contextFactory);
            env.setProperty("java.naming.provider.url", JNDIUrl);
            env.setProperty("com.webmethods.jms.naming.clientgroup", clientGroup);
            env.setProperty("com.webmethods.jms.clientIDSharing", "true");
            System.setProperty("com.webmethods.jms.clientIDSharing", "true");
            namingContext = new InitialContext(env);
            WmConnectionFactoryImpl wmConnectionFactory = (WmConnectionFactoryImpl) namingContext.lookup(connectionFactory);
            File trustStoreResource = ResourceUtils.getFile("" +
                    "classpath:edmicorebankingtruststore.jks");
            wmConnectionFactory.setSSLTruststore(trustStoreResource.toString());
            connection = wmConnectionFactory.createConnection("ccsuser", "abc12345");
            System.out.println("Connection created " + connection.toString());
            Session session = connection.createSession(false, Session.AUTO_ACKNOWLEDGE);
            WmTopic dest = (WmTopic) namingContext.lookup(topicName);
            MessageProducer producer = session.createProducer(dest);
            TextMessage message = session.createTextMessage();
            //HashMap<String, String> data = ExcelReader.getExcelData();
            //data.entrySet();
            // ArrayList<String> data = ExcelReader.getExcelData();
            CADMMethods cadmMethods = new CADMMethods();
            String[] cadmEntry = cadmMethods.cadmResponse.split("}");
            int counter = 1;
            int countofmsgs = 1;
            int noOfTxnCodes = cadmEntry.length;
            String actualCadmGroup = "";
            if (cadmMethods.cadmResponse.contains(groupID)) {
                actualCadmGroup = groupID;
            } else
                actualCadmGroup = "*";
            for (int i = 0; i < noOfTxnCodes - 1; i++) {
                String value = cadmEntry[i];
                String boTrxCode = value.split("BOTransactionCode\":\"")[1].toString().replace("\"", "");
                String baicode = value.split("BAICode\":\"")[1].toString().split("\"")[0];
                String cadmGroupID = value.split("clientGroupId\":\"")[1].toString().split("\"")[0];

                if (!cadmGroupID.equals(actualCadmGroup)) {
                    continue;
                }
                String filepath = new File(".").getCanonicalPath() + "/src/test/resources/rta-templatecopy.xml";
                DocumentBuilderFactory docFactory = DocumentBuilderFactory.newInstance();
                DocumentBuilder docBuilder = docFactory.newDocumentBuilder();
                System.out.println(filepath);
                Document doc = docBuilder.parse(filepath);
                //System.out.println(doc);
                Node staff = doc.getElementsByTagName("notifyCorporateFinancialTransactionRequest").item(0);
                //System.out.println(staff);
                NodeList list = staff.getChildNodes();
                Node student = list.item(1);
                //System.out.println(student);
                NodeList list1 = student.getChildNodes();
                Node trxnRequest = list1.item(3);
                //System.out.println(trxnRequest);
                NodeList list2 = trxnRequest.getChildNodes();
                Node trxDetail = list2.item(1);
                //System.out.println(trxDetail);
                NodeList list8 = staff.getChildNodes();
                Node header = list8.item(1);
                System.out.println(header);
                NodeList head = header.getChildNodes();
                Node originationDetails = head.item(3);
                System.out.println(originationDetails);
                NodeList originationDetailsList = originationDetails.getChildNodes();
                Node correlationID = originationDetailsList.item(7);
                System.out.println(correlationID.getTextContent());
                int correlation = Integer.parseInt(correlationID.getTextContent());
                correlationID.setTextContent("" + (correlation + 1));
//                NodeList list3 = trxDetail.getChildNodes();
//                Node trxEntry = list3.item(1);
//                System.out.println(trxEntry);
//                trxEntry.setTextContent(arrayValue[1]);
//                Node trxEntry4 = list3.item(5);
//                System.out.println(trxEntry4);
//                trxEntry4.setTextContent(arrayValue[0]);
                NodeList entryList = staff.getChildNodes();
                Node entryValue = entryList.item(3);
                System.out.println(entryValue);
                NodeList entryList1 = entryValue.getChildNodes();
                Node entryValue1 = entryList1.item(5);
                System.out.println(entryValue1);
                NodeList entryList2 = entryValue1.getChildNodes();
                Node entryValue2 = entryList2.item(1);
                System.out.println(entryValue2);
                NodeList entryList3 = entryValue2.getChildNodes();
                Node entryValue3 = entryList3.item(1);
                System.out.println(entryValue3);
                NodeList entryList4 = entryValue3.getChildNodes();
                Node entryValue4 = entryList4.item(15);
                System.out.println(entryValue4);
                NodeList entryList5 = entryValue4.getChildNodes();
                Node entryValue5 = entryList5.item(1);
                String previousValue = entryValue5.getTextContent();
                entryValue5.setTextContent(boTrxCode);
                TransformerFactory transformerFactory = TransformerFactory.newInstance();
                Transformer transformer = transformerFactory.newTransformer();
                DOMSource source = new DOMSource(doc);
                StreamResult result = new StreamResult(new File(filepath));
                transformer.transform(source, result);
                String request = readFile(filepath);
                // System.out.println("Sending Message " + request);
                message.setText(request);
                producer.send(message);
                System.out.println("Message Sent Successfully with transaction code - " + boTrxCode);

                PeekAndConsumeConfig peekAndConsumeConfig = new PeekAndConsumeConfig();
                activationKey activationKey1 = new activationKey();
                if (activationKey1.activationContent == null)
                    activationKey1.a_POST_request_is_made_to_the_activationKey_API_for_Group(groupID);
                activationKey1.user_has_already_generated_the_JWT_token_for_the_group(groupID);
                Thread.sleep(4000);
                String actualResponse = peekAndConsumeConfig.getPeekConsumeResponseAsString(ab.glue.api.activationKey.activKey.get(groupID), "consume").trim();
                if (actualResponse.equals("{\"messageId\":\"\",\"content\":[]}")) {
                    counter++;
                    System.out.println("Count of empty messages " + counter + ". transaction code passed is - " + boTrxCode);
                    Thread.sleep(3000);
                    peekAndConsumeConfig.getPeekConsumeResponseAsString(ab.glue.api.activationKey.activKey.get(groupID), "consume").trim();
                } else if (actualResponse.contains("<TITLE>Server Error</TITLE>") || actualResponse.contains("<TITLE>Network Error</TITLE>")) {
                    System.out.println("503 error displayed when transaction code passed is - " + boTrxCode);
                } else if (boTrxCode.equals("623") && (actualCadmGroup.equals("*"))) {
                    Assert.assertTrue("Expected code - " + boTrxCode + ". Actual response" + actualResponse + ". The CADM groupID is " + cadmGroupID, actualResponse.contains("transactionCode\":\"" + boTrxCode));
                    Assert.assertTrue("Expected code - " + 475 + ". Actual response" + actualResponse + ". The CADM groupID is " + cadmGroupID, actualResponse.contains("baiCode\":\"" + 475));

                } else if (boTrxCode.equals("510") && (actualCadmGroup.equals("*"))) {
                    Assert.assertTrue("Expected code - " + boTrxCode + ". Actual response" + actualResponse + ". The CADM groupID is " + cadmGroupID, actualResponse.contains("transactionCode\":\"" + boTrxCode));
                    Assert.assertTrue("Expected code - " + 175 + ". Actual response" + actualResponse + ". The CADM groupID is " + cadmGroupID, actualResponse.contains("baiCode\":\"" + 175));

                } else if (boTrxCode.equals("300") && (actualCadmGroup.equals("*"))) {
                    Assert.assertTrue("Expected code - " + boTrxCode + ". Actual response" + actualResponse + ". The CADM groupID is " + cadmGroupID, actualResponse.contains("transactionCode\":\"" + boTrxCode));
                    Assert.assertTrue("Expected code - " + 654 + ". Actual response" + actualResponse + ". The CADM groupID is " + cadmGroupID, actualResponse.contains("baiCode\":\"" + 654));

                } else if (boTrxCode.equals("251") && (actualCadmGroup.equals("GMY21362"))) {
                    Assert.assertTrue("Expected code - " + boTrxCode + ". Actual response" + actualResponse + ". The CADM groupID is " + cadmGroupID, actualResponse.contains("transactionCode\":\"" + boTrxCode));
                    Assert.assertTrue("Expected code - " + 506 + ". Actual response" + actualResponse + ". The CADM groupID is " + cadmGroupID, actualResponse.contains("baiCode\":\"" + 506));

                } else if (boTrxCode.equals("516") && (actualCadmGroup.equals("GMY21362"))) {
                    Assert.assertTrue("Expected code - " + boTrxCode + ". Actual response" + actualResponse + ". The CADM groupID is " + cadmGroupID, actualResponse.contains("transactionCode\":\"" + boTrxCode));
                    Assert.assertTrue("Expected code - " + 175 + ". Actual response" + actualResponse + ". The CADM groupID is " + cadmGroupID, actualResponse.contains("baiCode\":\"" + 175));

                } else {
                    countofmsgs++;
                      Assert.assertTrue("Expected code - " + boTrxCode + ". Actual response" + actualResponse+". The CADM groupID is "+cadmGroupID, actualResponse.contains("transactionCode\":\"" + boTrxCode));
                      Assert.assertTrue("Expected code - " + baicode + ". Actual response" + actualResponse+". The CADM groupID is "+cadmGroupID, actualResponse.contains("baiCode\":\"" + baicode));
                    System.out.println("count of msgs received" + i);
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
            throw e;
        } catch (Throwable throwable) {
            throwable.printStackTrace();
            throw throwable;
        }
    }

//    @Then("^user should see transaction code accordingly in the Consume response$")
//    public void user_modifies_Stub_country_IN_transaction_system_EBBS_transaction_code()throws IOException, ParserConfigurationException, SAXException, TransformerConfigurationException {
//        try {
//            Connection connection = null;
//            String contextFactory = "com.webmethods.jms.naming.WmJmsNamingCtxFactory";
//            String JNDIUrl = "wmjmsnaming://@10.20.160.24:6661/EDMIFramework";
//            String clientGroup = "admin";
//            String connectionFactory = "CoreBanking_API_ConnectionFactory";
//            String topicName = "scbCoreBankingTxnAlertCorpFinTxnNotifyV1T";
//            Context namingContext = null;
//            Properties env = new Properties();
//            env.setProperty("java.naming.factory.initial", contextFactory);
//            env.setProperty("java.naming.provider.url", JNDIUrl);
//            env.setProperty("com.webmethods.jms.naming.clientgroup", clientGroup);
//            env.setProperty("com.webmethods.jms.clientIDSharing", "true");
//            System.setProperty("com.webmethods.jms.clientIDSharing", "true");
//            namingContext = new InitialContext(env);
//            WmConnectionFactoryImpl wmConnectionFactory = (WmConnectionFactoryImpl) namingContext.lookup(connectionFactory);
//            File trustStoreResource = ResourceUtils.getFile("" +
//                    "classpath:edmicorebankingtruststore.jks");
//            wmConnectionFactory.setSSLTruststore(trustStoreResource.toString());
//            connection = wmConnectionFactory.createConnection("ccsuser", "abc12345");
//            System.out.println("Connection created " + connection.toString());
//            Session session = connection.createSession(false, Session.AUTO_ACKNOWLEDGE);
//            WmTopic dest = (WmTopic) namingContext.lookup(topicName);
//            MessageProducer producer = session.createProducer(dest);
//            TextMessage message = session.createTextMessage();
//            //HashMap<String, String> data = ExcelReader.getExcelData();
//            //data.entrySet();
//            ArrayList<String> data = ExcelReader.getExcelData();
//            for(String value : data) {
//                arrayValue = value.split("\\|");
//                String filepath = new File(".").getCanonicalPath() + "/src/test/resources/rta-template.xml";
//                DocumentBuilderFactory docFactory = DocumentBuilderFactory.newInstance();
//                DocumentBuilder docBuilder = docFactory.newDocumentBuilder();
//                System.out.println(filepath);
//                Document doc = docBuilder.parse(filepath);
//                System.out.println(doc);
//                Node staff = doc.getElementsByTagName("notifyCorporateFinancialTransactionRequest").item(0);
//                System.out.println(staff);
//                NodeList list = staff.getChildNodes();
//                Node student = list.item(1);
//                System.out.println(student);
//                NodeList list1 = student.getChildNodes();
//                Node trxnRequest = list1.item(3);
//                System.out.println(trxnRequest);
//                NodeList list2 = trxnRequest.getChildNodes();
//                Node trxDetail = list2.item(1);
//                System.out.println(trxDetail);
//                NodeList list3 = trxDetail.getChildNodes();
//                Node trxEntry = list3.item(1);
//                System.out.println(trxEntry);
//                trxEntry.setTextContent(arrayValue[1]);
//                Node trxEntry4 = list3.item(5);
//                System.out.println(trxEntry4);
//                trxEntry4.setTextContent(arrayValue[0]);
//                NodeList entryList = staff.getChildNodes();
//                Node entryValue = entryList.item(3);
//                System.out.println(entryValue);
//                NodeList entryList1 = entryValue.getChildNodes();
//                Node entryValue1 = entryList1.item(5);
//                System.out.println(entryValue1);
//                NodeList entryList2 = entryValue1.getChildNodes();
//                Node entryValue2 = entryList2.item(1);
//                System.out.println(entryValue2);
//                NodeList entryList3 = entryValue2.getChildNodes();
//                Node entryValue3 = entryList3.item(1);
//                System.out.println(entryValue3);
//                NodeList entryList4 = entryValue3.getChildNodes();
//                Node entryValue4 = entryList4.item(15);
//                System.out.println(entryValue4);
//                NodeList entryList5 = entryValue4.getChildNodes();
//                Node entryValue5 = entryList5.item(1);
//                entryValue5.setTextContent(arrayValue[2]);
//                TransformerFactory transformerFactory = TransformerFactory.newInstance();
//                Transformer transformer = transformerFactory.newTransformer();
//                DOMSource source = new DOMSource(doc);
//                StreamResult result = new StreamResult(new File(filepath));
//                transformer.transform(source, result);
//                String request = readFile(filepath);
//                System.out.println("Sending Message " + request);
//                message.setText(request);
//                producer.send(message);
//                System.out.println("Message Sent Successfully");
//                PeekAndConsumeConfig peekAndConsumeConfig = new PeekAndConsumeConfig();
//                activationKey activationKey1 = new activationKey();
//                activationKey1.user_has_already_generated_the_JWT_token_for_the_group("INDGRP1");
//                String actualResponse = peekAndConsumeConfig.getPeekConsumeResponseAsString(ab.glue.api.activationKey.activKey.get("INDGRP1"), "consume").trim();
//                Assert.assertTrue(actualResponse.contains(arrayValue[3]));
//            }
//        } catch (Exception e) {
//            e.printStackTrace();
//        } catch (Throwable throwable) {
//            throwable.printStackTrace();
//        }
//    }

    @When("^user publishes transaction with amount '(.*)' account number '(.+)' transaction type '(.+)' Currency Code '(.+)' BIC '(.+)'$")
    public void modifyxml1(String amount, String accountNumber, String trxType, String currencyCode, String bic) throws IOException, ParserConfigurationException, SAXException, TransformerConfigurationException {
        try {
            String filepath = new File(".").getCanonicalPath() + "/src/test/resources/rta-template.xml";
            DocumentBuilderFactory docFactory = DocumentBuilderFactory.newInstance();
            DocumentBuilder docBuilder = docFactory.newDocumentBuilder();
            // System.out.println(filepath);
            Document doc = docBuilder.parse(filepath);
            System.out.println(doc);
            Node staff = doc.getElementsByTagName("notifyCorporateFinancialTransactionRequest").item(0);
            System.out.println(staff);
            NodeList list = staff.getChildNodes();
            Node student = list.item(3);
            System.out.println(student);
            NodeList list1 = student.getChildNodes();
            Node trxnRequest = list1.item(5);
            System.out.println(trxnRequest);
            NodeList list2 = trxnRequest.getChildNodes();
            Node trxDetail = list2.item(1);
            System.out.println(trxDetail);
            NodeList list3 = trxDetail.getChildNodes();
            Node trxEntry = list3.item(1);
            //System.out.println(student);
            NodeList lists = trxEntry.getChildNodes();


            NodeList list8 = staff.getChildNodes();
            Node header = list8.item(1);
            System.out.println(header);
            NodeList head = header.getChildNodes();
            Node originationDetails = head.item(3);
            System.out.println(originationDetails);
            NodeList originationDetailsList = originationDetails.getChildNodes();
            Node correlationID = originationDetailsList.item(7);
            System.out.println(correlationID.getTextContent());
            int correlation = Integer.parseInt(correlationID.getTextContent());
            correlationID.setTextContent("" + (correlation + 1));
            for (int i = 0; i < lists.getLength(); i++) {

                Node node = lists.item(i);
                // get the salary element, and update the value
                if (node.getNodeName().equals("tns:TrnAmount")) {
                    node.setTextContent(amount);
                    System.out.println(node.getTextContent());

                }
                if (node.getNodeName().equals("tns:Account")) {
                    NodeList accountList = node.getChildNodes();
                    Node currencyCodeNode = accountList.item(1);
                    currencyCodeNode.setTextContent(currencyCode);
                    System.out.println(currencyCodeNode.getTextContent());
                    Node accountNo = accountList.item(3);
                    accountNo.setTextContent(accountNumber);
                    System.out.println(accountNo.getTextContent());
                }
                if (node.getNodeName().equals("tns:CreditDebitFlag")) {
                    node.setTextContent(trxType);
                    System.out.println(node.getTextContent());
                }
                if (node.getNodeName().contains("tns:SwiftAddress")) {
                    node.setTextContent(bic);
                    System.out.println(node.getTextContent());
                } if (node.getNodeName().equals("tns:TrnReference")) {
                    NodeList accountList = node.getChildNodes();
                    Node currencyCodeNode = accountList.item(1);
                    currencyCodeNode.setTextContent(currencyCode);
                    System.out.println(currencyCodeNode.getTextContent());
                }
            }
            TransformerFactory transformerFactory = TransformerFactory.newInstance();
            Transformer transformer = transformerFactory.newTransformer();
            DOMSource source = new DOMSource(doc);
            StreamResult result = new StreamResult(new File(filepath));
            transformer.transform(source, result);
            Connection connection = null;
            String contextFactory = "com.webmethods.jms.naming.WmJmsNamingCtxFactory";
            String JNDIUrl = "wmjmsnaming://@10.20.160.24:6661/EDMIFramework";
            String clientGroup = "admin";

            String connectionFactory = "CoreBanking_API_ConnectionFactory";
            String topicName = "scbCoreBankingTxnAlertCorpFinTxnNotifyV1T";
            Context namingContext = null;

            try {
                Properties env = new Properties();
                env.setProperty("java.naming.factory.initial", contextFactory);
                env.setProperty("java.naming.provider.url", JNDIUrl);
                env.setProperty("com.webmethods.jms.naming.clientgroup", clientGroup);
                env.setProperty("com.webmethods.jms.clientIDSharing", "true");
                System.setProperty("com.webmethods.jms.clientIDSharing", "true");

                namingContext = new InitialContext(env);

                WmConnectionFactoryImpl wmConnectionFactory = (WmConnectionFactoryImpl) namingContext.lookup(connectionFactory);
                File trustStoreResource = ResourceUtils.getFile("" +
                        "classpath:edmicorebankingtruststore.jks");
                wmConnectionFactory.setSSLTruststore(trustStoreResource.toString());

                connection = wmConnectionFactory.createConnection("ccsuser", "abc12345");

                System.out.println("Connection created " + connection.toString());
                Session session = connection.createSession(false, Session.AUTO_ACKNOWLEDGE);
                WmTopic dest = (WmTopic) namingContext.lookup(topicName);
                MessageProducer producer = session.createProducer(dest);
                TextMessage message = session.createTextMessage();

                String request = readFile(filepath);
                //System.out.println("Sending Message " + request);
                message.setText(request);
                producer.send(message);
                System.out.println("Message Sent Successfully"+request);
            Thread.sleep(5000);
            } catch (Exception e) {
                e.printStackTrace();
            }
        } catch (TransformerException e) {
            e.printStackTrace();
        }
    }




    @When("user performs transaction")
    public void performTransactionWithDetails(List<Map<String, String>> data) throws IOException, XPathExpressionException, SAXException, ParserConfigurationException, TransformerException, JMSException, NamingException, InterruptedException {
       String xml = PeekAndConsumeTest.inputStreamToString(getClass().getResourceAsStream("/rta-template.xml"));
        xml = DataClass.getXMLWithNewCorrelationID(xml);
        TransformerFactory transformerFactory = TransformerFactory.newInstance();
        Transformer transformer = transformerFactory.newTransformer();
        DocumentBuilderFactory docFactory = DocumentBuilderFactory.newInstance();
        DocumentBuilder docBuilder = docFactory.newDocumentBuilder();
        DOMSource source = new DOMSource(docBuilder.parse(new ByteArrayInputStream(xml.getBytes(StandardCharsets.UTF_8))));
        String filepath = new File(".").getCanonicalPath() + "/src/test/resources/rta-template.xml";
        StreamResult result = new StreamResult(new File(filepath));
        transformer.transform(source, result);
        for (Map<String, String> mapData : data) {

            for (Map.Entry<String, String> nowMap : mapData.entrySet()) {
                String xpath = DataClass.getXpath(nowMap.getKey());
                    xml =  modifyXMLValues(xpath, xml,nowMap.getValue());
            }
        }

        Connection connection = null;
        String contextFactory = "com.webmethods.jms.naming.WmJmsNamingCtxFactory";
        String JNDIUrl = "wmjmsnaming://@10.20.160.24:6661/EDMIFramework";
        String clientGroup = "admin";

        String connectionFactory = "CoreBanking_API_ConnectionFactory";
        String topicName = "scbCoreBankingTxnAlertCorpFinTxnNotifyV1T";
        Context namingContext = null;

            Properties env = new Properties();
            env.setProperty("java.naming.factory.initial", contextFactory);
            env.setProperty("java.naming.provider.url", JNDIUrl);
            env.setProperty("com.webmethods.jms.naming.clientgroup", clientGroup);
            env.setProperty("com.webmethods.jms.clientIDSharing", "true");
            System.setProperty("com.webmethods.jms.clientIDSharing", "true");

            namingContext = new InitialContext(env);

            WmConnectionFactoryImpl wmConnectionFactory = (WmConnectionFactoryImpl) namingContext.lookup(connectionFactory);
            File trustStoreResource = ResourceUtils.getFile("" +
                    "classpath:edmicorebankingtruststore.jks");
            wmConnectionFactory.setSSLTruststore(trustStoreResource.toString());

            connection = wmConnectionFactory.createConnection("ccsuser", "abc12345");

            System.out.println("Connection created " + connection.toString());
            Session session = connection.createSession(false, Session.AUTO_ACKNOWLEDGE);
            WmTopic dest = (WmTopic) namingContext.lookup(topicName);
            MessageProducer producer = session.createProducer(dest);
            TextMessage message = session.createTextMessage();


            //System.out.println("Sending Message " + request);
            message.setText(xml);
            producer.send(message);
            System.out.println("Message Sent Successfully - "+xml);
            Thread.sleep(10000);

    }

    @When("user posts a transaction with details")
    public void modifyxmlValues(DataTable dataTable) throws IOException, ParserConfigurationException, SAXException, XPathExpressionException {
        try {
            String amount = dataTable.asLists(String.class).get(1).get(0);
            String accountNumber = dataTable.asLists(String.class).get(1).get(1);
            String transactionType = dataTable.asLists(String.class).get(1).get(2);
            String currency = dataTable.asLists(String.class).get(1).get(3);
            String bic = dataTable.asLists(String.class).get(1).get(4);
            String transactionCode = "  " + dataTable.asLists(String.class).get(1).get(5) + "  ";
            String countryCode = dataTable.asLists(String.class).get(1).get(6);
            String filepath = new File(".").getCanonicalPath() + "/src/test/resources/rta-templatetxncode.xml";
            DocumentBuilderFactory docFactory = DocumentBuilderFactory.newInstance();
            DocumentBuilder docBuilder = docFactory.newDocumentBuilder();

            // System.out.println(filepath);
            Document doc = docBuilder.parse(filepath);
            System.out.println(doc);
            String xml = IOUtils.toString(getClass().getResourceAsStream( "/rta-templatetxncode.xml"));
            XPathExpression expr =
                    xPath.compile("//correlationID/text()");
            int correlationID = Integer.parseInt((String) expr.evaluate(doc, XPathConstants.STRING));
            int modifiedCorrelationID = correlationID + 1;
            xml = StringUtils.replace(xml, "<ns:correlationID>" + correlationID + "</ns:correlationID>", "<ns:correlationID>" + modifiedCorrelationID + "</ns:correlationID>");
            TransformerFactory transformerFactory = TransformerFactory.newInstance();
            Transformer transformer = transformerFactory.newTransformer();
            DOMSource source = new DOMSource(docBuilder.parse(new ByteArrayInputStream(xml.getBytes(StandardCharsets.UTF_8))));
            StreamResult result = new StreamResult(new File(filepath));
            transformer.transform(source, result);
            xml = StringUtils.replace(xml, "${amount}", amount);
            xml = StringUtils.replace(xml, "${accountNumber}", accountNumber);
            xml = StringUtils.replace(xml, "${transactionType}", transactionType);
            xml = StringUtils.replace(xml, "${currency}", currency);
            xml = StringUtils.replace(xml, "${bic}", bic);
            xml = StringUtils.replace(xml, "${transactionCode}", transactionCode);
            xml = StringUtils.replace(xml, "${countryCode}", countryCode);
            Connection connection = null;
            String contextFactory = "com.webmethods.jms.naming.WmJmsNamingCtxFactory";
            String JNDIUrl = "wmjmsnaming://@10.20.160.24:6661/EDMIFramework";
            String clientGroup = "admin";

            String connectionFactory = "CoreBanking_API_ConnectionFactory";
            String topicName = "scbCoreBankingTxnAlertCorpFinTxnNotifyV1T";
            Context namingContext = null;

            try {
                Properties env = new Properties();
                env.setProperty("java.naming.factory.initial", contextFactory);
                env.setProperty("java.naming.provider.url", JNDIUrl);
                env.setProperty("com.webmethods.jms.naming.clientgroup", clientGroup);
                env.setProperty("com.webmethods.jms.clientIDSharing", "true");
                System.setProperty("com.webmethods.jms.clientIDSharing", "true");

                namingContext = new InitialContext(env);

                WmConnectionFactoryImpl wmConnectionFactory = (WmConnectionFactoryImpl) namingContext.lookup(connectionFactory);
                File trustStoreResource = ResourceUtils.getFile("" +
                        "classpath:edmicorebankingtruststore.jks");
                wmConnectionFactory.setSSLTruststore(trustStoreResource.toString());

                connection = wmConnectionFactory.createConnection("ccsuser", "abc12345");

                System.out.println("Connection created " + connection.toString());
                Session session = connection.createSession(false, Session.AUTO_ACKNOWLEDGE);
                WmTopic dest = (WmTopic) namingContext.lookup(topicName);
                MessageProducer producer = session.createProducer(dest);
                TextMessage message = session.createTextMessage();

                //String request = readFile(filepath);
                System.out.println("Sending Message " + xml);
                message.setText(xml);
                producer.send(message);
                System.out.println("Message Sent Successfully");
            } catch (Exception e) {
                e.printStackTrace();
            }
        } catch (TransformerException e) {
            e.printStackTrace();
        }
    }



    @When("user posts a transaction with unique Transaction code with details")
    public void modifyXMLWithUniqueTransactionCode(DataTable dataTable) throws IOException, ParserConfigurationException, SAXException, XPathExpressionException {
        try {
            String amount = dataTable.asLists(String.class).get(1).get(0);
            String accountNumber = dataTable.asLists(String.class).get(1).get(1);
            String transactionType = dataTable.asLists(String.class).get(1).get(2);
            String currency = dataTable.asLists(String.class).get(1).get(3);
            String bic = dataTable.asLists(String.class).get(1).get(4);
            String transactionCode = "  " + dataTable.asLists(String.class).get(1).get(5) + "  ";
            String countryCode = dataTable.asLists(String.class).get(1).get(6);
            String ledger = dataTable.asLists(String.class).get(1).get(7);
            String processingSystem = dataTable.asLists(String.class).get(1).get(8);
            String filepath = new File(".").getCanonicalPath() + "/src/test/resources/rta-templatecopy.xml";
            DocumentBuilderFactory docFactory = DocumentBuilderFactory.newInstance();
            DocumentBuilder docBuilder = docFactory.newDocumentBuilder();

            // System.out.println(filepath);
            Document doc = docBuilder.parse(filepath);
            System.out.println(doc);
            String xml = IOUtils.toString(new FileInputStream(new File(filepath)));
            XPathExpression expr =
                    xPath.compile("//correlationID/text()");
            int correlationID = Integer.parseInt((String) expr.evaluate(doc, XPathConstants.STRING));
            int modifiedCorrelationID = correlationID + 1;
            XPathExpression expr1 =
                    xPath.compile("//ApprvSeqno/text()");
            BigDecimal apprvSeqNo = new BigDecimal((String) expr1.evaluate(doc, XPathConstants.STRING));
            modifiedapprvSeqNo = apprvSeqNo.add(new BigDecimal(1));
            xml = StringUtils.replace(xml, "<ns:correlationID>" + correlationID + "</ns:correlationID>", "<ns:correlationID>" + modifiedCorrelationID + "</ns:correlationID>");
            xml = StringUtils.replace(xml, "<tns:ApprvSeqno>" + apprvSeqNo + "</tns:ApprvSeqno>", "<tns:ApprvSeqno>" + modifiedapprvSeqNo + "</tns:ApprvSeqno>");

            TransformerFactory transformerFactory = TransformerFactory.newInstance();
            Transformer transformer = transformerFactory.newTransformer();
            DOMSource source = new DOMSource(docBuilder.parse(new ByteArrayInputStream(xml.getBytes(StandardCharsets.UTF_8))));
            StreamResult result = new StreamResult(new File(filepath));
            transformer.transform(source, result);
            xml = StringUtils.replace(xml, "${amount}", amount);
            xml = StringUtils.replace(xml, "${accountNumber}", accountNumber);
            xml = StringUtils.replace(xml, "${transactionType}", transactionType);
            xml = StringUtils.replace(xml, "${currency}", currency);
            xml = StringUtils.replace(xml, "${bic}", bic);
            xml = StringUtils.replace(xml, "${transactionCode}", transactionCode);
            xml = StringUtils.replace(xml, "${countryCode}", countryCode);
            xml = StringUtils.replace(xml, "${ledger}", ledger);
            xml = StringUtils.replace(xml, "${processingSystem}", processingSystem);
            Connection connection = null;
            String contextFactory = "com.webmethods.jms.naming.WmJmsNamingCtxFactory";
            String JNDIUrl = "wmjmsnaming://@10.20.160.24:6661/EDMIFramework";
            String clientGroup = "admin";

            String connectionFactory = "CoreBanking_API_ConnectionFactory";
            String topicName = "scbCoreBankingTxnAlertCorpFinTxnNotifyV1T";
            Context namingContext = null;

            try {
                Properties env = new Properties();
                env.setProperty("java.naming.factory.initial", contextFactory);
                env.setProperty("java.naming.provider.url", JNDIUrl);
                env.setProperty("com.webmethods.jms.naming.clientgroup", clientGroup);
                env.setProperty("com.webmethods.jms.clientIDSharing", "true");
                System.setProperty("com.webmethods.jms.clientIDSharing", "true");

                namingContext = new InitialContext(env);

                WmConnectionFactoryImpl wmConnectionFactory = (WmConnectionFactoryImpl) namingContext.lookup(connectionFactory);
                File trustStoreResource = ResourceUtils.getFile("" +
                        "classpath:edmicorebankingtruststore.jks");
                wmConnectionFactory.setSSLTruststore(trustStoreResource.toString());

                connection = wmConnectionFactory.createConnection("ccsuser", "abc12345");

                System.out.println("Connection created " + connection.toString());
                Session session = connection.createSession(false, Session.AUTO_ACKNOWLEDGE);
                WmTopic dest = (WmTopic) namingContext.lookup(topicName);
                MessageProducer producer = session.createProducer(dest);
                TextMessage message = session.createTextMessage();

                //String request = readFile(filepath);
                System.out.println("Sending Message " + xml);
                message.setText(xml);
                producer.send(message);
                System.out.println("Message Sent Successfully");
            } catch (Exception e) {
                e.printStackTrace();
            }
        } catch (TransformerException e) {
            e.printStackTrace();
        }
    }


    @When("user posts a custody transaction with details")
    public void sendCustodyTransaction(DataTable dataTable) throws IOException, ParserConfigurationException, SAXException, XPathExpressionException {
        try {
            List<List<String>> trns= dataTable.asLists(String.class);
            List<String> keys= trns.get(0);
            List<String> values= trns.get(1);
//            String bpID = "";
//            String scaAccountNumber = "";
//            String clientTransactionReference = "";
//            for(int i=0;i<keys.size();i++){
//                if(keys.get(i).equals("bpID"))
//                    bpID = values.get(i);
//                else if(keys.get(i).equals("scaAccountNumber"))
//                    scaAccountNumber = values.get(i);
//                else if(keys.get(i).equals("clientTransactionReference"))
//                    clientTransactionReference = values.get(i);
//                else if(keys.get(i).equals("clientTransactionReference"))
//                    clientTransactionReference = values.get(i);
//                else if(keys.get(i).)
//            }
//            String amount = dataTable.asLists(String.class).get(1).get(0);
//            String sc = dataTable.asLists(String.class).get(1).get(1);
//            String transactionType = dataTable.asLists(String.class).get(1).get(2);
//            String currency = dataTable.asLists(String.class).get(1).get(3);
//            String bic = dataTable.asLists(String.class).get(1).get(4);
//            String transactionCode = "  " + dataTable.asLists(String.class).get(1).get(5) + "  ";
//            String countryCode = dataTable.asLists(String.class).get(1).get(6);
//            String ledger = dataTable.asLists(String.class).get(1).get(7);
//            String processingSystem = dataTable.asLists(String.class).get(1).get(8);
            String filepath = new File(".").getCanonicalPath() + "/src/test/resources/test-data/custody-transaction-status.xml";
            DocumentBuilderFactory docFactory = DocumentBuilderFactory.newInstance();
            DocumentBuilder docBuilder = docFactory.newDocumentBuilder();

            // System.out.println(filepath);
            Document doc = docBuilder.parse(filepath);
            System.out.println(doc);
            String xml = IOUtils.toString(getClass().getResourceAsStream("/test-data/custody-transaction-status.xml"));

            TransformerFactory transformerFactory = TransformerFactory.newInstance();
            Transformer transformer = transformerFactory.newTransformer();
            DOMSource source = new DOMSource(docBuilder.parse(new ByteArrayInputStream(xml.getBytes(StandardCharsets.UTF_8))));
            StreamResult result = new StreamResult(new File(filepath));
            transformer.transform(source, result);

            Connection connection = null;
            String contextFactory = "com.webmethods.jms.naming.WmJmsNamingCtxFactory";
            String JNDIUrl = "wmjmsnaming://CS0T1_Jndi@gateway-hk.npedmi.standardchartered.com:6312/EDMIFramework";
            String clientGroup = "admin";

            String connectionFactory = "Security_S2BNG_CF";
            String topicName = "scbSecurityCustodyTransactionNotifyTransactionStatusV1ReqTTs";
            Context namingContext = null;

            try {
                Properties env = new Properties();
                env.setProperty("java.naming.factory.initial", contextFactory);
                env.setProperty("java.naming.provider.url", JNDIUrl);
                env.setProperty("com.webmethods.jms.naming.clientgroup", clientGroup);
                env.setProperty("com.webmethods.jms.clientIDSharing", "true");
                System.setProperty("com.webmethods.jms.clientIDSharing", "true");

                namingContext = new InitialContext(env);

                WmConnectionFactoryImpl wmConnectionFactory = (WmConnectionFactoryImpl) namingContext.lookup(connectionFactory);
                File trustStoreResource = ResourceUtils.getFile("" +
                        "classpath:npedmi.jks");
                wmConnectionFactory.setSSLTruststore(trustStoreResource.toString());

                connection = wmConnectionFactory.createConnection("vppedmiuser", "");

                System.out.println("Connection created " + connection.toString());
                Session session = connection.createSession(false, Session.AUTO_ACKNOWLEDGE);
                WmTopic dest = (WmTopic) namingContext.lookup(topicName);
                MessageProducer producer = session.createProducer(dest);
                TextMessage message = session.createTextMessage();

                //String request = readFile(filepath);
                System.out.println("Sending Message " + xml);
                message.setText(xml);
                producer.send(message);
                System.out.println("Message Sent Successfully");
            } catch (Exception e) {
                e.printStackTrace();
            }
        } catch (TransformerException e) {
            e.printStackTrace();
        }
    }


    @When("^user loops Stub with format as '(.*)' with amount '(.+)' account number '(.+)' transaction type '(.+)' Currency Code '(.+)' BIC '(.+)' for '(.+)' times$")
    public void modifyxmlformat(String format, String amount, String accountNumber, String trxType, String currencyCode, String bic, int n) throws IOException, ParserConfigurationException, SAXException, TransformerConfigurationException, InterruptedException, NamingException, JMSException {

        String contextFactory = "com.webmethods.jms.naming.WmJmsNamingCtxFactory";
        String JNDIUrl = "wmjmsnaming://@10.20.160.24:6661/EDMIFramework";
        String clientGroup = "admin";

        String connectionFactory = "CoreBanking_API_ConnectionFactory";
        String topicName = "scbCoreBankingTxnAlertCorpFinTxnNotifyV1T";
        Context namingContext = null;

        Properties env = new Properties();
        env.setProperty("java.naming.factory.initial", contextFactory);
        env.setProperty("java.naming.provider.url", JNDIUrl);
        env.setProperty("com.webmethods.jms.naming.clientgroup", clientGroup);
        env.setProperty("com.webmethods.jms.clientIDSharing", "true");
        System.setProperty("com.webmethods.jms.clientIDSharing", "true");

        namingContext = new InitialContext(env);

        WmConnectionFactoryImpl wmConnectionFactory = (WmConnectionFactoryImpl) namingContext.lookup(connectionFactory);
        File trustStoreResource = ResourceUtils.getFile("" +
                "classpath:edmicorebankingtruststore.jks");
        wmConnectionFactory.setSSLTruststore(trustStoreResource.toString());

        Connection connection = wmConnectionFactory.createConnection("ccsuser", "abc12345");

        System.out.println("Connection created " + connection.toString());
        Session session = connection.createSession(false, Session.AUTO_ACKNOWLEDGE);
        WmTopic dest = (WmTopic) namingContext.lookup(topicName);
        MessageProducer producer = session.createProducer(dest);

        BigDecimal amt = new BigDecimal(amount);
        //n = amt + n;
        for (int j = 0; j < n; j++)
            try {
                Thread.sleep(1000);
                amt = amt.add(new BigDecimal(j));
                String filepath = new File(".").getCanonicalPath() + "/src/test/resources/" + format;
                DocumentBuilderFactory docFactory = DocumentBuilderFactory.newInstance();
                DocumentBuilder docBuilder = docFactory.newDocumentBuilder();
                System.out.println(filepath);
                Document doc = docBuilder.parse(filepath);
                System.out.println(doc);
//                Node staff = null;
//                NodeList list = null;
//                Node student = null;
//                if (doc.getElementsByTagName("notifyCorporateFinancialTransactionRequest").item(0) == null&&doc.getElementsByTagName("notifyInternalAccountsTransactionRequest").item(0)!=null) {
//                    staff = doc.getElementsByTagName("notifyInternalAccountsTransactionRequest").item(0);
//                       list = staff.getChildNodes();
//                      student = list.item(3);           }
//                else if(doc.getElementsByTagName("ns3:notifyCorporateFinancialTransactionRequest").item(0) != null) {
//                    staff = doc.getElementsByTagName("ns3:notifyCorporateFinancialTransactionRequest").item(0);
//                     list = staff.getChildNodes();
//                     student = list.item(3);
//                }else {
//                    staff = doc.getElementsByTagName("notifyCorporateFinancialTransactionRequest").item(0);
//
//                    list = staff.getChildNodes();
//                  student = list.item(3);    }
//                System.out.println(staff);
//
//
//
//
//
//                NodeList list1 = student.getChildNodes();
//                Node trxnRequest = list1.item(5);
//                System.out.println(trxnRequest);
//                NodeList list2 = trxnRequest.getChildNodes();
//                Node trxDetail = list2.item(1);
//                System.out.println(trxDetail);
//                NodeList list3 = trxDetail.getChildNodes();
//                Node trxEntry = list3.item(1);
//                //System.out.println(student);
//                NodeList lists = trxEntry.getChildNodes();
//
//                NodeList list8 = staff.getChildNodes();
//                Node header = list8.item(1);
//                System.out.println(header);
//                NodeList head = header.getChildNodes();
//                Node originationDetails = head.item(3);
//                System.out.println(originationDetails);
//                NodeList originationDetailsList = originationDetails.getChildNodes();
//                Node correlationID = originationDetailsList.item(7);
//                System.out.println(correlationID.getTextContent());
//                int correlation = Integer.parseInt(correlationID.getTextContent());
//                correlationID.setTextContent("" + (correlation + 1));
//                for (int i = 0; i < lists.getLength(); i++) {
//
//                    Node node = lists.item(i);
//                    // get the salary element, and update the value
//                    if (node.getNodeName().equals("tns:TrnAmount")) {
//                        node.setTextContent("" + amt);
//                        System.out.println(node.getTextContent());
//                    }
//                    if (node.getNodeName().equals("tns:Account")) {
//                        NodeList accountList = node.getChildNodes();
//                        Node currencyCodeNode = accountList.item(1);
//                        currencyCodeNode.setTextContent(currencyCode);
//                        System.out.println(currencyCodeNode.getTextContent());
//                        Node accountNo = accountList.item(3);
//                        accountNo.setTextContent(accountNumber);
//                        System.out.println(accountNo.getTextContent());
//                    }
//                    if (node.getNodeName().equals("tns:ApprvSeqno")) {
//                        BigDecimal value = new BigDecimal(node.getTextContent());
//                        value = value.add(new BigDecimal(i));
//                        node.setTextContent("" + value);
//                        System.out.println("Transaction ID is - "+node.getTextContent()+". Got from the template - "+format);
//                    }
//                    if (node.getNodeName().equals("tns:CreditDebitFlag")) {
////                        if (j % 2 == 0)
////                            node.setTextContent("C");
////                        else
////                            node.setTextContent("D");
//                        node.setTextContent(trxType);
//                        System.out.println(node.getTextContent());
//                    }
//                    if (node.getNodeName().contains("tns:SwiftAddress")) {
//                        node.setTextContent(bic);
//                        System.out.println(node.getTextContent());
//                    }
//                }
                TransformerFactory transformerFactory = TransformerFactory.newInstance();
                Transformer transformer = transformerFactory.newTransformer();
                DOMSource source = new DOMSource(doc);
                StreamResult result = new StreamResult(new File(filepath));
                transformer.transform(source, result);

                try {
                    TextMessage message = session.createTextMessage();

                    String request = readFile(filepath);
                    System.out.println("Sending Message " + request);
                    message.setText(request);
                    producer.send(message);
                    System.out.println("Message Sent Successfully - " + now());
                    System.out.println("Current time is "+now());
                } catch (Exception e) {
                    e.printStackTrace();
                } finally {
                }
            } catch (TransformerException eq) {
                eq.printStackTrace();
            }

        if (connection != null)
            try {
                connection.close();
                System.out.println("Connection Terminated");
            } catch (JMSException e) {
                e.printStackTrace();
            }
        Thread.sleep(1000);
    }


    @When("^user loops Stub with amount '(.+)' account number '(.+)' transaction type '(.+)' Currency Code '(.+)' BIC '(.+)' for '(.+)' times$")
    public void modifyxml1(String amount, String accountNumber, String trxType, String currencyCode, String bic, int n) throws IOException, ParserConfigurationException, SAXException, TransformerConfigurationException, InterruptedException, NamingException, JMSException {

        String contextFactory = "com.webmethods.jms.naming.WmJmsNamingCtxFactory";
        String JNDIUrl = "wmjmsnaming://@10.20.160.24:6661/EDMIFramework";
        String clientGroup = "admin";

        String connectionFactory = "CoreBanking_API_ConnectionFactory";
        String topicName = "scbCoreBankingTxnAlertCorpFinTxnNotifyV1T";
        Context namingContext = null;

        Properties env = new Properties();
        env.setProperty("java.naming.factory.initial", contextFactory);
        env.setProperty("java.naming.provider.url", JNDIUrl);
        env.setProperty("com.webmethods.jms.naming.clientgroup", clientGroup);
        env.setProperty("com.webmethods.jms.clientIDSharing", "true");
        System.setProperty("com.webmethods.jms.clientIDSharing", "true");

        namingContext = new InitialContext(env);

        WmConnectionFactoryImpl wmConnectionFactory = (WmConnectionFactoryImpl) namingContext.lookup(connectionFactory);
        File trustStoreResource = ResourceUtils.getFile("" +
                "classpath:edmicorebankingtruststore.jks");
        wmConnectionFactory.setSSLTruststore(trustStoreResource.toString());

        Connection connection = wmConnectionFactory.createConnection("ccsuser", "abc12345");

        System.out.println("Connection created " + connection.toString());
        Session session = connection.createSession(false, Session.AUTO_ACKNOWLEDGE);
        WmTopic dest = (WmTopic) namingContext.lookup(topicName);
        MessageProducer producer = session.createProducer(dest);
        String filepath = new File(".").getCanonicalPath() + "/src/test/resources/rta-template.xml";
        DocumentBuilderFactory docFactory = DocumentBuilderFactory.newInstance();
        DocumentBuilder docBuilder = docFactory.newDocumentBuilder();
        System.out.println(filepath);
        Document doc = docBuilder.parse(filepath);
        System.out.println(doc);
        int amt = Integer.parseInt(amount);
        n = amt + n;
        for (int j = amt; j < n; j++) {
            try {
                Thread.sleep(1000);

                Node staff = doc.getElementsByTagName("notifyCorporateFinancialTransactionRequest").item(0);
                System.out.println(staff);
                NodeList list = staff.getChildNodes();
                Node student = list.item(3);
                System.out.println(student);
                NodeList list1 = student.getChildNodes();
                Node trxnRequest = list1.item(5);
                System.out.println(trxnRequest);
                NodeList list2 = trxnRequest.getChildNodes();
                Node trxDetail = list2.item(1);
                System.out.println(trxDetail);
                NodeList list3 = trxDetail.getChildNodes();
                Node trxEntry = list3.item(1);
                //System.out.println(student);

                NodeList list8 = staff.getChildNodes();
                Node header = list8.item(1);
                System.out.println(header);
                NodeList head = header.getChildNodes();
                Node originationDetails = head.item(3);
                System.out.println(originationDetails);
                NodeList originationDetailsList = originationDetails.getChildNodes();
                Node correlationID = originationDetailsList.item(7);
                System.out.println(correlationID.getTextContent());
                int correlation = Integer.parseInt(correlationID.getTextContent());
                correlationID.setTextContent("" + (correlation + 1));
                NodeList lists = trxEntry.getChildNodes();
                for (int i = 0; i < lists.getLength(); i++) {
                    Node node = lists.item(i);
                    // get the salary element, and update the value
                    if (node.getNodeName().equals("tns:TrnAmount")) {
                        node.setTextContent("" + j);
                        System.out.println(node.getTextContent());
                    }
                    if (node.getNodeName().equals("tns:Account")) {
                        NodeList accountList = node.getChildNodes();
                        Node currencyCodeNode = accountList.item(1);
                        currencyCodeNode.setTextContent(currencyCode);
                        System.out.println(currencyCodeNode.getTextContent());
                        Node accountNo = accountList.item(3);
                        accountNo.setTextContent(accountNumber);
                        System.out.println(accountNo.getTextContent());
                    }
                    if (node.getNodeName().equals("tns:CreditDebitFlag")) {
                        if (j % 2 == 0)
                            node.setTextContent("C");
                        else
                            node.setTextContent("D");
                        System.out.println(node.getTextContent());
                    }
                    if (node.getNodeName().contains("tns:SwiftAddress")) {
                        node.setTextContent(bic);
                        System.out.println(node.getTextContent());
                    }
                }
                TransformerFactory transformerFactory = TransformerFactory.newInstance();
                Transformer transformer = transformerFactory.newTransformer();
                DOMSource source = new DOMSource(doc);
                StreamResult result = new StreamResult(new File(filepath));
                transformer.transform(source, result);

                try {
                    TextMessage message = session.createTextMessage();

                    String request = readFile(filepath);
                    System.out.println("Sending Message ");
                    message.setText(request);
                    producer.send(message);
                    System.out.println("Message Sent Successfully");
                    Thread.sleep(2000);
                } catch (Exception e) {
                    e.printStackTrace();
                } finally {
                }
            } catch (TransformerException eq) {
                eq.printStackTrace();
            }
        }

        if (connection != null)
            try {
                connection.close();
                System.out.println("Connection Terminated");
            } catch (JMSException e) {
                e.printStackTrace();
            }
        Thread.sleep(25000);
    }


    @When("^the user publishes a '(.*)' transaction with random number for '(.*)' along with the details")
    public void verifyInimeg(String type, String randomNumberList, List<Map<String, String>> dataTable) throws IOException, ParserConfigurationException, SAXException, TransformerException, ClassNotFoundException, IllegalAccessException, XPathExpressionException, NoSuchFieldException {

        Properties prop = new Properties();
        InputStream input = new FileInputStream(new File(new File(".").getCanonicalPath() + "\\src\\test\\resources\\test-data\\EDMITopic.properties"));
        prop.load(input);
        String filepath = new File(".").getCanonicalPath() + "\\src\\test\\resources\\test-data\\"+prop.getProperty(type+"_XMLPath");
        DocumentBuilderFactory docFactory = DocumentBuilderFactory.newInstance();
        DocumentBuilder docBuilder = docFactory.newDocumentBuilder();

        // System.out.println(filepath);
        Document doc = docBuilder.parse(filepath);
        System.out.println(doc);
        String xml = IOUtils.toString(new FileInputStream(filepath));
        Map<String, String> keys = new HashMap<String, String>();
        GenericUtils genericUtils = new GenericUtils();

        if(!randomNumberList.equals("")){
            randomNumber = genericUtils.generateRandomNumber();
            for(String random : randomNumberList.split("\\,")){
                keys.put(random,randomNumber);
            }
        }
        xml = genericUtils.modifyXMLValuesWithRandomNumber(dataTable,keys,xml,Class.forName("ab.glue.api." + type));
        Connection connection = null;
        String contextFactory = prop.getProperty(type+"_contextFactory");
        String JNDIUrl =prop.getProperty(type+"_JNDIUrl");
        String clientGroup = prop.getProperty(type+"_clientGroup");

        String connectionFactory = prop.getProperty(type+"_connectionFactory");
        String topicName = prop.getProperty(type+"_topicName");
        Context namingContext = null;
        try {
            Properties env = new Properties();
            env.setProperty("java.naming.factory.initial", contextFactory);
            env.setProperty("java.naming.provider.url", JNDIUrl);
            env.setProperty("com.webmethods.jms.naming.clientgroup", clientGroup);
            env.setProperty("com.webmethods.jms.clientIDSharing", "true");
            System.setProperty("com.webmethods.jms.clientIDSharing", "true");

            namingContext = new InitialContext(env);

            WmConnectionFactoryImpl wmConnectionFactory = (WmConnectionFactoryImpl) namingContext.lookup(connectionFactory);
            File trustStoreResource = ResourceUtils.getFile("" +
                    prop.getProperty(type+"_trustStoreResource"));
            wmConnectionFactory.setSSLTruststore(trustStoreResource.toString());

            connection = wmConnectionFactory.createConnection( prop.getProperty(type+"_username"), prop.getProperty(type+"_password"));

            System.out.println("Connection created " + connection.toString());
            Session session = connection.createSession(false, Session.AUTO_ACKNOWLEDGE);
            WmTopic dest = (WmTopic) namingContext.lookup(topicName);
            MessageProducer producer = session.createProducer(dest);
            TextMessage message = session.createTextMessage();

            //String request = readFile(filepath);
            //System.out.println("Sending Message " + request);
            message.setText(xml);
            producer.send(message);
            System.out.println("Message Sent Successfully"+xml);
            Thread.sleep(5000);
        } catch (Exception e) {
            e.printStackTrace();

    }
    }
}

