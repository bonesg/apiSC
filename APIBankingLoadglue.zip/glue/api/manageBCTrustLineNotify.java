package ab.glue.api;

import cucumber.api.DataTable;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import io.restassured.http.ContentType;
import io.restassured.response.ValidatableResponse;
import java.io.File;
import java.util.List;
import java.util.Random;
import java.util.Scanner;
import static io.restassured.RestAssured.given;

/**
 * Created by 1556780 on 5/14/2018.
 */
public class manageBCTrustLineNotify {

    private String MId = null;
    private String AnchorId = null;
    private String ClientId = null;
    private static ValidatableResponse validatableResponse = null;
    private static ValidatableResponse validatableResponse2 = null;
    private static String response;
    private static String content;
    private static String url = "https://10.23.210.60:9012/api-banking/inimeg/transaction/generic";

    @Given("^A valid BC Member Anchor and Client:$")
    public void a_valid_BC_Member_and_Anchor(DataTable dataTable) throws Throwable {
        content = new Scanner(new File(".\\\\src\\\\test\\\\resources\\\\test-data\\\\manageBCTrustLineNotify.json")).useDelimiter("\\Z").next();
        List<List<String>> userDetails = dataTable.raw();
        MId = userDetails.get(0).get(0);
        AnchorId = userDetails.get(0).get(1);
        ClientId = userDetails.get(0).get(2);
        content = content.replace("Mid", MId);
        content = content.replace("AnchorId", AnchorId);
        content = content.replace("ClientId", ClientId);

        //System.out.println(content);
    }

    @When("^'manageBCTrustlineNotify' request is sent:$")
    public void managebctrustline_request_is_sent(DataTable dataTable) throws Throwable {
        List<List<String>> requestParams = dataTable.raw();
        String curr = requestParams.get(0).get(0);
        String amount = requestParams.get(0).get(1);

        Random rand = new Random();
        int reqId = rand.nextInt(999999999);
        int oprId = rand.nextInt(999999999);

        content = content.replace("CURR", curr);
        content = content.replace("AMOUNT", amount);
        content = content.replace("MessageId",Integer.toString(reqId));
        content=content.replace("OperationId",Integer.toString(oprId));
        //System.out.println(content);

        validatableResponse =
                given()
                        .contentType(ContentType.JSON)
                        .relaxedHTTPSValidation()
                        .when()
                        .body(content)
                        .post(url)
                        .then();
        //capturing API response as String
        response =
                given()
                        .contentType(ContentType.JSON)
                        .relaxedHTTPSValidation()
                        .when()
                        .body(content)
                        .post(url)
                        .thenReturn()
                        .asString();
    }

    @Then("^'manageBCTrustLineNotify' response should be Success$")
    public void api_response_should_be_Success() throws Throwable {
        validatableResponse.statusCode(200);
    }

    @Then("^verify that correct response is received by API Banking$")
    public void api_response_should_be_correct() throws Throwable {
        validatableResponse.statusCode(200);
    }

}
