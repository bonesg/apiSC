package ab.glue.api;

import ab.common.JWTTest;
import ab.utils.DBUtils;
import ab.utils.DataClass;
import ab.utils.GenericUtils;
import common.EndPoint;
import cucumber.api.DataTable;
import cucumber.api.PendingException;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import io.restassured.RestAssured;
import io.restassured.config.SSLConfig;
import io.restassured.http.ContentType;
import io.restassured.response.Response;
import org.apache.commons.lang3.StringUtils;
import org.junit.Assert;
import org.w3c.dom.Document;
import org.w3c.dom.Node;
import org.xml.sax.InputSource;

import javax.crypto.NoSuchPaddingException;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import java.io.*;
import java.security.KeyStore;
import java.security.NoSuchAlgorithmException;
import java.sql.Connection;
import java.sql.ResultSet;
import java.text.SimpleDateFormat;
import java.util.*;

/**
 * Created by 1571168 on 12/20/2017.
 */
public class AccountBalanceEnquiry {


    GenericUtils genericUtils = new GenericUtils();
    activationKey activationKey = new activationKey();
    DBUtils dbUtils = new DBUtils();
    public static Response response;
    public static String responseString;
    public static boolean responseEncrypted;
    public static int actualStatusCode;

    @Given("^the user hits the account balance inquiry with an account number '(.*)'$")
    public void getAccountBalanceUsingAccountNumber(String accNo) throws IOException, ParserConfigurationException {
        String filepath = new File(".").getCanonicalPath() + "/src/test/resources/rta-template.xml";
        DocumentBuilderFactory docFactory = DocumentBuilderFactory.newInstance();
        DocumentBuilder docBuilder = docFactory.newDocumentBuilder();
        NewStub newStub = new NewStub();
        String request = newStub.readFile(filepath);
        InputSource source = new InputSource(new ByteArrayInputStream(request.getBytes()));
//        ReqBalEnqType reqBalEnqType = new ReqBalEnqType();
//        HeadType head = new HeadType();
//        head.setMsgId("abcd123");
//        head.setOrgId("org123");
//        head.setTs("TS");
//        head.setValue("V");
//        head.setVer(new Float(1.0));
//        PayerType payerType = new PayerType();
//        payerType.setAddr("addr 1");
//        AcType acType = new AcType();
//        acType.setAddrType("ACCOUNT");
//
//        DetailType detailType = new DetailType();
//        detailType.setName("ACTYPE");
//        detailType.setValue("SAVINGS");
//        detailType.setName("ACNUM");
//        detailType.setValue(accNo);
//        acType.getDetail().add(detailType);
//        payerType.getAc().add(acType);
//
//        payerType.setName("Name");
//        payerType.setSeqNum("12345465");
//        payerType.setType("PERSON");
//        payerType.setCode("code");
//        InfoType info = new InfoType();
//        IdentityType identityType = new IdentityType();
//        identityType.setType("ACCOUNT");
//        identityType.setVerifiedName("TRUE");
//        info.setIdentity(identityType);
//        TxnType txnType = new TxnType();
//        txnType.setId("97977897");
//        txnType.setNote("note");
//        txnType.setTs("TS");
//        txnType.setType(TxnTypeValues.PAY);
//        reqBalEnqType.setHead(head);
//        reqBalEnqType.setPayer(payerType);
//        reqBalEnqType.setTxn(txnType);
//        String value = reqBalEnqType.toString();
//        Request request = new Request.Builder()
//                .url("/upi/v1/meta/balance-enquiry")
//                .header("", "")
//                .post(requestBody)
//                .build();
        throw new PendingException();
    }

    @Then("^the user should be able to see response with the details$")
    public void verifyResponse(List<Map<String, String>> data) throws Exception {
        for (Map<String, String> expectedData : data) {
            String accountNumber = expectedData.get("AccountNumber");
//            String certificate = expectedData.get("GroupID");
//            int statusCode = Integer.parseInt(expectedData.get("StatusCode"));
            String groupID = expectedData.get("GroupID");
//            String country = expectedData.get("Country");
            String currency = expectedData.get("Currency");
            String accountType = expectedData.get("AccountType");

            //String key = expectedData.keySet().toArray()[0].toString();
            Map<String, String> value = new HashMap<String, String>();
            //value = expectedData;
            Connection con = dbUtils.getConnection();
            String query = StringUtils.replace(dbUtils.DB_QUERY, "${accountNumber}", accountNumber);
            ResultSet resultSet = dbUtils.executeQuery(query);
            String closingAvailableBalance = dbUtils.executeQueryReturnNecessaryResult(resultSet,"OABCLOSINGACTUALBAL");
            String openingAvailableBalance = dbUtils.executeQueryReturnNecessaryResult(resultSet,"OABCLOSINGACTUALBAL");
            String closingLedgerBalance = dbUtils.executeQueryReturnNecessaryResult(resultSet,"OABCLOSINGACTUALBAL");
            String openingledgerBalance = dbUtils.executeQueryReturnNecessaryResult(resultSet,"OABCLOSINGACTUALBAL");
            value.put("OpeningAvailiableBalance",closingAvailableBalance);
            value.put("ClosingLedgerBalance",closingAvailableBalance);
            value.put("OpeningLedgerBalance",closingAvailableBalance);
            value.put("Balance",closingAvailableBalance);
            value.put("AccountNumber",expectedData.get("AccountNumber"));
            value.put("GroupID",expectedData.get("GroupID"));
            value.put("Currency",expectedData.get("Currency"));
            value.put("AccountType",expectedData.get("AccountType"));
            value.put("Country",expectedData.get("Country"));
//            responseString ="<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>\n" +
//                    "<ns2:RespBalEnq\n" +
//                    "    xmlns:ns2=\"http://www.sc.com/api/schema/2017/upi\">\n" +
//                    "    <ns2:Head ver=\"1.0\" ts=\"2018-03-22T17:08:33Z\" orgId=\"RTBIN001\"/>\n" +
//                    "    <ns2:Txn/>\n" +
//                    "    <ns2:Payer addr=\"22510603706-INR@ifsc.SCBLINBBXXX.scb\" name=\"XXXX\" type=\"CACC\">\n" +
//                    "        <Bal>\n" +
//                    "            <Data>1435485.1</Data>\n" +
//                    "        </Bal>\n" +
//                    "        <Info/>\n" +
//                    "        <Device/>\n" +
//                    "        <Ac>\n" +
//                    "            <Detail name=\"ACNUM\">22510603706</Detail>\n" +
//                    "        </Ac>\n" +
//                    "        <Amount curr=\"INR\"/>\n" +
//                    "    </ns2:Payer>\n" +
//                    "</ns2:RespBalEnq>";
            DataClass expectedClass = DataClass.getValueFromMap(value);

            DataClass actualClass = DataClass.getValueFromXml(responseString,value);
            //String val = DataClass.getValueFromMap(value).getAccountNumber();
            DataClass.verifyValues(expectedClass,actualClass);


            RestAssured.useRelaxedHTTPSValidation();
            Map<String, String> headerMap = new HashMap<String, String>();
            SimpleDateFormat dateFormatGmt = new SimpleDateFormat("yyyy-MMM-dd HH:mm:ss");
            dateFormatGmt.setTimeZone(TimeZone.getTimeZone("GMT"));
            SimpleDateFormat dateFormatLocal = new SimpleDateFormat("yyyy-MMM-dd HH:mm:ss");

                 try {
                Date date = dateFormatLocal.parse( dateFormatGmt.format(new Date()) );

            } catch (Throwable throwable) {
                     throwable.printStackTrace();
                 }
        }

    }

    @Then("^the user should be able to see open api form of response with the details$")
    public void verifyOpenApiResponse(List<Map<String, String>> data) throws Exception {
        for (Map<String, String> expectedData : data) {
            String accountNumber = expectedData.get("AccountNumber");
//            String certificate = expectedData.get("GroupID");
//            int statusCode = Integer.parseInt(expectedData.get("StatusCode"));
            String groupID = expectedData.get("GroupID");
//            String country = expectedData.get("Country");
            String currency = expectedData.get("Currency");
            String accountType = expectedData.get("AccountType");

            //String key = expectedData.keySet().toArray()[0].toString();
            Map<String, String> value = new HashMap<String, String>();
            //value = expectedData;
            Connection con = dbUtils.getConnection();
            String query = StringUtils.replace(dbUtils.DB_QUERY, "${accountNumber}", accountNumber);
            ResultSet resultSet = dbUtils.executeQuery(query);
            String closingAvailableBalance = dbUtils.executeQueryReturnNecessaryResult(resultSet,"OABCLOSINGACTUALBAL");
            String openingAvailableBalance = dbUtils.executeQueryReturnNecessaryResult(resultSet,"OABCLOSINGACTUALBAL");
            String closingLedgerBalance = dbUtils.executeQueryReturnNecessaryResult(resultSet,"OABCLOSINGACTUALBAL");
            String openingledgerBalance = dbUtils.executeQueryReturnNecessaryResult(resultSet,"OABCLOSINGACTUALBAL");
//                        value.put("AccountNumber",expectedData.get("AccountNumber"));
            value.put("GroupID",expectedData.get("GroupID"));
 //           value.put("Currency",expectedData.get("Currency"));value.put("OpeningAvailiableBalance",closingAvailableBalance);
//            value.put("ClosingLedgerBalance",closingAvailableBalance);
//            value.put("OpeningLedgerBalance",closingAvailableBalance);
//            value.put("Balance",closingAvailableBalance);

            value.put("AccountType",expectedData.get("AccountType"));
            value.put("BIC",expectedData.get("BIC"));

            DataClass expectedClass = DataClass.getValueFromMap(value);
            //DataClass actualClass = DataClass.getValueFromXml(responseString);

            DataClass actualClass = DataClass.getValueFromJSON(responseString,value);
            String val = DataClass.getValueFromMap(value).getAccountNumber();
            DataClass.verifyValues(expectedClass,actualClass);
                    }

    }




//
//    @Then("^the user should be able to see response with the details$")
//    public void verifyResponse(DataTable dataTable) throws Exception {
//        // Write code here that turns the phrase above into concrete actions
//        String accountNum = dataTable.asLists(Object.class).get(1).get(0).toString();
//        String amount = dataTable.asLists(Object.class).get(1).get(1).toString();
//        KeyStore keyStore = null;
//        String data = null;
//        Iterator iterator = dataTable.asLists(Object.class).get(1).iterator();
//        String accountNumber = "empty";
//        String certificate = "empty";
//        String token = "empty";
//        String contentType = "empty";
//        String groupID = "";
//        String country = "";
//        String currency = "";
//        String accountType = "";
//        String accountBalance = "";
//        int statusCode = 0;
//        if (iterator.hasNext())
//            statusCode = (int) iterator.next();
//        if (iterator.hasNext())
//            accountNumber = (String) iterator.next();
//        if (iterator.hasNext())
//            groupID = (String) iterator.next();
//        if (iterator.hasNext())
//            country = (String) iterator.next();
//        if (iterator.hasNext())
//            currency = (String) iterator.next();
//        if (iterator.hasNext())
//            accountType = (String) iterator.next();
//        if (iterator.hasNext())
//            accountBalance = (String) iterator.next();
//        RestAssured.useRelaxedHTTPSValidation();
//        Map<String, String> headerMap = new HashMap<String, String>();
//        SimpleDateFormat dateFormatGmt = new SimpleDateFormat("yyyy-MMM-dd HH:mm:ss");
//        dateFormatGmt.setTimeZone(TimeZone.getTimeZone("GMT"));
//        SimpleDateFormat dateFormatLocal = new SimpleDateFormat("yyyy-MMM-dd HH:mm:ss");
//
//        Connection con = dbUtils.getConnection();
//       // String result = dbUtils.executeQueryReturnNecessaryResult("select * from ds_oa_balances where OABACCNUM = '22510603706'","OABCLOSINGACTUALBAL");
//        try {
//            Date date = dateFormatLocal.parse( dateFormatGmt.format(new Date()) );
//            String responseValue = responseEncrypted ? responseString :response.thenReturn().asString();
//
//            byte[] responseBytes = response.thenReturn().asString().getBytes();
//            InputSource source = new InputSource(new ByteArrayInputStream(responseBytes));
//            Assert.assertTrue("", response.getStatusCode()==statusCode);
//            Assert.assertTrue("", responseString.contains("" + country));
//           //Assert.assertTrue("",  xPath.evaluate("//*:Payer/*:Amount/@curr", source).equals("" + currency));
//            Assert.assertTrue("", responseString.contains("" + accountType));
//            Assert.assertTrue("", responseString.contains("" + groupID));
//            //Assert.assertTrue("", xPath.evaluate("//*:Payer/*:Bal/*:Data/text()", source).equals("" + accountBalance));
//            Assert.assertTrue("", responseString.contains("" + date));
//        } catch (Throwable throwable) {
//            throwable.printStackTrace();
//        }
//        throw new PendingException();
//    }

//    static XPathFactory factory;
//    static XPath xPath;
//
//    static {
//        try {
//            factory = XPathFactory.newInstance(OBJECT_MODEL_SAXON);
//            xPath=factory.newXPath();
//        } catch (XPathFactoryConfigurationException e) {
//            throw new RuntimeException(e.getMessage(),e);
//        }
//    }


    @Then("^the user hits the account balance inquiry to get encrypted data with the details$")
    public void getAccountBalanceWithEncryption(DataTable dataTable) {
        try {
            responseEncrypted = true;
            getAccountBalance (dataTable);
                   } catch (Throwable throwable) {
            throwable.printStackTrace();
        }
    }

    @Then("^the user hits the open api form of account balance inquiry to get encrypted data with the details$")
    public void getAccountBalanceWithEncryptionForOpenApiFormat(DataTable dataTable) {
        try {
            responseEncrypted = true;
            getAccountBalanceOpenAPI (dataTable);
        } catch (Throwable throwable) {
            throwable.printStackTrace();
        }
    }

    @Then("^the user hits the account balance inquiry with details$")
    public void getAccountBalance (DataTable dataTable) {
        // Write code here that turns the phrase above into concrete actions
        try {
            //String filepath = new File(".").getCanonicalPath() + "/src/test/resources/test-data/UPI_AccountBalanceEnquiry.xml";
            SSLConfig config = null;
            String filepath = new File(".").getCanonicalPath() + "/src/test/resources/test-data/UPI_AccountBalanceEnquiry1.xml";
            DocumentBuilderFactory docFactory = DocumentBuilderFactory.newInstance();
            DocumentBuilder docBuilder = docFactory.newDocumentBuilder();
            NewStub newStub = new NewStub();
            String request = newStub.readFile(filepath);
            InputSource source = new InputSource(new ByteArrayInputStream(request.getBytes()));
            Document doc = docBuilder.parse(filepath);
            Node payer = doc.getElementsByTagName("Payer").item(0);
            KeyStore keyStore = null;
            String data = null;
            String activKey =  "";
            RestAssured.useRelaxedHTTPSValidation();
            Map<String, String> headerMap = new HashMap<String, String>();
            Iterator iterator = dataTable.asLists(Object.class).get(1).iterator();
            String accountNumber = "empty";
            String certificate = "empty";
            String token = "empty";
            String content = "empty";
            String groupID = "";
            String country = "";
            String currency = "";
            String accountType = "";
            InputStream input = getClass().getResourceAsStream("/test-data/activationKeyRequest.properties");
            Properties prop = new Properties();
            prop.load(input);
            int iteratorlength = dataTable.asLists(Object.class).get(1).size();
            if (iterator.hasNext()) {
                accountNumber = (String) iterator.next();
                request = StringUtils.replace(request, "${accountNumber}", accountNumber);
            }
            if (iterator.hasNext()) {
                groupID = (String) iterator.next();
                //headerMap.put("GroupId",groupID);
            }
            if (iterator.hasNext()) {
                country = (String) iterator.next();
                request = StringUtils.replace(request, "${accountCountry}", country);
            }
            if (iterator.hasNext()) {
                currency = (String) iterator.next();
                request = StringUtils.replace(request, "${accountCurrency}", currency);
            }
            if (iterator.hasNext()) {
                accountType = (String) iterator.next();
                request = StringUtils.replace(request, "${accountType}", accountType);
            }
            if (iterator.hasNext())
                content = (String) iterator.next();
            if (iterator.hasNext()) {
                token = (String) iterator.next();
                if (token.equals("Valid Token")) {
                    //String content = null;
                    activationKey.a_POST_request_is_made_to_the_activationKey_API_for_Group(groupID);
                    String[] parts = activKey.split("\"");
                    //token = JWTTest.createTokenForGroup(30L,activationKey.activationContent, activationKey.key, groupID);
                    token = JWTTest.createTokenForObject(30L,request, groupID);
                    //headerMap.put("JWTToken",token);
                }else if(token.equals("InvalidToken")){
                    //String content = null;
                    token = "JWTTokenJWTTokenJWTTokenJWTTokenJWTToken";
                    headerMap.put("JWTToken","JWTTokenJWTTokenJWTTokenJWTTokenJWTToken");
                }else if(token.equals("ExpiredToken")){
                    //String content = null;
                    activationKey.a_POST_request_is_made_to_the_activationKey_API_for_Group(groupID);
                    String[] parts = activKey.split("\"");
                    token = JWTTest.createTokenForObject(30L,request, groupID);
                    Thread.sleep(30000) ;
                   // headerMap.put("JWTToken",token);
                }else if(token.equals("DifferentGroupToken")){
                    //String content = null;
                    activationKey.a_POST_request_is_made_to_the_activationKey_API_for_Group("INDGRP1");
                    String[] parts = activKey.split("\"");
                    token = JWTTest.createTokenForObject(30L,request, "INDGRP1");
                    //headerMap.put("JWTToken",token);
                }else if(token.equals("DuplicateToken")){
                    activationKey.a_POST_request_is_made_to_the_activationKey_API_for_Group(groupID);
                    String[] parts = activKey.split("\"");
                    token = JWTTest.createTokenForObject(30L,request, groupID);
                    ab.glue.api.activationKey activationKey = new activationKey();
                    activationKey.activateWithoutVerification(groupID);
                   // headerMap.put("JWTToken",token);
                }else{
                    token = "";
                    headerMap.put("JWTToken","");
                }
            }
            if (iterator.hasNext())
                certificate = (String) iterator.next();
            if (certificate.equals("empty") || certificate.equals("Valid Cert")) {
                certificate = prop.getProperty(groupID + "_Certificate");
                //headerMap.put("X-Client-Certifcate","MIIFPDCCBCSgAwIBAgIQBhCY9/Oua9sbbZUiKb7/ETANBgkqhkiG9w0BAQsFADBlMQswCQYDVQQGEwJVUzEVMBMGA1UEChMMRGlnaUNlcnQgSW5jMRkwFwYDVQQLExB3d3cuZGlnaWNlcnQuY29tMSQwIgYDVQQDExtEaWdpQ2VydCBTSEEyIEFzc3VyZWQgSUQgQ0EwHhcNMTcwNTIzMDAwMDAwWhcNMTgwNTIzMTIwMDAwWjBXMQswCQYDVQQGEwJTRzESMBAGA1UEBxMJU2luZ2Fwb3JlMSAwHgYDVQQKExdTdGFuZGFyZCBDaGFydGVyZWQgQmFuazESMBAGA1UEAxMJQWNtZSBDb3JwMIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAx+79CIYpTbQdM93rnQe2y+gMCAZGKfwVuyT4xjYDmYfKr4+/6F2OUoVAP0wsS+EufaFOdwGRYD2Xcg8fH/jwp4dynekLNmO94et7pDBIQoHoyqUz5IfYIhbkwUV5zAjJEfrAlLXEfrBB+j8v6/DMWcYoFvXvq2mA/rZCr5S5L7RCKj17Tup6OpRasbohHADLwLx/gk/gaX7fAzV/4jETHw1zxRg9jT8WaPp+Qs3KeQlXqDEX6vpH12flHDl1dF+QfuKN5jlKG77yKsThglYwRTeaxrL3RgU8X6P8T1S5xpzGCIlE7RHFTpta1Hxn3oD59AvhQkQ8CkYyOWzt6GS6uQIDAQABo4IB9DCCAfAwHwYDVR0jBBgwFoAU5wIjgABP2Ne8lAvZP3Q5STI8inkwHQYDVR0OBBYEFIzxOlIwI/C/ktPcOkYtZA1XWTKrMAwGA1UdEwEB/wQCMAAwJgYDVR0RBB8wHYEbcHJhc2FubmEua2FuYWdhc2FiYWlAc2MuY29tMA4GA1UdDwEB/wQEAwIFoDAdBgNVHSUEFjAUBggrBgEFBQcDAgYIKwYBBQUHAwQwQwYDVR0gBDwwOjA4BgpghkgBhv1sBAECMCowKAYIKwYBBQUHAgEWHGh0dHBzOi8vd3d3LmRpZ2ljZXJ0LmNvbS9DUFMwgYgGA1UdHwSBgDB+MD2gO6A5hjdodHRwOi8vY3JsMy5kaWdpY2VydC5jb20vRGlnaUNlcnRTSEEyQXNzdXJlZElEQ0EtZzIuY3JsMD2gO6A5hjdodHRwOi8vY3JsNC5kaWdpY2VydC5jb20vRGlnaUNlcnRTSEEyQXNzdXJlZElEQ0EtZzIuY3JsMHkGCCsGAQUFBwEBBG0wazAkBggrBgEFBQcwAYYYaHR0cDovL29jc3AuZGlnaWNlcnQuY29tMEMGCCsGAQUFBzAChjdodHRwOi8vY2FjZXJ0cy5kaWdpY2VydC5jb20vRGlnaUNlcnRTSEEyQXNzdXJlZElEQ0EuY3J0MA0GCSqGSIb3DQEBCwUAA4IBAQCuOYPuakKB9qCCR7JYaA+92BprzqYFd1LwT62FrdzcPGupHix7ALoiw2jHuMQogrc3Rw0wZPUqgN29b2bcXX8r9B8OMVbxYL6VZGJ8P+WndUPOzbWdl7eAY/9HbkAUgcqzSP+BBcndCyKdR+bs43dYDNvhDzqL7hHgqjmxFxVz8C/25oLmBZ0yOXz5yLpVoTyHBl1OfAkrYj5WeQI8/uiR9bJ4SwY/NvUU+sOB/UJsxECjpmmdS26dYMRyLuFT7hZvmgv8L2wcjO6vyA9qm3kNb0dTJw1/xQG56pdaGRhdVEqp/L3/hW0COgQvOVdRNlVH9dU8cCl57ICj9rtxTrqg");
                keyStore = KeyStore.getInstance("PKCS12");
                keyStore.load(getClass().getResourceAsStream("/test-data/bny-cert.pfx"), "bny123".toCharArray());
                org.apache.http.conn.ssl.SSLSocketFactory clientAuthFactory = null;
                clientAuthFactory = new org.apache.http.conn.ssl.SSLSocketFactory(keyStore, "bny123");

               config = new SSLConfig().with().sslSocketFactory(clientAuthFactory).and().allowAllHostnames();
//                RestAssured.config = RestAssured.config().sslConfig(config);
            }else if(certificate.equals("InvalidCert")) {
                    keyStore = KeyStore.getInstance("PKCS12");
                    keyStore.load(getClass().getResourceAsStream("/test-data/invalidcert.pfx"), "123456".toCharArray());
                    org.apache.http.conn.ssl.SSLSocketFactory clientAuthFactory = null;
                    clientAuthFactory = new org.apache.http.conn.ssl.SSLSocketFactory(keyStore, "123456");
                    config = new SSLConfig().with().sslSocketFactory(clientAuthFactory).and().allowAllHostnames();
//                RestAssured.config = RestAssured.config().sslConfig(config);

            }else if(certificate.equals("DifferentCert")) {
                    keyStore = KeyStore.getInstance("PKCS12");
                    keyStore.load(getClass().getResourceAsStream("/test-data/newcsrcertificate.pfx"), "123456".toCharArray());
                    org.apache.http.conn.ssl.SSLSocketFactory clientAuthFactory = null;
                    clientAuthFactory = new org.apache.http.conn.ssl.SSLSocketFactory(keyStore, "123456");
                    config = new SSLConfig().with().sslSocketFactory(clientAuthFactory).and().allowAllHostnames();
            }
            if (token.equals("empty"))
                token = "";
            ContentType contentType = ContentType.XML;
            //2) pass to doPost function & put response into responses list

            if(content.equals("JSON"))
                contentType = ContentType.JSON;
            else if(content.equals("TXT"))
                contentType = ContentType.TEXT;
            else if(content.equals("HTML"))
                contentType = ContentType.HTML;
            else if(content.equals("BINARY"))
                contentType = ContentType.BINARY;
            else
                contentType = ContentType.XML;
            //headerMap.put("ResponseEncryptionType","AES256Signed");
            //headerMap.put("X-Client-Certifcate","MIIFPDCCBCSgAwIBAgIQBhCY9/Oua9sbbZUiKb7/ETANBgkqhkiG9w0BAQsFADBlMQswCQYDVQQGEwJVUzEVMBMGA1UEChMMRGlnaUNlcnQgSW5jMRkwFwYDVQQLExB3d3cuZGlnaWNlcnQuY29tMSQwIgYDVQQDExtEaWdpQ2VydCBTSEEyIEFzc3VyZWQgSUQgQ0EwHhcNMTcwNTIzMDAwMDAwWhcNMTgwNTIzMTIwMDAwWjBXMQswCQYDVQQGEwJTRzESMBAGA1UEBxMJU2luZ2Fwb3JlMSAwHgYDVQQKExdTdGFuZGFyZCBDaGFydGVyZWQgQmFuazESMBAGA1UEAxMJQWNtZSBDb3JwMIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAx+79CIYpTbQdM93rnQe2y+gMCAZGKfwVuyT4xjYDmYfKr4+/6F2OUoVAP0wsS+EufaFOdwGRYD2Xcg8fH/jwp4dynekLNmO94et7pDBIQoHoyqUz5IfYIhbkwUV5zAjJEfrAlLXEfrBB+j8v6/DMWcYoFvXvq2mA/rZCr5S5L7RCKj17Tup6OpRasbohHADLwLx/gk/gaX7fAzV/4jETHw1zxRg9jT8WaPp+Qs3KeQlXqDEX6vpH12flHDl1dF+QfuKN5jlKG77yKsThglYwRTeaxrL3RgU8X6P8T1S5xpzGCIlE7RHFTpta1Hxn3oD59AvhQkQ8CkYyOWzt6GS6uQIDAQABo4IB9DCCAfAwHwYDVR0jBBgwFoAU5wIjgABP2Ne8lAvZP3Q5STI8inkwHQYDVR0OBBYEFIzxOlIwI/C/ktPcOkYtZA1XWTKrMAwGA1UdEwEB/wQCMAAwJgYDVR0RBB8wHYEbcHJhc2FubmEua2FuYWdhc2FiYWlAc2MuY29tMA4GA1UdDwEB/wQEAwIFoDAdBgNVHSUEFjAUBggrBgEFBQcDAgYIKwYBBQUHAwQwQwYDVR0gBDwwOjA4BgpghkgBhv1sBAECMCowKAYIKwYBBQUHAgEWHGh0dHBzOi8vd3d3LmRpZ2ljZXJ0LmNvbS9DUFMwgYgGA1UdHwSBgDB+MD2gO6A5hjdodHRwOi8vY3JsMy5kaWdpY2VydC5jb20vRGlnaUNlcnRTSEEyQXNzdXJlZElEQ0EtZzIuY3JsMD2gO6A5hjdodHRwOi8vY3JsNC5kaWdpY2VydC5jb20vRGlnaUNlcnRTSEEyQXNzdXJlZElEQ0EtZzIuY3JsMHkGCCsGAQUFBwEBBG0wazAkBggrBgEFBQcwAYYYaHR0cDovL29jc3AuZGlnaWNlcnQuY29tMEMGCCsGAQUFBzAChjdodHRwOi8vY2FjZXJ0cy5kaWdpY2VydC5jb20vRGlnaUNlcnRTSEEyQXNzdXJlZElEQ0EuY3J0MA0GCSqGSIb3DQEBCwUAA4IBAQCuOYPuakKB9qCCR7JYaA+92BprzqYFd1LwT62FrdzcPGupHix7ALoiw2jHuMQogrc3Rw0wZPUqgN29b2bcXX8r9B8OMVbxYL6VZGJ8P+WndUPOzbWdl7eAY/9HbkAUgcqzSP+BBcndCyKdR+bs43dYDNvhDzqL7hHgqjmxFxVz8C/25oLmBZ0yOXz5yLpVoTyHBl1OfAkrYj5WeQI8/uiR9bJ4SwY/NvUU+sOB/UJsxECjpmmdS26dYMRyLuFT7hZvmgv8L2wcjO6vyA9qm3kNb0dTJw1/xQG56pdaGRhdVEqp/L3/hW0COgQvOVdRNlVH9dU8cCl57ICj9rtxTrqg");
            //headerMap.put("JWTToken", "");
            //headerMap.put("X-Client-Certifcate", "");
            if(responseEncrypted)
                headerMap.put("ResponseEncryptionType", "AES256Signed");
            else
            headerMap.put("ResponseEncryptionType", "non");
            //headerMap.put("GroupId",groupID);
            System.out.println("The request is "+ request);
            RestAssured.useRelaxedHTTPSValidation();

            try {
                RestAssured.config = RestAssured.config().sslConfig(config);
                response = genericUtils.getPOSTResponse(headerMap, token, "https://apitest.standardchartered.com/upi/ReqBalEnq/1.0", contentType);
               }catch(java.io.EOFException e){
            Assert.assertTrue("Invalid certificate is getting accepted",true);
        }
                // response = genericUtils.getPOSTResponse(headerMap, request, "https://10.23.210.60:9012/api-banking/upi/ReqBalEnq/1.0", contentType);
            System.out.println("The response is "+response.thenReturn().asString());
            actualStatusCode = response.getStatusCode();
            responseString = response.thenReturn().asString();
            System.out.println("The status code is "+actualStatusCode);
            //Assert.assertTrue("The Account Balance enquiry should be displayed with the balance with account number as " + "" + accountNumber + ". But it is displayed as " + response.thenReturn().asString(), response.thenReturn().asString().contains("" + accountNumber));
            }catch(java.io.EOFException e){
                Assert.assertTrue("Invalid certificate is getting accepted",true);
            }
        catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        } catch(PendingException e){
            e.printStackTrace();
        } catch (Throwable throwable) {
            throwable.printStackTrace();
        }
    }

    @Then("^the user hits the open api form of account balance inquiry with details$")
    public void getAccountBalanceOpenAPI(DataTable dataTable){
        // Write code here that turns the phrase above into concrete actions
        try {
            String filepath = new File(".").getCanonicalPath() + "/src/test/resources/test-data/UPI_AccountBalanceEnquiry1.xml";
            DocumentBuilderFactory docFactory = DocumentBuilderFactory.newInstance();
            DocumentBuilder docBuilder = docFactory.newDocumentBuilder();
            NewStub newStub = new NewStub();
            String request = newStub.readFile(filepath);
            InputSource source = new InputSource(new ByteArrayInputStream(request.getBytes()));
            Document doc = docBuilder.parse(filepath);
            Node payer = doc.getElementsByTagName("Payer").item(0);
            KeyStore keyStore = null;
            String data = null;
            String activKey =  "";
            RestAssured.useRelaxedHTTPSValidation();
            Map<String, String> headerMap = new HashMap<String, String>();
            Map<String, String> paramMap = new HashMap<String, String>();
            Iterator iterator = dataTable.asLists(Object.class).get(1).iterator();
            String accountNumber = "empty";
            String certificate = "empty";
            String token = "empty";
            String content = "empty";
            String groupID = "";
            String country = "";
            String currency = "";
            String accountType = "";
            InputStream input = getClass().getResourceAsStream("/test-data/activationKeyRequest.properties");
            Properties prop = new Properties();
            prop.load(input);
            RestAssured.useRelaxedHTTPSValidation();
            SSLConfig config = null;
            SSLConfig config1 = null;
            if (iterator.hasNext()) {
                accountNumber = (String) iterator.next();
                request = StringUtils.replace(request, "${accountNumber}", accountNumber);
            }
            if (iterator.hasNext()) {
                groupID = (String) iterator.next();
                //headerMap.put("GroupId",groupID);
            }
            if (iterator.hasNext()) {
                country = (String) iterator.next();
                request = StringUtils.replace(request, "${accountCountry}", country);
            }
            if (iterator.hasNext()) {
                currency = (String) iterator.next();
                request = StringUtils.replace(request, "${accountCurrency}", currency);
            }
            if (iterator.hasNext()) {
                accountType = (String) iterator.next();
                request = StringUtils.replace(request, "${accountType}", accountType);
            }
            if (iterator.hasNext())
                content = (String) iterator.next();

            if (iterator.hasNext()) {
                token = (String) iterator.next();
                if (iterator.hasNext())
                    certificate = (String) iterator.next();
                if (token.equals("Valid Token")) {
                    //String content = null;
                    activationKey.a_POST_request_is_made_to_the_activationKey_API_for_Group(groupID);
                    String[] parts = activKey.split("\"");
                    //token = JWTTest.createTokenForGroup(30L,activationKey.activationContent, activationKey.key, groupID);
                    activationKey.user_has_already_generated_the_JWT_token_for_the_group(groupID);
                    token = activationKey.activKey.get(groupID);
                    //activationKey.activateWithoutVerification(groupID);
                    headerMap.put("JWTToken",token);
                }else if(token.equals("InvalidToken")){
                    //String content = null;
                    headerMap.put("JWTToken","JWTTokenJWTTokenJWTTokenJWTTokenJWTToken");
                }else if(token.equals("EmptyToken")){
                    //String content = null;
                    headerMap.put("JWTToken","");
                }
                else if(token.equals("ExpiredToken")){
                    //String content = null;
                    activationKey.a_POST_request_is_made_to_the_activationKey_API_for_Group(groupID);
                    activationKey.user_has_already_generated_the_JWT_token_for_the_group(groupID);
                    token = activationKey.activKey.get(groupID);
                    Thread.sleep(30000) ;
                    headerMap.put("JWTToken",token);
                }else if(token.equals("DifferentGroupToken")){
                    //String content = null;
                    activationKey.a_POST_request_is_made_to_the_activationKey_API_for_Group("INDGRP1");
                    activationKey.user_has_already_generated_the_JWT_token_for_the_group("INDGRP1");
                    token = activationKey.activKey.get("INDGRP1");
                    activationKey.activKey.get("INDGRP1");
                    headerMap.put("JWTToken",token);
                }else if(token.equals("DuplicateToken")){
                    activationKey.a_POST_request_is_made_to_the_activationKey_API_for_Group(groupID);
                    activationKey.user_has_already_generated_the_JWT_token_for_the_group(groupID);
                    token = activationKey.activKey.get(groupID);
                    activationKey.activateWithoutVerification(groupID);
                    headerMap.put("JWTToken",token);
                }else{
                    headerMap.put("JWTToken","");
                }
            }
            if (certificate.equals("empty") || certificate.equals("Valid Cert")) {
               // certificate = prop.getProperty(groupID + "_Certificate");
                KeyStore keyStore1 = null;
                keyStore1 = KeyStore.getInstance("PKCS12");
                keyStore1.load(getClass().getResourceAsStream("./src/test/resources/test-data/bny-cert.pfx"), "bny123".toCharArray());
                org.apache.http.conn.ssl.SSLSocketFactory clientAuthFactory = null;
                clientAuthFactory = new org.apache.http.conn.ssl.SSLSocketFactory(keyStore1, "bny123");
                config = new SSLConfig().with().sslSocketFactory(clientAuthFactory).and().allowAllHostnames();
            }else if(certificate.equals("InvalidCert")) {
                //certificate = prop.getProperty(groupID + "_Certificate");
                //headerMap.put("X-Client-Certifcate","MIIFPDCCBCSgAwIBAgIQBhCY9/Oua9sbbZUiKb7/ETANBgkqhkiG9w0BAQsFADBlMQswCQYDVQQGEwJVUzEVMBMGA1UEChMMRGlnaUNlcnQgSW5jMRkwFwYDVQQLExB3d3cuZGlnaWNlcnQuY29tMSQwIgYDVQQDExtEaWdpQ2VydCBTSEEyIEFzc3VyZWQgSUQgQ0EwHhcNMTcwNTIzMDAwMDAwWhcNMTgwNTIzMTIwMDAwWjBXMQswCQYDVQQGEwJTRzESMBAGA1UEBxMJU2luZ2Fwb3JlMSAwHgYDVQQKExdTdGFuZGFyZCBDaGFydGVyZWQgQmFuazESMBAGA1UEAxMJQWNtZSBDb3JwMIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAx+79CIYpTbQdM93rnQe2y+gMCAZGKfwVuyT4xjYDmYfKr4+/6F2OUoVAP0wsS+EufaFOdwGRYD2Xcg8fH/jwp4dynekLNmO94et7pDBIQoHoyqUz5IfYIhbkwUV5zAjJEfrAlLXEfrBB+j8v6/DMWcYoFvXvq2mA/rZCr5S5L7RCKj17Tup6OpRasbohHADLwLx/gk/gaX7fAzV/4jETHw1zxRg9jT8WaPp+Qs3KeQlXqDEX6vpH12flHDl1dF+QfuKN5jlKG77yKsThglYwRTeaxrL3RgU8X6P8T1S5xpzGCIlE7RHFTpta1Hxn3oD59AvhQkQ8CkYyOWzt6GS6uQIDAQABo4IB9DCCAfAwHwYDVR0jBBgwFoAU5wIjgABP2Ne8lAvZP3Q5STI8inkwHQYDVR0OBBYEFIzxOlIwI/C/ktPcOkYtZA1XWTKrMAwGA1UdEwEB/wQCMAAwJgYDVR0RBB8wHYEbcHJhc2FubmEua2FuYWdhc2FiYWlAc2MuY29tMA4GA1UdDwEB/wQEAwIFoDAdBgNVHSUEFjAUBggrBgEFBQcDAgYIKwYBBQUHAwQwQwYDVR0gBDwwOjA4BgpghkgBhv1sBAECMCowKAYIKwYBBQUHAgEWHGh0dHBzOi8vd3d3LmRpZ2ljZXJ0LmNvbS9DUFMwgYgGA1UdHwSBgDB+MD2gO6A5hjdodHRwOi8vY3JsMy5kaWdpY2VydC5jb20vRGlnaUNlcnRTSEEyQXNzdXJlZElEQ0EtZzIuY3JsMD2gO6A5hjdodHRwOi8vY3JsNC5kaWdpY2VydC5jb20vRGlnaUNlcnRTSEEyQXNzdXJlZElEQ0EtZzIuY3JsMHkGCCsGAQUFBwEBBG0wazAkBggrBgEFBQcwAYYYaHR0cDovL29jc3AuZGlnaWNlcnQuY29tMEMGCCsGAQUFBzAChjdodHRwOi8vY2FjZXJ0cy5kaWdpY2VydC5jb20vRGlnaUNlcnRTSEEyQXNzdXJlZElEQ0EuY3J0MA0GCSqGSIb3DQEBCwUAA4IBAQCuOYPuakKB9qCCR7JYaA+92BprzqYFd1LwT62FrdzcPGupHix7ALoiw2jHuMQogrc3Rw0wZPUqgN29b2bcXX8r9B8OMVbxYL6VZGJ8P+WndUPOzbWdl7eAY/9HbkAUgcqzSP+BBcndCyKdR+bs43dYDNvhDzqL7hHgqjmxFxVz8C/25oLmBZ0yOXz5yLpVoTyHBl1OfAkrYj5WeQI8/uiR9bJ4SwY/NvUU+sOB/UJsxECjpmmdS26dYMRyLuFT7hZvmgv8L2wcjO6vyA9qm3kNb0dTJw1/xQG56pdaGRhdVEqp/L3/hW0COgQvOVdRNlVH9dU8cCl57ICj9rtxTrqg");
                try{
                    keyStore = KeyStore.getInstance("PKCS12");
                    keyStore.load(getClass().getResourceAsStream("/test-data/invalidcert.pfx"), "123456".toCharArray());
                    org.apache.http.conn.ssl.SSLSocketFactory clientAuthFactory = null;
                    clientAuthFactory = new org.apache.http.conn.ssl.SSLSocketFactory(keyStore, "123456");
                    config = new SSLConfig().with().sslSocketFactory(clientAuthFactory).and().allowAllHostnames();
                }catch(java.io.EOFException e){
                    System.out.println("The request could not accept invalid certificate.");
                    Assert.assertTrue("Invalid certificate is getting accepted",true);
                    return;
                }
            }else if(certificate.equals("DifferentCert")) {
                //certificate = prop.getProperty(groupID + "_Certificate");
                //headerMap.put("X-Client-Certifcate","MIIFPDCCBCSgAwIBAgIQBhCY9/Oua9sbbZUiKb7/ETANBgkqhkiG9w0BAQsFADBlMQswCQYDVQQGEwJVUzEVMBMGA1UEChMMRGlnaUNlcnQgSW5jMRkwFwYDVQQLExB3d3cuZGlnaWNlcnQuY29tMSQwIgYDVQQDExtEaWdpQ2VydCBTSEEyIEFzc3VyZWQgSUQgQ0EwHhcNMTcwNTIzMDAwMDAwWhcNMTgwNTIzMTIwMDAwWjBXMQswCQYDVQQGEwJTRzESMBAGA1UEBxMJU2luZ2Fwb3JlMSAwHgYDVQQKExdTdGFuZGFyZCBDaGFydGVyZWQgQmFuazESMBAGA1UEAxMJQWNtZSBDb3JwMIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAx+79CIYpTbQdM93rnQe2y+gMCAZGKfwVuyT4xjYDmYfKr4+/6F2OUoVAP0wsS+EufaFOdwGRYD2Xcg8fH/jwp4dynekLNmO94et7pDBIQoHoyqUz5IfYIhbkwUV5zAjJEfrAlLXEfrBB+j8v6/DMWcYoFvXvq2mA/rZCr5S5L7RCKj17Tup6OpRasbohHADLwLx/gk/gaX7fAzV/4jETHw1zxRg9jT8WaPp+Qs3KeQlXqDEX6vpH12flHDl1dF+QfuKN5jlKG77yKsThglYwRTeaxrL3RgU8X6P8T1S5xpzGCIlE7RHFTpta1Hxn3oD59AvhQkQ8CkYyOWzt6GS6uQIDAQABo4IB9DCCAfAwHwYDVR0jBBgwFoAU5wIjgABP2Ne8lAvZP3Q5STI8inkwHQYDVR0OBBYEFIzxOlIwI/C/ktPcOkYtZA1XWTKrMAwGA1UdEwEB/wQCMAAwJgYDVR0RBB8wHYEbcHJhc2FubmEua2FuYWdhc2FiYWlAc2MuY29tMA4GA1UdDwEB/wQEAwIFoDAdBgNVHSUEFjAUBggrBgEFBQcDAgYIKwYBBQUHAwQwQwYDVR0gBDwwOjA4BgpghkgBhv1sBAECMCowKAYIKwYBBQUHAgEWHGh0dHBzOi8vd3d3LmRpZ2ljZXJ0LmNvbS9DUFMwgYgGA1UdHwSBgDB+MD2gO6A5hjdodHRwOi8vY3JsMy5kaWdpY2VydC5jb20vRGlnaUNlcnRTSEEyQXNzdXJlZElEQ0EtZzIuY3JsMD2gO6A5hjdodHRwOi8vY3JsNC5kaWdpY2VydC5jb20vRGlnaUNlcnRTSEEyQXNzdXJlZElEQ0EtZzIuY3JsMHkGCCsGAQUFBwEBBG0wazAkBggrBgEFBQcwAYYYaHR0cDovL29jc3AuZGlnaWNlcnQuY29tMEMGCCsGAQUFBzAChjdodHRwOi8vY2FjZXJ0cy5kaWdpY2VydC5jb20vRGlnaUNlcnRTSEEyQXNzdXJlZElEQ0EuY3J0MA0GCSqGSIb3DQEBCwUAA4IBAQCuOYPuakKB9qCCR7JYaA+92BprzqYFd1LwT62FrdzcPGupHix7ALoiw2jHuMQogrc3Rw0wZPUqgN29b2bcXX8r9B8OMVbxYL6VZGJ8P+WndUPOzbWdl7eAY/9HbkAUgcqzSP+BBcndCyKdR+bs43dYDNvhDzqL7hHgqjmxFxVz8C/25oLmBZ0yOXz5yLpVoTyHBl1OfAkrYj5WeQI8/uiR9bJ4SwY/NvUU+sOB/UJsxECjpmmdS26dYMRyLuFT7hZvmgv8L2wcjO6vyA9qm3kNb0dTJw1/xQG56pdaGRhdVEqp/L3/hW0COgQvOVdRNlVH9dU8cCl57ICj9rtxTrqg");
                try{
                    keyStore = KeyStore.getInstance("PKCS12");
                    keyStore.load(getClass().getResourceAsStream("/test-data/bny-cert.pfx"), "bny123".toCharArray());
                    org.apache.http.conn.ssl.SSLSocketFactory clientAuthFactory = null;
                    clientAuthFactory = new org.apache.http.conn.ssl.SSLSocketFactory(keyStore, "bny123");
                    config = new SSLConfig().with().sslSocketFactory(clientAuthFactory).and().allowAllHostnames();
                }catch(Exception e){
                    Assert.assertTrue("Invalid certificate is getting accepted",true);
                }
            }
            if (token.equals("empty"))
                token = "";
            ContentType contentType = ContentType.XML;
            //2) pass to doPost function & put response into responses list

            if(content.equals("JSON"))
                contentType = ContentType.JSON;
            else if(content.equals("TEXT"))
                contentType = ContentType.TEXT;
            else if(content.equals("HTML"))
                contentType = ContentType.HTML;
            else if(content.equals("BINARY"))
                contentType = ContentType.BINARY;
            else
                contentType = ContentType.XML;
            //headerMap.put("ResponseEncryptionType","AES256Signed");
            //headerMap.put("X-Client-Certifcate","MIIFPDCCBCSgAwIBAgIQBhCY9/Oua9sbbZUiKb7/ETANBgkqhkiG9w0BAQsFADBlMQswCQYDVQQGEwJVUzEVMBMGA1UEChMMRGlnaUNlcnQgSW5jMRkwFwYDVQQLExB3d3cuZGlnaWNlcnQuY29tMSQwIgYDVQQDExtEaWdpQ2VydCBTSEEyIEFzc3VyZWQgSUQgQ0EwHhcNMTcwNTIzMDAwMDAwWhcNMTgwNTIzMTIwMDAwWjBXMQswCQYDVQQGEwJTRzESMBAGA1UEBxMJU2luZ2Fwb3JlMSAwHgYDVQQKExdTdGFuZGFyZCBDaGFydGVyZWQgQmFuazESMBAGA1UEAxMJQWNtZSBDb3JwMIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAx+79CIYpTbQdM93rnQe2y+gMCAZGKfwVuyT4xjYDmYfKr4+/6F2OUoVAP0wsS+EufaFOdwGRYD2Xcg8fH/jwp4dynekLNmO94et7pDBIQoHoyqUz5IfYIhbkwUV5zAjJEfrAlLXEfrBB+j8v6/DMWcYoFvXvq2mA/rZCr5S5L7RCKj17Tup6OpRasbohHADLwLx/gk/gaX7fAzV/4jETHw1zxRg9jT8WaPp+Qs3KeQlXqDEX6vpH12flHDl1dF+QfuKN5jlKG77yKsThglYwRTeaxrL3RgU8X6P8T1S5xpzGCIlE7RHFTpta1Hxn3oD59AvhQkQ8CkYyOWzt6GS6uQIDAQABo4IB9DCCAfAwHwYDVR0jBBgwFoAU5wIjgABP2Ne8lAvZP3Q5STI8inkwHQYDVR0OBBYEFIzxOlIwI/C/ktPcOkYtZA1XWTKrMAwGA1UdEwEB/wQCMAAwJgYDVR0RBB8wHYEbcHJhc2FubmEua2FuYWdhc2FiYWlAc2MuY29tMA4GA1UdDwEB/wQEAwIFoDAdBgNVHSUEFjAUBggrBgEFBQcDAgYIKwYBBQUHAwQwQwYDVR0gBDwwOjA4BgpghkgBhv1sBAECMCowKAYIKwYBBQUHAgEWHGh0dHBzOi8vd3d3LmRpZ2ljZXJ0LmNvbS9DUFMwgYgGA1UdHwSBgDB+MD2gO6A5hjdodHRwOi8vY3JsMy5kaWdpY2VydC5jb20vRGlnaUNlcnRTSEEyQXNzdXJlZElEQ0EtZzIuY3JsMD2gO6A5hjdodHRwOi8vY3JsNC5kaWdpY2VydC5jb20vRGlnaUNlcnRTSEEyQXNzdXJlZElEQ0EtZzIuY3JsMHkGCCsGAQUFBwEBBG0wazAkBggrBgEFBQcwAYYYaHR0cDovL29jc3AuZGlnaWNlcnQuY29tMEMGCCsGAQUFBzAChjdodHRwOi8vY2FjZXJ0cy5kaWdpY2VydC5jb20vRGlnaUNlcnRTSEEyQXNzdXJlZElEQ0EuY3J0MA0GCSqGSIb3DQEBCwUAA4IBAQCuOYPuakKB9qCCR7JYaA+92BprzqYFd1LwT62FrdzcPGupHix7ALoiw2jHuMQogrc3Rw0wZPUqgN29b2bcXX8r9B8OMVbxYL6VZGJ8P+WndUPOzbWdl7eAY/9HbkAUgcqzSP+BBcndCyKdR+bs43dYDNvhDzqL7hHgqjmxFxVz8C/25oLmBZ0yOXz5yLpVoTyHBl1OfAkrYj5WeQI8/uiR9bJ4SwY/NvUU+sOB/UJsxECjpmmdS26dYMRyLuFT7hZvmgv8L2wcjO6vyA9qm3kNb0dTJw1/xQG56pdaGRhdVEqp/L3/hW0COgQvOVdRNlVH9dU8cCl57ICj9rtxTrqg");
            //headerMap.put("JWTToken", "");
            //headerMap.put("X-Client-Certifcate", "");
            if(!responseEncrypted)
               // headerMap.put("ResponseEncryptionType", "AES256Signed");
            headerMap.put("ResponseEncryptionType", "non");
            //headerMap.put("GroupId",groupID);
            System.out.println("The request is "+ request);
            RestAssured.config = RestAssured.config().sslConfig(config);
            response = genericUtils.getGETResponseWithParam(headerMap, paramMap, EndPoint.ACCOUNTBALANCEOPENAPIURL +accountNumber, contentType);
            //response = genericUtils.getGETResponseWithParam(headerMap, paramMap, "https://10.23.210.60:9012/api-banking/scb/cib/account/"+accountNumber, contentType);
            System.out.println("The response is "+response.thenReturn().asString());
            actualStatusCode = response.getStatusCode();
            responseString = response.thenReturn().asString();
            System.out.println("The status code is "+actualStatusCode);
            //Assert.assertTrue("The Account Balance enquiry should be displayed with the balance with account number as " + "" + accountNumber + ". But it is displayed as " + response.thenReturn().asString(), response.thenReturn().asString().contains("" + accountNumber));
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        } catch(PendingException e){
            e.printStackTrace();
        } catch (Throwable throwable) {
            throwable.printStackTrace();
        }
    }

    @Then("^the user should be able to see error message '(.+)' with status code as '(\\d+)'$")
    public void verifyErrorMessage(String error, int expectedStatusCode) throws IOException {
        // Write code here that turns the phrase above into concrete actions
        String actualErrorMessage = response.thenReturn().asString();
        commonApiMethods commonApiMethods = new commonApiMethods();
        InputStream input = getClass().getResourceAsStream("/test-data/errorMessages.properties");
        commonApiMethods.errorMessageProperties.load(input);
        String expectedErrorMessage = commonApiMethods.errorMessageProperties.get(error).toString();
        Assert.assertTrue("Status code of the response should be displayed as "+expectedStatusCode+". But it is getting displayed as "+actualStatusCode,expectedStatusCode==actualStatusCode);
        Assert.assertTrue("The expected error message is "+expectedErrorMessage+". But actual error message is displayed as "+response.thenReturn().asString(), response.thenReturn().asString().equals(expectedErrorMessage));
    }

    @Then("^the user should be able to see status code as '(\\d+)' with the below details when decrypting with correct private key for '(.*)'$")
            public void verifyDecryptionWithValidPrivateKey(Integer arg0, String contentType,List<Map<String,String>> expectedData) throws Exception {
        // Write code here that turns the phrase above into concrete actions
        for (Map<String, String> data : expectedData) {
            String groupID = data.get("GroupID");
            Assert.assertTrue("Peek Response is not displayed as encrypted content. Actual Response - " + response.thenReturn().asString(), response.thenReturn().asString().contains("content") && response.thenReturn().asString().contains("key"));
            responseEncrypted = true;
            responseString = genericUtils.decryptResponse(response, groupID);
            if(contentType.equals("XML"))
                verifyResponse(expectedData);
            else
                verifyOpenApiResponse(expectedData);
        }
    }

    @Then("^the user should be able to see error message when decrypting with private key of group '(.*)'$")
            public void verifyDecryptionErrorWithInvalidData(String groupID) throws NoSuchPaddingException, NoSuchAlgorithmException, IOException {
        responseEncrypted=true;
        responseString = genericUtils.decryptResponse(response,groupID);
    }

}
