package ab.glue.api;

import ab.utils.GenericUtils;

/**
 * Created by 1571168 on 9/19/2018.
 */
public class Peek extends GenericUtils {

    @Data(name = "AccountNumber", xpath = "//Payer/Ac/Detail", jsonpath = "[0].number", responseJSonPath = "")
    String accountNumber;

    //ns2:Payer/Ac/Detail/text(, responseJSonPath = "")

    @Data(name = "Currency", xpath = "//Payer/Amount/attribute::curr", jsonpath = "[0].currency", responseJSonPath = "")
    String currency;

    @Data(name = "GroupID", xpath = "//Head/attribute::orgId", jsonpath = "[0].groupId", responseJSonPath = "")
    String groupID;

    @Data(name = "Country", xpath = "//Payer/Country", jsonpath = "[0].country", responseJSonPath = "")
    String country;

    @Data(name = "AccountType", xpath = "//Payer/attribute::type", jsonpath = "[0].type", responseJSonPath = "")
    String accountType;

    @Data(name = "Balance", xpath = "//Payer/Bal/AvailableBal", jsonpath = "[0].balance.amount", responseJSonPath = "")
    String accountBalance;

    @Data(name = "OpeningAvailiableBalance", xpath = "//Payer/Bal/OpeningBal", jsonpath = "[0].balance.opening", responseJSonPath = "")
    String openingBalance;

    @Data(name = "ClosingLedgerBalance", xpath = "//Payer/Bal/ClosingLedgerBal", jsonpath = "[0].balance.closingLedger", responseJSonPath = "")
    String closingLedgeraccountBalance;

    @Data(name = "BIC", xpath = "//Payer/attribute::addr", jsonpath = "[0].swiftBic", responseJSonPath = "")
    String swift_bic;

//    @Data(name = "BankID", xpath = "//Payer/Bal/OpeningLedgerBal", jsonpath = "balance[1].bank_id", responseJSonPath = "")
//    String bank_id;

    @Data(name = "OpeningLedgerBalance", xpath = "//Payer/Bal/OpeningLedgerBal", jsonpath = "[0].balance.openingLedger", responseJSonPath = "")
    String openingLedgeraccountBalance;

    @Data(name = "CreditDebitAmount", xpath = "//TransactionDetails/TransactionEntry//TrnAmount", jsonpath = "content[0].transactionAmount.amount", responseJSonPath = "")
    String creditDebitccountBalance;

    @Data(name = "CreditDebitAccountNo", xpath = "//TransactionDetails/TransactionEntry//AccountNo", jsonpath = "content[0].accountIdentifier.accountId", responseJSonPath = "")
    String creditDebitAccountNo;

    @Data(name = "CreditDebitCorrelationID", xpath = "//Header/originationDetails//correlationID", jsonpath = "content[0].accountIdentifier.accountId", responseJSonPath = "")
    String creditDebitCorrelationID;

    @Data(name = "CreditDebitFlag", xpath = "//TransactionDetails/TransactionEntry//CreditDebitFlag", jsonpath = "content[0].adviceType", responseJSonPath = "")
    String creditDebitFlag;


    @Data(name = "CreditDebitFlag1", xpath = "//TransactionDetails/TransactionEntry//CreditDebitFlag", jsonpath = "content[0].adviceType", responseJSonPath = "")
    String creditDebitFlag1;

    @Data(name = "CreditDebitCurrency", xpath = "//TransactionDetails/TransactionEntry//Account//CurrencyCode", jsonpath = "content[0].transactionAmount.currencyCode", responseJSonPath = "")
    String creditDebitCurrency;

    @Data(name = "CreditDebitBIC", xpath = "//TransactionDetails/TransactionEntry//SwiftAddress", jsonpath = "content[0].accountIdentifier.bankCode", responseJSonPath = "")
    String creditDebitBIC;

    @Data(name = "CreditDebitTransactionCode", xpath = "//TransactionDetails/TransactionEntry//TrnCode//Code", jsonpath = "content[0].transactionCode", responseJSonPath = "")
    String creditDebitTransactionCode;

    @Data(name = "CreditDebitCountryCode", xpath = "//header//countryCode", jsonpath = "content[0].transactionCode", responseJSonPath = "")
    String creditDebitCountryCode;

    @Data(name = "CreditDebitTransactionIdentifier", xpath = "//TransactionDetails/TransactionEntry//ApprvSeqno", jsonpath = "content[0].transactionIdentifier.identifier", responseJSonPath = "")
    String creditDebitTransactionIdentifier;

    @Data(name = "CreditDebitClientIdentifier", xpath = "//TransactionDetails/TransactionEntry//Paydtl//SenderRefno", jsonpath = "content[0].clientIdentifier.identifier", responseJSonPath = "")
    String creditDebitClientIdentifier;

    @Data(name = "CreditDebitValueDate", xpath = "//TransactionDetails/TransactionEntry//ValueDate", jsonpath = "content[0].valueDate", responseJSonPath = "")
    String creditDebitValueDate;


    @Data(name = "CreditDebitTransactionDescription", xpath = "//TransactionDetails/TransactionEntry//TrnCode//Desc", jsonpath = "content[0].transactionDescription", responseJSonPath = "")
    String creditDebitTransactionDescription;

    @Data(name = "CreditDebitPreTransactionBalance", xpath = "//TransactionDetails/TransactionEntry//BalanceDetails//Ledger", jsonpath = "content[0].preExecutionBalance.amount", responseJSonPath = "")
    String CreditDebitPreTransactionBalance;

    @Data(name = "CreditDebitVirtualaccountnumber", xpath = "//TransactionDetails/TransactionEntry//VirtualAccountNo", jsonpath = "content[0].virtualAccountId", responseJSonPath = "")
    String CreditDebitVirtualaccountnumber;

    @Data(name = "CreditDebitBAICode", xpath = "//TransactionDetails/TransactionEntry//VirtualAccountNo", jsonpath = "content[0].baiCode", responseJSonPath = "")
    String creditDebitBAICode;

    @Data(name = "CreditDebitNarration1", xpath = "//TransactionDetails/TransactionEntry//Narrations/Narration1", jsonpath = "", responseJSonPath = "")
    String creditDebitNarration1;


    @Data(name = "CreditDebitNarration2", xpath = "//TransactionDetails/TransactionEntry//Narrations/Narration2", jsonpath = "", responseJSonPath = "")
    String creditDebitNarration2;

    @Data(name = "CreditDebitNarration3", xpath = "//TransactionDetails/TransactionEntry//Narrations/Narration3", jsonpath = "", responseJSonPath = "")
    String CreditDebitNarration3;

    @Data(name = "CreditDebitNarration4", xpath = "//TransactionDetails/TransactionEntry//Narrations/Narration4", jsonpath = "", responseJSonPath = "")
    String CreditDebitNarration4;

    @Data(name = "CreditDebitExternalIdentifier", xpath = "", jsonpath = "content[0].externalIdentifier.identifier", responseJSonPath = "")
    String CreditDebitExternalIdentifier;

    @Data(name = "CreditDebitTransactionFreeText1", xpath = "", jsonpath = "content[0].transactionFreeText[0]", responseJSonPath = "")
    String CreditDebitTransactionFreeText1;

    @Data(name = "CreditDebitTransactionFreeText2", xpath = "", jsonpath = "content[0].transactionFreeText[1]", responseJSonPath = "")
    String CreditDebitTransactionFreeText2;
    @Data(name = "CreditDebitTransactionFreeText3", xpath = "", jsonpath = "content[0].transactionFreeText[2]", responseJSonPath = "")
    String CreditDebitTransactionFreeText3;
    @Data(name = "CreditDebitTransactionFreeText4", xpath = "", jsonpath = "content[0].transactionFreeText[3]", responseJSonPath = "")
    String CreditDebitTransactionFreeText4;


    @Data(name = "inimegRequestAmount", xpath = "", jsonpath = "request.body.amount.value", responseJSonPath = "")
    String inimegRequestAmount;
    @Data(name = "inimegRequestClientId", xpath = "", jsonpath = "request.head.clientId", responseJSonPath = "")
    String inimegRequestClientId;

    @Data(name = "inimegResponseResultCode", xpath = "", jsonpath = "response.body.resultInfo.resultCode", responseJSonPath = "")
    String inimegResponseResultCode;
    @Data(name = "inimegResponseClientId", xpath = "", jsonpath = "response.head.clientId", responseJSonPath = "")
    String inimegResponseClientId;


    @Data(name = "inimegRequestCurrency", xpath = "", jsonpath = "request.body.amount.currency", responseJSonPath = "")
    String inimegRequestCurrency;
    @Data(name = "inimegRequestAccountNumber", xpath = "", jsonpath = "request.body.accountInfo.accountNo", responseJSonPath = "")
    String inimegRequestAccountNumber;
    @Data(name = "inimegRequestSignature", xpath = "", jsonpath = "signature", responseJSonPath = "")
    String inimegRequestSignature;

    @Data(name = "inimegResponseCurrency", xpath = "", jsonpath = "response.body.resultInfo.resultCode", responseJSonPath = "")
    String inimegResponseCurrency;

    @Data(name = "inimegResponseResultStatus", xpath = "", jsonpath = "response.body.resultInfo.resultStatus", responseJSonPath = "")
    String inimegResponseResultStatus;

    @Data(name = "inimegRequestMsgId", xpath = "", jsonpath = "request.head.reqMsgId", responseJSonPath = "")
    String inimegRequestMsgId;

    @Data(name = "inimegManageTrustlineRequestAmount", xpath = "", jsonpath = "request.body.limitAmount.value", responseJSonPath = "")
    String inimegManageTrustlineRequestAmount;

    @Data(name = "inimegManageTrustlineRequestCurrency", xpath = "", jsonpath = "request.body.limitAmount.currency", responseJSonPath = "")
    String inimegManageTrustlineRequestCurrency;

    @Data(name = "inimegResponseMsgId", xpath = "", jsonpath = "response.head.reqMsgId", responseJSonPath = "")
    String inimegResponseMsgId;

    @Data(name = "inimegRequestAccountId", xpath = "", jsonpath = "request.body.accountId", responseJSonPath = "")
    String inimegRequestAccountId;

    @Data(name = "inimegQueryBCTrustlineRequestCurrency", xpath = "", jsonpath = "request.body.currency", responseJSonPath = "")
    String inimegQueryBCTrustlineRequestCurrency;

    @Data(name = "inimegQueryManageTrustlineResponseCurrency", xpath = "", jsonpath = "response.body.queryBcBalanceResponse.balanceInfos[0].amount.currency", responseJSonPath = "")
    String    inimegQueryManageTrustlineResponseCurrency;

    @Data(name = "inimegQueryManageTrustlineResponseAmount", xpath = "", jsonpath = "response.body.queryBcBalanceResponse.balanceInfos[0].amount.value", responseJSonPath = "")
    String    inimegQueryManageTrustlineResponseAmount;

    @Data(name = "inimegQueryBCOperationType", xpath = "", jsonpath = "request.body.operationType", responseJSonPath = "")
    String    inimegQueryBCOperationType;

    @Data(name = "inimegQueryBCOperationID", xpath = "", jsonpath = "request.body.bcOperationId", responseJSonPath = "")
    String inimegQueryBCOperationID;

    @Data(name = "inimegQueryBCOperationResponseResultStatus", xpath = "", jsonpath = "response.body.bcOperationResponse.resultInfo.resultStatus", responseJSonPath = "")
    String inimegQueryBCOperationResponseResultStatus;

    @Data(name = "inimegQueryBCOperationResponseBCOperationId", xpath = "", jsonpath = "response.body.bcOperationResponse.bcOperationId", responseJSonPath = "")
    String inimegQueryBCOperationResponseBCOperationId;

    @Data(name = "inimegQueryBCOperationResponseBCOperationMId", xpath = "", jsonpath = "response.body.bcOperationResponse.bcOperatorMid", responseJSonPath = "")
    String inimegQueryBCOperationResponseBCOperationMId;

    @Data(name = "inimegQueryBCOperationResponseResultCode", xpath = "", jsonpath = "response.body.bcOperationResponse.resultInfo.resultCode", responseJSonPath = "")
    String inimegQueryBCOperationResponseResultCode;

    @Data(name = "inimegQueryBCOperationResponseResultCode", xpath = "", jsonpath = "response.body.bcOperationResponse.resultInfo.resultCode", responseJSonPath = "")
    String inimegQueryBCOperationResponseResult;

    @Data(name = "openAPIPaymentAmount", xpath = "", jsonpath = "instruction.amount", responseJSonPath = "")
    String openAPIPaymentAmount = null;

    @Data(name = "openAPIPaymentCurrency", xpath = "", jsonpath = "instruction.currency", responseJSonPath = "")
    String openAPIPaymentCurrency= null;

    @Data(name = "openAPIPaymentDebitAccountNumber", xpath = "", jsonpath = "instruction.debtor.account.id", responseJSonPath = "")
    String openAPIPaymentDebitAccountNumber= null;

    @Data(name = "openAPIPaymentCreditAccountNumber", xpath = "", jsonpath = "instruction.creditor.account.id", responseJSonPath = "")
    String openAPIPaymentCreditAccountNumber= null;

    @Data(name = "openAPIPaymentDebitBIC", xpath = "", jsonpath = "instruction.debtorAgent.financialInstitution.BIC", responseJSonPath = "")
    String openAPIPaymentDebitBIC= null;

    @Data(name = "openAPIPaymentCreditBIC", xpath = "", jsonpath = "instruction.creditorAgent.financialInstitution.BIC", responseJSonPath = "")
    String openAPIPaymentCreditBIC= null;

    @Data(name = "openAPIPaymentdebitName", xpath = "", jsonpath = "instruction.debtor.name", responseJSonPath = "")
    String openAPIPaymentdebitName= null;

    @Data(name = "openAPIPaymentcreditName", xpath = "", jsonpath = "instruction.creditor.name", responseJSonPath = "")
    String openAPIPaymentcreditName= null;

    @Data(name = "openAPIPaymentdebitCountry", xpath = "", jsonpath = "instruction.debtorAgent.financialInstitution.postalAddress.country", responseJSonPath = "")
    String openAPIPaymentdebitCountry= null;

    @Data(name = "openAPIPaymentcreditCountry", xpath = "", jsonpath = "instruction.creditorAgent.financialInstitution.postalAddress.country", responseJSonPath = "")
    String openAPIPaymentcreditCountry= null;

    @Data(name = "openAPIPaymentType", xpath = "", jsonpath = "instruction.paymentType", responseJSonPath = "")
    String openAPIPaymentType= null;

    @Data(name = "openAPIPaymentMessageID", xpath = "", jsonpath = "header.messageId", responseJSonPath = "")
    String openAPIPaymentMessageID= null;

    @Data(name = "openAPIPaymentReferenceID", xpath = "", jsonpath = "instruction.referenceId", responseJSonPath = "")
    String openAPIPaymentReferenceID= null;

    @GenericUtils.Data(name = "openAPIPaymentStatusEndToEndId", xpath = "", jsonpath = "statuses[0].endToEndId",responseJSonPath ="content[1].endToEndId")
    String openAPIPaymentStatusEndToEndId = null;

    @GenericUtils.Data(name = "openAPIPaymentStatusStatusCode", xpath = "", jsonpath = "statuses[0].statusCode",responseJSonPath ="content[1].statusCode")
    String openAPIPaymentStatusStatusCode = null;

    @GenericUtils.Data(name = "openAPIPaymentStatusLastAssignee", xpath = "", jsonpath = "statuses[0].lastAssignee",responseJSonPath ="content[1].lastAssignee")
    String openAPIPaymentStatusLastAssignee= null;

    @GenericUtils.Data(name = "openAPIPaymentStatusReasonCode", xpath = "", jsonpath = "statuses[0].reasonCode",responseJSonPath ="content[1].reasonCode")
    String openAPIPaymentStatusReasonCode= null;

    @GenericUtils.Data(name = "openAPIPaymentStatusReasonIsoCode", xpath = "", jsonpath = "statuses[0].reasonIsoCode",responseJSonPath ="content[1].reasonIsoCode")
    String openAPIPaymentStatusReasonIsoCode= null;

    @GenericUtils.Data(name = "openAPIPaymentStatusAdditionalInformation", xpath = "", jsonpath = "statuses[0].additionalInformation",responseJSonPath ="content[1].additionalInformation")
    String openAPIPaymentStatusAdditionalInformation= null;

    @GenericUtils.Data(name = "openAPIPaymentStatusReasonInformation", xpath = "", jsonpath = "statuses[0].additionalInformation",responseJSonPath ="content[1].reasonInformation")
    String openAPIPaymentStatusReasonInformation= null;

    @Data(name = "custodyHoldingSCAID", xpath = "", jsonpath = "content[0].securitiesAccount", responseJSonPath = "content[0].securitiesAccount")
    String custodyHoldingSCAID= null;

    @Data(name = "custodyStatus", xpath = "", jsonpath = "content[0].status", responseJSonPath = "content[0].status")
    String custodyStatus= null;

    @Data(name = "custodyTradeDate", xpath = "", jsonpath = "content[0].tradeDate", responseJSonPath = "content[0].tradeDate")
    String custodyTradeDate= null;

    @Data(name = "custodySettlementDate", xpath = "", jsonpath = "content[0].settlementDate", responseJSonPath = "content[0].settlementDate")
    String custodySettlementDate= null;

    @Data(name = "custodyClientTransactionIdentifier", xpath = "", jsonpath = "content[0].transactionReference.clientTransactionIdentifier", responseJSonPath = "content[0].transactionReference.clientTransactionIdentifier")
    String custodyClientTransactionIdentifier= null;

    @Data(name = "custodyTransactionIdentifier", xpath = "", jsonpath = "content[0].transactionReference.transactionIdentifier", responseJSonPath = "content[0].transactionReference.transactionIdentifier")
    String custodyTransactionIdentifier= null;
}
