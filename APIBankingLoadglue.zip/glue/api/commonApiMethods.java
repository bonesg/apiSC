package ab.glue.api;

import common.RestAssuredConfig;
import cucumber.api.Scenario;
import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import io.restassured.RestAssured;
import io.restassured.specification.ProxySpecification;

import java.io.InputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Properties;


/**
 * Created by 1556780 on 2/27/2017.
 * This class contains common methods used across all the api glue-code classes
 */
public class commonApiMethods {

    public static ArrayList<HashMap> data = new ArrayList<>();
    public static String scenarioName = "";
    public static Properties errorMessageProperties = new Properties();
    public static Properties prop = new Properties();
    public static Properties endPointProp = new Properties();
    //Setting up rest configuration: BaseURI, BasePath, Port
    @Before
    public void setup_API_Configurations(Scenario scenario) throws Throwable {
        RestAssuredConfig.RestConfig();
        String testcaseID = scenario.getName().split(" -")[0];
        System.out.println(testcaseID);
        //data = ExcelReader.getTestDataByTestCaseId(testcaseID, "APIBanking");
        scenarioName = scenario.getName();
        InputStream input = getClass().getResourceAsStream("/test-data/errorMessages.properties");
        errorMessageProperties.load(input);
        InputStream input1 = getClass().getResourceAsStream("/test-data/activationKeyRequest.properties");
        prop.load(input1);
        InputStream input2 = getClass().getResourceAsStream("/test-data/endPoint.properties");
        endPointProp.load(input2);
        ProxySpecification proxySpecification = new ProxySpecification("10.65.128.43",8080,"HTTP");
        RestAssured.proxy(proxySpecification);
    }






    @Given("^'(.+)' API$")
    public void an_API(String apiName) throws Throwable {
        System.out.println("Validating: "+apiName+" API. ");
    }

    @Given("^I get the test data for '(.+)'$")
    public void getTestData(String testCaseID){
        System.out.println("Given :"+scenarioName);

    }


}
