package ab.glue.api;

import ab.api.tests.PeekAndConsumeTest;
import ab.common.JWTTest;
import ab.common.PeekAndConsumeConfig;
import ab.utils.GenericUtils;
import com.github.wnameless.json.flattener.JsonFlattener;
import com.github.wnameless.json.unflattener.JsonUnflattener;
import com.google.common.collect.ImmutableMap;
import com.google.common.collect.Maps;
import common.EncryptDecrypt;
import common.EndPoint;
import common.JWT;
import common.RestAssuredConfig;
import cucumber.api.DataTable;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import io.restassured.RestAssured;
import io.restassured.config.SSLConfig;
import io.restassured.http.ContentType;
import io.restassured.response.Response;
import io.restassured.response.ValidatableResponse;
import org.apache.http.HttpStatus;
import org.junit.Assert;

import javax.crypto.NoSuchPaddingException;
import javax.xml.bind.DatatypeConverter;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.security.*;
import java.security.cert.CertificateEncodingException;
import java.security.cert.X509Certificate;
import java.util.*;

import static io.restassured.RestAssured.given;
import static java.lang.System.currentTimeMillis;
import static org.joda.time.Instant.now;

/**
 * Created by 1556780 on 6/21/2017.
 */
public class activationKey extends RestAssuredConfig {

    private static ValidatableResponse validatableResponse = null;
    private static String response;
    private static String statusText;
    private static int statusCode;
    public static String activationContent = null;
    public static String key = null;
    public static String token = null;
    public static String certificate = null;
    public static String activationKeyResponseString = null;
    public static int activationKeyResponseStatus;
    public static HashMap<String, String> activKey = new HashMap<String, String>();
    public static HashMap<String, String> contentAndKey = new HashMap<String,  String>();
    GenericUtils genericUtils = new GenericUtils();
    @When("^a POST request is made to the activationKey API for the group '(.+)'$")
            public void createActivationKeyForGroup(String group) throws Throwable {
                String content = null;
                try {
                    content = new Scanner(new File("./src/test/resources/test-data/"+group+"activationKeyBody.json")).useDelimiter("\\Z").next();
                } catch (Exception e) {
                    e.printStackTrace();
        }

        KeyStore keyStore = null;

        //capturing API response as validatable response
        validatableResponse = given()
                .proxy("10.65.128.43", 8080)
                .contentType(ContentType.JSON)
                .body(content)
                .when()
                .post(EndPoint.POST_CreateActivationKey)
                .then();
        //capturing API response as String
        response =
                given()
                        .proxy("10.65.128.43", 8080)
                        .contentType(ContentType.JSON)
                        .body(content)
                        .when()
                        .post(EndPoint.POST_CreateActivationKey)
                        .thenReturn()
                        .asString();
        System.out.println("Response is " + response);
        String[] parts = response.split("\"");
        /*for (String s : parts) {
            System.out.println(s);
        }*/

        activationContent = parts[3];
        key = parts[7];
    }

    @When("^a POST request is made to the activationKey API$")
    public void a_POST_request_is_made_to_the_activationKey_API() throws Throwable {
        String content = null;
        try {
           // content = new Scanner(new File("./src/test/resources/activationKeyBody.json")).useDelimiter("\\Z").next();
            content = new Scanner(getClass().getResourceAsStream("/test-data/activationKeyBody"+"INDGROUP"+".json")).useDelimiter("\\Z").next();
        } catch (Exception e) {
            e.printStackTrace();
        }

        KeyStore keyStore = null;

        //capturing API response as validatable response
        validatableResponse = given()
                .proxy("10.65.128.43", 8080)
                .contentType(ContentType.JSON)
                .body(content)
                .when()
                .post(EndPoint.CREATE_ACTIVATION_KEY_URL+EndPoint.POST_CreateActivationKey)
                .then();
        //capturing API response as String
        response =
                given()
                        .proxy("10.65.128.43", 8080)
                        .contentType(ContentType.JSON)
                        .body(content)
                        .when()
                        .post(EndPoint.CREATE_ACTIVATION_KEY_URL+EndPoint.POST_CreateActivationKey)
                        .thenReturn()
                        .asString();
        System.out.println("Response is " + response);
        String[] parts = response.split("\"");
        /*for (String s : parts) {
            System.out.println(s);
        }*/

        activationContent = parts[5];
        key = parts[9];
    }


    @When("^a POST request is made to the activationKey API with public key '(.*)' groupID '(.*)' certificate thumbprint '(.*)'$")
    public void a_POST_request_is_made_to_the_activation_key(String publicKey, String groupID, String thumbprint) throws Throwable {
        String content = null;
        try {
            // content = new Scanner(new File("./src/test/resources/activationKeyBody.json")).useDelimiter("\\Z").next();
            content = new Scanner(getClass().getResourceAsStream("/test-data/activationKeyBody.json")).useDelimiter("\\Z").next();
        } catch (Exception e) {
            e.printStackTrace();
        }
        content = content.replaceAll(" ","");
        String expectedFingerprint = content.split("\"certificateThumbprint\":\"")[1].split("\",")[0];
        String expectedPublickey = content.split("\"publicKey\":\"")[1].split("\",")[0];
        String expectedGroupID = content.split("\"groupId\":\"")[1].split("\",")[0];
        content = content.replaceAll(expectedFingerprint,thumbprint);
        content = content.replaceAll(expectedPublickey,publicKey);
        content = content.replaceAll(expectedGroupID,groupID);
        System.out.println("Request passed : "+content);
        KeyStore keyStore = null;
HashMap<String, String> headerMap = new HashMap<String, String>();
        //capturing API response as validatable response
        RestAssured.useRelaxedHTTPSValidation();
       Response response1 =
        genericUtils.getPOSTResponse(headerMap,content,EndPoint.CREATE_ACTIVATION_KEY_URL+EndPoint.POST_CreateActivationKey,ContentType.JSON);
        activationKeyResponseStatus = response1
                .getStatusCode();

        //capturing API response as String
        activationKeyResponseString = response1
                .thenReturn()
                .asString();

        statusText = response1.statusLine();
        String[] parts = null;
        if(!activationKeyResponseString.equals("")) {
            parts = activationKeyResponseString.split("\"");
            activationContent = parts[5];
            key = parts[9];
        }
        System.out.println("Response is " + activationKeyResponseString);
        System.out.println("Response Status code is "+activationKeyResponseStatus);
        System.out.println("Response Status text is "+statusText+"\n");

    }

    @Then("^the response should be displayed as 500 error$")
        public void verifyActivationKeyResponse(){

        Assert.assertTrue("", statusCode == 500);
        Assert.assertTrue("",response.contains(""));
    }

    @When("^a POST request is made to the activationKey API with values$")
    public void postActivationKeywithDataTable(DataTable table) throws Throwable {
        String content = null;
        content = new Scanner(getClass().getResourceAsStream("/test-data/activationKeyBody.json")).useDelimiter("\\Z").next();
        Map<String, Object> flattenJson = JsonFlattener.flattenAsMap(content);
        System.out.println(flattenJson.toString().replaceAll("\\\\/","\\/"));
        List<Map<String  ,String>> data = table.asMaps(String.class, String.class);
        Map<String, String> mapData = new HashMap<String,String>();
        for (Map map :data) {
            for (Object key : map.keySet()) {
                flattenJson.replace(key.toString(), map.get(key.toString()));
            }
        }
        String unflattenJson = JsonUnflattener.unflatten(flattenJson.toString()).replaceAll("\\\\/","\\/");
        System.out.println("request passed is "+unflattenJson);
        GenericUtils genericUtils = new GenericUtils();
        Map<String, String> headerMap = new HashMap<String, String>();
        Response response1 =  genericUtils.getPOSTResponse(headerMap,unflattenJson.toString(),EndPoint.CREATE_ACTIVATION_KEY_URL+EndPoint.POST_CreateActivationKey,ContentType.JSON);
        //capturing API response as validatable response
        validatableResponse = response1
                .then();
        response = response1.thenReturn().asString();
        System.out.println("Response is " + response);
        String[] parts = response.split("\"");
        activationContent = parts[5];
        key = parts[9];

    }

     @When("^a POST request is made to the activationKey API for group '(.+)'$")
    public void a_POST_request_is_made_to_the_activationKey_API_for_Group(String group) throws Throwable {
        RestAssuredConfig.RestConfigProxy();
        String[] parts = getActivationKey(group, commonApiMethods.prop).split("\"");
        activationContent = parts[5];
        key = parts[9];
    }


    @When("^a POST request is made to the activationKey API with '(.*)' for group '(.+)'$")
    public void createActivationKeyWithNewCertificate(String value, String groupID) throws Throwable {
        InputStream input = getClass().getResourceAsStream("/test-data/activationKeyRequest.properties");
        Properties prop = new Properties();
        prop.load(input);
        String activationKey = "";
        RestAssured.useRelaxedHTTPSValidation();
        activationKey = new Scanner(getClass().getResourceAsStream("/test-data/activationKeyBody.json")).useDelimiter("\\Z").next();
        Map<String, Object> flattenJson = JsonFlattener.flattenAsMap(activationKey);
        System.out.println(flattenJson.toString().replaceAll("\\\\/", "\\/"));
        flattenJson.replace("ActivationKeyBody.groupId", groupID);
        flattenJson.replace("ActivationKeyBody.propertyBag.supportEmailAddress", prop.getProperty(groupID + "_Email"));
        flattenJson.replace("ActivationKeyBody.propertyBag.supportContactName", prop.getProperty(groupID + "_Name"));
        if(value.equals("newPublicKey")) {
            flattenJson.replace("ActivationKeyBody.publicKey", prop.getProperty(groupID + "_NewPublicKey"));
            flattenJson.replace("ActivationKeyBody.certificateThumbprint", prop.getProperty(groupID + "_Certificate"));
        }
        else if(value.equals("newCertificate")) {
            flattenJson.replace("ActivationKeyBody.certificateThumbprint", prop.getProperty(groupID + "_NewCertificate"));
            flattenJson.replace("ActivationKeyBody.publicKey", prop.getProperty(groupID + "_PublicKey"));
        }
        else {
            flattenJson.replace("ActivationKeyBody.publicKey", prop.getProperty(groupID + "_PublicKey"));
            flattenJson.replace("ActivationKeyBody.certificateThumbprint", prop.getProperty(groupID + "_Certificate"));
        }
        String unflattenJson = JsonUnflattener.unflatten(flattenJson.toString()).replaceAll("\\\\/", "\\/");
        System.out.println("request passed is " + unflattenJson);
        HashMap<String, String> headerMap1 = new HashMap<String, String>();
        Response response = genericUtils.getPOSTResponse(headerMap1, unflattenJson, EndPoint.CREATE_ACTIVATION_KEY_URL+EndPoint.POST_CreateActivationKey, ContentType.JSON);
        activationKeyResponseStatus = response.getStatusCode();
        activationKeyResponseString = response.thenReturn().asString();
        activationKey = response.thenReturn().asString();
        System.out.println("The activation key is "+activationKey);
        String[] parts = activationKey.split("\"");
        activationContent = parts[5];
        key = parts[9];
    }

    @When("^a POST request is made to the activationKey API for new group '(.+)' with already activated public key of group '(.*)'$")
    public void postRequestWithAlreadyActivatedGroupPublicKey(String group, String alreadyActivatedGroupID) throws Throwable {
        InputStream input = getClass().getResourceAsStream("/test-data/activationKeyRequest.properties");
        Properties prop = new Properties();
        prop.load(input);
        Response responseString = getActivationKeyResponseForAlreadyActivatedPublicKey(group,alreadyActivatedGroupID,prop);
        activationKeyResponseString = responseString.thenReturn().asString();
        activationKeyResponseStatus = responseString.getStatusCode();
    }


@Then("^API response should be displayed with as '(.*)' with status code '(.*)'")
public void verifyResponseWithStatusCode(String expectedResponse, int expectedStatusCode ){
    Assert.assertTrue("The expected response - "+expectedResponse+". Actual Response - "+activationKeyResponseString, expectedResponse.equals(activationKeyResponseString));
    Assert.assertTrue("The expected status code - "+expectedStatusCode+". Actual status code - "+activationKeyResponseStatus, activationKeyResponseStatus==expectedStatusCode);
}

    @Then("^API response should be displayed with status code '(.*)'")
    public void verifyResponseWithStatusCode(int expectedStatusCode ){
       Assert.assertTrue("The expected status code - "+expectedStatusCode+". Actual status code - "+activationKeyResponseStatus, activationKeyResponseStatus==expectedStatusCode);
    }


    @Then("^API response should be OK$")
    public void API_response_should_be_OK() throws Throwable {
        validatableResponse
                .statusCode(HttpStatus.SC_OK);
    }

    @Then("^content and key data should be generated$")
    public void content_and_key_data_should_be_generated() throws Throwable {
        System.out.println(activationContent);
        System.out.println(key);
    }

    @When("^generated content and key is passed to the create token method$")
    public void generated_content_and_key_is_passed_to_the_create_token_method() throws Throwable {
        token = JWTTest.createToken(activationContent, key);
        activKey.put("INDGROUP",token);
    }

    @When("^generated content and key is passed to the create token method for the group '(.+)'$")
    public void generated_content_and_key_is_passed_to_the_create_token_method_for_the_group(String groupID) throws Throwable {
       try {

           token = JWTTest.createTokenForGroup(30L,activationContent, key, groupID);
           activKey.put(groupID,token);
       } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @When("^Token is generated for the group '(.*)' with batch size '(.*)'$")
    public void generateTokenWithBatchSize(String groupID, int batchSize) throws NoSuchPaddingException, NoSuchAlgorithmException, IOException, SignatureException, InvalidKeyException {
        Map<String,Object> activationRequest = Maps.newHashMap();
        //activationRequest.put("webHookUrl", "http://10.23.210.59:8443/webhook");
        //String endpoint = "EndPoint.POST_WEBHOOKURL_"+group;
        //activationRequest.put("webHookUrl", RestAssuredConfig.webhookURL.get(groupID));
        //activationRequest.put("enableWebHook", "true");
        activationRequest.put("batchSize", batchSize);
       // activationRequest.put("messageId","abcde");
       // activationRequest.put("activationKey",
               // ImmutableMap.of("content", activationContent, "key", key));
       /* activationRequest.put("activationKey",
                ImmutableMap.of("content", "/zHeqDLusQpIacscuEwJdks0k1PYtkXmCFM9E5PZBniJM54WmgohdPk7hS6fx5hslxPPP3NtciOz878b6ypEOLi2kYZ9Vz+k7D99KOClb/BLANEgA48Az58gWv1zNScwMP87N+5FWX6EFAfFz/n4XoL4TP2RgcVXltIir6UIpdlZN4cvsT9Ame+Agm6SNXqp5FA22Yb3MbaYF+BPYpEpp3VLDVEO1uv+nMkki8jk0a/4tUTiVUCE2Gmox7Px0s0IlWuRdNyflqkaUxUcCrPlSyqhXSwMXLLTanUrKoD1u1BrUkZIjIgQMDw3Ltlm/Ev0iRFgi8IetQRwiFn6B59+kk72yijCZ+jslwujr+RVL8ApGhGh0fVIj4/ss+pkAJFaHTOBT53Si7aGnTqCi72qaMD0weYoe5qx2eu7R4MgvwL88Vzj2W4lOxIWu5ZQw5NScCexn/whGaBZiUyrMCqm8K/76YWsMUGXgeq06vtHBlf6CPoUnFzwqQT601MZ5LyU2InFfamK4O2U0ngFAMzawfIPfvvYn+PfoMS8UKeCQzG6NEqwV21KstvZT5t2Gr97YpNu1IfCtvzKRjU7ggMSKvuTbD9r9FC50Y1sV9G4r86NaPTxqSW2Lp9PAlWZErPk6AIgxwxehzgtzgIFm7/oqtVAe91Iv0NdPqKrKL2/o1K3NuYlJ9xb+GaOcGEk3nPStG7cSbitEPMrhz3FSQ0KidtvfMXK2ebYl5RGCMnPIzw+bTow1xCXS4UbRbEYyl/TGu2XwfWPPw8H4EDwTkgfPfrd8DMB8Ar/YMvsmfu3rGncduJyOzeVRbyxcojL9WFG",
                        "key", "nMALLFtZV2ouAF28283m+2SAAy+IMcyncLjrzIvRmwbJ5rn1pZoMcC8YfrTojPb6bmWWoVly5uZBhPNhqIqd1ZsO82oiXw5Zo5xakRYypbWAsRsKE1oO8Po82djXHBUDgWWn5SGDi1AcGZ+iaql8H0BoE/xSsvKPuZ9+MlogYC76+6NTpqzjeuHtTOfrw2QVUwH1UxIQwALfNfTS0NUXYCk6UCxVs+JI07GvH9SBgCFLbToRCO9uTkH6ONsfzggEv+a3AhIoonglIT5t/J3si10lKbkm1OyrOF+P4NT3VkYPc540xWOdxMNSrbxhNjG1/IgLlNNz1HY3cHQa/sRPLw=="));
   */         String privateKey = commonApiMethods.prop.getProperty(groupID+"_PrivateKey");
        System.out.println("private key is "+privateKey);
        String token = JWT.createToken(30, activationRequest, new EncryptDecrypt().convertStringToPrivateKey(privateKey));
        System.out.println("token is "+token);
        activKey.put(groupID,token);
    }

    @When("^user has already generated the JWT token with newPrivateKey for the group '(.*)'$")
    public void generateTokenWithDifferentPrivateKey(String groupID) throws Throwable {
        try {

            Map<String,Object> activationRequest = Maps.newHashMap();
            //activationRequest.put("webHookUrl", "http://10.23.210.59:8443/webhook");
            //String endpoint = "EndPoint.POST_WEBHOOKURL_"+group;
            activationRequest.put("webHookUrl", RestAssuredConfig.webhookURL.get(groupID));
            activationRequest.put("enableWebHook", "true");
            activationRequest.put("activationKey",
                    ImmutableMap.of("content", activationContent, "key", key));
            token = JWT.createToken(30L,activationRequest, new EncryptDecrypt().convertStringToPrivateKey(
                    org.apache.commons.io.IOUtils.toString(JWTTest.class.getClassLoader().getResourceAsStream(groupID+"newprivate.txt"))
            ));
            System.out.println("token is "+token);
            activKey.put(groupID,token);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public String signCSRForGroup(String groupID) throws Throwable {
        String signedCSR = "";
        RestAssured.useRelaxedHTTPSValidation();
        signedCSR = new Scanner(new File(".\\src\\test\\resources\\test-Data\\signCSRjson.json")).useDelimiter("\\Z").next();
        Map<String, Object> flattenJson = JsonFlattener.flattenAsMap(signedCSR);
        System.out.println(flattenJson.toString().replaceAll("\\\\/", "\\/"));
        InputStream input = getClass().getResourceAsStream("/test-data/activationKeyRequest.properties");
        Properties prop = new Properties();
        prop.load(input);
        flattenJson.replace("SignCsrRequest.csr", prop.getProperty(groupID+"_CSR"));
        String unflattenJson = JsonUnflattener.unflatten(flattenJson.toString()).replaceAll("\\\\/", "\\/");
        System.out.println("request passed is " + unflattenJson);
        HashMap<String, String> headerMap1 = new HashMap<String, String>();
        signedCSR = genericUtils.getPOSTResponse(headerMap1, unflattenJson, EndPoint.CREATE_ACTIVATION_KEY_URL_CSRSIGN, ContentType.JSON).thenReturn().asString().replaceAll("\\\\n", "\n");
        System.out.println("The signed csr is "+signedCSR);
        return signedCSR;
    }

    public String getActivationKey(String groupID,Properties prop) throws Throwable {
        String activationKey = "";
        RestAssured.useRelaxedHTTPSValidation();
        activationKey = PeekAndConsumeTest.inputStreamToString(getClass().getResourceAsStream("/test-data/activationKeyBody.json"));
        Map<String, Object> flattenJson = JsonFlattener.flattenAsMap(activationKey);
        System.out.println(flattenJson.toString().replaceAll("\\\\/", "\\/"));
        flattenJson.replace("ActivationKeyBody.groupId", groupID);
        if(prop.getProperty(groupID + "_PublicKey")==null) {
            String[] publicPrivateKeyPair = genericUtils.generatePublicPrivateKey();
            prop.setProperty(groupID + "_PublicKey",publicPrivateKeyPair[0]);
            prop.setProperty(groupID + "_PrivateKey",publicPrivateKeyPair[1]);
            prop.setProperty(groupID + "_Certificate","F6:FB:32:6E:AA:37:07:DB:CB:4C:7F:74:C4:A4:7B:29:BF:39:74:C6");
            prop.setProperty(groupID + "_Name","Tester");
            prop.setProperty(groupID + "_Email","test@test.com");
            //prop.setProperty(groupID + "_Port","3433");
        }
        flattenJson.replace("ActivationKeyBody.propertyBag.supportEmailAddress", prop.getProperty(groupID + "_Email"));
        flattenJson.replace("ActivationKeyBody.propertyBag.supportContactName", prop.getProperty(groupID + "_Name"));
        flattenJson.replace("ActivationKeyBody.publicKey", prop.getProperty(groupID + "_PublicKey"));
        flattenJson.replace("ActivationKeyBody.certificateThumbprint", prop.getProperty(groupID + "_Certificate"));
        String unflattenJson = JsonUnflattener.unflatten(flattenJson.toString()).replaceAll("\\\\/", "\\/");
        System.out.println("request passed is " + unflattenJson);
        HashMap<String, String> headerMap1 = new HashMap<String, String>();
        Response response = genericUtils.getPOSTResponse(headerMap1, unflattenJson, EndPoint.CREATE_ACTIVATION_KEY_URL+EndPoint.POST_CreateActivationKey, ContentType.JSON);
        activationKeyResponseStatus = response.getStatusCode();
        activationKeyResponseString = response.thenReturn().asString();
        activationKey = response.thenReturn().asString();
        System.out.println("The activation key is "+activationKey);
        String[] parts = activationKey.split("\"");
        activationContent = parts[5];
        key = parts[9];
        return activationKey;
    }

    public Response getActivationKeyResponseForAlreadyActivatedPublicKey(String groupID,String alreadyActivatedgroupID,Properties prop) throws Throwable {
        Response activationKeyResponse;
        String activationKey = "";
        RestAssured.useRelaxedHTTPSValidation();
        activationKey = PeekAndConsumeTest.inputStreamToString(getClass().getResourceAsStream("/test-data/activationKeyBody.json"));
        Map<String, Object> flattenJson = JsonFlattener.flattenAsMap(activationKey);
        System.out.println(flattenJson.toString().replaceAll("\\\\/", "\\/"));
        flattenJson.replace("ActivationKeyBody.groupId", groupID);
        flattenJson.replace("ActivationKeyBody.propertyBag.supportEmailAddress", prop.getProperty(groupID + "_Email"));
        flattenJson.replace("ActivationKeyBody.propertyBag.supportContactName", prop.getProperty(groupID + "_Name"));
        flattenJson.replace("ActivationKeyBody.publicKey", prop.getProperty(alreadyActivatedgroupID + "_PublicKey"));
        flattenJson.replace("ActivationKeyBody.certificateThumbprint", prop.getProperty(groupID + "_Certificate"));
        String unflattenJson = JsonUnflattener.unflatten(flattenJson.toString()).replaceAll("\\\\/", "\\/");
        System.out.println("request passed is " + unflattenJson);
        HashMap<String, String> headerMap1 = new HashMap<String, String>();
        activationKeyResponse = genericUtils.getPOSTResponse(headerMap1, unflattenJson, EndPoint.CREATE_ACTIVATION_KEY_URL+EndPoint.POST_CreateActivationKey, ContentType.JSON);
        return activationKeyResponse;
    }


    @Then("Key mismatch error should be displayed on using invalid private key for group '(.+)'$")
    public void verifyKeyMismatcherror(String groupID) throws Throwable {
        try {
            // content = new Scanner(new File("./src/test/resources/activationKeyBody.json")).useDelimiter("\\Z").next();
          /* String content = new Scanner(new File("./src/test/resources/test-data/"+groupID+"ContentAndKey.txt")).useDelimiter("\\Z").next();
           String[] parts = content.split("\"");
           activationContent = parts[3];
           key = parts[7];*/
            token = JWTTest.createTokenForGroup(30L, activationContent, key, groupID);
            activKey.put(groupID,token);
        } catch (Exception e) {
            Assert.assertTrue(e.toString().contains("java.security.SignatureException: Could not sign data"));
        }
        }


    @When("Client generates token and make it wait for '(.*)' seconds for the group '(.+)'$")
    public void verify(int sec, String groupID) throws Throwable {
        try {
            token = JWTTest.createTokenForGroup(30L, activationContent, key, groupID);
            activKey.put(groupID,token);
            Thread.sleep(sec*1000);
        } catch (Exception e) {
            Assert.assertTrue(e.toString().contains("java.security.SignatureException: Could not sign data"));
        }
    }

    @When("Client generates token with '(.*)' seconds expiry and make it wait for '(.*)' seconds for the group '(.+)'$")
    public void createTokenAndWait(long expiryTimeout, int sec, String groupID) throws Throwable {
        try {
            token = JWTTest.createTokenForGroup(expiryTimeout,activationContent, key, groupID);
            activKey.put(groupID,token);
            Thread.sleep(sec*1000);
        } catch (Exception e) {
            Assert.assertTrue(e.toString().contains("java.security.SignatureException: Could not sign data"));
        }
    }

    @Then("^token should be generated successfully$")
    public void token_should_be_generated_successfully() throws Throwable {
        System.out.println(token);
    }

    @Given("^user has valid SSL certificate$")
    public void user_has_valid_SSL_certificate() throws Throwable {
        //certificate = new Scanner(new File(".\\\\src\\\\test\\\\resources\\\\test-data\\\\certificate.txt")).useDelimiter("\\Z").next();
        certificate = new Scanner(getClass().getResourceAsStream("/test-data/certificate.txt")).useDelimiter("\\Z").next();
    }

    @Given("^user has already generated the JWT token$")
    public void user_has_already_generated_the_JWT_token() throws Throwable {
        a_POST_request_is_made_to_the_activationKey_API();
        content_and_key_data_should_be_generated();
        generated_content_and_key_is_passed_to_the_create_token_method();
    }

    @Given("^user has already generated the JWT token for the group '(.+)'$")
    public void user_has_already_generated_the_JWT_token_for_the_group(String group) throws Throwable {
        //a_POST_request_is_made_to_the_activationKey_API_for_Group(group);
        //content_and_key_data_should_be_generated();
        generated_content_and_key_is_passed_to_the_create_token_method_for_the_group(group);
    }

    @Given("^The user has generated the signed csr for the group '(.*)'$")
    public void generateSignedCSRForGroup(String groupID) throws Throwable {
        signCSRForGroup(groupID);

    }

    @When("^a POST request is made to akamai endpoint$")
    public void a_POST_request_is_made_to_akamai_endpoint() throws Throwable {
        //Configuration to add the token and certificate
        RestAssuredConfig.RestConfigAkamai();
        commonApiMethods commonApiMethods = new commonApiMethods();
        KeyStore keyStore = null;
        String token = null;
        try {

            token = PeekAndConsumeTest.inputStreamToString(getClass().getResourceAsStream("/test-Data/Token.txt"));
            keyStore = KeyStore.getInstance("PKCS12");
            keyStore.load(getClass().getResourceAsStream("/test-data/bny-cert.pfx"), "bny123".toCharArray());
            org.apache.http.conn.ssl.SSLSocketFactory clientAuthFactory = null;
            clientAuthFactory = new org.apache.http.conn.ssl.SSLSocketFactory(keyStore, "123456");
            SSLConfig config = null;
            config = new SSLConfig().with().sslSocketFactory(clientAuthFactory).and().allowAllHostnames();
            RestAssured.config = RestAssured.config().sslConfig(config);
        } catch (Exception e) {
            e.printStackTrace();
        }

        //Hit the Post request with URL with the config and print the response
        response = given()
                .body(token)
                .when()
                .post(EndPoint.POST_ActivateUser)
                .thenReturn()
                .asString();

        validatableResponse = given()//.contentType(ContentType.TEXT)
                .body(token)
                .when()
                .post(EndPoint.POST_ActivateUser)
                .then();
        System.out.println(response);
    }

    @When("^a POST request is made to axway endpoint for the group '(.+)'$")
    public void a_POST_request_is_made_to_axway_endpoint(String group) throws Throwable {
        //Configuration to add the token and certificate
        KeyStore keyStore = null;
        String token = null;
        //System.setProperty("http.proxyHost", "10.65.1.33");
        //System.setProperty("http.proxyPort", "8080");
        System.out.println("Current time is "+now());
        //token = new Scanner(new File("./src/test/resources/test-data/Token.txt")).useDelimiter("\\Z").next();
        token = activKey.get(group);
        keyStore = KeyStore.getInstance("PKCS12");
        keyStore.load(getClass().getResourceAsStream("/test-data/bny-cert.pfx"), "bny123".toCharArray());
        org.apache.http.conn.ssl.SSLSocketFactory clientAuthFactory = null;
        clientAuthFactory = new org.apache.http.conn.ssl.SSLSocketFactory(keyStore, "bny123");
        SSLConfig config = null;
        config = new SSLConfig().with().sslSocketFactory(clientAuthFactory).and().allowAllHostnames();
        RestAssured.config = RestAssured.config().sslConfig(config);
        //Hit the Post request with URL with the config and print the response
        GenericUtils genericUtils = new GenericUtils();
        Map<String, String> headerMap = new HashMap<String, String>();
        Response response1 = null;
        CADMMethods cadmMethods = new CADMMethods();
        if(!cadmMethods.verifyIfGroupActivated(group)) {
            response1 = genericUtils.getPOSTResponse(headerMap, token, common.EndPoint.ACTIVATE_URL + EndPoint.POST_ActivateUser, ContentType.TEXT);
            response = response1.thenReturn().asString();
            statusCode = response1.getStatusCode();
            System.out.println(response);
            System.out.println("Status code is " + statusCode);
            Assert.assertTrue("Axway response should be displayed with word 'Activated'. But it is displayed as " + response, response.contains("Activated"));
            Assert.assertFalse("", response.contains("null"));
        }
    }

    @When("^a POST request is made to axway endpoint for the group '(.+)' even if activated$")
    public void a_POST_request_is_made_to_axway_endpointEvenIfActivatedBefore(String group) throws Throwable {
        //Configuration to add the token and certificate
        KeyStore keyStore = null;
        String token = null;
        //System.setProperty("http.proxyHost", "10.65.1.33");
        //System.setProperty("http.proxyPort", "8080");
        System.out.println("Current time is " + now());
        //token = new Scanner(new File("./src/test/resources/test-data/Token.txt")).useDelimiter("\\Z").next();
        token = activKey.get(group);
        keyStore = KeyStore.getInstance("PKCS12");
        keyStore.load(getClass().getResourceAsStream("/test-data/bny-cert.pfx"), "bny123".toCharArray());
        org.apache.http.conn.ssl.SSLSocketFactory clientAuthFactory = null;
        clientAuthFactory = new org.apache.http.conn.ssl.SSLSocketFactory(keyStore, "bny123");
        SSLConfig config = null;
        config = new SSLConfig().with().sslSocketFactory(clientAuthFactory).and().allowAllHostnames();
        RestAssured.config = RestAssured.config().sslConfig(config);
        //Hit the Post request with URL with the config and print the response
        GenericUtils genericUtils = new GenericUtils();
        Map<String, String> headerMap = new HashMap<String, String>();
        Response response1 = genericUtils.getPOSTResponse(headerMap, token, common.EndPoint.ACTIVATE_URL + EndPoint.POST_ActivateUser, ContentType.TEXT);
        response = response1.thenReturn().asString();
        statusCode = response1.getStatusCode();
        System.out.println(response);
        System.out.println("Status code is " + statusCode);
        Assert.assertTrue("Axway response should be displayed with word 'Activated'. But it is displayed as " + response, response.contains("Activated"));
        Assert.assertFalse("", response.contains("null"));
    }

    @When("^a POST request is made to axway endpoint for the group '(.+)' without verification$")
    public void activateWithoutVerification(String group) throws Throwable {
        //Configuration to add the token and certificate
        String[] parts = activationKeyResponseString.split("\"");
        activationContent = parts[5];
        key = parts[9];
        KeyStore keyStore = null;
        String token = null;
        //System.setProperty("http.proxyHost", "10.65.1.33");
        //System.setProperty("http.proxyPort", "8080");
        System.out.println("Current time is "+now());
        token = activKey.get(group);
        keyStore = KeyStore.getInstance("PKCS12");
        keyStore.load(getClass().getResourceAsStream("/test-data/bny-cert.pfx"), "bny123".toCharArray());
        org.apache.http.conn.ssl.SSLSocketFactory clientAuthFactory = null;
        clientAuthFactory = new org.apache.http.conn.ssl.SSLSocketFactory(keyStore, "bny123");
        SSLConfig config = null;
        config = new SSLConfig().with().sslSocketFactory(clientAuthFactory).and().allowAllHostnames();
        RestAssured.config = RestAssured.config().sslConfig(config);
        //Hit the Post request with URL with the config and print the response
        GenericUtils genericUtils = new GenericUtils();
        Map<String, String> headerMap = new HashMap<String, String>();
        Response response1 = genericUtils.getPOSTResponse(headerMap,token,common.EndPoint.ACTIVATE_URL+EndPoint.POST_ActivateUser,ContentType.TEXT);
        response = response1.thenReturn().asString();
        statusCode = response1.getStatusCode();
        System.out.println(response);
        System.out.println(response);
        statusCode =response1
                .statusCode();
        System.out.println(statusCode);
    }


    @When("^a POST request is made to axway endpoint with certificate as '(.*)' and password '(.*)' for the group '(.+)'")
    public void activateWithoutVerificationWithCertificate(String certifcate, String password, String group) throws Throwable {
        //Configuration to add the token and certificate
//        String[] parts = activationKeyResponseString.split("\"");
//        activationContent = parts[5];
//        key = parts[9];
        KeyStore keyStore = null;

        //System.setProperty("http.proxyHost", "10.65.1.33");
        //System.setProperty("http.proxyPort", "8080");
        System.out.println("Current time is "+now());
        //token = new Scanner(new File("./src/test/resources/test-data/Token.txt")).useDelimiter("\\Z").next();
        token = activKey.get(group);
        keyStore = KeyStore.getInstance("PKCS12");
        keyStore.load(getClass().getResourceAsStream("/test-data/"+certifcate), password.toCharArray());
        org.apache.http.conn.ssl.SSLSocketFactory clientAuthFactory = null;
        clientAuthFactory = new org.apache.http.conn.ssl.SSLSocketFactory(keyStore, password);
        SSLConfig config = null;
        config = new SSLConfig().with().sslSocketFactory(clientAuthFactory).and().allowAllHostnames();
        RestAssured.config = RestAssured.config().sslConfig(config);
        //Hit the Post request with URL with the config and print the response
        GenericUtils genericUtils = new GenericUtils();
        Map<String, String> headerMap = new HashMap<String, String>();
        System.out.println("The URL used is - "+common.EndPoint.ACTIVATE_URL+EndPoint.POST_ActivateUser);
        CADMMethods cadmMethods = new CADMMethods();
        if(!cadmMethods.verifyServiceAvailableInCADM(group)) {
            Response response1 = genericUtils.getPOSTResponse(headerMap, token, common.EndPoint.ACTIVATE_URL + EndPoint.POST_ActivateUser, ContentType.TEXT);
            response = response1.thenReturn().asString();
            statusCode = response1.getStatusCode();
            System.out.println(response);
            System.out.println("Response headers are " + response1.headers());
            statusCode = response1
                    .statusCode();
            System.out.println(statusCode);
        }
    }

    private static String getThumbprint(X509Certificate cert)
            throws NoSuchAlgorithmException, CertificateEncodingException {
        MessageDigest md = MessageDigest.getInstance("SHA-1");
        byte[] der = cert.getEncoded();
        md.update(der);
        byte[] digest = md.digest();
        String digestHex = DatatypeConverter.printHexBinary(digest);
        return digestHex.toUpperCase();
    }

    @Then("Activate response should be displayed as '(.*)' with status code as '(.*)'")
    public void verifyActivateResponse(String expectedResponse, int expectedStatusCode){

        Assert.assertTrue("The expected status code - "+expectedStatusCode+". Actual status code - "+statusCode, statusCode==expectedStatusCode);
        Assert.assertTrue("The expected response - "+expectedResponse+". Actual Response - "+response, expectedResponse.equals(response));
    }

    @Then("^a POST request to axway endpoint for the group '(.+)' should return expiry token error$")
    public void verifyExpiryTokenError(String group) throws Throwable {
        //Configuration to add the token and certificate
        RestAssuredConfig.RestConfigAkamai();
        commonApiMethods commonApiMethods = new commonApiMethods();
        KeyStore keyStore = null;
        String token = null;

        //token = new Scanner(new File("./src/test/resources/test-data/Token.txt")).useDelimiter("\\Z").next();
        token = activKey.get(group);
        keyStore = KeyStore.getInstance("PKCS12");
        keyStore.load(getClass().getResourceAsStream("/test-data/bny-cert.pfx"), "bny123".toCharArray());
        org.apache.http.conn.ssl.SSLSocketFactory clientAuthFactory = null;
        clientAuthFactory = new org.apache.http.conn.ssl.SSLSocketFactory(keyStore, "bny123");
        SSLConfig config = null;
        config = new SSLConfig().with().sslSocketFactory(clientAuthFactory).and().allowAllHostnames();
        RestAssured.config = RestAssured.config().sslConfig(config);
        //Hit the Post request with URL with the config and print the response
        System.out.println("Current time in milliseconds is  "+currentTimeMillis());
        Response response1 = given()
                .contentType(ContentType.TEXT)
                // .header("X-Client-Certifcate","MIIFPDCCBCSgAwIBAgIQBhCY9/Oua9sbbZUiKb7/ETANBgkqhkiG9w0BAQsFADBlMQswCQYDVQQGEwJVUzEVMBMGA1UEChMMRGlnaUNlcnQgSW5jMRkwFwYDVQQLExB3d3cuZGlnaWNlcnQuY29tMSQwIgYDVQQDExtEaWdpQ2VydCBTSEEyIEFzc3VyZWQgSUQgQ0EwHhcNMTcwNTIzMDAwMDAwWhcNMTgwNTIzMTIwMDAwWjBXMQswCQYDVQQGEwJTRzESMBAGA1UEBxMJU2luZ2Fwb3JlMSAwHgYDVQQKExdTdGFuZGFyZCBDaGFydGVyZWQgQmFuazESMBAGA1UEAxMJQWNtZSBDb3JwMIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAx+79CIYpTbQdM93rnQe2y+gMCAZGKfwVuyT4xjYDmYfKr4+/6F2OUoVAP0wsS+EufaFOdwGRYD2Xcg8fH/jwp4dynekLNmO94et7pDBIQoHoyqUz5IfYIhbkwUV5zAjJEfrAlLXEfrBB+j8v6/DMWcYoFvXvq2mA/rZCr5S5L7RCKj17Tup6OpRasbohHADLwLx/gk/gaX7fAzV/4jETHw1zxRg9jT8WaPp+Qs3KeQlXqDEX6vpH12flHDl1dF+QfuKN5jlKG77yKsThglYwRTeaxrL3RgU8X6P8T1S5xpzGCIlE7RHFTpta1Hxn3oD59AvhQkQ8CkYyOWzt6GS6uQIDAQABo4IB9DCCAfAwHwYDVR0jBBgwFoAU5wIjgABP2Ne8lAvZP3Q5STI8inkwHQYDVR0OBBYEFIzxOlIwI/C/ktPcOkYtZA1XWTKrMAwGA1UdEwEB/wQCMAAwJgYDVR0RBB8wHYEbcHJhc2FubmEua2FuYWdhc2FiYWlAc2MuY29tMA4GA1UdDwEB/wQEAwIFoDAdBgNVHSUEFjAUBggrBgEFBQcDAgYIKwYBBQUHAwQwQwYDVR0gBDwwOjA4BgpghkgBhv1sBAECMCowKAYIKwYBBQUHAgEWHGh0dHBzOi8vd3d3LmRpZ2ljZXJ0LmNvbS9DUFMwgYgGA1UdHwSBgDB+MD2gO6A5hjdodHRwOi8vY3JsMy5kaWdpY2VydC5jb20vRGlnaUNlcnRTSEEyQXNzdXJlZElEQ0EtZzIuY3JsMD2gO6A5hjdodHRwOi8vY3JsNC5kaWdpY2VydC5jb20vRGlnaUNlcnRTSEEyQXNzdXJlZElEQ0EtZzIuY3JsMHkGCCsGAQUFBwEBBG0wazAkBggrBgEFBQcwAYYYaHR0cDovL29jc3AuZGlnaWNlcnQuY29tMEMGCCsGAQUFBzAChjdodHRwOi8vY2FjZXJ0cy5kaWdpY2VydC5jb20vRGlnaUNlcnRTSEEyQXNzdXJlZElEQ0EuY3J0MA0GCSqGSIb3DQEBCwUAA4IBAQCuOYPuakKB9qCCR7JYaA+92BprzqYFd1LwT62FrdzcPGupHix7ALoiw2jHuMQogrc3Rw0wZPUqgN29b2bcXX8r9B8OMVbxYL6VZGJ8P+WndUPOzbWdl7eAY/9HbkAUgcqzSP+BBcndCyKdR+bs43dYDNvhDzqL7hHgqjmxFxVz8C/25oLmBZ0yOXz5yLpVoTyHBl1OfAkrYj5WeQI8/uiR9bJ4SwY/NvUU+sOB/UJsxECjpmmdS26dYMRyLuFT7hZvmgv8L2wcjO6vyA9qm3kNb0dTJw1/xQG56pdaGRhdVEqp/L3/hW0COgQvOVdRNlVH9dU8cCl57ICj9rtxTrqg")
                .body(token)
                .when()
                //.post("https://uklvadapp006:8080/cib/v1/activate")
                .post(EndPoint.POST_ActivateUser);
        GenericUtils genericUtils = new GenericUtils();
        Map<String, String> headerMap = new HashMap<String, String>();
        response1 = genericUtils.getPOSTResponse(headerMap,token,common.EndPoint.ACTIVATE_URL+EndPoint.POST_ActivateUser,ContentType.TEXT);
        response = response1
                .thenReturn()
                .asString();
        System.out.println(response);
        statusCode =response1
                .statusCode();
        System.out.println(statusCode);
        Assert.assertTrue("Expected Status code : 403. Actual status code "+statusCode,statusCode==403);
        //  Assert.assertTrue("The expected response should have token expiry message. But actual message is "+response,response.contains("JWT issue time is too far in the past"));


    }



    @When("^a POST request is made to axway endpoint with the token '(.*)'$")
    public void a_POST_request_is_made_to_axway_withToken(String token) throws Throwable {
        //Configuration to add the token and certificate
        //RestAssuredConfig.RestConfig2();
        RestAssured.useRelaxedHTTPSValidation();
        commonApiMethods commonApiMethods = new commonApiMethods();
        KeyStore keyStore = null;

        keyStore = KeyStore.getInstance("PKCS12");
        keyStore.load(getClass().getResourceAsStream("/test-data/bny-cert.pfx"), "bny123".toCharArray());
        org.apache.http.conn.ssl.SSLSocketFactory clientAuthFactory = null;
        clientAuthFactory = new org.apache.http.conn.ssl.SSLSocketFactory(keyStore, "bny123");
        SSLConfig config = null;
        config = new SSLConfig().with().sslSocketFactory(clientAuthFactory).and().allowAllHostnames();
        RestAssured.config = RestAssured.config().sslConfig(config);
        GenericUtils genericUtils = new GenericUtils();
        Map<String, String> headerMap = new HashMap<String, String>();
        Response response1 = genericUtils.getPOSTResponse(headerMap,token,common.EndPoint.ACTIVATE_URL+EndPoint.POST_ActivateUser,ContentType.TEXT);

        response = response1
                .thenReturn()
                .asString();

        statusCode = response1
                .statusCode();
        System.out.println(response);
    }

    /**
     * This method is used verify whether the POST request for Activate returns a 500 error message
     * @param group - The GroupID for which the Activate request is to be triggered
     * @throws Throwable
     */
    @Then("^a POST request to axway endpoint for the group '(.+)' should return 403 error for certificate$")
    public void an_invalid_POST_request_is_made_to_axway_endpoint(String group) throws Throwable {
        //Configuration to add the token and certificate
        RestAssuredConfig.RestConfigAkamai();
        activationKey activationKey1 = new activationKey();

        commonApiMethods commonApiMethods = new commonApiMethods();
        KeyStore keyStore = null;
        String token = null;
        activationKey1.a_POST_request_is_made_to_the_activationKey_API_for_Group(group);
        //activationKey1.generateTokenWithBatchSize(group,0);
        PeekAndConsumeConfig peekAndConsumeConfig = new PeekAndConsumeConfig();

        //token = new Scanner(new File("./src/test/resources/test-data/Token.txt")).useDelimiter("\\Z").next();
        token = activKey.get(group);
        keyStore = KeyStore.getInstance("PKCS12");
        keyStore.load(getClass().getResourceAsStream("/test-data/newcert.pfx"), "123456".toCharArray());
        org.apache.http.conn.ssl.SSLSocketFactory clientAuthFactory = null;
        clientAuthFactory = new org.apache.http.conn.ssl.SSLSocketFactory(keyStore, "123456");
        SSLConfig config = null;
        config = new SSLConfig().with().sslSocketFactory(clientAuthFactory).and().allowAllHostnames();
        RestAssured.config = RestAssured.config().sslConfig(config);
        //Hit the Post request with URL with the config and print the response
        System.out.println("Current time in milliseconds is  "+currentTimeMillis());
        Response response1 = given()
                .contentType(ContentType.TEXT)
                // .header("X-Client-Certifcate","MIIFPDCCBCSgAwIBAgIQBhCY9/Oua9sbbZUiKb7/ETANBgkqhkiG9w0BAQsFADBlMQswCQYDVQQGEwJVUzEVMBMGA1UEChMMRGlnaUNlcnQgSW5jMRkwFwYDVQQLExB3d3cuZGlnaWNlcnQuY29tMSQwIgYDVQQDExtEaWdpQ2VydCBTSEEyIEFzc3VyZWQgSUQgQ0EwHhcNMTcwNTIzMDAwMDAwWhcNMTgwNTIzMTIwMDAwWjBXMQswCQYDVQQGEwJTRzESMBAGA1UEBxMJU2luZ2Fwb3JlMSAwHgYDVQQKExdTdGFuZGFyZCBDaGFydGVyZWQgQmFuazESMBAGA1UEAxMJQWNtZSBDb3JwMIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAx+79CIYpTbQdM93rnQe2y+gMCAZGKfwVuyT4xjYDmYfKr4+/6F2OUoVAP0wsS+EufaFOdwGRYD2Xcg8fH/jwp4dynekLNmO94et7pDBIQoHoyqUz5IfYIhbkwUV5zAjJEfrAlLXEfrBB+j8v6/DMWcYoFvXvq2mA/rZCr5S5L7RCKj17Tup6OpRasbohHADLwLx/gk/gaX7fAzV/4jETHw1zxRg9jT8WaPp+Qs3KeQlXqDEX6vpH12flHDl1dF+QfuKN5jlKG77yKsThglYwRTeaxrL3RgU8X6P8T1S5xpzGCIlE7RHFTpta1Hxn3oD59AvhQkQ8CkYyOWzt6GS6uQIDAQABo4IB9DCCAfAwHwYDVR0jBBgwFoAU5wIjgABP2Ne8lAvZP3Q5STI8inkwHQYDVR0OBBYEFIzxOlIwI/C/ktPcOkYtZA1XWTKrMAwGA1UdEwEB/wQCMAAwJgYDVR0RBB8wHYEbcHJhc2FubmEua2FuYWdhc2FiYWlAc2MuY29tMA4GA1UdDwEB/wQEAwIFoDAdBgNVHSUEFjAUBggrBgEFBQcDAgYIKwYBBQUHAwQwQwYDVR0gBDwwOjA4BgpghkgBhv1sBAECMCowKAYIKwYBBQUHAgEWHGh0dHBzOi8vd3d3LmRpZ2ljZXJ0LmNvbS9DUFMwgYgGA1UdHwSBgDB+MD2gO6A5hjdodHRwOi8vY3JsMy5kaWdpY2VydC5jb20vRGlnaUNlcnRTSEEyQXNzdXJlZElEQ0EtZzIuY3JsMD2gO6A5hjdodHRwOi8vY3JsNC5kaWdpY2VydC5jb20vRGlnaUNlcnRTSEEyQXNzdXJlZElEQ0EtZzIuY3JsMHkGCCsGAQUFBwEBBG0wazAkBggrBgEFBQcwAYYYaHR0cDovL29jc3AuZGlnaWNlcnQuY29tMEMGCCsGAQUFBzAChjdodHRwOi8vY2FjZXJ0cy5kaWdpY2VydC5jb20vRGlnaUNlcnRTSEEyQXNzdXJlZElEQ0EuY3J0MA0GCSqGSIb3DQEBCwUAA4IBAQCuOYPuakKB9qCCR7JYaA+92BprzqYFd1LwT62FrdzcPGupHix7ALoiw2jHuMQogrc3Rw0wZPUqgN29b2bcXX8r9B8OMVbxYL6VZGJ8P+WndUPOzbWdl7eAY/9HbkAUgcqzSP+BBcndCyKdR+bs43dYDNvhDzqL7hHgqjmxFxVz8C/25oLmBZ0yOXz5yLpVoTyHBl1OfAkrYj5WeQI8/uiR9bJ4SwY/NvUU+sOB/UJsxECjpmmdS26dYMRyLuFT7hZvmgv8L2wcjO6vyA9qm3kNb0dTJw1/xQG56pdaGRhdVEqp/L3/hW0COgQvOVdRNlVH9dU8cCl57ICj9rtxTrqg")
                .body(token)
                .when()
                //.post("https://uklvadapp006:8080/cib/v1/activate")
                .post(EndPoint.POST_ActivateUser);
        GenericUtils genericUtils = new GenericUtils();
        Map<String, String> headerMap = new HashMap<String, String>();
        headerMap.put("ResponseEncryptionType", "non");
        response1 = genericUtils.getPOSTResponse(headerMap,token,""+EndPoint.POST_ActivateUser,ContentType.TEXT);
     //   response1 = peekAndConsumeConfig.getPeekConsumeResponse(ab.glue.api.activationKey.activKey.get(group) , "consume");
        response = response1

                .thenReturn()

                .asString();
        System.out.println(response);
        statusCode =response1
                .statusCode();
        System.out.println(statusCode);
        Assert.assertTrue("Expected Status code : 403. Actual status code "+statusCode,statusCode==403);
        Assert.assertTrue(response.equals("{\"errorCode\": \"403\", \"errorMessage\" : \"Failed to call upstream service, status code: 403, message 403 Forbidden - Invalid activation key / transport combination.\" }"));
    }


    /**
     * This method is used verify whether the POST request for Activate returns a 500 error message
     * @param group - The GroupID for which the Activate request is to be triggered
     * @throws Throwable
     */
    @Then("^a POST request to consume post for the group '(.+)' should return 403 error for certificate$")
    public void an_invalid_POST_request_is_made_to_consume_post (String group) throws Throwable {
        //Configuration to add the token and certificate
        RestAssuredConfig.RestConfigAkamai();
        activationKey activationKey1 = new activationKey();

        commonApiMethods commonApiMethods = new commonApiMethods();
        KeyStore keyStore = null;
        String token = null;
        activationKey1.a_POST_request_is_made_to_the_activationKey_API_for_Group(group);
        activationKey1.generateTokenWithBatchSize(group,0);
        PeekAndConsumeConfig peekAndConsumeConfig = new PeekAndConsumeConfig();

        //token = new Scanner(new File("./src/test/resources/test-data/Token.txt")).useDelimiter("\\Z").next();
        token = activKey.get(group);
        keyStore = KeyStore.getInstance("PKCS12");
        keyStore.load(getClass().getResourceAsStream("/test-data/newcert.pfx"), "123456".toCharArray());
        org.apache.http.conn.ssl.SSLSocketFactory clientAuthFactory = null;
        clientAuthFactory = new org.apache.http.conn.ssl.SSLSocketFactory(keyStore, "123456");
        SSLConfig config = null;
        config = new SSLConfig().with().sslSocketFactory(clientAuthFactory).and().allowAllHostnames();
        RestAssured.config = RestAssured.config().sslConfig(config);
        //Hit the Post request with URL with the config and print the response
        System.out.println("Current time in milliseconds is  "+currentTimeMillis());
        Response response1 = given()
                .contentType(ContentType.TEXT)
                // .header("X-Client-Certifcate","MIIFPDCCBCSgAwIBAgIQBhCY9/Oua9sbbZUiKb7/ETANBgkqhkiG9w0BAQsFADBlMQswCQYDVQQGEwJVUzEVMBMGA1UEChMMRGlnaUNlcnQgSW5jMRkwFwYDVQQLExB3d3cuZGlnaWNlcnQuY29tMSQwIgYDVQQDExtEaWdpQ2VydCBTSEEyIEFzc3VyZWQgSUQgQ0EwHhcNMTcwNTIzMDAwMDAwWhcNMTgwNTIzMTIwMDAwWjBXMQswCQYDVQQGEwJTRzESMBAGA1UEBxMJU2luZ2Fwb3JlMSAwHgYDVQQKExdTdGFuZGFyZCBDaGFydGVyZWQgQmFuazESMBAGA1UEAxMJQWNtZSBDb3JwMIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAx+79CIYpTbQdM93rnQe2y+gMCAZGKfwVuyT4xjYDmYfKr4+/6F2OUoVAP0wsS+EufaFOdwGRYD2Xcg8fH/jwp4dynekLNmO94et7pDBIQoHoyqUz5IfYIhbkwUV5zAjJEfrAlLXEfrBB+j8v6/DMWcYoFvXvq2mA/rZCr5S5L7RCKj17Tup6OpRasbohHADLwLx/gk/gaX7fAzV/4jETHw1zxRg9jT8WaPp+Qs3KeQlXqDEX6vpH12flHDl1dF+QfuKN5jlKG77yKsThglYwRTeaxrL3RgU8X6P8T1S5xpzGCIlE7RHFTpta1Hxn3oD59AvhQkQ8CkYyOWzt6GS6uQIDAQABo4IB9DCCAfAwHwYDVR0jBBgwFoAU5wIjgABP2Ne8lAvZP3Q5STI8inkwHQYDVR0OBBYEFIzxOlIwI/C/ktPcOkYtZA1XWTKrMAwGA1UdEwEB/wQCMAAwJgYDVR0RBB8wHYEbcHJhc2FubmEua2FuYWdhc2FiYWlAc2MuY29tMA4GA1UdDwEB/wQEAwIFoDAdBgNVHSUEFjAUBggrBgEFBQcDAgYIKwYBBQUHAwQwQwYDVR0gBDwwOjA4BgpghkgBhv1sBAECMCowKAYIKwYBBQUHAgEWHGh0dHBzOi8vd3d3LmRpZ2ljZXJ0LmNvbS9DUFMwgYgGA1UdHwSBgDB+MD2gO6A5hjdodHRwOi8vY3JsMy5kaWdpY2VydC5jb20vRGlnaUNlcnRTSEEyQXNzdXJlZElEQ0EtZzIuY3JsMD2gO6A5hjdodHRwOi8vY3JsNC5kaWdpY2VydC5jb20vRGlnaUNlcnRTSEEyQXNzdXJlZElEQ0EtZzIuY3JsMHkGCCsGAQUFBwEBBG0wazAkBggrBgEFBQcwAYYYaHR0cDovL29jc3AuZGlnaWNlcnQuY29tMEMGCCsGAQUFBzAChjdodHRwOi8vY2FjZXJ0cy5kaWdpY2VydC5jb20vRGlnaUNlcnRTSEEyQXNzdXJlZElEQ0EuY3J0MA0GCSqGSIb3DQEBCwUAA4IBAQCuOYPuakKB9qCCR7JYaA+92BprzqYFd1LwT62FrdzcPGupHix7ALoiw2jHuMQogrc3Rw0wZPUqgN29b2bcXX8r9B8OMVbxYL6VZGJ8P+WndUPOzbWdl7eAY/9HbkAUgcqzSP+BBcndCyKdR+bs43dYDNvhDzqL7hHgqjmxFxVz8C/25oLmBZ0yOXz5yLpVoTyHBl1OfAkrYj5WeQI8/uiR9bJ4SwY/NvUU+sOB/UJsxECjpmmdS26dYMRyLuFT7hZvmgv8L2wcjO6vyA9qm3kNb0dTJw1/xQG56pdaGRhdVEqp/L3/hW0COgQvOVdRNlVH9dU8cCl57ICj9rtxTrqg")
                .body(token)
                .when()
                //.post("https://uklvadapp006:8080/cib/v1/activate")
                .post(EndPoint.POST_ActivateUser);
        GenericUtils genericUtils = new GenericUtils();
        Map<String, String> headerMap = new HashMap<String, String>();
        headerMap.put("ResponseEncryptionType", "non");
        //response1 = genericUtils.getPOSTResponse(headerMap,token,""+EndPoint.POST_ActivateUser,ContentType.TEXT);
        response1 =
                peekAndConsumeConfig.getConsumePOSTAPIResponse(headerMap,ab.glue.api.activationKey.activKey.get(group) , "consume","newcert.pfx","123456");
        response = response1

                .thenReturn()

                .asString();
        System.out.println(response);
        statusCode =response1
                .statusCode();
        System.out.println(statusCode);
        Assert.assertTrue("Expected Status code : 403. Actual status code "+statusCode,statusCode==403);
        Assert.assertTrue(response.equals("{\"errorCode\": \"403\", \"errorMessage\" : \"Failed to call upstream service, status code: 403, message 403 Forbidden - Invalid activation key / transport combination.\" }"));
    }

    /**
     * This method is used verify whether the POST request for Activate returns a 500 error message
     * @param group - The GroupID for which the Activate request is to be triggered
     * @throws Throwable
     */
    @Then("^a POST request to axway endpoint for the group '(.+)' should return 403 error for invalid certificate$")
    public void verifyErrorForInvalidCertificate(String group) throws Throwable {
        //Configuration to add the token and certificate
        try {
            RestAssuredConfig.RestConfigAkamai();
            commonApiMethods commonApiMethods = new commonApiMethods();
            KeyStore keyStore = null;
            String token = null;

            //token = new Scanner(new File("./src/test/resources/test-data/Token.txt")).useDelimiter("\\Z").next();
            token = activKey.get(group);
            keyStore = KeyStore.getInstance("PKCS12");
            keyStore.load(getClass().getResourceAsStream("/test-data/invalidcert.pfx"), "123456".toCharArray());
            org.apache.http.conn.ssl.SSLSocketFactory clientAuthFactory = null;
            clientAuthFactory = new org.apache.http.conn.ssl.SSLSocketFactory(keyStore, "123456");
            SSLConfig config = null;
            config = new SSLConfig().with().sslSocketFactory(clientAuthFactory).and().allowAllHostnames();
            RestAssured.config = RestAssured.config().sslConfig(config);
            //Hit the Post request with URL with the config and print the response
            System.out.println("Current time in milliseconds is  " + currentTimeMillis());
            Response response1 = given()
                    .contentType(ContentType.TEXT)
                    // .header("X-Client-Certifcate","MIIFPDCCBCSgAwIBAgIQBhCY9/Oua9sbbZUiKb7/ETANBgkqhkiG9w0BAQsFADBlMQswCQYDVQQGEwJVUzEVMBMGA1UEChMMRGlnaUNlcnQgSW5jMRkwFwYDVQQLExB3d3cuZGlnaWNlcnQuY29tMSQwIgYDVQQDExtEaWdpQ2VydCBTSEEyIEFzc3VyZWQgSUQgQ0EwHhcNMTcwNTIzMDAwMDAwWhcNMTgwNTIzMTIwMDAwWjBXMQswCQYDVQQGEwJTRzESMBAGA1UEBxMJU2luZ2Fwb3JlMSAwHgYDVQQKExdTdGFuZGFyZCBDaGFydGVyZWQgQmFuazESMBAGA1UEAxMJQWNtZSBDb3JwMIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAx+79CIYpTbQdM93rnQe2y+gMCAZGKfwVuyT4xjYDmYfKr4+/6F2OUoVAP0wsS+EufaFOdwGRYD2Xcg8fH/jwp4dynekLNmO94et7pDBIQoHoyqUz5IfYIhbkwUV5zAjJEfrAlLXEfrBB+j8v6/DMWcYoFvXvq2mA/rZCr5S5L7RCKj17Tup6OpRasbohHADLwLx/gk/gaX7fAzV/4jETHw1zxRg9jT8WaPp+Qs3KeQlXqDEX6vpH12flHDl1dF+QfuKN5jlKG77yKsThglYwRTeaxrL3RgU8X6P8T1S5xpzGCIlE7RHFTpta1Hxn3oD59AvhQkQ8CkYyOWzt6GS6uQIDAQABo4IB9DCCAfAwHwYDVR0jBBgwFoAU5wIjgABP2Ne8lAvZP3Q5STI8inkwHQYDVR0OBBYEFIzxOlIwI/C/ktPcOkYtZA1XWTKrMAwGA1UdEwEB/wQCMAAwJgYDVR0RBB8wHYEbcHJhc2FubmEua2FuYWdhc2FiYWlAc2MuY29tMA4GA1UdDwEB/wQEAwIFoDAdBgNVHSUEFjAUBggrBgEFBQcDAgYIKwYBBQUHAwQwQwYDVR0gBDwwOjA4BgpghkgBhv1sBAECMCowKAYIKwYBBQUHAgEWHGh0dHBzOi8vd3d3LmRpZ2ljZXJ0LmNvbS9DUFMwgYgGA1UdHwSBgDB+MD2gO6A5hjdodHRwOi8vY3JsMy5kaWdpY2VydC5jb20vRGlnaUNlcnRTSEEyQXNzdXJlZElEQ0EtZzIuY3JsMD2gO6A5hjdodHRwOi8vY3JsNC5kaWdpY2VydC5jb20vRGlnaUNlcnRTSEEyQXNzdXJlZElEQ0EtZzIuY3JsMHkGCCsGAQUFBwEBBG0wazAkBggrBgEFBQcwAYYYaHR0cDovL29jc3AuZGlnaWNlcnQuY29tMEMGCCsGAQUFBzAChjdodHRwOi8vY2FjZXJ0cy5kaWdpY2VydC5jb20vRGlnaUNlcnRTSEEyQXNzdXJlZElEQ0EuY3J0MA0GCSqGSIb3DQEBCwUAA4IBAQCuOYPuakKB9qCCR7JYaA+92BprzqYFd1LwT62FrdzcPGupHix7ALoiw2jHuMQogrc3Rw0wZPUqgN29b2bcXX8r9B8OMVbxYL6VZGJ8P+WndUPOzbWdl7eAY/9HbkAUgcqzSP+BBcndCyKdR+bs43dYDNvhDzqL7hHgqjmxFxVz8C/25oLmBZ0yOXz5yLpVoTyHBl1OfAkrYj5WeQI8/uiR9bJ4SwY/NvUU+sOB/UJsxECjpmmdS26dYMRyLuFT7hZvmgv8L2wcjO6vyA9qm3kNb0dTJw1/xQG56pdaGRhdVEqp/L3/hW0COgQvOVdRNlVH9dU8cCl57ICj9rtxTrqg")
                    .body(token)
                    .when()
                    //.post("https://uklvadapp006:8080/cib/v1/activate")
                    .post(EndPoint.POST_ActivateUser);
            GenericUtils genericUtils = new GenericUtils();
            Map<String, String> headerMap = new HashMap<String, String>();
            response1 = genericUtils.getPOSTResponse(headerMap, token, common.EndPoint.ACTIVATE_URL + EndPoint.POST_ActivateUser, ContentType.TEXT);
            response = response1
                    .thenReturn()
                    .asString();
            System.out.println("response is - "+response);
            statusCode = response1
                    .statusCode();
            System.out.println("status code is - "+statusCode);
            Assert.assertTrue("Expected Status code : 403. Actual status code " + statusCode, statusCode == 403);
            Assert.assertTrue(response.equals("{\"errorCode\": \"403\", \"errorMessage\" : \"Failed to call upstream service, status code: 403, message 403 Forbidden - Invalid activation key / transport combination.\" }"));
        }catch(java.io.EOFException e){
            Assert.assertTrue(true);
        }
        }

    /**
     * This method is to hit the Activate request with invalid certificate verify if the correct error message is displayed
     * @throws Throwable
     */
    @Then("^error should be displayed for invalid certificate$")
    public void verifyCertificateError() throws Throwable {
        //Configuration to add the token and certificate
        RestAssuredConfig.RestConfig2();
        RestAssured.useRelaxedHTTPSValidation();
        commonApiMethods commonApiMethods = new commonApiMethods();
        KeyStore keyStore = null;
        keyStore = KeyStore.getInstance("PKCS12");
        keyStore.load(getClass().getResourceAsStream("/test-data/newcertificate.pfx"), "bny123".toCharArray());
        org.apache.http.conn.ssl.SSLSocketFactory clientAuthFactory = null;
        clientAuthFactory = new org.apache.http.conn.ssl.SSLSocketFactory(keyStore, "bny123");
        SSLConfig config = null;
        config = new SSLConfig().with().sslSocketFactory(clientAuthFactory).and().allowAllHostnames();
        RestAssured.config = RestAssured.config().sslConfig(config);
        //Hit the Post request with URL with the config and print the response
        Response response1 =  given()
                .contentType(ContentType.TEXT)
                //.header("X-Client-Certifcate","MIIFPDCCBCSgAwIBAgIQBhCY9/Oua9sbbZUiKb7/+79CIYpTbQdM93rnQe2y+gMCAZGKfwVuyT4xjYDmYfKr4+/6F2OUoVAP0wsS+EufaFOdwGRYD2Xcg8fH/jwp4dynekLNmO94et7pDBIQoHoyqUz5IfYIhbkwUV5zAjJEfrAlLXEfrBB+j8v6/DMWcYoFvXvq2mA/rZCr5S5L7RCKj17Tup6OpRasbohHADLwLx/gk/gaX7fAzV/4jETHw1zxRg9jT8WaPp+Qs3KeQlXqDEX6vpH12flHDl1dF+QfuKN5jlKG77yKsThglYwRTeaxrL3RgU8X6P8T1S5xpzGCIlE7RHFTpta1Hxn3oD59AvhQkQ8CkYyOWzt6GS6uQIDAQABo4IB9DCCAfAwHwYDVR0jBBgwFoAU5wIjgABP2Ne8lAvZP3Q5STI8inkwHQYDVR0OBBYEFIzxOlIwI/C/ktPcOkYtZA1XWTKrMAwGA1UdEwEB/wQCMAAwJgYDVR0RBB8wHYEbcHJhc2FubmEua2FuYWdhc2FiYWlAc2MuY29tMA4GA1UdDwEB/wQEAwIFoDAdBgNVHSUEFjAUBggrBgEFBQcDAgYIKwYBBQUHAwQwQwYDVR0gBDwwOjA4BgpghkgBhv1sBAECMCowKAYIKwYBBQUHAgEWHGh0dHBzOi8vd3d3LmRpZ2ljZXJ0LmNvbS9DUFMwgYgGA1UdHwSBgDB+MD2gO6A5hjdodHRwOi8vY3JsMy5kaWdpY2VydC5jb20vRGlnaUNlcnRTSEEyQXNzdXJlZElEQ0EtZzIuY3JsMD2gO6A5hjdodHRwOi8vY3JsNC5kaWdpY2VydC5jb20vRGlnaUNlcnRTSEEyQXNzdXJlZElEQ0EtZzIuY3JsMHkGCCsGAQUFBwEBBG0wazAkBggrBgEFBQcwAYYYaHR0cDovL29jc3AuZGlnaWNlcnQuY29tMEMGCCsGAQUFBzAChjdodHRwOi8vY2FjZXJ0cy5kaWdpY2VydC5jb20vRGlnaUNlcnRTSEEyQXNzdXJlZElEQ0EuY3J0MA0GCSqGSIb3DQEBCwUAA4IBAQCuOYPuakKB9qCCR7JYaA+92BprzqYFd1LwT62FrdzcPGupHix7ALoiw2jHuMQogrc3Rw0wZPUqgN29b2bcXX8r9B8OMVbxYL6VZGJ8P+WndUPOzbWdl7eAY/9HbkAUgcqzSP+BBcndCyKdR+bs43dYDNvhDzqL7hHgqjmxFxVz8C/25oLmBZ0yOXz5yLpVoTyHBl1OfAkrYj5WeQI8/uiR9bJ4SwY/NvUU+sOB/UJsxECjpmmdS26dYMRyLuFT7hZvmgv8L2wcjO6vyA9qm3kNb0dTJw1/xQG56pdaGRhdVEqp/L3/hW0COgQvOVdRNlVH9dU8cCl57ICj9rtxTrqg")
                .body(token)
                .when()
                //.post("https://uklvadapp006:8080/cib/v1/activate")
                .post(EndPoint.POST_ActivateUser);
        int StatusCode = response1
                .getStatusCode();
        response = response1.thenReturn().asString();
        System.out.println(response);
        Assert.assertTrue(StatusCode!=200);
    }

    @Then("^user should be registered successfully$")
    public void user_should_be_registered_successfully() throws Throwable {
        System.out.println("");
        System.out.println("response: " + response);
    }

    @Then("^the response should be displayed as 400 error$")
    public void verify400ResponseError(){
        Assert.assertTrue("The expected status code is 400. Actual Status Code : "+activationKeyResponseStatus, activationKeyResponseStatus == 400);
        Assert.assertTrue("The expected status text is 'HTTP/1.1 400 Bad Request'. Actual Status Code : '"+statusText+"'", statusText.equals("HTTP/1.1 400 Bad Request"));
        Assert.assertTrue("The response should be displayed as empty. But the response is displayed as "+response,activationKeyResponseString.equals(""));
    }

}


