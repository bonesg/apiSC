package ab.glue.api;

import ab.common.PeekAndConsumeConfig;
import ab.common.RemoteWebHook;
import ab.common.WebHookStarter;
import ab.utils.GenericUtils;
import common.EndPoint;
import common.RestAssuredConfig;
import cucumber.api.java.After;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.response.Response;
import org.junit.Assert;

import java.util.HashMap;
import java.util.Map;

import static io.restassured.RestAssured.given;

/**
 * Created by 1571168 on 8/25/2017.
 */
public class WebHook {

    public static Map<String, WebHookStarter> webhookStarters = new HashMap<>();


    @When("^the Webhook is turned on for the group '(.*)'$")
    public void turnWebhookon(String groupID) throws Throwable {

//        GenericUtils genericUtils = new GenericUtils();
//        Map<String, String> headerMap = new HashMap<String, String>();
//        Map<String, String> paramMap = new HashMap<String, String>();
//        paramMap.put("group",groupID);
//        String value = genericUtils.getGETResponseWithParam(headerMap,paramMap, EndPoint.WEBHOOK_URL+"webhook/factory/start", ContentType.JSON).thenReturn().asString();
        if (!webhookStarters.containsKey(groupID)) {

            WebHookStarter webhookStarter = new RemoteWebHook("10.23.210.60", "apiadm", "Admin@2018");
            webhookStarter.setConfig("private-key", commonApiMethods.prop.getProperty(groupID + "_PrivateKey"));
            webhookStarter.setConfig("public-key", commonApiMethods.prop.getProperty(groupID + "_PublicKey"));
            webhookStarter.setConfig("port", commonApiMethods.prop.getProperty(groupID + "_Port"));
            webhookStarter.start();
            webhookStarters.put(groupID, webhookStarter);
            RestAssuredConfig.webhookURL.put(groupID, webhookStarter.getWebHookUrl()+"/webhook");
            GenericUtils genericUtils = new GenericUtils();
            Thread.sleep(1000);
        }

        System.out.println("Webhook could not be turned on");
    }

    @After
    public void after(cucumber.api.Scenario scenario) {
        if(WebHook.webhookStarters.get("INGRP999")!=null)
        verifyWebhookTurnedOff("INGRP999");
        GenericGlue.randomMessageID = null;
    }

    /**
     * This method is used to hit the Peek api and verify the response with the expected response
     */
    @Then("^Webhook logs should contain only one invalid message for the group '(.+)'$")
    public void clearMessages(String groupID) throws Throwable {
        String logs = WebHook.webhookStarters.get(groupID).getLog().toString();
        Assert.assertTrue("Webhook message displayed multiple times", org.apache.commons.lang3.StringUtils.countMatches(logs,"Invalid message payload")==1);
    }

    /**
     * This method is used to hit the Peek api and verify the response with the expected response
     */
    @Then("^Webhook response should be cleared value for the group '(.+)'$")
    public void clearMessage(String groupID) throws Throwable {
         Thread.sleep(15000);
        Map<String, String> headerMap = new HashMap<>();
        GenericUtils genericUtils = new GenericUtils();
        Map<String, String> paramMap = new HashMap<>();
        System.out.println("" + WebHook.webhookStarters.get(groupID).getWebHookUrl() + "/messages");
        RestAssuredConfig.RestConfig4();
        RestAssured.baseURI = WebHook.webhookStarters.get(groupID).getWebHookUrl();
        RestAssured.basePath = "/webhook";
        RestAssured.useRelaxedHTTPSValidation();
        Response response1 = given()
                .headers(headerMap)
                .when()
                .get("/clearMessages");
        String res = response1.thenReturn().asString();
        System.out.println("response:" + res);
    }

    /**
     * This method is used to hit the Peek api and verify the response with the expected response
     */
    @Then("^Webhook response should be displayed with amount '(.+)' accountNo '(.+)' transactionType '(.+)' the expected value for the group '(.+)'$")
    public void peekValueTest(String amount, String accountNo, String trxType, String groupID) throws Throwable {
        Thread.sleep(10000);
        GenericUtils utils = new GenericUtils();
        String expectedResponse = EndPoint.WEBHOOK_MESSAGE.replaceAll(" ", "");
        expectedResponse = utils.expectedValueTrim(expectedResponse, groupID, amount, accountNo, trxType).replaceAll("\\.00", "").replaceAll("\\{\"messageId\":\"\",\"content\":\\[", "[\"");
        ;
        verifyWebhookMessages(expectedResponse, groupID);
     }

    /**
     * This method is used to hit the Peek api and verify the response with the expected response
     */
    @Then("^Webhook response should be displayed with amount '(.+)' accountNo '(.+)' transactionType '(.+)' currency '(.+)' BIC '(.+)' BAICode '(.+)' and ledger '(.*)' for the group '(.+)'$")
    public void webhookValueTest(String amount, String accountNo, String trxType, String currency, String bic, String baiCode, String ledger, String groupID) throws Throwable {
        Thread.sleep(11000);
        GenericUtils utils = new GenericUtils();
        String expectedResponse = EndPoint.WEBHOOK_MESSAGE.replaceAll(" ", "");
        expectedResponse = utils.expectedValueTrimWithRandomTransaction(expectedResponse,groupID,amount, accountNo,trxType,currency,bic,ledger, baiCode).replaceAll("\\.00","").replaceAll("\\{\"messageId\":\"\",\"content\":\\[", "[\"");
        ;
        verifyWebhookMessages(expectedResponse, groupID);
    }

    public void verifyWebhookMessages(String expectedResponse, String groupID) throws Throwable {
        PeekAndConsumeConfig peekAndConsumeConfig = new PeekAndConsumeConfig();
        RestAssured.useRelaxedHTTPSValidation();
            Map<String, String> headerMap = new HashMap<>();
            GenericUtils genericUtils = new GenericUtils();
            Map<String, String> paramMap = new HashMap<>();
            Response actualResponse = genericUtils.getGETResponseWithParam(headerMap, paramMap, WebHook.webhookStarters.get(groupID).getWebHookUrl() + "/webhook/messages", ContentType.JSON);
            String response = actualResponse.thenReturn().asString().replaceAll("\\\\","");
            int statusCode = actualResponse.getStatusCode();
            //String actualResponse = peekAndConsumeConfig.getPeekConsumeResponseAsString(activationKey, "peek").trim();
            System.out.println("Webhook status code : " + statusCode);
            //actualResponse = utils.peekConsumeTrim(actualResponse);
            System.out.println("actualResponse : " + response);
            System.out.println("expectedResponse : " + expectedResponse);
            Assert.assertTrue("Peek Response is not displayed as expected. Expected Response - " + expectedResponse + ". Actual Response - " + response, response.contains(expectedResponse));
        }


    /**
     * This method is used to hit the Peek api and verify the response with the expected response
     */
    @Then("^Webhook response should be displayed with '(.+)' messages for the group '(.+)'$")
    public void peekValueNumberTest(int expectedNumber, String groupID) throws Throwable {
        Thread.sleep(20000);
        GenericUtils utils = new GenericUtils();
        PeekAndConsumeConfig peekAndConsumeConfig = new PeekAndConsumeConfig();
        RestAssured.useRelaxedHTTPSValidation();
        try{
            Map<String, String> headerMap = new HashMap<>();
            GenericUtils genericUtils = new GenericUtils();
            Map<String, String> paramMap = new HashMap<>();
            Response actualResponse = genericUtils.getGETResponseWithParam(headerMap, paramMap, WebHook.webhookStarters.get(groupID).getWebHookUrl() + "/webhook/messages", ContentType.JSON);
            String response = actualResponse.thenReturn().asString().replaceAll("\\\\","");
            int statusCode = actualResponse.getStatusCode();
            //String actualResponse = peekAndConsumeConfig.getPeekConsumeResponseAsString(activationKey, "peek").trim();
            System.out.println("Webhook status code : " + statusCode);
            //actualResponse = utils.peekConsumeTrim(actualResponse);
            System.out.println("actualResponse : " + response);
            int numberOfTransactions = utils.verifyNumberOfTransactions(response,groupID);
            Assert.assertTrue("Expected - "+expectedNumber+". Actual - "+numberOfTransactions,numberOfTransactions==expectedNumber);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }


    /**
     * This method is used to hit the Peek api and verify the response with the expected response
     */
    @Then("^Webhook response should be displayed with empty response for the group '(.*)'$")
    public void verifyEmptyResponse(String groupID) throws Throwable {
        Thread.sleep(10000);
        GenericUtils utils = new GenericUtils();
        PeekAndConsumeConfig peekAndConsumeConfig = new PeekAndConsumeConfig();
        RestAssured.useRelaxedHTTPSValidation();
        try{
            Map<String, String> headerMap = new HashMap<>();
            GenericUtils genericUtils = new GenericUtils();
            Map<String, String> paramMap = new HashMap<>();
            Response actualResponse = genericUtils.getGETResponseWithParam(headerMap, paramMap, WebHook.webhookStarters.get(groupID).getWebHookUrl() + "/webhook/messages", ContentType.JSON);
            String response = actualResponse.thenReturn().asString().replaceAll("\\\\","");
            int statusCode = actualResponse.getStatusCode();
            //String actualResponse = peekAndConsumeConfig.getPeekConsumeResponseAsString(activationKey, "peek").trim();
            System.out.println("Webhook status code : " + statusCode);
            //actualResponse = utils.peekConsumeTrim(actualResponse);
            System.out.println("actualResponse : " + response);
            Assert.assertTrue("Peek Response is not displayed as expected. Expected Response - []. Actual Response - " + response, response.equals("[]"));
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Then("^Webhook should be displayed with the expected value for group '(.*)'$")
    public void verifyWebhook(String groupID) throws Throwable {
        System.out.println("Webhook could not be verified");
    }

    @When("the webhook is turned off for the group '(.*)'$")
    public void verifyWebhookTurnedOff(String groupID) {
        WebHook.webhookStarters.get(groupID).stop();
        //webhookStarters.get(groupID).stop();
        WebHook.webhookStarters.remove(groupID);
        RestAssuredConfig.webhookURL.remove(groupID);
        System.out.printf("Webhook stopped for " + groupID);

    }

    @Then("Webhook should be displayed with the empty message")
    public void verifyEmptyMessageInWebhook() {
        System.out.println("Webhook could not display messages");
    }
}
