package ab.glue.api;

import ab.utils.GenericUtils;
import io.restassured.response.Response;

/**
 * Created by 1571168 on 1/7/2018.
 */
public class OpenAPIPayNow extends GenericUtils {
    GenericUtils genericUtils = new GenericUtils();
    activationKey activationKey = new activationKey();
    public static Response response;
    public static String responseString;
    public static int responseStatus;
    public static boolean responseEncrypted;
    public static String randomMessageID;

    @Data(name = "openAPIPaymentMessageSender", xpath = "", jsonpath = "header.messageSender",responseJSonPath ="")
    String openAPIPaymentMessageSender = null;

    @Data(name = "openAPIPaymentCountry", xpath = "", jsonpath = "header.countryCode",responseJSonPath ="")
    String openAPIPaymentCountry = null;

    @Data(name = "openAPIPaymentAmount", xpath = "", jsonpath = "instruction.amount.amount",responseJSonPath ="")
    String openAPIPaymentAmount = null;

    @Data(name = "openAPIPaymentCurrency", xpath = "", jsonpath = "instruction.amount.currencyCode",responseJSonPath ="")
    String openAPIPaymentCurrency= null;

    @Data(name = "openAPIPaymentDebitAccountNumber", xpath = "", jsonpath = "instruction.debtorAccount.id",responseJSonPath ="")
    String openAPIPaymentDebitAccountNumber= null;

    @Data(name = "openAPIPaymentCreditAccountNumber", xpath = "", jsonpath = "instruction.creditorAccount.id",responseJSonPath ="")
    String openAPIPaymentCreditAccountNumber= null;

    @Data(name = "openAPIPaymentDebitBIC", xpath = "", jsonpath = "instruction.debtorAgent.financialInstitution.BIC",responseJSonPath ="")
    String openAPIPaymentDebitBIC= null;

    @Data(name = "openAPIPaymentCreditBIC", xpath = "", jsonpath = "instruction.creditorAgent.financialInstitution.BIC",responseJSonPath ="")
    String openAPIPaymentCreditBIC= null;

    @Data(name = "openAPIPaymentdebitName", xpath = "", jsonpath = "instruction.debtor.name",responseJSonPath ="")
    String openAPIPaymentdebitName= null;

    @Data(name = "openAPIPaymentcreditName", xpath = "", jsonpath = "instruction.creditor.name",responseJSonPath ="")
    String openAPIPaymentcreditName= null;

    @Data(name = "openAPIPaymentdebitPostalAddressCountry", xpath = "", jsonpath = "instruction.debtorAgent.financialInstitution.postalAddress.country",responseJSonPath ="")
    String openAPIPaymentdebitPostalAddressCountry= null;

    @Data(name = "openAPIPaymentdebitCountry", xpath = "", jsonpath = "instruction.debtorAgent.financialInstitution.postalAddress.country",responseJSonPath ="")
    String openAPIPaymentdebitCountry= null;

    @Data(name = "openAPIPaymentcreditCountry", xpath = "", jsonpath = "instruction.creditorAgent.financialInstitution.postalAddress.country",responseJSonPath ="")
    String openAPIPaymentcreditCountry= null;

    @Data(name = "openAPIPaymentType", xpath = "", jsonpath = "instruction.paymentType",responseJSonPath ="")
    String openAPIPaymentType= null;

    @Data(name = "openAPIPaymentMessageID", xpath = "", jsonpath = "header.messageId",responseJSonPath ="")
    String openAPIPaymentMessageID= null;

    @Data(name = "openAPIPaymentReferenceID", xpath = "", jsonpath = "instruction.referenceId",responseJSonPath ="clientReferenceId")
    String openAPIPaymentReferenceID= null;

    @Data(name = "openAPIPaymentResponseClientReferenceId", xpath = "", jsonpath = "clientReferenceId",responseJSonPath ="clientReferenceId")
    String openAPIPaymentResponseClientReferenceId= null;

    @Data(name = "openAPIPaymentTypePreference", xpath = "", jsonpath = "instruction.paymentTypePreference",responseJSonPath ="")
    String openAPIPaymentTypePreference= null;

    @Data(name = "openAPIPaymentTimestamp", xpath = "", jsonpath = "instruction.paymentTimestamp",responseJSonPath ="")
    String openAPIPaymentTimestamp= null;

    @Data(name = "openAPIPaymentHeaderTimestamp", xpath = "", jsonpath = "header.timestamp",responseJSonPath ="")
    String openAPIPaymentHeaderTimestamp= null;


    @Data(name = "openAPIPaymentRequiredExecutionDate", xpath = "", jsonpath = "instruction.requiredExecutionDate",responseJSonPath ="")
    String openAPIPaymentRequiredExecutionDate= null;

    @Data(name = "openAPIRequiredExecutionDate", xpath = "", jsonpath = "instruction.requiredExecutionDate",responseJSonPath ="")
    String openAPIRequiredExecutionDate= null;

    @Data(name = "openAPIType", xpath = "", jsonpath = "instruction.type",responseJSonPath ="")
    String openAPIType= null;

    @Data(name = "openAPIPurpose", xpath = "", jsonpath = "instruction.purpose",responseJSonPath ="")
    String openAPIPurpose= null;

    @Data(name = "openAPIDebitorName", xpath = "", jsonpath = "instruction.debtor.name",responseJSonPath ="")
    String openAPIDebitorName= null;

    @Data(name = "openAPIDebitorAgentBIC", xpath = "", jsonpath = "instruction.debtorAgent.financialInstitution.BIC",responseJSonPath ="")
    String openAPIDebitorAgentBIC= null;

    @Data(name = "openAPIDebitorAgentName", xpath = "", jsonpath = "instruction.debtorAgent.financialInstitution.name",responseJSonPath ="")
    String openAPIDebitorAgentName= null;

    @Data(name = "openAPIClearingSystemId", xpath = "", jsonpath = "instruction.debtorAgent.clearingSystemId",responseJSonPath ="")
    String openAPIClearingSystemId= null;

    @Data(name = "openAPICreditorName", xpath = "", jsonpath = "instruction.creditor.name",responseJSonPath ="")
    String openAPICreditorName = null;

    @Data(name = "openAPICreditorAccount", xpath = "", jsonpath = "instruction.creditorAccount.id",responseJSonPath ="")
    String openAPICreditorAccount = null;

    @Data(name = "openAPICreditorAgentBIC", xpath = "", jsonpath = "instruction.creditorAgent.financialInstitution.BIC",responseJSonPath ="")
    String openAPICreditorAgentBIC = null;

    @Data(name = "openAPICreditorAgentName", xpath = "", jsonpath = "instruction.creditorAgent.financialInstitution.name",responseJSonPath ="")
    String openAPICreditorAgentName = null;

    @Data(name = "openAPICreditorAgentPostalAddress", xpath = "", jsonpath = "instruction.creditorAgent.financialInstitution",responseJSonPath ="")
    String openAPICreditorAgentPostalAddress = null;


    @Data(name = "openAPICreditorId", xpath = "", jsonpath = "instruction.creditor.identity.id",responseJSonPath ="")
    String openAPIidentityType= null;


    @Data(name = "openAPICreditoridentityType", xpath = "", jsonpath = "instruction.creditor.identity.identityType",responseJSonPath ="")
    String openAPICreditoridentityType= null;

    @Data(name = "openAPIPaymentDebitAccountIdentifierType", xpath = "", jsonpath = "instruction.debtorAccount.identifierType",responseJSonPath ="")
    String openAPIPaymentDebitAccountIdentifierType= null;

}
