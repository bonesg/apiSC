package ab.glue.api;

import cucumber.api.DataTable;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import io.restassured.http.ContentType;
import io.restassured.response.ValidatableResponse;

import java.io.File;
import java.util.List;
import java.util.Scanner;

import static io.restassured.RestAssured.given;

//import config.Constants;
//import config.ExcelUtil;
//import config.RestAssuredConfig;

/**
 * Created by 1556780 on 5/9/2018.
 */
public class manageBCTrustLine {

    private String MId = null;
    private String AnchorId = null;
    private static ValidatableResponse validatableResponse = null;
    private static ValidatableResponse validatableResponse2 = null;
    private static String response;
    private static String content;
    private static String url = "https://10.23.210.60:9012/api-banking/inimeg/transaction/generic";

    @Given("^A valid BC Member and Anchor:$")
    public void a_valid_BC_Member_and_Anchor(DataTable dataTable) throws Throwable {
        content = new Scanner(new File(".\\\\src\\\\test\\\\resources\\\\test-data\\\\manageTrustLineRequest.json")).useDelimiter("\\Z").next();
        List<List<String>> userDetails = dataTable.raw();
        MId = userDetails.get(0).get(0);
        AnchorId = userDetails.get(0).get(1);
        content = content.replace("Mid", MId);
        content = content.replace("AnchorId", AnchorId);
        //System.out.println(content);
    }

    @When("^'manageBCTrustline' request is sent:$")
    public void managebctrustline_request_is_sent(DataTable dataTable) throws Throwable {
        //content = new Scanner(new File(".\\\\src\\\\test\\\\resources\\\\test-data\\\\manageTrustLineRequest.json")).useDelimiter("\\Z").next();
        List<List<String>> requestParams = dataTable.raw();
        String curr = requestParams.get(0).get(0);
        String amount = requestParams.get(0).get(1);
        content = content.replace("CURR", curr);
        content = content.replace("AMOUNT", amount);
        //System.out.println(content);

        validatableResponse =
                given()
                        .contentType(ContentType.JSON)
                        .relaxedHTTPSValidation()
                        .when()
                        .body(content)
                        .post(url)
                        .then();
        //capturing API response as String
        response =
                given()
                        .contentType(ContentType.JSON)
                        .relaxedHTTPSValidation()
                        .when()
                        .body(content)
                        .post(url)
                        .thenReturn()
                        .asString();
    }


    @Then("^API response should be Success$")
    public void api_response_should_be_Success() throws Throwable {
        validatableResponse.statusCode(200);
    }

    @When("^'queryBCTrustline' request is sent:$")
    public void querybctrustline_request_is_sent(DataTable dataTable) throws Throwable {
        content = new Scanner(new File(".\\\\src\\\\test\\\\resources\\\\test-data\\\\queryBCTrustLineRequest.json")).useDelimiter("\\Z").next();
        List<List<String>> requestParams = dataTable.raw();
        String mid = requestParams.get(0).get(0);
        String anchorid = requestParams.get(0).get(1);
        String curr = requestParams.get(0).get(2);
        content = content.replace("Mid", mid);
        content = content.replace("AnchorId", anchorid);
        content = content.replace("CURR", curr);
        validatableResponse2 =
                given()
                        .contentType(ContentType.JSON)
                        .relaxedHTTPSValidation()
                        .when()
                        .body(content)
                        .post(url)
                        .then();
        //capturing API response as String
        response =
                given()
                        .contentType(ContentType.JSON)
                        .relaxedHTTPSValidation()
                        .when()
                        .body(content)
                        .post(url)
                        .thenReturn()
                        .asString();
    }

    @When("^verify that Trust Line is successfully setup$")
    public void verify_that_Trust_Line_is_successfully_setup() throws Throwable {
        validatableResponse2.statusCode(200);
    }


}
