package ab.glue.api;

import ab.utils.GenericUtils;
import io.restassured.response.Response;

/**
 * Created by 1571168 on 8/14/2018.
 */
public class OpenAPIPaymentStatusEnquiry {

    GenericUtils genericUtils = new GenericUtils();
    activationKey activationKey = new activationKey();
    public static Response response;
    public static String responseString;
    public static int responseStatus;
    public static boolean responseEncrypted;
    public static String randomMessageID;

    @GenericUtils.Data(name = "openAPIClientReferenceIds", xpath = "clientReferenceIds", jsonpath = "clientReferenceIds[0]",responseJSonPath ="clientReferenceIds[0]")
    String openAPIPaymentClientReferenceID = null;

    @GenericUtils.Data(name = "openAPIPaymentStatusGroupId", xpath = "", jsonpath = "statuses[0].groupId",responseJSonPath ="")
    String openAPIPaymentStatusGroupId = null;

    @GenericUtils.Data(name = "openAPIPaymentStatusEndToEndId", xpath = "", jsonpath = "statuses[0].endToEndId",responseJSonPath ="")
    String openAPIPaymentStatusEndToEndId = null;

    @GenericUtils.Data(name = "openAPIPaymentStatusClientIdentifier", xpath = "", jsonpath = "statuses[0].clientIdentifier",responseJSonPath ="")
    String openAPIPaymentStatusClientIdentifier = null;

    @GenericUtils.Data(name = "openAPIPaymentStatusPaymentContainerId", xpath = "", jsonpath = "statuses[0].paymentContainerId",responseJSonPath ="")
    String openAPIPaymentStatusPaymentContainerId = null;

    @GenericUtils.Data(name = "openAPIPaymentStatusStatusString", xpath = "", jsonpath = "statuses[0].statusString",responseJSonPath ="")
    String openAPIPaymentStatusStatusString = null;

    @GenericUtils.Data(name = "openAPIPaymentStatusStatusCode", xpath = "", jsonpath = "statuses[0].statusCode",responseJSonPath ="")
    String openAPIPaymentStatusStatusCode = null;

    @GenericUtils.Data(name = "openAPIPaymentStatusLastAssignee", xpath = "", jsonpath = "statuses[0].lastAssignee",responseJSonPath ="")
    String openAPIPaymentStatusLastAssignee= null;

    @GenericUtils.Data(name = "openAPIPaymentStatusReasonCode", xpath = "", jsonpath = "statuses[0].reasonCode",responseJSonPath ="")
    String openAPIPaymentStatusReasonCode= null;

    @GenericUtils.Data(name = "openAPIPaymentStatusReasonIsoCode", xpath = "", jsonpath = "statuses[0].reasonIsoCode",responseJSonPath ="")
    String openAPIPaymentStatusReasonIsoCode= null;

    @GenericUtils.Data(name = "openAPIPaymentStatusAdditionalInformation", xpath = "", jsonpath = "statuses[0].additionalInformation",responseJSonPath ="")
    String openAPIPaymentStatusAdditionalInformation= null;

    @GenericUtils.Data(name = "openAPIPaymentStatusTimestamp", xpath = "", jsonpath = "statuses[0].Timestamp",responseJSonPath ="")
    String openAPIPaymentStatusTimestamp= null;

    @GenericUtils.Data(name = "openAPIPaymentStatusOriginalTransactionId", xpath = "", jsonpath = "statuses[0].originalTransactionId",responseJSonPath ="")
    String openAPIPaymentStatusOriginalTransactionId= null;

    @GenericUtils.Data(name = "openAPIPaymentStatusClearingSystemReference", xpath = "", jsonpath = "statuses[0].clearingSystemReference",responseJSonPath ="")
    String openAPIPaymentStatusClearingSystemReference= null;

    @GenericUtils.Data(name = "openAPIPaymentStatusLimitBreachIndicator", xpath = "", jsonpath = "statuses[0].limitBreachIndicator",responseJSonPath ="")
    String openAPIPaymentStatusLimitBreachIndicator= null;

    @GenericUtils.Data(name = "openAPIPaymentStatusReasonInformation", xpath = "", jsonpath = "statuses[0].reasonInformation",responseJSonPath ="")
    String openAPIPaymentStatusReasonInformation= null;

    @GenericUtils.Data(name = "openAPIPaymentStatusChequeNumber", xpath = "", jsonpath = "statuses[0].cheque.number",responseJSonPath ="")
    String openAPIPaymentStatusChequeNumber= null;

    @GenericUtils.Data(name = "openAPIPaymentStatusClearingDate", xpath = "", jsonpath = "statuses[0].cheque.clearingDate",responseJSonPath ="")
    String openAPIPaymentStatusClearingDate= null;

    @GenericUtils.Data(name = "openAPIPaymentStatusTransactionReference", xpath = "", jsonpath = "statuses[0].cheque.transactionReference",responseJSonPath ="")
    String openAPIPaymentStatusTransactionReference= null;

    @GenericUtils.Data(name = "openAPIPaymentStatusBatchNumber", xpath = "", jsonpath = "statuses[0].cheque.batchNumber",responseJSonPath ="")
    String openAPIPaymentStatusBatchNumber= null;

    @GenericUtils.Data(name = "openAPITransactionStatusClientReferenceID", xpath = "clientReferenceIds", jsonpath = "clientReferenceIds",responseJSonPath ="clientReferenceIds[0]")
    String openAPITransactionStatusClientReferenceID = null;


}
