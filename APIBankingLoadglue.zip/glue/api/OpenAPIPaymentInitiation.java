package ab.glue.api;

import ab.common.JWTTest;
import ab.utils.GenericUtils;
import cucumber.api.DataTable;
import cucumber.api.java.en.When;
import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.response.Response;
import org.apache.commons.lang3.StringUtils;
import org.junit.Assert;
import org.w3c.dom.Document;
import org.w3c.dom.Node;
import org.xml.sax.InputSource;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.InputStream;
import java.security.KeyStore;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Properties;

/**
 * Created by 1571168 on 1/7/2018.
 */
public class OpenAPIPaymentInitiation extends GenericUtils {
    GenericUtils genericUtils = new GenericUtils();
    activationKey activationKey = new activationKey();
    public static Response response;
    public static String responseString;
    public static int responseStatus;
    public static boolean responseEncrypted;
    public static String randomMessageID;

    @Data(name = "openAPIPaymentMessageSender", xpath = "", jsonpath = "header.messageSender",responseJSonPath ="")
    String openAPIPaymentMessageSender = null;

    @Data(name = "openAPIPaymentCountry", xpath = "", jsonpath = "header.countryCode",responseJSonPath ="")
    String openAPIPaymentCountry = null;

    @Data(name = "openAPIPaymentAmount", xpath = "", jsonpath = "instruction.amount.amount",responseJSonPath ="")
    String openAPIPaymentAmount = null;

    @Data(name = "openAPIPaymentCurrency", xpath = "", jsonpath = "instruction.amount.currencyCode",responseJSonPath ="")
    String openAPIPaymentCurrency= null;

    @Data(name = "openAPIPaymentDebitAccountNumber", xpath = "", jsonpath = "instruction.debtorAccount.id",responseJSonPath ="")
    String openAPIPaymentDebitAccountNumber= null;

    @Data(name = "openAPIPaymentCreditAccountNumber", xpath = "", jsonpath = "instruction.creditorAccount.id",responseJSonPath ="")
    String openAPIPaymentCreditAccountNumber= null;

    @Data(name = "openAPIPaymentDebitBIC", xpath = "", jsonpath = "instruction.debtorAgent.financialInstitution.BIC",responseJSonPath ="")
    String openAPIPaymentDebitBIC= null;

    @Data(name = "openAPIPaymentDebitAccountIdentifierType", xpath = "", jsonpath = "instruction.debtorAccount.identifierType",responseJSonPath ="")
    String openAPIPaymentDebitAccountIdentifierType= null;

    @Data(name = "openAPIPaymentCreditBIC", xpath = "", jsonpath = "instruction.creditorAgent.financialInstitution.BIC",responseJSonPath ="")
    String openAPIPaymentCreditBIC= null;

    @Data(name = "openAPIPaymentdebitName", xpath = "", jsonpath = "instruction.debtor.name",responseJSonPath ="")
    String openAPIPaymentdebitName= null;

    @Data(name = "openAPIPaymentcreditName", xpath = "", jsonpath = "instruction.creditor.name",responseJSonPath ="")
    String openAPIPaymentcreditName= null;

    @Data(name = "openAPIPaymentdebitPostalAddressCountry", xpath = "", jsonpath = "instruction.debtorAgent.financialInstitution.postalAddress.country",responseJSonPath ="")
    String openAPIPaymentdebitPostalAddressCountry= null;

    @Data(name = "openAPIPaymentdebitCountry", xpath = "", jsonpath = "instruction.debtorAgent.financialInstitution.postalAddress.country",responseJSonPath ="")
    String openAPIPaymentdebitCountry= null;

    @Data(name = "openAPIPaymentcreditCountry", xpath = "", jsonpath = "instruction.creditorAgent.financialInstitution.postalAddress.country",responseJSonPath ="")
    String openAPIPaymentcreditCountry= null;

    @Data(name = "openAPIPaymentType", xpath = "", jsonpath = "instruction.paymentType",responseJSonPath ="")
    String openAPIPaymentType= null;

    @Data(name = "openAPIPaymentMessageID", xpath = "", jsonpath = "header.messageId",responseJSonPath ="")
    String openAPIPaymentMessageID= null;

    @Data(name = "openAPIPaymentReferenceID", xpath = "", jsonpath = "instruction.referenceId",responseJSonPath ="clientReferenceId")
    String openAPIPaymentReferenceID= null;

    @Data(name = "openAPIPaymentResponseClientReferenceId", xpath = "", jsonpath = "clientReferenceId",responseJSonPath ="clientReferenceId")
    String openAPIPaymentResponseClientReferenceId= null;

    @Data(name = "openAPIPaymentTypePreference", xpath = "", jsonpath = "instruction.paymentTypePreference",responseJSonPath ="")
    String openAPIPaymentTypePreference= null;

    @Data(name = "openAPIPaymentTimestamp", xpath = "", jsonpath = "instruction.paymentTimestamp",responseJSonPath ="")
    String openAPIPaymentTimestamp= null;

    @Data(name = "openAPIPaymentHeaderTimestamp", xpath = "", jsonpath = "header.timestamp",responseJSonPath ="")
    String openAPIPaymentHeaderTimestamp= null;

    @Data(name = "openAPIPaymentRequiredExecutionDate", xpath = "", jsonpath = "instruction.requiredExecutionDate",responseJSonPath ="")
    String openAPIPaymentRequiredExecutionDate= null;

    @Data(name = "openAPIType", xpath = "", jsonpath = "instruction.type",responseJSonPath ="")
    String openAPIType= null;

    @Data(name = "openAPIPurpose", xpath = "", jsonpath = "instruction.purpose",responseJSonPath ="")
    String openAPIPurpose= null;

    @Data(name = "openAPIDebitorName", xpath = "", jsonpath = "instruction.debtor.name",responseJSonPath ="")
    String openAPIDebitorName= null;

    @Data(name = "openAPIDebitorAgentBIC", xpath = "", jsonpath = "instruction.debtorAgent.financialInstitution.BIC",responseJSonPath ="")
    String openAPIDebitorAgentBIC= null;

    @Data(name = "openAPIDebitorAgentName", xpath = "", jsonpath = "instruction.debtorAgent.financialInstitution.name",responseJSonPath ="")
    String openAPIDebitorAgentName= null;

    @Data(name = "openAPIClearingSystemId", xpath = "", jsonpath = "instruction.debtorAgent.clearingSystemId",responseJSonPath ="")
    String openAPIClearingSystemId= null;

    @Data(name = "openAPICreditorName", xpath = "", jsonpath = "instruction.creditor.name",responseJSonPath ="")
    String openAPICreditorName = null;

    @Data(name = "openAPICreditorAccount", xpath = "", jsonpath = "instruction.creditorAccount.id",responseJSonPath ="")
    String openAPICreditorAccount = null;

    @Data(name = "openAPICreditorAgentBIC", xpath = "", jsonpath = "instruction.creditorAgent.financialInstitution.BIC",responseJSonPath ="")
    String openAPICreditorAgentBIC = null;

    @Data(name = "openAPICreditorAgentName", xpath = "", jsonpath = "instruction.creditorAgent.financialInstitution.name",responseJSonPath ="")
    String openAPICreditorAgentName = null;

    @Data(name = "openAPICreditorAgentPostalAddress", xpath = "", jsonpath = "instruction.creditorAgent.financialInstitution",responseJSonPath ="")
    String openAPICreditorAgentPostalAddress = null;

    @Data(name = "openAPIPaymentCreditAccountIdentifierType", xpath = "", jsonpath = "instruction.creditorAccount.identifierType",responseJSonPath ="")
    String openAPIPaymentCreditAccountIdentifierType= null;

    @When("^UPI payment requests for the following details$")
    public void paymentInitiation(DataTable dataTable) throws Throwable {
        String filepath = new File(".").getCanonicalPath() + "/src/test/resources/test-data/UPI_AccountBalanceEnquiry.xml";
        DocumentBuilderFactory docFactory = DocumentBuilderFactory.newInstance();
        DocumentBuilder docBuilder = docFactory.newDocumentBuilder();
        NewStub newStub = new NewStub();
        String request = newStub.readFile(filepath);
        InputSource source = new InputSource(new ByteArrayInputStream(request.getBytes()));
        Document doc = docBuilder.parse(filepath);
        Node payer = doc.getElementsByTagName("Payer").item(0);
        KeyStore keyStore = null;
        String data = null;

        RestAssured.useRelaxedHTTPSValidation();
        Map<String, String> headerMap = new HashMap<String, String>();
        Iterator iterator = dataTable.asLists(Object.class).get(1).iterator();
        String accountNumber = "empty";
        String certificate = "empty";
        String token = "empty";
        String content = "empty";
        String groupID = "";
        String country = "";
        String currency = "";
        String accountType = "";
        InputStream input = getClass().getResourceAsStream("/test-data/activationKeyRequest.properties");
        Properties prop = new Properties();
        prop.load(input);
        if (iterator.hasNext()) {
            accountNumber = (String) iterator.next();
            request = StringUtils.replace(request, "${accountNumber}", accountNumber);
        }
        if (iterator.hasNext())
            groupID = (String) iterator.next();
        if (iterator.hasNext())
            country = (String) iterator.next();
        if (iterator.hasNext())
            currency = (String) iterator.next();
        if (iterator.hasNext())
            accountType = (String) iterator.next();
        if (iterator.hasNext())
            content = (String) iterator.next();
        if (iterator.hasNext()) {
            token = (String) iterator.next();
            if (token.equals("Valid Token")) {
                //String content = null;
                //activationKey.a_POST_request_is_made_to_the_activationKey_API_for_Group(groupID);
                //activationKey.activKey.put(groupID,token);
                String activKey =  activationKey.getActivationKey(groupID,prop);
                String[] parts = activKey.split("\"");
                token = JWTTest.createTokenForGroup(30L, parts[5], parts[9], groupID);
                headerMap.put("JWTToken",token);
            }
        }
        if (certificate.equals("empty") || certificate.equals("Valid Cert")) {
            certificate = prop.getProperty(groupID + "_Certificate");
            headerMap.put("X-Client-Certifcate","MIIFPDCCBCSgAwIBAgIQBhCY9/Oua9sbbZUiKb7/ETANBgkqhkiG9w0BAQsFADBlMQswCQYDVQQGEwJVUzEVMBMGA1UEChMMRGlnaUNlcnQgSW5jMRkwFwYDVQQLExB3d3cuZGlnaWNlcnQuY29tMSQwIgYDVQQDExtEaWdpQ2VydCBTSEEyIEFzc3VyZWQgSUQgQ0EwHhcNMTcwNTIzMDAwMDAwWhcNMTgwNTIzMTIwMDAwWjBXMQswCQYDVQQGEwJTRzESMBAGA1UEBxMJU2luZ2Fwb3JlMSAwHgYDVQQKExdTdGFuZGFyZCBDaGFydGVyZWQgQmFuazESMBAGA1UEAxMJQWNtZSBDb3JwMIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAx+79CIYpTbQdM93rnQe2y+gMCAZGKfwVuyT4xjYDmYfKr4+/6F2OUoVAP0wsS+EufaFOdwGRYD2Xcg8fH/jwp4dynekLNmO94et7pDBIQoHoyqUz5IfYIhbkwUV5zAjJEfrAlLXEfrBB+j8v6/DMWcYoFvXvq2mA/rZCr5S5L7RCKj17Tup6OpRasbohHADLwLx/gk/gaX7fAzV/4jETHw1zxRg9jT8WaPp+Qs3KeQlXqDEX6vpH12flHDl1dF+QfuKN5jlKG77yKsThglYwRTeaxrL3RgU8X6P8T1S5xpzGCIlE7RHFTpta1Hxn3oD59AvhQkQ8CkYyOWzt6GS6uQIDAQABo4IB9DCCAfAwHwYDVR0jBBgwFoAU5wIjgABP2Ne8lAvZP3Q5STI8inkwHQYDVR0OBBYEFIzxOlIwI/C/ktPcOkYtZA1XWTKrMAwGA1UdEwEB/wQCMAAwJgYDVR0RBB8wHYEbcHJhc2FubmEua2FuYWdhc2FiYWlAc2MuY29tMA4GA1UdDwEB/wQEAwIFoDAdBgNVHSUEFjAUBggrBgEFBQcDAgYIKwYBBQUHAwQwQwYDVR0gBDwwOjA4BgpghkgBhv1sBAECMCowKAYIKwYBBQUHAgEWHGh0dHBzOi8vd3d3LmRpZ2ljZXJ0LmNvbS9DUFMwgYgGA1UdHwSBgDB+MD2gO6A5hjdodHRwOi8vY3JsMy5kaWdpY2VydC5jb20vRGlnaUNlcnRTSEEyQXNzdXJlZElEQ0EtZzIuY3JsMD2gO6A5hjdodHRwOi8vY3JsNC5kaWdpY2VydC5jb20vRGlnaUNlcnRTSEEyQXNzdXJlZElEQ0EtZzIuY3JsMHkGCCsGAQUFBwEBBG0wazAkBggrBgEFBQcwAYYYaHR0cDovL29jc3AuZGlnaWNlcnQuY29tMEMGCCsGAQUFBzAChjdodHRwOi8vY2FjZXJ0cy5kaWdpY2VydC5jb20vRGlnaUNlcnRTSEEyQXNzdXJlZElEQ0EuY3J0MA0GCSqGSIb3DQEBCwUAA4IBAQCuOYPuakKB9qCCR7JYaA+92BprzqYFd1LwT62FrdzcPGupHix7ALoiw2jHuMQogrc3Rw0wZPUqgN29b2bcXX8r9B8OMVbxYL6VZGJ8P+WndUPOzbWdl7eAY/9HbkAUgcqzSP+BBcndCyKdR+bs43dYDNvhDzqL7hHgqjmxFxVz8C/25oLmBZ0yOXz5yLpVoTyHBl1OfAkrYj5WeQI8/uiR9bJ4SwY/NvUU+sOB/UJsxECjpmmdS26dYMRyLuFT7hZvmgv8L2wcjO6vyA9qm3kNb0dTJw1/xQG56pdaGRhdVEqp/L3/hW0COgQvOVdRNlVH9dU8cCl57ICj9rtxTrqg");
        }
        if (token.equals("empty"))
            token = "";
        ContentType contentType = ContentType.XML;
        //2) pass to doPost function & put response into responses list

        if(content.equals("JSON"))
            contentType = ContentType.JSON;
        else if(content.equals("TEXT"))
            contentType = ContentType.TEXT;
        else if(content.equals("HTML"))
            contentType = ContentType.HTML;
        else if(content.equals("BINARY"))
            contentType = ContentType.BINARY;
        else
            contentType = ContentType.XML;
        //headerMap.put("ResponseEncryptionType","AES256Signed");
        //headerMap.put("X-Client-Certifcate","MIIFPDCCBCSgAwIBAgIQBhCY9/Oua9sbbZUiKb7/ETANBgkqhkiG9w0BAQsFADBlMQswCQYDVQQGEwJVUzEVMBMGA1UEChMMRGlnaUNlcnQgSW5jMRkwFwYDVQQLExB3d3cuZGlnaWNlcnQuY29tMSQwIgYDVQQDExtEaWdpQ2VydCBTSEEyIEFzc3VyZWQgSUQgQ0EwHhcNMTcwNTIzMDAwMDAwWhcNMTgwNTIzMTIwMDAwWjBXMQswCQYDVQQGEwJTRzESMBAGA1UEBxMJU2luZ2Fwb3JlMSAwHgYDVQQKExdTdGFuZGFyZCBDaGFydGVyZWQgQmFuazESMBAGA1UEAxMJQWNtZSBDb3JwMIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAx+79CIYpTbQdM93rnQe2y+gMCAZGKfwVuyT4xjYDmYfKr4+/6F2OUoVAP0wsS+EufaFOdwGRYD2Xcg8fH/jwp4dynekLNmO94et7pDBIQoHoyqUz5IfYIhbkwUV5zAjJEfrAlLXEfrBB+j8v6/DMWcYoFvXvq2mA/rZCr5S5L7RCKj17Tup6OpRasbohHADLwLx/gk/gaX7fAzV/4jETHw1zxRg9jT8WaPp+Qs3KeQlXqDEX6vpH12flHDl1dF+QfuKN5jlKG77yKsThglYwRTeaxrL3RgU8X6P8T1S5xpzGCIlE7RHFTpta1Hxn3oD59AvhQkQ8CkYyOWzt6GS6uQIDAQABo4IB9DCCAfAwHwYDVR0jBBgwFoAU5wIjgABP2Ne8lAvZP3Q5STI8inkwHQYDVR0OBBYEFIzxOlIwI/C/ktPcOkYtZA1XWTKrMAwGA1UdEwEB/wQCMAAwJgYDVR0RBB8wHYEbcHJhc2FubmEua2FuYWdhc2FiYWlAc2MuY29tMA4GA1UdDwEB/wQEAwIFoDAdBgNVHSUEFjAUBggrBgEFBQcDAgYIKwYBBQUHAwQwQwYDVR0gBDwwOjA4BgpghkgBhv1sBAECMCowKAYIKwYBBQUHAgEWHGh0dHBzOi8vd3d3LmRpZ2ljZXJ0LmNvbS9DUFMwgYgGA1UdHwSBgDB+MD2gO6A5hjdodHRwOi8vY3JsMy5kaWdpY2VydC5jb20vRGlnaUNlcnRTSEEyQXNzdXJlZElEQ0EtZzIuY3JsMD2gO6A5hjdodHRwOi8vY3JsNC5kaWdpY2VydC5jb20vRGlnaUNlcnRTSEEyQXNzdXJlZElEQ0EtZzIuY3JsMHkGCCsGAQUFBwEBBG0wazAkBggrBgEFBQcwAYYYaHR0cDovL29jc3AuZGlnaWNlcnQuY29tMEMGCCsGAQUFBzAChjdodHRwOi8vY2FjZXJ0cy5kaWdpY2VydC5jb20vRGlnaUNlcnRTSEEyQXNzdXJlZElEQ0EuY3J0MA0GCSqGSIb3DQEBCwUAA4IBAQCuOYPuakKB9qCCR7JYaA+92BprzqYFd1LwT62FrdzcPGupHix7ALoiw2jHuMQogrc3Rw0wZPUqgN29b2bcXX8r9B8OMVbxYL6VZGJ8P+WndUPOzbWdl7eAY/9HbkAUgcqzSP+BBcndCyKdR+bs43dYDNvhDzqL7hHgqjmxFxVz8C/25oLmBZ0yOXz5yLpVoTyHBl1OfAkrYj5WeQI8/uiR9bJ4SwY/NvUU+sOB/UJsxECjpmmdS26dYMRyLuFT7hZvmgv8L2wcjO6vyA9qm3kNb0dTJw1/xQG56pdaGRhdVEqp/L3/hW0COgQvOVdRNlVH9dU8cCl57ICj9rtxTrqg");
        //headerMap.put("JWTToken", "");
        //headerMap.put("X-Client-Certifcate", "");
        if(responseEncrypted)
            headerMap.put("ResponseEncryptionType", "AES256Signed");
        headerMap.put("GroupId","B0001");
        System.out.println("The request is "+ request);
        response = genericUtils.getPOSTResponse(headerMap, request, "https://10.23.210.60:9012/api/upi/ReqBalEnq/1.0", contentType);
        System.out.println("The response is "+response.thenReturn().asString());
        System.out.println("The status code is "+response.getStatusCode());
        Assert.assertTrue("The Account Balance enquiry should be displayed with the balance with account number as " + "" + accountNumber + ". But it is displayed as " + response.thenReturn().asString(), response.thenReturn().asString().contains("" + accountNumber));

    }


    @When("^Open API payment requests for the following details$")
    public void OpenAPIPaymentInitiation(DataTable dataTable) throws Throwable {
        String filepath = new File(".").getCanonicalPath() + "/src/test/resources/test-data/UPI_AccountBalanceEnquiry.xml";
        DocumentBuilderFactory docFactory = DocumentBuilderFactory.newInstance();
        DocumentBuilder docBuilder = docFactory.newDocumentBuilder();
        NewStub newStub = new NewStub();
        String request = newStub.readFile(filepath);
        InputSource source = new InputSource(new ByteArrayInputStream(request.getBytes()));
        Document doc = docBuilder.parse(filepath);
        Node payer = doc.getElementsByTagName("Payer").item(0);
        KeyStore keyStore = null;
        String data = null;

        RestAssured.useRelaxedHTTPSValidation();
        Map<String, String> headerMap = new HashMap<String, String>();
        Iterator iterator = dataTable.asLists(Object.class).get(1).iterator();
        String accountNumber = "empty";
        String certificate = "empty";
        String token = "empty";
        String content = "empty";
        String groupID = "";
        String country = "";
        String currency = "";
        String accountType = "";
        InputStream input = getClass().getResourceAsStream("/test-data/activationKeyRequest.properties");
        Properties prop = new Properties();
        prop.load(input);
        if (iterator.hasNext()) {
            accountNumber = (String) iterator.next();
            request = StringUtils.replace(request, "${accountNumber}", accountNumber);
        }
        if (iterator.hasNext())
            groupID = (String) iterator.next();
        if (iterator.hasNext())
            country = (String) iterator.next();
        if (iterator.hasNext())
            currency = (String) iterator.next();
        if (iterator.hasNext())
            accountType = (String) iterator.next();
        if (iterator.hasNext())
            content = (String) iterator.next();
        if (iterator.hasNext()) {
            token = (String) iterator.next();
            if (token.equals("Valid Token")) {
                //String content = null;
                //activationKey.a_POST_request_is_made_to_the_activationKey_API_for_Group(groupID);
                //activationKey.activKey.put(groupID,token);
                String activKey =  activationKey.getActivationKey(groupID,prop);
                String[] parts = activKey.split("\"");
                token = JWTTest.createTokenForGroup(30L, parts[5], parts[9], groupID);
                headerMap.put("JWTToken",token);
            }
        }
        if (certificate.equals("empty") || certificate.equals("Valid Cert")) {
            certificate = prop.getProperty(groupID + "_Certificate");
            headerMap.put("X-Client-Certifcate","MIIFPDCCBCSgAwIBAgIQBhCY9/Oua9sbbZUiKb7/ETANBgkqhkiG9w0BAQsFADBlMQswCQYDVQQGEwJVUzEVMBMGA1UEChMMRGlnaUNlcnQgSW5jMRkwFwYDVQQLExB3d3cuZGlnaWNlcnQuY29tMSQwIgYDVQQDExtEaWdpQ2VydCBTSEEyIEFzc3VyZWQgSUQgQ0EwHhcNMTcwNTIzMDAwMDAwWhcNMTgwNTIzMTIwMDAwWjBXMQswCQYDVQQGEwJTRzESMBAGA1UEBxMJU2luZ2Fwb3JlMSAwHgYDVQQKExdTdGFuZGFyZCBDaGFydGVyZWQgQmFuazESMBAGA1UEAxMJQWNtZSBDb3JwMIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAx+79CIYpTbQdM93rnQe2y+gMCAZGKfwVuyT4xjYDmYfKr4+/6F2OUoVAP0wsS+EufaFOdwGRYD2Xcg8fH/jwp4dynekLNmO94et7pDBIQoHoyqUz5IfYIhbkwUV5zAjJEfrAlLXEfrBB+j8v6/DMWcYoFvXvq2mA/rZCr5S5L7RCKj17Tup6OpRasbohHADLwLx/gk/gaX7fAzV/4jETHw1zxRg9jT8WaPp+Qs3KeQlXqDEX6vpH12flHDl1dF+QfuKN5jlKG77yKsThglYwRTeaxrL3RgU8X6P8T1S5xpzGCIlE7RHFTpta1Hxn3oD59AvhQkQ8CkYyOWzt6GS6uQIDAQABo4IB9DCCAfAwHwYDVR0jBBgwFoAU5wIjgABP2Ne8lAvZP3Q5STI8inkwHQYDVR0OBBYEFIzxOlIwI/C/ktPcOkYtZA1XWTKrMAwGA1UdEwEB/wQCMAAwJgYDVR0RBB8wHYEbcHJhc2FubmEua2FuYWdhc2FiYWlAc2MuY29tMA4GA1UdDwEB/wQEAwIFoDAdBgNVHSUEFjAUBggrBgEFBQcDAgYIKwYBBQUHAwQwQwYDVR0gBDwwOjA4BgpghkgBhv1sBAECMCowKAYIKwYBBQUHAgEWHGh0dHBzOi8vd3d3LmRpZ2ljZXJ0LmNvbS9DUFMwgYgGA1UdHwSBgDB+MD2gO6A5hjdodHRwOi8vY3JsMy5kaWdpY2VydC5jb20vRGlnaUNlcnRTSEEyQXNzdXJlZElEQ0EtZzIuY3JsMD2gO6A5hjdodHRwOi8vY3JsNC5kaWdpY2VydC5jb20vRGlnaUNlcnRTSEEyQXNzdXJlZElEQ0EtZzIuY3JsMHkGCCsGAQUFBwEBBG0wazAkBggrBgEFBQcwAYYYaHR0cDovL29jc3AuZGlnaWNlcnQuY29tMEMGCCsGAQUFBzAChjdodHRwOi8vY2FjZXJ0cy5kaWdpY2VydC5jb20vRGlnaUNlcnRTSEEyQXNzdXJlZElEQ0EuY3J0MA0GCSqGSIb3DQEBCwUAA4IBAQCuOYPuakKB9qCCR7JYaA+92BprzqYFd1LwT62FrdzcPGupHix7ALoiw2jHuMQogrc3Rw0wZPUqgN29b2bcXX8r9B8OMVbxYL6VZGJ8P+WndUPOzbWdl7eAY/9HbkAUgcqzSP+BBcndCyKdR+bs43dYDNvhDzqL7hHgqjmxFxVz8C/25oLmBZ0yOXz5yLpVoTyHBl1OfAkrYj5WeQI8/uiR9bJ4SwY/NvUU+sOB/UJsxECjpmmdS26dYMRyLuFT7hZvmgv8L2wcjO6vyA9qm3kNb0dTJw1/xQG56pdaGRhdVEqp/L3/hW0COgQvOVdRNlVH9dU8cCl57ICj9rtxTrqg");
        }
        if (token.equals("empty"))
            token = "";
        ContentType contentType = ContentType.XML;
        //2) pass to doPost function & put response into responses list

        if(content.equals("JSON"))
            contentType = ContentType.JSON;
        else if(content.equals("TEXT"))
            contentType = ContentType.TEXT;
        else if(content.equals("HTML"))
            contentType = ContentType.HTML;
        else if(content.equals("BINARY"))
            contentType = ContentType.BINARY;
        else
            contentType = ContentType.XML;
        //headerMap.put("ResponseEncryptionType","AES256Signed");
        //headerMap.put("X-Client-Certifcate","MIIFPDCCBCSgAwIBAgIQBhCY9/Oua9sbbZUiKb7/ETANBgkqhkiG9w0BAQsFADBlMQswCQYDVQQGEwJVUzEVMBMGA1UEChMMRGlnaUNlcnQgSW5jMRkwFwYDVQQLExB3d3cuZGlnaWNlcnQuY29tMSQwIgYDVQQDExtEaWdpQ2VydCBTSEEyIEFzc3VyZWQgSUQgQ0EwHhcNMTcwNTIzMDAwMDAwWhcNMTgwNTIzMTIwMDAwWjBXMQswCQYDVQQGEwJTRzESMBAGA1UEBxMJU2luZ2Fwb3JlMSAwHgYDVQQKExdTdGFuZGFyZCBDaGFydGVyZWQgQmFuazESMBAGA1UEAxMJQWNtZSBDb3JwMIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAx+79CIYpTbQdM93rnQe2y+gMCAZGKfwVuyT4xjYDmYfKr4+/6F2OUoVAP0wsS+EufaFOdwGRYD2Xcg8fH/jwp4dynekLNmO94et7pDBIQoHoyqUz5IfYIhbkwUV5zAjJEfrAlLXEfrBB+j8v6/DMWcYoFvXvq2mA/rZCr5S5L7RCKj17Tup6OpRasbohHADLwLx/gk/gaX7fAzV/4jETHw1zxRg9jT8WaPp+Qs3KeQlXqDEX6vpH12flHDl1dF+QfuKN5jlKG77yKsThglYwRTeaxrL3RgU8X6P8T1S5xpzGCIlE7RHFTpta1Hxn3oD59AvhQkQ8CkYyOWzt6GS6uQIDAQABo4IB9DCCAfAwHwYDVR0jBBgwFoAU5wIjgABP2Ne8lAvZP3Q5STI8inkwHQYDVR0OBBYEFIzxOlIwI/C/ktPcOkYtZA1XWTKrMAwGA1UdEwEB/wQCMAAwJgYDVR0RBB8wHYEbcHJhc2FubmEua2FuYWdhc2FiYWlAc2MuY29tMA4GA1UdDwEB/wQEAwIFoDAdBgNVHSUEFjAUBggrBgEFBQcDAgYIKwYBBQUHAwQwQwYDVR0gBDwwOjA4BgpghkgBhv1sBAECMCowKAYIKwYBBQUHAgEWHGh0dHBzOi8vd3d3LmRpZ2ljZXJ0LmNvbS9DUFMwgYgGA1UdHwSBgDB+MD2gO6A5hjdodHRwOi8vY3JsMy5kaWdpY2VydC5jb20vRGlnaUNlcnRTSEEyQXNzdXJlZElEQ0EtZzIuY3JsMD2gO6A5hjdodHRwOi8vY3JsNC5kaWdpY2VydC5jb20vRGlnaUNlcnRTSEEyQXNzdXJlZElEQ0EtZzIuY3JsMHkGCCsGAQUFBwEBBG0wazAkBggrBgEFBQcwAYYYaHR0cDovL29jc3AuZGlnaWNlcnQuY29tMEMGCCsGAQUFBzAChjdodHRwOi8vY2FjZXJ0cy5kaWdpY2VydC5jb20vRGlnaUNlcnRTSEEyQXNzdXJlZElEQ0EuY3J0MA0GCSqGSIb3DQEBCwUAA4IBAQCuOYPuakKB9qCCR7JYaA+92BprzqYFd1LwT62FrdzcPGupHix7ALoiw2jHuMQogrc3Rw0wZPUqgN29b2bcXX8r9B8OMVbxYL6VZGJ8P+WndUPOzbWdl7eAY/9HbkAUgcqzSP+BBcndCyKdR+bs43dYDNvhDzqL7hHgqjmxFxVz8C/25oLmBZ0yOXz5yLpVoTyHBl1OfAkrYj5WeQI8/uiR9bJ4SwY/NvUU+sOB/UJsxECjpmmdS26dYMRyLuFT7hZvmgv8L2wcjO6vyA9qm3kNb0dTJw1/xQG56pdaGRhdVEqp/L3/hW0COgQvOVdRNlVH9dU8cCl57ICj9rtxTrqg");
        //headerMap.put("JWTToken", "");
        //headerMap.put("X-Client-Certifcate", "");
        if(responseEncrypted)
            headerMap.put("ResponseEncryptionType", "AES256Signed");
        headerMap.put("GroupId","B0001");
        System.out.println("The request is "+ request);
        response = genericUtils.getPOSTResponse(headerMap, request, "https://10.23.210.60:9012/api/upi/ReqBalEnq/1.0", contentType);
        System.out.println("The response is "+response.thenReturn().asString());
        System.out.println("The status code is "+response.getStatusCode());
        Assert.assertTrue("The Account Balance enquiry should be displayed with the balance with account number as " + "" + accountNumber + ". But it is displayed as " + response.thenReturn().asString(), response.thenReturn().asString().contains("" + accountNumber));

    }
}
