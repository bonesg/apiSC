package com.sc.channels;

public class Webhook {

    String group;
    int port;
    String privateKey;
    String publicKey;


    public Webhook(int port, String group) {
        this.port = port;
        this.group = group;
    }


    public void start() {

    }


    public void stop() {

    }


    @Override
    public String toString(){
        return String.format("{\"port\": \"%s\", \"group\":\"%s\"}",port+"",group);
    }
}
