package com.sc.channels;

import sun.rmi.server.InactiveGroupException;

import javax.ws.rs.*;
import javax.ws.rs.core.MediaType;
import java.io.IOException;
import java.net.ServerSocket;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

@Path("webhook/factory")
public class Resource {

    static Map<Integer,Webhook> webhooks = new ConcurrentHashMap<>();

    @GET
    @Path("start")
    @Produces(MediaType.APPLICATION_JSON)
    public String createWebHook(@QueryParam("group") String group) throws IOException {

        ServerSocket socket = new ServerSocket(0);
        Webhook webhook = new Webhook( socket.getLocalPort(),group);
        try{
            webhook.start();
            webhooks.put(socket.getLocalPort(),webhook);
        }
        catch (Exception e){
        }
        return String.format("{\"port\":\"%s\"}",webhook.port);
    }

    @GET
    @Path("stop")
    @Produces(MediaType.APPLICATION_JSON)
    public String closeWebhook(@QueryParam("port") String port, @QueryParam("group") String group){

        Webhook webhook = webhooks.remove(Integer.parseInt(port));
        webhook.stop();
        return String.format("{\"message\":\"webhook running at %s stopped\"}",port);
    }

    @GET
    @Path("status")
    public String getListOfOpenPorts(){
        return webhooks.values().toString();
    }

}
