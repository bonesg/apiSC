package ab.common;

import org.apache.activemq.ActiveMQConnectionFactory;
import org.apache.activemq.command.ActiveMQTopic;
import org.apache.commons.io.IOUtils;
import org.junit.Test;
import org.springframework.core.io.ClassPathResource;

import javax.jms.*;
import java.io.FileInputStream;
import java.io.IOException;

public class PostMessageForWebHook {

       public Message createTextMessage(Session session, FileInputStream fileInputStream) throws IOException, JMSException {
        TextMessage txt = session.createTextMessage();
        txt.setText(IOUtils.toString(fileInputStream));
        return txt;
    }

}
