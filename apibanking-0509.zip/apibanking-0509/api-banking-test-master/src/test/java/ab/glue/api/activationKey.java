package ab.glue.api;

import common.EndPoint;
import ab.common.JWTTest;
import common.RestAssuredConfig;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import io.restassured.RestAssured;
import io.restassured.config.SSLConfig;
import io.restassured.http.ContentType;
import io.restassured.response.ValidatableResponse;
import org.apache.http.HttpStatus;
import org.junit.Assert;

import java.io.File;
import java.io.FileInputStream;
import java.security.KeyStore;
import java.util.HashMap;
import java.util.Scanner;

import static io.restassured.RestAssured.given;
import static org.junit.Assert.assertTrue;

/**
 * Created by 1556780 on 6/21/2017.
 */
public class activationKey extends RestAssuredConfig {

    private static ValidatableResponse validatableResponse = null;
    private static String response;
    private static int statusCode;
    public static String activationContent = null;
    public static String key = null;
    public static String token = null;
    public static String certificate = null;
    public static HashMap<String, String> activKey = new HashMap<String, String>();

    @When("^a POST request is made to the activationKey API for the group '(.+)'$")
            public void createActivationKeyForGroup(String group) throws Throwable {
                String content = null;
                try {
                    content = new Scanner(new File("./src/test/resources/test-data/"+group+"activationKeyBody.json")).useDelimiter("\\Z").next();
                } catch (Exception e) {
                    e.printStackTrace();
        }

        KeyStore keyStore = null;

        //capturing API response as validatable response
        validatableResponse = given()
                .proxy("10.65.128.43", 8080)
                .contentType(ContentType.JSON)
                .body(content)
                .when()
                .post(EndPoint.POST_CreateActivationKey)
                .then();
        //capturing API response as String
        response =
                given()
                        .proxy("10.65.128.43", 8080)
                        .contentType(ContentType.JSON)
                        .body(content)
                        .when()
                        .post(EndPoint.POST_CreateActivationKey)
                        .thenReturn()
                        .asString();
        System.out.println("Response is " + response);
        String[] parts = response.split("\"");
        /*for (String s : parts) {
            System.out.println(s);
        }*/

        activationContent = parts[3];
        key = parts[7];
    }

    @When("^a POST request is made to the activationKey API$")
    public void a_POST_request_is_made_to_the_activationKey_API() throws Throwable {
        String content = null;
        try {
           // content = new Scanner(new File("./src/test/resources/activationKeyBody.json")).useDelimiter("\\Z").next();
            content = new Scanner(new File("./src/test/resources/test-data/activationKeyBody"+"INDGROUP"+".json")).useDelimiter("\\Z").next();
        } catch (Exception e) {
            e.printStackTrace();
        }

        KeyStore keyStore = null;

        //capturing API response as validatable response
        validatableResponse = given()
                .proxy("10.65.128.43", 8080)
                .contentType(ContentType.JSON)
                .body(content)
                .when()
                .post(EndPoint.POST_CreateActivationKey)
                .then();
        //capturing API response as String
        response =
                given()
                        .proxy("10.65.128.43", 8080)
                        .contentType(ContentType.JSON)
                        .body(content)
                        .when()
                        .post(EndPoint.POST_CreateActivationKey)
                        .thenReturn()
                        .asString();
        System.out.println("Response is " + response);
        String[] parts = response.split("\"");
        /*for (String s : parts) {
            System.out.println(s);
        }*/

        activationContent = parts[3];
        key = parts[7];
    }


    @When("^a POST request is made to the activationKey API with public key '(.+)' groupID '(.+)' certificate thumbprint '(.+)'$")
    public void a_POST_request_is_made_to_the_activation_key(String publicKey, String groupID, String thumbprint) throws Throwable {
        String content = null;
        try {
            // content = new Scanner(new File("./src/test/resources/activationKeyBody.json")).useDelimiter("\\Z").next();
            content = new Scanner(new File("./src/test/resources/test-data/activationKeyBody.json")).useDelimiter("\\Z").next();
        } catch (Exception e) {
            e.printStackTrace();
        }
        content = content.replaceAll(" ","");
        String expectedFingerprint = content.split("\"certificateThumbprint\":\"")[1].split("\",")[0];
        String expectedPublickey = content.split("\"publicKey\":\"")[1].split("\",")[0];
        String expectedGroupID = content.split("\"groupId\":\"")[1].split("\",")[0];
        content = content.replaceAll(expectedFingerprint,thumbprint);
        content = content.replaceAll(expectedPublickey,publicKey);
        content = content.replaceAll(expectedGroupID,groupID);
        KeyStore keyStore = null;

        //capturing API response as validatable response
        statusCode = given()
                .proxy("10.65.128.43", 8080)
                .contentType(ContentType.JSON)
                .body(content)
                .when()
                .post(EndPoint.POST_CreateActivationKey)
                .getStatusCode();
        //capturing API response as String
        response =
                given()
                        .proxy("10.65.128.43", 8080)
                        .contentType(ContentType.JSON)
                        .body(content)
                        .when()
                        .post(EndPoint.POST_CreateActivationKey)
                        .getBody()
                        .asString();
        System.out.println("Response is " + response);

    }

    @Then("^the response should be displayed as 403 error$")
        public void verifyActivationKeyResponse(){

        Assert.assertTrue("", statusCode == 403);
        Assert.assertTrue("",response.contains(""));
    }

    @When("^a POST request is made to the activationKey API for group '(.+)'$")
    public void a_POST_request_is_made_to_the_activationKey_API_for_Group(String group) throws Throwable {
        String content = null;
        try {
            // content = new Scanner(new File("./src/test/resources/activationKeyBody.json")).useDelimiter("\\Z").next();
            content = new Scanner(new File("./src/test/resources/test-data/activationKeyBody"+group+".json")).useDelimiter("\\Z").next();
        } catch (Exception e) {
            e.printStackTrace();
        }
        KeyStore keyStore = null;

        //capturing API response as validatable response
        validatableResponse = given()
                .proxy("10.65.128.43", 8080)
                .contentType(ContentType.JSON)
                .body(content)
                .when()
                .post(EndPoint.CREATE_ACTIVATION_KEY_URL+EndPoint.POST_CreateActivationKey)
                .then();
        //capturing API response as String
        response =
                given()
                        .proxy("10.65.128.43", 8080)
                        .contentType(ContentType.JSON)
                        .body(content)
                        .when()
                        .post(EndPoint.CREATE_ACTIVATION_KEY_URL+EndPoint.POST_CreateActivationKey)
                        .thenReturn()
                        .asString();
        System.out.println("Response is " + response);
        String[] parts = response.split("\"");
        /*for (String s : parts) {
            System.out.println(s);
        }*/

        activationContent = parts[3];
        key = parts[7];
    }

    @Then("^API response should be OK$")
    public void API_response_should_be_OK() throws Throwable {
        validatableResponse
                .statusCode(HttpStatus.SC_OK);
    }

    @Then("^content and key data should be generated$")
    public void content_and_key_data_should_be_generated() throws Throwable {
        System.out.println(activationContent);
        System.out.println(key);
    }

    @When("^generated content and key is passed to the create token method$")
    public void generated_content_and_key_is_passed_to_the_create_token_method() throws Throwable {
        token = JWTTest.createToken(activationContent, key);
        activKey.put("INDGROUP",token);
    }

    @When("^generated content and key is passed to the create token method for the group ''(.+)''$")
    public void generated_content_and_key_is_passed_to_the_create_token_method_for_the_group(String groupID) throws Throwable {
        token = JWTTest.createTokenForGroup(activationContent, key, groupID);
        //activKey.put(groupID,token);
        activKey.put("INDGROUP","eyJhbGciOiJSUzI1NiJ9.eyJpc3MiOiJTQ0IiLCJhdWQiOiJTQ0ItQVBJQmFua2luZyIsImlhdCI6MTUwMjk0MTc5NywiZXhwIjozMDAwMDE1MDI5NDE3OTcsInBheWxvYWQiOnsiZW5hYmxlV2ViSG9vayI6InRydWUiLCJ3ZWJIb29rVXJsIjoiaHR0cDovLzE4LjIyMC4xNTYuMi93ZWJob29rIiwiYWN0aXZhdGlvbktleSI6eyJjb250ZW50IjoiZ2UyT2F5dWZNNnV2Z3ZZYzBWdkxlOTRTYmt5NzdveXJlenhSSzJpL3hocndkRitiQVZicldJcUNZeWFWYXpOZjRScWFlTkJhTkZNSW9BSGdZenhWTFYzdmRoNnVod2V3dGJHelpnNFo0RDVjd2dtZUtiZFpYd2tvOUNEMGE4S3F0TmRENDBVbkRVRU1NK0RZYVZtTlQ0c0dJMEI4K3pJZE0wVDFoVkE5NzdJVDYzYzJaYjNyR29EZGJZWG9xaGRmRWxLL2hJMU5NUDZzUXUzRWdXSlh5UEJjWnNrTkpoeDQ0WWkvV3BVSkNtaU5mcGliREJlWUllKzExNWEyTTJvZzdRcnlrQ0dVQ2RXdUwrYVlJYXlaT200eHgxZmFscUJvNE80NlVnaHp5bUNhN0pJc0lLN0pRMUdZK0RXbDRuN204V3NTVlRpOUVPaithTzlCT0dYeUtmZWdqRXNPcU8wZDlPVFlkbWpFRHNUWHlhWVlQV2JpcnpnYWcwcEJQVXdNaUZodFVOdE9ZSENSV3FVVDdEM1U5Qk81UDN2VmF4ajVjNHUxMHM1elRPR1BRd1d3S291QzBmS01sdldsTXByMDdJamd4djdlNDI5QkF6ZkdlVk1mekt4OGM4QUFWaWVXNndlQ2NYMVB2WlFOWE9FZTJHNmRpdzRyQ0lEQnpnRmwwdGpZVmRwUkhqZDJtWjRJakt1MklTMHE2bk9pNjRRYmVkQXNGckVMZUowYm5xZE9udGk5SnR5N3c0dk43ZWNuQUZVZTlGSHB6Vk9uMnAva0thSVQ3ZUxFUytkcVZ3Tk8vN3YyZkhsbnpyWlVWY3didXplbXdEek9HZXlCYUtCZnpSeVJERENGVFU4SkhueGtrZnArM25RNE5aOU9iQTVscHJWdis4VlhhdW5rWGcreGRRMGRiU3RkOXIzbTBwUjhkQVBOUGs5czFOYUtXRXdWUWpJVFZOelRvZTFlaWxobVpGRis0NEdMS0JFME1zaXI3WVZVV1pUbmtvcld2dzVHMjZkeU1DV3E0a2JwRUxkazczZjd5OU1ubDluM1phYzEwZ0pzcFNOcGJRWDBMTWd5MUwrdENyYlMrcnJRK0ZpZyIsImtleSI6IlpSU3IrSzVBcWR1QTZ3aVk2S21NSS9LTVE2d2NRem5HTzg1ZWJCVVZjdnlqOXZDVEpsRDdQdDNCdHlPUktPQ2grYnNLUi9iRVpBWlNqcG1OTzVlZ0JkRDBzZXdhNkRGaEpNQ0hENG1DS2hDT2RrQ2VreXlST2VtVHUycGx0cWNoNnUwc281a3F2TTBVYmVMcHF0RFRDZ3lKc3ZqdmVjTUNKK0MyZ1ZDZWJhc05lckVmZzM0UXN1ZUVSQlRiZlN6dFpMelVZRUtDaWI4Q2I4L0xtcFN3dFBxam5Nd1M1ckw5TkY2Q0kwS09vQVhtMXRCN0pUMFc1SXR1akNST3FJM2JGUTFlSDlIbzljeFAzWmt4cTJxc2RZYlNkS0phRnZ5eGlDeGQwRE8vOHphVjJoRzMxRStaSVFhTER0MHBORWtScEFaRHgrN1VpbWY5WHpyeXNJTENqQVx1MDAzZFx1MDAzZCJ9fX0.IvSNfIrsitDimWf9cfkCOnSEIYPxgU7o2LrUfdl026XqR7R_UM-SY24SwiOKaHuFFrggeeRQ8DLFhKGWcMiW1daadOxc_l1gY82U7Nerj6Y-9Wluz7Szdj_BmgplAqmAHrf2WvfQVTNnnbrID68cCw0K2fzPYT6ZKfFgGefYg86j6wF9FEeebSDm27l8d0_gB5JoPmDPkZPPLQzhIFByW294Ts1PeSxzLkhdP4dJ3ZvSK2BvNKzZQj8S-4aTB4C1O248cS8dFyUBxCjrCYld_XHOUi_76WkUZ2knAC8bVkXJTjIL3IRfQDs4k9Th50Qhma1-CnjAubTReK233zA0YA");
        //activKey.put("INDGRP","eyJhbGciOiJSUzI1NiJ9.eyJpc3MiOiJTQ0IiLCJhdWQiOiJTQ0ItQVBJQmFua2luZyIsImlhdCI6MTUwMjk0MTc5NywiZXhwIjozMDAwMDE1MDI5NDE3OTcsInBheWxvYWQiOnsiZW5hYmxlV2ViSG9vayI6InRydWUiLCJ3ZWJIb29rVXJsIjoiaHR0cDovLzE4LjIyMC4xNTYuMi93ZWJob29rIiwiYWN0aXZhdGlvbktleSI6eyJjb250ZW50IjoiZ2UyT2F5dWZNNnV2Z3ZZYzBWdkxlOTRTYmt5NzdveXJlenhSSzJpL3hocndkRitiQVZicldJcUNZeWFWYXpOZjRScWFlTkJhTkZNSW9BSGdZenhWTFYzdmRoNnVod2V3dGJHelpnNFo0RDVjd2dtZUtiZFpYd2tvOUNEMGE4S3F0TmRENDBVbkRVRU1NK0RZYVZtTlQ0c0dJMEI4K3pJZE0wVDFoVkE5NzdJVDYzYzJaYjNyR29EZGJZWG9xaGRmRWxLL2hJMU5NUDZzUXUzRWdXSlh5UEJjWnNrTkpoeDQ0WWkvV3BVSkNtaU5mcGliREJlWUllKzExNWEyTTJvZzdRcnlrQ0dVQ2RXdUwrYVlJYXlaT200eHgxZmFscUJvNE80NlVnaHp5bUNhN0pJc0lLN0pRMUdZK0RXbDRuN204V3NTVlRpOUVPaithTzlCT0dYeUtmZWdqRXNPcU8wZDlPVFlkbWpFRHNUWHlhWVlQV2JpcnpnYWcwcEJQVXdNaUZodFVOdE9ZSENSV3FVVDdEM1U5Qk81UDN2VmF4ajVjNHUxMHM1elRPR1BRd1d3S291QzBmS01sdldsTXByMDdJamd4djdlNDI5QkF6ZkdlVk1mekt4OGM4QUFWaWVXNndlQ2NYMVB2WlFOWE9FZTJHNmRpdzRyQ0lEQnpnRmwwdGpZVmRwUkhqZDJtWjRJakt1MklTMHE2bk9pNjRRYmVkQXNGckVMZUowYm5xZE9udGk5SnR5N3c0dk43ZWNuQUZVZTlGSHB6Vk9uMnAva0thSVQ3ZUxFUytkcVZ3Tk8vN3YyZkhsbnpyWlVWY3didXplbXdEek9HZXlCYUtCZnpSeVJERENGVFU4SkhueGtrZnArM25RNE5aOU9iQTVscHJWdis4VlhhdW5rWGcreGRRMGRiU3RkOXIzbTBwUjhkQVBOUGs5czFOYUtXRXdWUWpJVFZOelRvZTFlaWxobVpGRis0NEdMS0JFME1zaXI3WVZVV1pUbmtvcld2dzVHMjZkeU1DV3E0a2JwRUxkazczZjd5OU1ubDluM1phYzEwZ0pzcFNOcGJRWDBMTWd5MUwrdENyYlMrcnJRK0ZpZyIsImtleSI6IlpSU3IrSzVBcWR1QTZ3aVk2S21NSS9LTVE2d2NRem5HTzg1ZWJCVVZjdnlqOXZDVEpsRDdQdDNCdHlPUktPQ2grYnNLUi9iRVpBWlNqcG1OTzVlZ0JkRDBzZXdhNkRGaEpNQ0hENG1DS2hDT2RrQ2VreXlST2VtVHUycGx0cWNoNnUwc281a3F2TTBVYmVMcHF0RFRDZ3lKc3ZqdmVjTUNKK0MyZ1ZDZWJhc05lckVmZzM0UXN1ZUVSQlRiZlN6dFpMelVZRUtDaWI4Q2I4L0xtcFN3dFBxam5Nd1M1ckw5TkY2Q0kwS09vQVhtMXRCN0pUMFc1SXR1akNST3FJM2JGUTFlSDlIbzljeFAzWmt4cTJxc2RZYlNkS0phRnZ5eGlDeGQwRE8vOHphVjJoRzMxRStaSVFhTER0MHBORWtScEFaRHgrN1VpbWY5WHpyeXNJTENqQVx1MDAzZFx1MDAzZCJ9fX0.IvSNfIrsitDimWf9cfkCOnSEIYPxgU7o2LrUfdl026XqR7R_UM-SY24SwiOKaHuFFrggeeRQ8DLFhKGWcMiW1daadOxc_l1gY82U7Nerj6Y-9Wluz7Szdj_BmgplAqmAHrf2WvfQVTNnnbrID68cCw0K2fzPYT6ZKfFgGefYg86j6wF9FEeebSDm27l8d0_gB5JoPmDPkZPPLQzhIFByW294Ts1PeSxzLkhdP4dJ3ZvSK2BvNKzZQj8S-4aTB4C1O248cS8dFyUBxCjrCYld_XHOUi_76WkUZ2knAC8bVkXJTjIL3IRfQDs4k9Th50Qhma1-CnjAubTReK233zA0YA");
    }

    @Then("^token should be generated successfully$")
    public void token_should_be_generated_successfully() throws Throwable {
        System.out.println(token);
    }

    @Given("^user has valid SSL certificate$")
    public void user_has_valid_SSL_certificate() throws Throwable {
        //certificate = new Scanner(new File(".\\\\src\\\\test\\\\resources\\\\test-data\\\\certificate.txt")).useDelimiter("\\Z").next();
        certificate = new Scanner(new File("./src/test/resources/test-data/certificate.txt")).useDelimiter("\\Z").next();
    }

    @Given("^user has already generated the JWT token$")
    public void user_has_already_generated_the_JWT_token() throws Throwable {
        a_POST_request_is_made_to_the_activationKey_API();
        content_and_key_data_should_be_generated();
        generated_content_and_key_is_passed_to_the_create_token_method();
    }

    @Given("^user has already generated the JWT token for the group '(.+)'$")
    public void user_has_already_generated_the_JWT_token_for_the_group(String group) throws Throwable {
        a_POST_request_is_made_to_the_activationKey_API_for_Group(group);
        content_and_key_data_should_be_generated();
        generated_content_and_key_is_passed_to_the_create_token_method_for_the_group(group);
    }

    @When("^a POST request is made to akamai endpoint$")
    public void a_POST_request_is_made_to_akamai_endpoint() throws Throwable {
        //Configuration to add the token and certificate
        RestAssuredConfig.RestConfigAkamai();
        commonApiMethods commonApiMethods = new commonApiMethods();
        KeyStore keyStore = null;
        String token = null;
        try {
            token = new Scanner(new File("./src/test/resources/test-data/Token.txt")).useDelimiter("\\Z").next();
            keyStore = KeyStore.getInstance("PKCS12");
            keyStore.load(new FileInputStream("./src/test/resources/test-data/certificate.pfx"), "123456".toCharArray());
            org.apache.http.conn.ssl.SSLSocketFactory clientAuthFactory = null;
            clientAuthFactory = new org.apache.http.conn.ssl.SSLSocketFactory(keyStore, "123456");
            SSLConfig config = null;
            config = new SSLConfig().with().sslSocketFactory(clientAuthFactory).and().allowAllHostnames();
            RestAssured.config = RestAssured.config().sslConfig(config);
        } catch (Exception e) {
            e.printStackTrace();
        }

        //Hit the Post request with URL with the config and print the response
        response = given()
                .body(token)
                .when()
                .post(EndPoint.POST_ActivateUser)
                .thenReturn()
                .asString();

        validatableResponse = given()//.contentType(ContentType.TEXT)
                .body(token)
                .when()
                .post(EndPoint.POST_ActivateUser)
                .then();
        System.out.println(response);
    }

    @When("^a POST request is made to axway endpoint for the group '(.+)'$")
    public void a_POST_request_is_made_to_axway_endpoint(String group) throws Throwable {
        //Configuration to add the token and certificate
        RestAssuredConfig.RestConfig2();
        RestAssured.useRelaxedHTTPSValidation();
        commonApiMethods commonApiMethods = new commonApiMethods();
        KeyStore keyStore = null;
        String token = null;

        //token = new Scanner(new File("./src/test/resources/test-data/Token.txt")).useDelimiter("\\Z").next();
        token = activKey.get(group);

        //Hit the Post request with URL with the config and print the response
        response = given()
                .contentType(ContentType.TEXT)
                .header("X-Client-Certifcate","MIIFPDCCBCSgAwIBAgIQBhCY9/Oua9sbbZUiKb7/ETANBgkqhkiG9w0BAQsFADBlMQswCQYDVQQGEwJVUzEVMBMGA1UEChMMRGlnaUNlcnQgSW5jMRkwFwYDVQQLExB3d3cuZGlnaWNlcnQuY29tMSQwIgYDVQQDExtEaWdpQ2VydCBTSEEyIEFzc3VyZWQgSUQgQ0EwHhcNMTcwNTIzMDAwMDAwWhcNMTgwNTIzMTIwMDAwWjBXMQswCQYDVQQGEwJTRzESMBAGA1UEBxMJU2luZ2Fwb3JlMSAwHgYDVQQKExdTdGFuZGFyZCBDaGFydGVyZWQgQmFuazESMBAGA1UEAxMJQWNtZSBDb3JwMIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAx+79CIYpTbQdM93rnQe2y+gMCAZGKfwVuyT4xjYDmYfKr4+/6F2OUoVAP0wsS+EufaFOdwGRYD2Xcg8fH/jwp4dynekLNmO94et7pDBIQoHoyqUz5IfYIhbkwUV5zAjJEfrAlLXEfrBB+j8v6/DMWcYoFvXvq2mA/rZCr5S5L7RCKj17Tup6OpRasbohHADLwLx/gk/gaX7fAzV/4jETHw1zxRg9jT8WaPp+Qs3KeQlXqDEX6vpH12flHDl1dF+QfuKN5jlKG77yKsThglYwRTeaxrL3RgU8X6P8T1S5xpzGCIlE7RHFTpta1Hxn3oD59AvhQkQ8CkYyOWzt6GS6uQIDAQABo4IB9DCCAfAwHwYDVR0jBBgwFoAU5wIjgABP2Ne8lAvZP3Q5STI8inkwHQYDVR0OBBYEFIzxOlIwI/C/ktPcOkYtZA1XWTKrMAwGA1UdEwEB/wQCMAAwJgYDVR0RBB8wHYEbcHJhc2FubmEua2FuYWdhc2FiYWlAc2MuY29tMA4GA1UdDwEB/wQEAwIFoDAdBgNVHSUEFjAUBggrBgEFBQcDAgYIKwYBBQUHAwQwQwYDVR0gBDwwOjA4BgpghkgBhv1sBAECMCowKAYIKwYBBQUHAgEWHGh0dHBzOi8vd3d3LmRpZ2ljZXJ0LmNvbS9DUFMwgYgGA1UdHwSBgDB+MD2gO6A5hjdodHRwOi8vY3JsMy5kaWdpY2VydC5jb20vRGlnaUNlcnRTSEEyQXNzdXJlZElEQ0EtZzIuY3JsMD2gO6A5hjdodHRwOi8vY3JsNC5kaWdpY2VydC5jb20vRGlnaUNlcnRTSEEyQXNzdXJlZElEQ0EtZzIuY3JsMHkGCCsGAQUFBwEBBG0wazAkBggrBgEFBQcwAYYYaHR0cDovL29jc3AuZGlnaWNlcnQuY29tMEMGCCsGAQUFBzAChjdodHRwOi8vY2FjZXJ0cy5kaWdpY2VydC5jb20vRGlnaUNlcnRTSEEyQXNzdXJlZElEQ0EuY3J0MA0GCSqGSIb3DQEBCwUAA4IBAQCuOYPuakKB9qCCR7JYaA+92BprzqYFd1LwT62FrdzcPGupHix7ALoiw2jHuMQogrc3Rw0wZPUqgN29b2bcXX8r9B8OMVbxYL6VZGJ8P+WndUPOzbWdl7eAY/9HbkAUgcqzSP+BBcndCyKdR+bs43dYDNvhDzqL7hHgqjmxFxVz8C/25oLmBZ0yOXz5yLpVoTyHBl1OfAkrYj5WeQI8/uiR9bJ4SwY/NvUU+sOB/UJsxECjpmmdS26dYMRyLuFT7hZvmgv8L2wcjO6vyA9qm3kNb0dTJw1/xQG56pdaGRhdVEqp/L3/hW0COgQvOVdRNlVH9dU8cCl57ICj9rtxTrqg")
                .body(token)
                .when()
                //.post("https://uklvadapp006:8080/cib/v1/activate")
                .post(EndPoint.POST_ActivateUser)
                .thenReturn()
                .asString();

        validatableResponse = given()
                .contentType(ContentType.TEXT)
                .header("X-Client-Certifcate","MIIFPDCCBCSgAwIBAgIQBhCY9/Oua9sbbZUiKb7/ETANBgkqhkiG9w0BAQsFADBlMQswCQYDVQQGEwJVUzEVMBMGA1UEChMMRGlnaUNlcnQgSW5jMRkwFwYDVQQLExB3d3cuZGlnaWNlcnQuY29tMSQwIgYDVQQDExtEaWdpQ2VydCBTSEEyIEFzc3VyZWQgSUQgQ0EwHhcNMTcwNTIzMDAwMDAwWhcNMTgwNTIzMTIwMDAwWjBXMQswCQYDVQQGEwJTRzESMBAGA1UEBxMJU2luZ2Fwb3JlMSAwHgYDVQQKExdTdGFuZGFyZCBDaGFydGVyZWQgQmFuazESMBAGA1UEAxMJQWNtZSBDb3JwMIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAx+79CIYpTbQdM93rnQe2y+gMCAZGKfwVuyT4xjYDmYfKr4+/6F2OUoVAP0wsS+EufaFOdwGRYD2Xcg8fH/jwp4dynekLNmO94et7pDBIQoHoyqUz5IfYIhbkwUV5zAjJEfrAlLXEfrBB+j8v6/DMWcYoFvXvq2mA/rZCr5S5L7RCKj17Tup6OpRasbohHADLwLx/gk/gaX7fAzV/4jETHw1zxRg9jT8WaPp+Qs3KeQlXqDEX6vpH12flHDl1dF+QfuKN5jlKG77yKsThglYwRTeaxrL3RgU8X6P8T1S5xpzGCIlE7RHFTpta1Hxn3oD59AvhQkQ8CkYyOWzt6GS6uQIDAQABo4IB9DCCAfAwHwYDVR0jBBgwFoAU5wIjgABP2Ne8lAvZP3Q5STI8inkwHQYDVR0OBBYEFIzxOlIwI/C/ktPcOkYtZA1XWTKrMAwGA1UdEwEB/wQCMAAwJgYDVR0RBB8wHYEbcHJhc2FubmEua2FuYWdhc2FiYWlAc2MuY29tMA4GA1UdDwEB/wQEAwIFoDAdBgNVHSUEFjAUBggrBgEFBQcDAgYIKwYBBQUHAwQwQwYDVR0gBDwwOjA4BgpghkgBhv1sBAECMCowKAYIKwYBBQUHAgEWHGh0dHBzOi8vd3d3LmRpZ2ljZXJ0LmNvbS9DUFMwgYgGA1UdHwSBgDB+MD2gO6A5hjdodHRwOi8vY3JsMy5kaWdpY2VydC5jb20vRGlnaUNlcnRTSEEyQXNzdXJlZElEQ0EtZzIuY3JsMD2gO6A5hjdodHRwOi8vY3JsNC5kaWdpY2VydC5jb20vRGlnaUNlcnRTSEEyQXNzdXJlZElEQ0EtZzIuY3JsMHkGCCsGAQUFBwEBBG0wazAkBggrBgEFBQcwAYYYaHR0cDovL29jc3AuZGlnaWNlcnQuY29tMEMGCCsGAQUFBzAChjdodHRwOi8vY2FjZXJ0cy5kaWdpY2VydC5jb20vRGlnaUNlcnRTSEEyQXNzdXJlZElEQ0EuY3J0MA0GCSqGSIb3DQEBCwUAA4IBAQCuOYPuakKB9qCCR7JYaA+92BprzqYFd1LwT62FrdzcPGupHix7ALoiw2jHuMQogrc3Rw0wZPUqgN29b2bcXX8r9B8OMVbxYL6VZGJ8P+WndUPOzbWdl7eAY/9HbkAUgcqzSP+BBcndCyKdR+bs43dYDNvhDzqL7hHgqjmxFxVz8C/25oLmBZ0yOXz5yLpVoTyHBl1OfAkrYj5WeQI8/uiR9bJ4SwY/NvUU+sOB/UJsxECjpmmdS26dYMRyLuFT7hZvmgv8L2wcjO6vyA9qm3kNb0dTJw1/xQG56pdaGRhdVEqp/L3/hW0COgQvOVdRNlVH9dU8cCl57ICj9rtxTrqg")
                .body(token)
                .when()
                .post(EndPoint.POST_ActivateUser)
                .then();
        System.out.println(response);
    }



    @When("^a POST request is made to axway endpoint with the token '(.*)'$")
    public void a_POST_request_is_made_to_axway_withToken(String token) throws Throwable {
        //Configuration to add the token and certificate
        RestAssuredConfig.RestConfig2();
        RestAssured.useRelaxedHTTPSValidation();
        commonApiMethods commonApiMethods = new commonApiMethods();
        KeyStore keyStore = null;

        //Hit the Post request with URL with the config and print the response
        response = given()
                .contentType(ContentType.TEXT)
                .header("X-Client-Certifcate","MIIFPDCCBCSgAwIBAgIQBhCY9/Oua9sbbZUiKb7/ETANBgkqhkiG9w0BAQsFADBlMQswCQYDVQQGEwJVUzEVMBMGA1UEChMMRGlnaUNlcnQgSW5jMRkwFwYDVQQLExB3d3cuZGlnaWNlcnQuY29tMSQwIgYDVQQDExtEaWdpQ2VydCBTSEEyIEFzc3VyZWQgSUQgQ0EwHhcNMTcwNTIzMDAwMDAwWhcNMTgwNTIzMTIwMDAwWjBXMQswCQYDVQQGEwJTRzESMBAGA1UEBxMJU2luZ2Fwb3JlMSAwHgYDVQQKExdTdGFuZGFyZCBDaGFydGVyZWQgQmFuazESMBAGA1UEAxMJQWNtZSBDb3JwMIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAx+79CIYpTbQdM93rnQe2y+gMCAZGKfwVuyT4xjYDmYfKr4+/6F2OUoVAP0wsS+EufaFOdwGRYD2Xcg8fH/jwp4dynekLNmO94et7pDBIQoHoyqUz5IfYIhbkwUV5zAjJEfrAlLXEfrBB+j8v6/DMWcYoFvXvq2mA/rZCr5S5L7RCKj17Tup6OpRasbohHADLwLx/gk/gaX7fAzV/4jETHw1zxRg9jT8WaPp+Qs3KeQlXqDEX6vpH12flHDl1dF+QfuKN5jlKG77yKsThglYwRTeaxrL3RgU8X6P8T1S5xpzGCIlE7RHFTpta1Hxn3oD59AvhQkQ8CkYyOWzt6GS6uQIDAQABo4IB9DCCAfAwHwYDVR0jBBgwFoAU5wIjgABP2Ne8lAvZP3Q5STI8inkwHQYDVR0OBBYEFIzxOlIwI/C/ktPcOkYtZA1XWTKrMAwGA1UdEwEB/wQCMAAwJgYDVR0RBB8wHYEbcHJhc2FubmEua2FuYWdhc2FiYWlAc2MuY29tMA4GA1UdDwEB/wQEAwIFoDAdBgNVHSUEFjAUBggrBgEFBQcDAgYIKwYBBQUHAwQwQwYDVR0gBDwwOjA4BgpghkgBhv1sBAECMCowKAYIKwYBBQUHAgEWHGh0dHBzOi8vd3d3LmRpZ2ljZXJ0LmNvbS9DUFMwgYgGA1UdHwSBgDB+MD2gO6A5hjdodHRwOi8vY3JsMy5kaWdpY2VydC5jb20vRGlnaUNlcnRTSEEyQXNzdXJlZElEQ0EtZzIuY3JsMD2gO6A5hjdodHRwOi8vY3JsNC5kaWdpY2VydC5jb20vRGlnaUNlcnRTSEEyQXNzdXJlZElEQ0EtZzIuY3JsMHkGCCsGAQUFBwEBBG0wazAkBggrBgEFBQcwAYYYaHR0cDovL29jc3AuZGlnaWNlcnQuY29tMEMGCCsGAQUFBzAChjdodHRwOi8vY2FjZXJ0cy5kaWdpY2VydC5jb20vRGlnaUNlcnRTSEEyQXNzdXJlZElEQ0EuY3J0MA0GCSqGSIb3DQEBCwUAA4IBAQCuOYPuakKB9qCCR7JYaA+92BprzqYFd1LwT62FrdzcPGupHix7ALoiw2jHuMQogrc3Rw0wZPUqgN29b2bcXX8r9B8OMVbxYL6VZGJ8P+WndUPOzbWdl7eAY/9HbkAUgcqzSP+BBcndCyKdR+bs43dYDNvhDzqL7hHgqjmxFxVz8C/25oLmBZ0yOXz5yLpVoTyHBl1OfAkrYj5WeQI8/uiR9bJ4SwY/NvUU+sOB/UJsxECjpmmdS26dYMRyLuFT7hZvmgv8L2wcjO6vyA9qm3kNb0dTJw1/xQG56pdaGRhdVEqp/L3/hW0COgQvOVdRNlVH9dU8cCl57ICj9rtxTrqg")
                .body(token)
                .when()
                        //.post("https://uklvadapp006:8080/cib/v1/activate")
                .post(EndPoint.POST_ActivateUser)
                .thenReturn()
                .asString();

        statusCode = given()
                .contentType(ContentType.TEXT)
                .header("X-Client-Certifcate","MIIFPDCCBCSgAwIBAgIQBhCY9/Oua9sbbZUiKb7/ETANBgkqhkiG9w0BAQsFADBlMQswCQYDVQQGEwJVUzEVMBMGA1UEChMMRGlnaUNlcnQgSW5jMRkwFwYDVQQLExB3d3cuZGlnaWNlcnQuY29tMSQwIgYDVQQDExtEaWdpQ2VydCBTSEEyIEFzc3VyZWQgSUQgQ0EwHhcNMTcwNTIzMDAwMDAwWhcNMTgwNTIzMTIwMDAwWjBXMQswCQYDVQQGEwJTRzESMBAGA1UEBxMJU2luZ2Fwb3JlMSAwHgYDVQQKExdTdGFuZGFyZCBDaGFydGVyZWQgQmFuazESMBAGA1UEAxMJQWNtZSBDb3JwMIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAx+79CIYpTbQdM93rnQe2y+gMCAZGKfwVuyT4xjYDmYfKr4+/6F2OUoVAP0wsS+EufaFOdwGRYD2Xcg8fH/jwp4dynekLNmO94et7pDBIQoHoyqUz5IfYIhbkwUV5zAjJEfrAlLXEfrBB+j8v6/DMWcYoFvXvq2mA/rZCr5S5L7RCKj17Tup6OpRasbohHADLwLx/gk/gaX7fAzV/4jETHw1zxRg9jT8WaPp+Qs3KeQlXqDEX6vpH12flHDl1dF+QfuKN5jlKG77yKsThglYwRTeaxrL3RgU8X6P8T1S5xpzGCIlE7RHFTpta1Hxn3oD59AvhQkQ8CkYyOWzt6GS6uQIDAQABo4IB9DCCAfAwHwYDVR0jBBgwFoAU5wIjgABP2Ne8lAvZP3Q5STI8inkwHQYDVR0OBBYEFIzxOlIwI/C/ktPcOkYtZA1XWTKrMAwGA1UdEwEB/wQCMAAwJgYDVR0RBB8wHYEbcHJhc2FubmEua2FuYWdhc2FiYWlAc2MuY29tMA4GA1UdDwEB/wQEAwIFoDAdBgNVHSUEFjAUBggrBgEFBQcDAgYIKwYBBQUHAwQwQwYDVR0gBDwwOjA4BgpghkgBhv1sBAECMCowKAYIKwYBBQUHAgEWHGh0dHBzOi8vd3d3LmRpZ2ljZXJ0LmNvbS9DUFMwgYgGA1UdHwSBgDB+MD2gO6A5hjdodHRwOi8vY3JsMy5kaWdpY2VydC5jb20vRGlnaUNlcnRTSEEyQXNzdXJlZElEQ0EtZzIuY3JsMD2gO6A5hjdodHRwOi8vY3JsNC5kaWdpY2VydC5jb20vRGlnaUNlcnRTSEEyQXNzdXJlZElEQ0EtZzIuY3JsMHkGCCsGAQUFBwEBBG0wazAkBggrBgEFBQcwAYYYaHR0cDovL29jc3AuZGlnaWNlcnQuY29tMEMGCCsGAQUFBzAChjdodHRwOi8vY2FjZXJ0cy5kaWdpY2VydC5jb20vRGlnaUNlcnRTSEEyQXNzdXJlZElEQ0EuY3J0MA0GCSqGSIb3DQEBCwUAA4IBAQCuOYPuakKB9qCCR7JYaA+92BprzqYFd1LwT62FrdzcPGupHix7ALoiw2jHuMQogrc3Rw0wZPUqgN29b2bcXX8r9B8OMVbxYL6VZGJ8P+WndUPOzbWdl7eAY/9HbkAUgcqzSP+BBcndCyKdR+bs43dYDNvhDzqL7hHgqjmxFxVz8C/25oLmBZ0yOXz5yLpVoTyHBl1OfAkrYj5WeQI8/uiR9bJ4SwY/NvUU+sOB/UJsxECjpmmdS26dYMRyLuFT7hZvmgv8L2wcjO6vyA9qm3kNb0dTJw1/xQG56pdaGRhdVEqp/L3/hW0COgQvOVdRNlVH9dU8cCl57ICj9rtxTrqg")
                .body(token)
                .when()
                .post(EndPoint.POST_ActivateUser)
                .statusCode();
        System.out.println(response);
    }

    @Then("^user should be registered successfully$")
    public void user_should_be_registered_successfully() throws Throwable {
        System.out.println("");
        System.out.println("response: " + response);
    }

    @Then("^the response should be displayed as 400 error$")
    public void verify400ResponseError(){

        Assert.assertTrue("", statusCode == 400);
        Assert.assertTrue("",response.contains("\"status\":500,\"error\":\"Internal Server Error\",\"exception\":"));
    }

}


