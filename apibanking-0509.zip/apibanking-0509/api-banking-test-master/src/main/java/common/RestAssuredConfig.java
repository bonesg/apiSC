/**
 * 
 */
package common;


import io.restassured.RestAssured;
import io.restassured.config.SSLConfig;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.security.*;
import java.security.cert.CertificateException;
import java.util.HashMap;

//import src.test.java.ab.common.EndPoint;

import java.util.Scanner;

/**
 * @author 1556780
 * RestAssured Configurations
 */
public class RestAssuredConfig {
	static String password="";
	public static String env = null;
    public static HashMap<String,String> webhookURL  = new HashMap<String,String>();

	public static void RestConfig(){

		//Activation Key and JWT generation
		//RestAssured.baseURI = "http://10.23.210.59";
        webhookURL.put("INDGROUP", common.EndPoint.POST_WEBHOOKURL_INDGROUP);
        webhookURL.put("INDGRP",common.EndPoint.POST_WEBHOOKURL_INDGRP);
        webhookURL.put("INDTEST", EndPoint.POST_WEBHOOKURL_INDTEST);
        webhookURL.put("INRCMS02",common.EndPoint.POST_WEBHOOKURL_INCRMS02_);
       //RestAssured.baseURI = common.EndPoint.CREATE_ACTIVATION_KEY_URL;
        //RestAssured.baseURI = "http://uklvadapp007";
		//RestAssured.baseURI = "https://apitest.standardchartered.com";
		//env = RestAssured.baseURI;
		//RestAssured.port = 8080;
        //RestAssured.port = 8080;
		//RestAssured.basePath = "/api";
	}

	public static void RestConfig2(){
		//User registration
        RestAssured.baseURI = common.EndPoint.ACTIVATE_URL;
		env = RestAssured.baseURI;
		RestAssured.basePath = "/cib/v1";
	}

    public static void RestConfigAkamai() {
        //Configuration with token in pfx format and certificate
        RestAssured.baseURI = "https://apitest.standardchartered.com";
        RestAssured.port = 443;
        RestAssured.basePath = "/cib/api/v1";

    }

	public static void RestConfig3() {

		//RestAssured.config().sslConfig( new SSLConfig().relaxedHTTPSValidation());
		RestAssured.baseURI = "https://apitest.standardchartered.com";
//		RestAssured.baseURI = "https://sit.sc.com";
		RestAssured.port = 443;
		//RestAssured.basePath = "/cib/api/v1";
		//RestAssured.basePath = "/api/v1";
		RestAssured.basePath = "/cib/api";

		//https://apitest.standardchartered.com/cib/api/v1

		//reading
		KeyStore keyStore = null;
		SSLConfig config = null;

		//char[] password = "abc12345".toCharArray();
		char[] password = "123456".toCharArray();
		FileInputStream fIn = null;
		try {
			//fIn = new FileInputStream(".\\\\src\\\\test\\\\resources\\\\mykeystore");
			fIn = new FileInputStream("./src/test/resources/Test.jks");
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}
		try {
			keyStore = KeyStore.getInstance(KeyStore.getDefaultType());
		} catch (KeyStoreException e) {
			e.printStackTrace();
		}
		try {
			keyStore.load(fIn, password);
		} catch (IOException e) {
			e.printStackTrace();
		} catch (NoSuchAlgorithmException e) {
			e.printStackTrace();
		} catch (CertificateException e) {
			e.printStackTrace();
		}
		if (keyStore != null) {

			org.apache.http.conn.ssl.SSLSocketFactory clientAuthFactory = null;
			try {
				clientAuthFactory = new org.apache.http.conn.ssl.SSLSocketFactory(keyStore, String.valueOf(password));
			} catch (NoSuchAlgorithmException e) {
				e.printStackTrace();
			} catch (KeyManagementException e) {
				e.printStackTrace();
			} catch (KeyStoreException e) {
				e.printStackTrace();
			} catch (UnrecoverableKeyException e) {
				e.printStackTrace();
			}
			// set the config in rest assured
			config = new SSLConfig().with().sslSocketFactory(clientAuthFactory).and().allowAllHostnames();
			RestAssured.config = RestAssured.config().sslConfig(config);
		}
	}
}
