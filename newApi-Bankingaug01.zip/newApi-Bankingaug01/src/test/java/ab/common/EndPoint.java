package ab.common;

/**
 * @author 1556780
 * This interface contains research portal API end-points
 */
public interface EndPoint {
	String POST_CreateActivationKey = "/createActivationKey";
	String POST_ActivateUser = "/activate";
}
