package ab.api.tests;

import com.standardchartered.genie.junit.Genie;
import cucumber.api.CucumberOptions;
import cucumber.api.junit.Cucumber;
import org.junit.runner.RunWith;

@RunWith(Genie.class)
@CucumberOptions(
        features = {"classpath:features"},
        glue = {
        "classpath:ab.glue",
        },
        tags = {"@genie","~@ignore"},
        //format = {"pretty","html:target/CucumberReports"},
        strict = true
)
public class apiTest {

}
