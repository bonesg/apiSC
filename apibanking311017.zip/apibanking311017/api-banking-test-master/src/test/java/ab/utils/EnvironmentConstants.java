package ab.utils;

/**
 * Created by 1571168 on 8/24/2017.
 */
public class EnvironmentConstants {

    protected String INDIGO_WebhookURL = "";
}
