package common;

import com.google.gson.*;
import net.oauth.jsontoken.JsonToken;
import net.oauth.jsontoken.crypto.RsaSHA256Signer;
import org.joda.time.Instant;

import java.lang.reflect.Type;
import java.security.InvalidKeyException;
import java.security.PrivateKey;
import java.security.SignatureException;
import java.security.interfaces.RSAPrivateKey;
import java.time.LocalDate;

import static java.lang.System.currentTimeMillis;
import static org.joda.time.Instant.now;

public class JWT {

    private static final String ISSUER = "SCB";

    private static final String AUDIENCE = "SCB-APIBanking";

    private static final long TOKEN_TIMEOUT_DURATION = 1000L * 30L;

    private JWT() {
    }

    public static <T> String createToken(long timeout, T payload, PrivateKey privateKey) throws SignatureException, InvalidKeyException {

        RsaSHA256Signer signer;
        signer = new RsaSHA256Signer(ISSUER, null, (RSAPrivateKey) privateKey);

        //Configure JSON token
        JsonToken token = new JsonToken(signer);

        token.setAudience(AUDIENCE);

        token.setIssuedAt(now());
        token.setExpiration(new Instant(currentTimeMillis() + (timeout * 1000L)));

        //Configure request object, which provides information of the item
        JsonObject payloadO = token.getPayloadAsJsonObject();
        payloadO.add("payload", new Gson().toJsonTree(payload));
        return token.serializeAndSign();

    }

   // public static <T> String createTokenS(long timeout, JWTTokenPrototype tokenPrototype) {
//        GsonBuilder builder = new GsonBuilder();
//        Gson gson = Converters.registerAll(builder)
//                .registerTypeHierarchyAdapter(java.time.Instant.class,new Java8_InstantConverter())
//                .registerTypeHierarchyAdapter(LocalDate.class, new Java8_LocalDateConverter())
//        .create();
//
//
//        RsaSHA256Signer signer;
//        try {
//
//            signer = new RsaSHA256Signer(tokenPrototype.getIssuer(), null, (RSAPrivateKey) tokenPrototype.getPrivateKey());
//
//            //Configure JSON token
//            JsonToken token = new JsonToken(signer);
//
//            long issueTime = currentTimeMillis() ;
//            String JTI_KEY = "jti";
//            token.setParam(JTI_KEY, tokenPrototype.getMessageId());
//            token.setAudience(AUDIENCE);
//            token.setIssuedAt(new Instant(issueTime));
//            token.setExpiration(new Instant(issueTime + (timeout *1000L)));
//
//            //Configure request object, which provides information of the item
//            JsonObject payloadO = token.getPayloadAsJsonObject();
//            payloadO.add("payload", gson.toJsonTree(tokenPrototype.getPayload()));
//            return token.serializeAndSign();
//
//        } catch (SignatureException | InvalidKeyException e) {
//            throw new RuntimeException(e);
//        }
   // }


    private static class InstantTypeConverter
            implements JsonSerializer<Instant>, JsonDeserializer<Instant> {
        @Override
        public JsonElement serialize(Instant src, Type srcType, JsonSerializationContext context) {
            return new JsonPrimitive(src.getMillis());
        }

        @Override
        public Instant deserialize(JsonElement json, Type type, JsonDeserializationContext context)
                throws JsonParseException {
            return new Instant(json.getAsLong());
        }
    }

    private static  class Java8_InstantConverter implements JsonSerializer<java.time.Instant>, JsonDeserializer<java.time.Instant> {
        public Java8_InstantConverter() {
        }

        public JsonElement serialize(java.time.Instant src, Type typeOfSrc, JsonSerializationContext context) {
            return new JsonPrimitive(src.getEpochSecond());
        }

        public java.time.Instant deserialize(JsonElement json, Type typeOfT, JsonDeserializationContext context) throws JsonParseException {
            return json.getAsString() != null && !json.getAsString().isEmpty()? java.time.Instant.parse(json.getAsString()):null;
        }
    }

    private static  class Java8_LocalDateConverter implements JsonSerializer<LocalDate>, JsonDeserializer<LocalDate> {
        public Java8_LocalDateConverter() {
        }

        public JsonElement serialize(LocalDate src, Type typeOfSrc, JsonSerializationContext context) {
            return new JsonPrimitive(src.format(java.time.format.DateTimeFormatter.ISO_DATE));
        }

        public LocalDate deserialize(JsonElement json, Type typeOfT, JsonDeserializationContext context) throws JsonParseException {
            return json.getAsString() != null && !json.getAsString().isEmpty()? LocalDate.parse(json.getAsString()):null;
        }
    }
}
