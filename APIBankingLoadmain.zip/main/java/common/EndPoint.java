package common;

import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;

/**
 * @author 1556780
 * This interface contains research portal API end-points
 */
public interface EndPoint {
	String POST_CreateActivationKey = "/uaasv2/services/jwt/createActivationKey";
	String POST_ActivateUser = "/activate";
    String POST_WEBHOOKURL_INDGROUP = "";
    String POST_WEBHOOKURL_INDGRP = "http://10.23.210.59:8443/webhook";
    String POST_WEBHOOKURL_INDTEST = "http://10.64.224.19:8443/webhook10.64.224.19:8443/webhook10.64.224.19:8443/webhook10.64.224.19:8443/webhook10.64.224.19:8443/webhook10.64.224.19:8443/webhook10.64.224.19:8443/webhook10.64.224.19:8443/webhook10.64.224.19:8443/webhook10.64.224.19:8443/webjkk";
    String POST_WEBHOOKURL_INCRMS02_ = "";
    String POST_WEBHOOKURL_INDGRP1 = "http://10.23.210.60:8443/webhook";
    //String POST_WEBHOOKURL_INDSEGSE = "http://18.220.156.2/webhook";
    String POST_WEBHOOKURL_INDSEGSE = "http://10.23.210.60:8443/webhook";
    String CADM_URL ="https://10.20.166.89:2606";
    String PULL_API_URL ="https://apitest.standardchartered.com/core/event/" ;
    String  CREATE_ACTIVATION_KEY_URL= "https://10.20.164.88:443";
   // String  CREATE_ACTIVATION_KEY_URL="https://starsecwb.standardchartered.com";
    //String  CREATE_ACTIVATION_KEY_URL_CSRSIGN= "https://starsecwb.standardchartered.com/uaasv2/services/jwt/signCsr";
    String  CREATE_ACTIVATION_KEY_URL_CSRSIGN= "https://10.20.164.88:443/uaasv2/services/jwt/signCsr";
    //String  CREATE_ACTIVATION_KEY_URL= "http://10.20.167.163";
    String ACTIVATE_URL = "https://apitest.standardchartered.com";
   // String ACTIVATE_URL = "http://23.202.248.7";
     String WEBHOOK_URL = "";
    String WEBHOOKSTARTURL = "";
    String WEBHOOKSTOPURL = "";
    String WEBHOOKSTATUSURL = "";

    String inimegURL =  "https://10.23.210.60:9012/api-banking/inimeg/transaction/generic/";
    @Data(name = "https://10.23.210.60:9012/api-banking/inimeg/transaction/generic/")
    String issueBCBalance = null;

    @Data(name = "https://10.23.210.60:9012/api-banking/inimeg/transaction/generic/")
    String redeemBCBalance = null;

    @Data(name = "https://10.23.210.60:9012/api-banking/inimeg/transaction/generic/")
    String manageTrustline = null;

    @Data(name = "https://apitest.standardchartered.com/openapi/custody/holding")
    String CustodyHolding = null;

    @Data(name = "https://apitest.standardchartered.com/openapi/custody/transaction")
    String CustodyTransactionStatus = null;

    String ACCOUNTBALANCEOPENAPIURL = "https://apitest.standardchartered.com/openapi/account/";
//    @Data(name = "https://10.23.210.60:9012/api-banking/openapi/custody/holding")
//    String CustodyHolding = null;

    String directCustodyOauthURL = "https://10.20.166.35:5101/Authorization?client_id=e6066840d54f18f8bf51c44387f22711&response_type=code";
    String directCustodyHoldingsURL ="https://10.20.166.35:5101/rest/API_TM_Services.Services.corporate.custody.v1.customers.holdings";
    //String ACTIVATE_URL = "http://10.128.55.216/uaasv2/services/jwt";
    String WEBHOOK_MESSAGE = "[ { \"groupId\": \"INDGROUP\", \"transactionIdentifier\": { \"type\": \"Other\", \"identifier\": \"a2c198e9-3ac8-412b-b5ba-65c4756f4076\" },\"creditDate\": \"2015-11-16\", \"accountIdentifier\": { \"accountId\": \"17082017\", \"currencyCode\": { \"isoCode\": \"INR\" }, \"bankCode\": \"SCBLINBBXXX\" }, \"debitDate\": \"2015-11-16\", \"adviceType\": \"Credit\", \"transactionCode\": \"002\", \"transactionDescription\": \"UPI PAY - SCB Acct to Bene Acct SCB & Non-SCB - DR\", \"postExecutionBalance\": { \"currencyCode\": \"INR\", \"amount\": 99803990 }, \"preExecutionBalance\": { \"currencyCode\": \"INR\", \"amount\": 99809590 }, \"transactionFreeText\": [ \"UPI/715615346607/\", \"UPI CYCLE 2/SIVAAACHEN@SCBL/\", \"75110011017/EMAILSLOWNESS/\", \"123-13123-13123\" ], \"transactionAmount\": { \"currencyCode\": \"INR\", \"amount\": 5600 }, \"clientIdentifier\": { \"type\": \"Other\", \"identifier\": \"\" }, \"externalIdentifier\": { \"type\": \"Other\", \"identifier\": \"\" } } ]";
    String WEBHOOK_EBBS_MESSAGE = "[ { \"groupId\": \"INDGROUP\", \"transactionIdentifier\": { \"type\": \"Other\", \"identifier\": \"a2c198e9-3ac8-412b-b5ba-65c4756f4076\" },\"creditDate\": \"2015-11-16\", \"accountIdentifier\": { \"accountId\": \"17082017\", \"currencyCode\": { \"isoCode\": \"INR\" }, \"bankCode\": \"SCBLINBBXXX\" }, \"debitDate\": \"2015-11-16\", \"adviceType\": \"Credit\", \"transactionCode\": \"002\", \"transactionDescription\": \"UPI PAY - SCB Acct to Bene Acct SCB & Non-SCB - DR\", \"postExecutionBalance\": { \"currencyCode\": \"INR\", \"amount\": 99803990 }, \"preExecutionBalance\": { \"currencyCode\": \"INR\", \"amount\": 99809590 }, \"transactionFreeText\": [\"CASHDEPOSIT\",\"2015-11-16100SUPPORTM1551\",\"22205269504\", \"75110011017/EMAILSLOWNESS/\", \"123-13123-13123\" ], \"transactionAmount\": { \"currencyCode\": \"INR\", \"amount\": 5600 }, \"clientIdentifier\": { \"type\": \"Other\", \"identifier\": \"\" }, \"externalIdentifier\": { \"type\": \"Other\", \"identifier\": \"\" } } ]";

//    @Data(name = "https://10.23.210.59:9025/api-banking/openapi/payment/initiate")
//    String OpenAPIPaymentInitiation = null;

    @Data(name = ACTIVATE_URL+"/openapi/payment/initiate")
    String OpenAPIPaymentInitiation = null;

    @Data(name = ACTIVATE_URL+"/openapi/paynow/payment/initiate")
    String OpenAPIPayNow = null;

    @Data(name = ACTIVATE_URL+"/openapi/payment/status")
    String OpenAPIPaymentStatusEnquiry = null;

    @Data(name = ACTIVATE_URL+"/core/event/peek")
    String Peek = null;

    @Data(name = ACTIVATE_URL+"/core/event/consume")
    String Consume = null;

    @Data(name = ACTIVATE_URL+"/core/event/recover")
    String Recover = null;

    @Data(name = ACTIVATE_URL+"/core/event/statistics")
    String Statistics = null;

    @Data(name = ACTIVATE_URL+"/openapi/payment/template/save")
    String PaymentTemplate = null;

    @Retention(RetentionPolicy.RUNTIME)
    public @interface Data {
        String name();
    }
}
