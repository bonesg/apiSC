package ab.api.tests;

import ab.common.JWTTest;
import ab.glue.api.NewStub;
import ab.glue.api.activationKey;
import ab.glue.api.commonApiMethods;
import com.fasterxml.jackson.dataformat.xml.XmlMapper;
import common.EncryptDecrypt;
import io.restassured.RestAssured;
import io.restassured.config.SSLConfig;
import io.restassured.http.ContentType;
import io.restassured.response.Response;
import io.restassured.specification.ProxySpecification;
import org.junit.Test;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import java.io.*;
import java.security.*;
import java.security.spec.InvalidKeySpecException;
import java.sql.*;
import java.util.Base64;

import static io.restassured.RestAssured.given;
import static org.joda.time.Instant.now;
/**
 * Created by 1571168 on 7/31/2017.
 */
public class PeekAndConsumeTest {
    /**
     * The test will verify whether Peek API returns a successful response
     */
    @Test
    public void peekTest(){
        RestAssured.useRelaxedHTTPSValidation();
        Response data = given()
                //.proxy("10.23.210.60", 8080)
                .header("GroupId","APIMS1")
                .header("Content-Type","text/plain")
                //.header("responseTransactionType","Custody")
                .contentType(ContentType.TEXT)
                .when()
                .get("https://10.23.210.59:9012/api-banking/core/event/peek");
        String data1=  data.thenReturn().asString();
        System.out.println("Peek Value "+ data1.toString());
        System.out.println("status is "+data.getStatusCode());
    }

//    @Test
    public void getXml() throws IOException {
        File file = new File("simple_bean.xml");
        XmlMapper xmlMapper = new XmlMapper();
        String xml = inputStreamToString(getClass().getResourceAsStream("/rta-templateimps.xml"));
        PeekAndConsumeTest value = xmlMapper.readValue(xml, PeekAndConsumeTest.class);
    }
    public static String inputStreamToString(InputStream is) throws IOException {
        StringBuilder sb = new StringBuilder();
        String line;
        BufferedReader br = new BufferedReader(new InputStreamReader(is));
        while ((line = br.readLine()) != null) {
            sb.append(line);
        }
        br.close();
        return sb.toString();
    }

    /**
     * The test will verify whether Consume API returns a successful response
     */
//    @Test
//    public void consumeTest(){
//        final String data = given()
//                .proxy("10.23.210.60", 8080)
//                //.contentType(ContentType.TEXT)
//                .when().header("GroupId","INRCMS02")
//                .get("https://10.23.210.60:9012/api/core/event/consume")
//                .thenReturn()
//                .asString();
//        System.out.println("Consume Value "+data);
//    }

    @Test
    public void accountBalanceTest() throws IOException, ParserConfigurationException {
        RestAssured.useRelaxedHTTPSValidation();
        String filepath = new File(".").getCanonicalPath() + "/src/test/resources/test-data/UPI_AccountBalanceEnquiry.xml";
        DocumentBuilderFactory docFactory = DocumentBuilderFactory.newInstance();
        DocumentBuilder docBuilder = docFactory.newDocumentBuilder();
        NewStub newStub = new NewStub();
        String request = newStub.readFile(filepath);
        System.out.println("The request is "+request);
        Response data = given()
                .header("GroupId","RTBIN001")
                .contentType(ContentType.XML)
                .body(request)
                .when()
                .post("https://10.23.210.60:9012/api-banking/upi/ReqBalEnq/1.0");
        System.out.println("Peek Value "+data.thenReturn().asString());
        System.out.println("Peek status "+data.getStatusCode());
    }

    @Test
    public void accountBalanceExternalTest() throws Throwable {
        ProxySpecification proxySpecification = new ProxySpecification("10.65.128.43",8080,"HTTP");
        RestAssured.proxy(proxySpecification);
        RestAssured.useRelaxedHTTPSValidation();
        String filepath = new File(".").getCanonicalPath() + "/src/test/resources/test-data/UPI_AccountBalanceEnquiry.xml";
        DocumentBuilderFactory docFactory = DocumentBuilderFactory.newInstance();
        DocumentBuilder docBuilder = docFactory.newDocumentBuilder();
        NewStub newStub = new NewStub();
        String request = newStub.readFile(filepath);
        System.out.println("The request is "+request);
        activationKey activateKey = new activationKey();
        InputStream input1 = getClass().getResourceAsStream("/test-data/activationKeyRequest.properties");
        commonApiMethods.prop.load(input1);
        String groupId = "RTBIN001";
        //activateKey.getActivationKey(groupId,commonApiMethods.prop);
       // activateKey.user_has_already_generated_the_JWT_token_for_the_group(groupId);
        activateKey.a_POST_request_is_made_to_the_activationKey_API_for_Group(groupId);
        String token= JWTTest.createTokenForObject(30L,request, groupId);
        KeyStore keyStore = null;
        keyStore = KeyStore.getInstance("PKCS12");
        keyStore.load(getClass().getResourceAsStream("/test-data/bny-cert.pfx"), "bny123".toCharArray());
        org.apache.http.conn.ssl.SSLSocketFactory clientAuthFactory = null;
        clientAuthFactory = new org.apache.http.conn.ssl.SSLSocketFactory(keyStore, "bny123");
        SSLConfig config = null;
        config = new SSLConfig().with().sslSocketFactory(clientAuthFactory).and().allowAllHostnames();
        RestAssured.config = RestAssured.config().sslConfig(config);
        Response data = given()
                //.header("GroupId",groupId)
                .contentType(ContentType.TEXT)
                .header("ResponseEncryptionType", "non")
                .body(token)
                .when()
                .post("https://apitest.standardchartered.com/upi/ReqBalEnq/1.0");
        System.out.println("Current time is "+now());
        System.out.println("Account Balance Response Body : "+data.thenReturn().asString());
        System.out.println("Account Balance status code : "+data.getStatusCode());
    }

    @Test
    public void JWTTest() throws Throwable {
        ProxySpecification proxySpecification = new ProxySpecification("10.65.128.43",8080,"HTTP");
        RestAssured.proxy(proxySpecification);
        RestAssured.useRelaxedHTTPSValidation();
        KeyStore keyStore = null;
        keyStore = KeyStore.getInstance("PKCS12");
        keyStore.load(getClass().getResourceAsStream("/test-data/inicert.pfx"), "123456".toCharArray());
        org.apache.http.conn.ssl.SSLSocketFactory clientAuthFactory = null;
        clientAuthFactory = new org.apache.http.conn.ssl.SSLSocketFactory(keyStore, "123456");
        SSLConfig config = null;
        config = new SSLConfig().with().sslSocketFactory(clientAuthFactory).and().allowAllHostnames();
        RestAssured.config = RestAssured.config().sslConfig(config);
        EncryptDecrypt encryptDecrypt = new EncryptDecrypt();
        String encryptedString = encryptDecrypt.encryptWithPublicKeyString(encryptDecrypt.convertStringToPublicKey("MIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAyT7VhlFvkka8NhF1qWVL5Q5aDAbynu10Rzj2vKbQMOLC+g06wtYhB1h57tOr71Yuv\n" +
                "3R+z/sk3pn2HMI53c8tVucXCBw7NJvaMI9XBxjBREr6I9wCTbBikSzv+Ypuxu1BaKjFi3qdXGCXbd0TE5fo2Bha+OegaCI1xgNzy8YVNGBqijIzBpGrGV1zSZ41Mn4GFFXJ590AXY+flVJTk7z93lzKoCEX8vgqI8IEZbC9ezJ7wNXcOfb2MnJFhdP0uTUyHuitQbTPUm9UfcdOuDrLlspCziDF40FQx4T0s+ALWEiPLL\n" +
                "jKyOBzs+99v9mYIMWRPHD02ECVaaApsPO49jjniQIDAQAB\n"), "{\n" +
                "    \"request\":{\n" +
                "        \"head\":{\n" +
                "            \"version\":\"3.0.1\",\n" +
                "            \"function\":\"fund.remit.blockchain.common.redeemBCBalanceNotify\",\n" +
                "            \"clientId\":\"3200002S00000004\",\n" +
                "            \"reqTime\":\"2001-07-04T12:08:56+05:30\",\n" +
                "            \"reqMsgId\":\"1234567i877ewiopiopioiweruirtref1987631\",\n" +
                "            \"reserve\":\"{}\"\n" +
                "        },\n" +
                "        \"body\":{\n" +
                "            \"bizResultOnBC\":{\n" +
                "                \"resultStatus\":\"S\",\n" +
                "                \"resultCodeId\":\"00000000\",\n" +
                "                \"resultCode\":\"SUCCESS\",\n" +
                "                \"resultMsg\":\"success\"\n" +
                "            },\n" +
                "            \"bcOperationId\":\"1755\",\n" +
                "            \"amount\":{\n" +
                "                \"currency\":\"HKD\",\n" +
                "                \"value\":\"8998\"         \n" +
                "                },\n" +
                "            \"bcMid\":\"101SCBL000000001000\",\n" +
                "            \"bcAnchorMid\":\"101SCBL000000001000\",\n" +
                "            \"bcCompleteTime\":\"2001-07-04T12:08:56+05:30\",\n" +
                "            \"extendInfo\":\"{}\"\n" +
                "        }\n" +
                "    },\n" +
                "    \"signature\":\"signature string\"\n" +
                "}\n");

        System.out.println(encryptedString);
        String groupId = "INTEST10";
               Response data = given()
                //.header("GroupId",groupId)
                .contentType(ContentType.JSON)
                //.header("ResponseEncryptionType", "non")
                //.header("JWTToken", token)
                //.header("x-client-certifcate","-----BEGINCERTIFICATE-----MIIDqTCCApGgAwIBAgIIQwSt69WHfvswDQYJKoZIhvcNAQELBQAwga0xHjAcBgkqhkiG9w0BCQEWD3N0YXIucHNzQHNjLmNvbTELMAkGA1UEBhMCSEsxCzAJBgNVBAgTAkhLMQswCQYDVQQHEwJISzEgMB4GA1UEChMXU3RhbmRhcmQgQ2hhcnRlcmVkIEJhbmsxIDAeBgNVBAsTF1N0YW5kYXJkIENoYXJ0ZXJlZCBCYW5rMSAwHgYDVQQDExdTMkIgQXBpIEJhbmtpbmcgUm9vdCBDQTAeFw0xODAzMDUwMTUwMTBaFw0yMTAzMDQwMTUwMTBaMHsxEDAOBgNVBAMTB1RFU1RHMTQxFDASBgNVBAsTC0FQSSBCYW5raW5nMSAwHgYDVQQKExdBUEkgQmFua2luZyBUZXN0IENsaWVudDEVMBMGA1UEBxMMRGVmYXVsdCBDaXR5MQswCQYDVQQIEwJISzELMAkGA1UEBhMCSEswggEiMA0GCSqGSIb3DQEBAQUAA4IBDwAwggEKAoIBAQCkSsts+7waZefO9ckal2WFH2qp57L2WZL09yGVFrqxWnUW2X5GyWc7HL77ZLqnwZA8RfE9jlXFaJPeDhGckyGNXbgR/sKkVOOYk82CVYn4H3MgUPB5uQNeecbTNS6sYY7pQAYRXGZ5E1Acwx9xDStUR5FGAImV7hTHOHoLC94ALy26oCh2vFflfrUSVgz7URznGoaHvZ3cjI9rw4D5rI3HeaBvkfwXxigKXRDfPXxyGPphJ9CJcw+uA8U2j1JA4ATrSHkJ3+/7QHJgi6pyzJ27XZecNqG5DkAyTz3JUAJ6qz6/PcGIV0j47LpSZSqgD7eCfhtbYLDqzmgBC1qGLII5AgMBAAEwDQYJKoZIhvcNAQELBQADggEBAHR2oFueccLQdpgOOV2wVMpkS/RNGV3GeeEkGp1GEYFh0re/IpwuN+LIoL2j4Ddzj7zVyi9M0vgLDuWp1yAtqnmpyiMtSERiR42N87q5uQ7aUxagTDuxxxyvftASfBYcYOIiGSdbMOFIYXRq7ZCWfRWJxuulNjSVrYxWIxwSyoHX26BDxMnwhqOEbD7G7x+5cqom3dGk+aW+oAJ1XNCn0RlUs5OSh9WhrNaOqLG7slZiDJzzJVKuIT2HdzTg1h+zqgQpxi4U73qP8qG/KpRZ7NEJFshwmPSseoNhq/bi8YghA4UbUFiPD0yg10jtZW6lItXMn6tXAxb2fAeLlt5OlMU=-----ENDCERTIFICATE-----")
                .body(encryptedString)
                .when()
                .post("https://apitest.standardchartered.com/internal/cib/inimeg/transaction/generic/notification.htm");
        String content = data.asString().split("\"content\":\"")[1].split("\"")[0];
        String key = data.asString().split("\"key\":\"")[1].split("\"")[0];
        String respo = encryptDecrypt.decryptWithPrivateKey(encryptDecrypt.convertStringToPrivateKey("MIIEvAIBADANBgkqhkiG9w0BAQEFAASCBKYwggSiAgEAAoIBAQC8bDAgzofF/tprSxn0GPPnVgnkjWMHX98dj3G6YoRzDElTomy5UTAi0zmxQkr+2DCzXEiVgLoZc1SUdsVmYc5zR2sjbC71tPXS1A+V/qIPH4b2Zj7o/78G8JjLUGQtTOccyDELdCV2dYvLTuVoFBgsqHrowxfp0zg4y1wG6BIdE01LgNfGQI2sO6FghJ6sy0wGUJgwK+3jjtnu5YzVBixF1B6/fv5UY5WLB4NLDylMZ/6yjwCpSzqNQvowJ3RLz8Pz2wXBfe5AeI7koXj4THs5KagNzEozcEYHwpKHC5C8LbNubDfKMeAEaHsmNl7J5MFSHsVp5Ve0j9v5l7MuloBzAgMBAAECggEAKOIgnz2w4BkoM1ecTgaMBYn5o4m6DwOSWcuiFZsCuiPUVT1M8fjXxPan8fo8Y4dtKb3AUhAYUSVhGMWcl1ZpgUHh0VHL7qxRGmnA5/7UEwv4MMaGp++19z+FJ7hNxDaHfwtA+Qc+ibF/n6GCzU5u4GG+KXsLWUTnUgtt8GGybHRAV6ZX77QCPMK5Q/ePGbwyhOMHnwu2qD/Av9rVKaNq1MOAsYHFWnwDV0AjQuBVukdG0B7n3z8d6jvuFeZofCMumYQvMaUoubHNIHYsTAm+8i4hGIkbmv6EexT3OoXwvzWpoWRb2IwA6bBjRUtWGxhtJPEfdbAh2/MNC9K1yr5uQQKBgQDjSw/8kB9csCBKE4VOKxEQ7bhlZSrPxymHAOsn9gQ7R6KSFzquc3KtKglUjYdsqqrzJcLiVqZ2aYSmi6/PjpZHLDYrPF/qIsr5aTofGbpPaEprKggxzC4KvIfb3ULS2NYtnf8thUH+Z8NcmleFHTxjO+QjElg6x5EfLfb3ueWwiwKBgQDUOFhhQnHPG470YYF0ohK6ZHdslKXZRNKeefm6RJrig/LNKURCsi5fWs8vn0ryzyjTiTzjYP33mnTxBq6Lj7gtjg6NpqsLHyUSYX4FXEQOpxYNK5fzK/SKejoGGdAHLL/+9EBxX4MLx68vAbS8CLbo0/AYY8zsURMG19/I979EuQKBgBP9khZghqGcS/q35M2PNB0NC16/mxhTJ+/bwNLu7EhacI3wxRR6yuc3/0IUgIiqKgbgl1dYz6MyfJw5ROk4XTc9SDZdRQJOtRNikd4SYTSCs6jhNX9LufDvy/Mmbq4krBGvB7Z1NeyuK5yFZpUqkRkZN2NuRZxF2Rmo7UO0ceMpAoGARvo9XPIbHFisPEHsSTT3rI1zf8ZLndot00Eaa9kMMFxPNZzqrp/ncI7voo7VQ1ZT4kQRMD89UbXADOjeMeE0iU/swCWRKVwWSwp+Wo6cWIY7ktYUsQjvde0hQO8bK3slD8FjWEfIjYUQq1kXuJf1jPNtZsriO9t10KEcwJtTxkkCgYBFDD3YwDw5Vh9GLuhBVygXmKvFf5HjR4WdDeg+FzQ07eEUQ1ckja154uh34EujWOH7bKX6ZZNfKKDlNluM16wO8mcM/IKvOe9T660yC51O6dN4rYZ0PI/KEldagN3o0xbLxmE7iyIxjHWqjkdx7YQL30qcW3zDrbkqfDAqe4/s5Q=="),new EncryptDecrypt.EncryptedContent(content, key));
        System.out.println("Response is " + respo);
        System.out.println("Response status code is " + data.getStatusCode());
    }

//    @Test
    public  void publicprivatekeypairgeneration() throws NoSuchAlgorithmException, NoSuchProviderException, InvalidKeySpecException {

        KeyPairGenerator keyGen = KeyPairGenerator.getInstance("RSA");
        keyGen.initialize(2048);
        KeyPair pair = keyGen.generateKeyPair();
        PrivateKey priv = pair.getPrivate();
        PublicKey pub = pair.getPublic();
        Base64.Encoder encoder = Base64.getEncoder();
        String privateKeyBase64Str = encoder.encodeToString(priv.getEncoded());
        System.out.println("Private key in Base64 format:\n" + privateKeyBase64Str.trim().replaceAll("[\\t\\n\\r]+","").replaceAll("\\s+", ""));//it creates 1623 chars or 1620 chars
        String publicKeyBase64Str = encoder.encodeToString(pub.getEncoded());
        System.out.println("Public key in Base64 format:\n" + publicKeyBase64Str.trim().replaceAll("[\\t\\n\\r]+","").replaceAll("\\s+", ""));
    }

    @Test
    public void accountBalanceOpenApiTest() throws Throwable {
        //ProxySpecification proxySpecification = new ProxySpecification("10.65.128.43",8080,"HTTP");
        RestAssured.useRelaxedHTTPSValidation();
//        activationKey activateKey = new activationKey();
//        String groupId = "RTBIN001";
//        FileInputStream input1 = new FileInputStream(new File(".\\src\\test\\resources\\test-data\\activationKeyRequest.properties"));
//        commonApiMethods.prop.load(input1);
//        activateKey.a_POST_request_is_made_to_the_activationKey_API_for_Group(groupId);
//        activateKey.user_has_already_generated_the_JWT_token_for_the_group(groupId);
//        activateKey.a_POST_request_is_made_to_axway_endpoint(groupId);
//        String token = activateKey.activKey.get(groupId);
//        KeyStore keyStore = null;
//        keyStore = KeyStore.getInstance("PKCS12");
//        keyStore.load(new FileInputStream("./src/test/resources/test-data/certificate.pfx"), "123456".toCharArray());
//        org.apache.http.conn.ssl.SSLSocketFactory clientAuthFactory = null;
//        clientAuthFactory = new org.apache.http.conn.ssl.SSLSocketFactory(keyStore, "123456");
//        SSLConfig config = null;
//        config = new SSLConfig().with().sslSocketFactory(clientAuthFactory).and().allowAllHostnames();
//        RestAssured.config = RestAssured.config().sslConfig(config);
        Response data = given()
                //.proxy("10.23.210.60", 8080)
                .header("GroupId","INDGRPIU")
                //.header("ResponseEncryptionType", "AES256Signed")
                //.header("JWTToken",token)
               //// .header("Content-Type","text/plain")
                .contentType(ContentType.TEXT)
                .when()
                .get("https://10.23.210.59:9012/api-banking/openapi/banks/scb/account/22510603706");
               // .get("https://apitest.standardchartered.com/scb/cib/account/22510603706");
        System.out.println("Peek Value is "+data.thenReturn().asString());
        System.out.println("Peek status is "+data.getStatusCode());
    }


    /**
     * The test will verify whether Peek API returns a successful response
     */
//    @Test
    public void getValueFromClassic() throws ClassNotFoundException, SQLException {
        Class.forName("oracle.jdbc.driver.OracleDriver");
        String url = "jdbc:oracle:thin:@10.128.52.72:1591:IMINT1";
        Connection con = DriverManager.getConnection(url, "infouser", "infouser");
        boolean value = con.isClosed();
        Statement stmt = null;
        String query = "select * from ds_oa_balances where OABACCNUM = '22510603706'";
        try {
            stmt = con.createStatement();
            ResultSet rs = stmt.executeQuery(query);
            while (rs.next()) {
                String actualClosingBalance = rs.getString("OABCLOSINGACTUALBAL");

                System.out.println("actualClosingBalance - "+actualClosingBalance);
            }
        } catch (SQLException e ) {
            e.printStackTrace();
        } finally {
            if (stmt != null) { stmt.close(); }
        }

    }


}
