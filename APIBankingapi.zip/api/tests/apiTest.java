package ab.api.tests;

import cucumber.api.CucumberOptions;
import cucumber.api.junit.Cucumber;
import org.junit.runner.RunWith;

@RunWith(Cucumber.class)
@CucumberOptions(
        features = {"classpath:features"},
        glue = {
        "classpath:ab.glue"
        },
        format = {"pretty","html:target/CucumberReports"},
        tags = {"@paymentSuccessfulGenieLoad","~@ignore"},
        plugin = {"json:target/TestReport-cucumber.json"},
        strict = true)

public class apiTest {

//        @AfterClass
//        public static void teardown() throws Throwable {
//                PeekAndConsume peekAndConsume = new PeekAndConsume();
//                peekAndConsume.consumeAll();
//        }
}