package ab.glue.api;

import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

/**
 * Created by 1571168 on 8/25/2017.
 */
public class WebHook {


    @When( "^the Webhook is turned on$")
    public void turnWebhookon(){
        System.out.println("Webhook could not be turned on");
    }

    @Then("^Webhook should be displayed with the expected value$")
    public void verifyWebhook(){
        System.out.println("Webhook could not be verified");
    }

    @When("the webhook is turned off")
    public void verifyWebhookTurnedOff(){
        System.out.println("Webhook could not be turned off");
    }

    @Then ("Webhook should be displayed with the empty message")
    public void verifyEmptyMessageInWebhook(){
        System.out.println("Webhook could not display messages");
    }
}
