package ab.utils;

public class GenericUtils {
    /**
     * This method will trim the value of the expected Peek/Consume/Recover response
     * @param value - The value to be trimmed
     * @return value - The value that is trimmed for the verification
     */
    public String peekConsumeTrim(String value){
        String data = "";
        String[] actualData = value.split("\"externalIdentifier\":\\{\"type\":\"Other\",\"identifier\":\"\"}}");
        String finalData ="";
        for(int i =0; i<actualData.length-1;i++) {
            value = actualData[i] + "\"externalIdentifier\":{\"type\":\"Other\",\"identifier\":\"\"}}";
            data = value.split("identifier")[0] + "identifier" + "creditDate" + value.split("creditDate")[1].replaceAll("\\.00", "");
            finalData = finalData + data.replaceAll(" ","");
        }
        return finalData+"]";
    }

    /**
     * The method will modify and trim the expected value that is to be verified with actual value.
     * @param value - The value that is to trimmed
     * @param group - The group ID value which is to be added to verification
     * @param amount - The amount value which is to be added to verification
     * @param accountNo - The account number value which is to be added for verification.
     * @param trxType - The transaction type value which is to be added for verification.
     * @return - The trimmed/modified data that is to be returned
     */
    public String expectedValueTrim(String value, String group, String amount, String accountNo,  String trxType){
        String data = "";
        int pretransaction = 99803990;
        //data= multipleTransaction(amount,value);
        //String[] transactions = data.split("]");
        String[] amountArray = amount.split(",");
        String[] accountNoArray = accountNo.split(",");
        String[] groupArray = group.split(",");
        String[] trxTypeArray = trxType.split(",");
        String finaldata ="";
        for(int i=0; i< amountArray.length;i++) {
            data = value.split("identifier")[0] + "identifier" + "creditDate" + value.split("creditDate")[1].replaceAll("\\.00", "\"2");
            data = data.split("groupId\":\"")[0] + "groupId\":\"" + groupArray[i] + "\",\"transactionIdentifier" + data.split("\",\"transactionIdentifier")[1];
            data = data.split("\"accountId\"")[0] + "\"accountId\":\"" + accountNoArray[i] + "\",\"currencyCode\":{\"isoCode\"" + data.split("\",\"currencyCode\":\\{\"isoCode\"")[1];
            if (trxTypeArray[i].equals("C")) {
                trxType = "Credit";
                pretransaction = 99803990 - Integer.parseInt(amountArray[i]);
            } else {
                trxType = "Debit";
                pretransaction = 99803990 + Integer.parseInt(amountArray[i]);
            }
            data = data.split("adviceType")[0] + "adviceType\":\"" + trxType + "\",\"transactionCode" + data.split("\",\"transactionCode")[1];
            data = data.split("\"preExecutionBalance\":\\{\"currencyCode\":\"INR\",\"amount\":")[0] + "\"preExecutionBalance\":{\"currencyCode\":\"INR\",\"amount\":" + pretransaction + "},\"transactionFreeText\"" + data.split("},\"transactionFreeText\"")[1];
            data = data.split("transactionAmount\":\\{\"currencyCode\":\"INR\",\"amount\":")[0] + "transactionAmount\":{\"currencyCode\":\"INR\",\"amount\":" + amountArray[i] + "},\"clientIdentifier\":" + data.split("},\"clientIdentifier\":")[1];
            finaldata = finaldata + data;
        }
        finaldata = finaldata.replaceAll("\\]\\[",",");
        return finaldata;

    }

    public String multipleTransaction(String amount, String value){
        int counter = 0;
        if(amount.contains(",")){
            String[] trx = amount.split(",");
            counter = counter+trx.length;
        }
        for(int i=1;i<counter; i++) {
            value = value +value;
        }
        return value;
    }
}
