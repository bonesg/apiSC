$(document).ready(function() {var formatter = new CucumberHTML.DOMFormatter($('.cucumber-report'));formatter.uri("features/api/pull.feature");
formatter.feature({
  "line": 1,
  "name": "Pull Mechanism scenarios",
  "description": "",
  "id": "pull-mechanism-scenarios",
  "keyword": "Feature"
});
formatter.scenarioOutline({
  "line": 138,
  "name": "TC_PULL_007 - When both webhook is down, verify messages for Peek of Group A and Group B",
  "description": "",
  "id": "pull-mechanism-scenarios;tc-pull-007---when-both-webhook-is-down,-verify-messages-for-peek-of-group-a-and-group-b",
  "type": "scenario_outline",
  "keyword": "Scenario Outline",
  "tags": [
    {
      "line": 137,
      "name": "@ab"
    },
    {
      "line": 137,
      "name": "@peekAndConsume"
    },
    {
      "line": 137,
      "name": "@regression"
    },
    {
      "line": 137,
      "name": "@pull"
    },
    {
      "line": 137,
      "name": "@pull7"
    }
  ]
});
formatter.step({
  "comments": [
    {
      "line": 139,
      "value": "#When Add Group Services of CADM is called for the group \u0027\u003cGroupID\u003e\u0027 to disable the group"
    },
    {
      "line": 140,
      "value": "#Then APIBanking should be disabled in CADM for the group \u0027\u003cGroupID\u003e\u0027"
    }
  ],
  "line": 141,
  "name": "\u0027activationKey and activate\u0027 API",
  "keyword": "Given "
});
formatter.step({
  "line": 142,
  "name": "user has valid SSL certificate",
  "keyword": "And "
});
formatter.step({
  "line": 143,
  "name": "user has already generated the JWT token for the group \u0027\u003cGroupIDA\u003e\u0027",
  "keyword": "And "
});
formatter.step({
  "line": 144,
  "name": "a POST request is made to axway endpoint for the group \u0027\u003cGroupIDA\u003e\u0027",
  "keyword": "When "
});
formatter.step({
  "comments": [
    {
      "line": 145,
      "value": "#Then user should be registered successfully"
    },
    {
      "line": 146,
      "value": "#And APIBanking should be enabled in CADM for the group \u0027\u003cGroupIDA\u003e\u0027"
    },
    {
      "line": 147,
      "value": "#Given user has already generated the JWT token for the group \u0027\u003cGroupIDB\u003e\u0027"
    },
    {
      "line": 148,
      "value": "#When a POST request is made to axway endpoint for the group \u0027\u003cGroupIDB\u003e\u0027"
    },
    {
      "line": 149,
      "value": "#Then user should be registered successfully"
    },
    {
      "line": 150,
      "value": "#And APIBanking should be enabled in CADM for the group \u0027\u003cGroupIDB\u003e\u0027"
    },
    {
      "line": 151,
      "value": "#When user modifies Stub with amount \u0027\u003cAmount\u003e\u0027 account number \u0027\u003cAccountNo\u003e\u0027 transaction type \u0027\u003cCreditDebit\u003e\u0027 Currency Code \u0027INR\u0027 BIC \u0027SCBLINBBXXX\u0027"
    }
  ],
  "line": 152,
  "name": "Recover response should be displayed with amount \u0027\u003cAmount\u003e\u0027 accountNo \u0027\u003cAccountNo\u003e\u0027 transactionType \u0027\u003cCreditDebit\u003e\u0027 the expected value for the group \u0027\u003cGroupIDA\u003e\u0027",
  "keyword": "Then "
});
formatter.step({
  "line": 153,
  "name": "Peek response should be displayed with amount \u0027\u003cAmount\u003e\u0027 accountNo \u0027\u003cAccountNo\u003e\u0027 transactionType \u0027\u003cCreditDebit\u003e\u0027 the expected value for the group \u0027\u003cGroupIDB\u003e\u0027",
  "keyword": "Then "
});
formatter.examples({
  "line": 154,
  "name": "",
  "description": "",
  "id": "pull-mechanism-scenarios;tc-pull-007---when-both-webhook-is-down,-verify-messages-for-peek-of-group-a-and-group-b;",
  "rows": [
    {
      "cells": [
        "Amount",
        "AccountNo",
        "CreditDebit",
        "GroupIDA",
        "GroupIDB"
      ],
      "line": 155,
      "id": "pull-mechanism-scenarios;tc-pull-007---when-both-webhook-is-down,-verify-messages-for-peek-of-group-a-and-group-b;;1"
    },
    {
      "cells": [
        "5555",
        "17082017",
        "D",
        "INDGROUP",
        "INDGRP"
      ],
      "line": 156,
      "id": "pull-mechanism-scenarios;tc-pull-007---when-both-webhook-is-down,-verify-messages-for-peek-of-group-a-and-group-b;;2"
    },
    {
      "cells": [
        "5555",
        "17082017",
        "D",
        "INDGRP",
        "INDGRP"
      ],
      "line": 157,
      "id": "pull-mechanism-scenarios;tc-pull-007---when-both-webhook-is-down,-verify-messages-for-peek-of-group-a-and-group-b;;3"
    }
  ],
  "keyword": "Examples"
});
formatter.before({
  "duration": 518426124,
  "status": "passed"
});
formatter.scenario({
  "line": 156,
  "name": "TC_PULL_007 - When both webhook is down, verify messages for Peek of Group A and Group B",
  "description": "",
  "id": "pull-mechanism-scenarios;tc-pull-007---when-both-webhook-is-down,-verify-messages-for-peek-of-group-a-and-group-b;;2",
  "type": "scenario",
  "keyword": "Scenario Outline",
  "tags": [
    {
      "line": 137,
      "name": "@ab"
    },
    {
      "line": 137,
      "name": "@peekAndConsume"
    },
    {
      "line": 137,
      "name": "@regression"
    },
    {
      "line": 137,
      "name": "@pull7"
    },
    {
      "line": 137,
      "name": "@pull"
    }
  ]
});
formatter.step({
  "comments": [
    {
      "line": 139,
      "value": "#When Add Group Services of CADM is called for the group \u0027\u003cGroupID\u003e\u0027 to disable the group"
    },
    {
      "line": 140,
      "value": "#Then APIBanking should be disabled in CADM for the group \u0027\u003cGroupID\u003e\u0027"
    }
  ],
  "line": 141,
  "name": "\u0027activationKey and activate\u0027 API",
  "keyword": "Given "
});
formatter.step({
  "line": 142,
  "name": "user has valid SSL certificate",
  "keyword": "And "
});
formatter.step({
  "line": 143,
  "name": "user has already generated the JWT token for the group \u0027INDGROUP\u0027",
  "matchedColumns": [
    3
  ],
  "keyword": "And "
});
formatter.step({
  "line": 144,
  "name": "a POST request is made to axway endpoint for the group \u0027INDGROUP\u0027",
  "matchedColumns": [
    3
  ],
  "keyword": "When "
});
formatter.step({
  "comments": [
    {
      "line": 145,
      "value": "#Then user should be registered successfully"
    },
    {
      "line": 146,
      "value": "#And APIBanking should be enabled in CADM for the group \u0027\u003cGroupIDA\u003e\u0027"
    },
    {
      "line": 147,
      "value": "#Given user has already generated the JWT token for the group \u0027\u003cGroupIDB\u003e\u0027"
    },
    {
      "line": 148,
      "value": "#When a POST request is made to axway endpoint for the group \u0027\u003cGroupIDB\u003e\u0027"
    },
    {
      "line": 149,
      "value": "#Then user should be registered successfully"
    },
    {
      "line": 150,
      "value": "#And APIBanking should be enabled in CADM for the group \u0027\u003cGroupIDB\u003e\u0027"
    },
    {
      "line": 151,
      "value": "#When user modifies Stub with amount \u0027\u003cAmount\u003e\u0027 account number \u0027\u003cAccountNo\u003e\u0027 transaction type \u0027\u003cCreditDebit\u003e\u0027 Currency Code \u0027INR\u0027 BIC \u0027SCBLINBBXXX\u0027"
    }
  ],
  "line": 152,
  "name": "Recover response should be displayed with amount \u00275555\u0027 accountNo \u002717082017\u0027 transactionType \u0027D\u0027 the expected value for the group \u0027INDGROUP\u0027",
  "matchedColumns": [
    0,
    1,
    2,
    3
  ],
  "keyword": "Then "
});
formatter.step({
  "line": 153,
  "name": "Peek response should be displayed with amount \u00275555\u0027 accountNo \u002717082017\u0027 transactionType \u0027D\u0027 the expected value for the group \u0027INDGRP\u0027",
  "matchedColumns": [
    0,
    1,
    2,
    4
  ],
  "keyword": "Then "
});
formatter.match({
  "arguments": [
    {
      "val": "activationKey and activate",
      "offset": 1
    }
  ],
  "location": "commonApiMethods.an_API(String)"
});
formatter.result({
  "duration": 321242195,
  "status": "passed"
});
formatter.match({
  "location": "activationKey.user_has_valid_SSL_certificate()"
});
formatter.result({
  "duration": 6997701,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "INDGROUP",
      "offset": 56
    }
  ],
  "location": "activationKey.user_has_already_generated_the_JWT_token_for_the_group(String)"
});
formatter.result({
  "duration": 613601738,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "INDGROUP",
      "offset": 56
    }
  ],
  "location": "activationKey.a_POST_request_is_made_to_axway_endpoint(String)"
});
formatter.result({
  "duration": 5404407348,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "5555",
      "offset": 50
    },
    {
      "val": "17082017",
      "offset": 67
    },
    {
      "val": "D",
      "offset": 94
    },
    {
      "val": "INDGROUP",
      "offset": 131
    }
  ],
  "location": "PeekAndConsume.recoverValueTest(String,String,String,String)"
});
formatter.result({
  "duration": 775393902,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "5555",
      "offset": 47
    },
    {
      "val": "17082017",
      "offset": 64
    },
    {
      "val": "D",
      "offset": 91
    },
    {
      "val": "INDGRP",
      "offset": 128
    }
  ],
  "location": "PeekAndConsume.peekValueTest(String,String,String,String)"
});
formatter.result({
  "duration": 701866872,
  "status": "passed"
});
formatter.before({
  "duration": 14636913,
  "status": "passed"
});
formatter.scenario({
  "line": 157,
  "name": "TC_PULL_007 - When both webhook is down, verify messages for Peek of Group A and Group B",
  "description": "",
  "id": "pull-mechanism-scenarios;tc-pull-007---when-both-webhook-is-down,-verify-messages-for-peek-of-group-a-and-group-b;;3",
  "type": "scenario",
  "keyword": "Scenario Outline",
  "tags": [
    {
      "line": 137,
      "name": "@ab"
    },
    {
      "line": 137,
      "name": "@peekAndConsume"
    },
    {
      "line": 137,
      "name": "@regression"
    },
    {
      "line": 137,
      "name": "@pull7"
    },
    {
      "line": 137,
      "name": "@pull"
    }
  ]
});
formatter.step({
  "comments": [
    {
      "line": 139,
      "value": "#When Add Group Services of CADM is called for the group \u0027\u003cGroupID\u003e\u0027 to disable the group"
    },
    {
      "line": 140,
      "value": "#Then APIBanking should be disabled in CADM for the group \u0027\u003cGroupID\u003e\u0027"
    }
  ],
  "line": 141,
  "name": "\u0027activationKey and activate\u0027 API",
  "keyword": "Given "
});
formatter.step({
  "line": 142,
  "name": "user has valid SSL certificate",
  "keyword": "And "
});
formatter.step({
  "line": 143,
  "name": "user has already generated the JWT token for the group \u0027INDGRP\u0027",
  "matchedColumns": [
    3
  ],
  "keyword": "And "
});
formatter.step({
  "line": 144,
  "name": "a POST request is made to axway endpoint for the group \u0027INDGRP\u0027",
  "matchedColumns": [
    3
  ],
  "keyword": "When "
});
formatter.step({
  "comments": [
    {
      "line": 145,
      "value": "#Then user should be registered successfully"
    },
    {
      "line": 146,
      "value": "#And APIBanking should be enabled in CADM for the group \u0027\u003cGroupIDA\u003e\u0027"
    },
    {
      "line": 147,
      "value": "#Given user has already generated the JWT token for the group \u0027\u003cGroupIDB\u003e\u0027"
    },
    {
      "line": 148,
      "value": "#When a POST request is made to axway endpoint for the group \u0027\u003cGroupIDB\u003e\u0027"
    },
    {
      "line": 149,
      "value": "#Then user should be registered successfully"
    },
    {
      "line": 150,
      "value": "#And APIBanking should be enabled in CADM for the group \u0027\u003cGroupIDB\u003e\u0027"
    },
    {
      "line": 151,
      "value": "#When user modifies Stub with amount \u0027\u003cAmount\u003e\u0027 account number \u0027\u003cAccountNo\u003e\u0027 transaction type \u0027\u003cCreditDebit\u003e\u0027 Currency Code \u0027INR\u0027 BIC \u0027SCBLINBBXXX\u0027"
    }
  ],
  "line": 152,
  "name": "Recover response should be displayed with amount \u00275555\u0027 accountNo \u002717082017\u0027 transactionType \u0027D\u0027 the expected value for the group \u0027INDGRP\u0027",
  "matchedColumns": [
    0,
    1,
    2,
    3
  ],
  "keyword": "Then "
});
formatter.step({
  "line": 153,
  "name": "Peek response should be displayed with amount \u00275555\u0027 accountNo \u002717082017\u0027 transactionType \u0027D\u0027 the expected value for the group \u0027INDGRP\u0027",
  "matchedColumns": [
    0,
    1,
    2,
    4
  ],
  "keyword": "Then "
});
formatter.match({
  "arguments": [
    {
      "val": "activationKey and activate",
      "offset": 1
    }
  ],
  "location": "commonApiMethods.an_API(String)"
});
formatter.result({
  "duration": 94395,
  "status": "passed"
});
formatter.match({
  "location": "activationKey.user_has_valid_SSL_certificate()"
});
formatter.result({
  "duration": 450454,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "INDGRP",
      "offset": 56
    }
  ],
  "location": "activationKey.user_has_already_generated_the_JWT_token_for_the_group(String)"
});
formatter.result({
  "duration": 15539330,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "INDGRP",
      "offset": 56
    }
  ],
  "location": "activationKey.a_POST_request_is_made_to_axway_endpoint(String)"
});
formatter.result({
  "duration": 1548558190,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "5555",
      "offset": 50
    },
    {
      "val": "17082017",
      "offset": 67
    },
    {
      "val": "D",
      "offset": 94
    },
    {
      "val": "INDGRP",
      "offset": 131
    }
  ],
  "location": "PeekAndConsume.recoverValueTest(String,String,String,String)"
});
formatter.result({
  "duration": 840579042,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "5555",
      "offset": 47
    },
    {
      "val": "17082017",
      "offset": 64
    },
    {
      "val": "D",
      "offset": 91
    },
    {
      "val": "INDGRP",
      "offset": 128
    }
  ],
  "location": "PeekAndConsume.peekValueTest(String,String,String,String)"
});
formatter.result({
  "duration": 1073308033,
  "status": "passed"
});
});