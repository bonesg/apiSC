$(document).ready(function() {var formatter = new CucumberHTML.DOMFormatter($('.cucumber-report'));formatter.uri("features/api/pull.feature");
formatter.feature({
  "line": 1,
  "name": "Pull Mechanism scenarios",
  "description": "",
  "id": "pull-mechanism-scenarios",
  "keyword": "Feature"
});
formatter.scenarioOutline({
  "line": 116,
  "name": "TC_PULL_006 - When both webhook is down, verify messages for Peek of Group A and Recover of Group B",
  "description": "",
  "id": "pull-mechanism-scenarios;tc-pull-006---when-both-webhook-is-down,-verify-messages-for-peek-of-group-a-and-recover-of-group-b",
  "type": "scenario_outline",
  "keyword": "Scenario Outline",
  "tags": [
    {
      "line": 115,
      "name": "@ab"
    },
    {
      "line": 115,
      "name": "@peekAndConsume"
    },
    {
      "line": 115,
      "name": "@regression"
    },
    {
      "line": 115,
      "name": "@pull"
    },
    {
      "line": 115,
      "name": "@pull6"
    }
  ]
});
formatter.step({
  "comments": [
    {
      "line": 117,
      "value": "#When Add Group Services of CADM is called for the group \u0027\u003cGroupID\u003e\u0027 to disable the group"
    },
    {
      "line": 118,
      "value": "#Then APIBanking should be disabled in CADM for the group \u0027\u003cGroupID\u003e\u0027"
    }
  ],
  "line": 119,
  "name": "\u0027activationKey and activate\u0027 API",
  "keyword": "Given "
});
formatter.step({
  "line": 120,
  "name": "user has valid SSL certificate",
  "keyword": "And "
});
formatter.step({
  "line": 121,
  "name": "user has already generated the JWT token for the group \u0027\u003cGroupIDA\u003e\u0027",
  "keyword": "And "
});
formatter.step({
  "line": 122,
  "name": "a POST request is made to axway endpoint for the group \u0027\u003cGroupIDA\u003e\u0027",
  "keyword": "When "
});
formatter.step({
  "line": 123,
  "name": "user should be registered successfully",
  "keyword": "Then "
});
formatter.step({
  "comments": [
    {
      "line": 124,
      "value": "#And APIBanking should be enabled in CADM for the group \u0027\u003cGroupIDA\u003e\u0027"
    },
    {
      "line": 125,
      "value": "#Given user has already generated the JWT token for the group \u0027\u003cGroupIDB\u003e\u0027"
    },
    {
      "line": 126,
      "value": "#When a POST request is made to axway endpoint for the group \u0027\u003cGroupIDB\u003e\u0027"
    },
    {
      "line": 127,
      "value": "#Then user should be registered successfully"
    },
    {
      "line": 128,
      "value": "#And APIBanking should be enabled in CADM for the group \u0027\u003cGroupIDB\u003e\u0027"
    },
    {
      "line": 129,
      "value": "#When user modifies Stub with amount \u0027\u003cAmount\u003e\u0027 account number \u0027\u003cAccountNo\u003e\u0027 transaction type \u0027\u003cCreditDebit\u003e\u0027 Currency Code \u0027INR\u0027 BIC \u0027SCBLINBBXXX\u0027"
    }
  ],
  "line": 130,
  "name": "Consume response should be displayed with amount \u0027\u003cAmount\u003e\u0027 accountNo \u0027\u003cAccountNo\u003e\u0027 transactionType \u0027\u003cCreditDebit\u003e\u0027 the expected value for the group \u0027\u003cGroupIDA\u003e\u0027",
  "keyword": "Then "
});
formatter.step({
  "line": 131,
  "name": "Recover response should be displayed with amount \u0027\u003cAmount\u003e\u0027 accountNo \u0027\u003cAccountNo\u003e\u0027 transactionType \u0027\u003cCreditDebit\u003e\u0027 the expected value for the group \u0027\u003cGroupIDB\u003e\u0027",
  "keyword": "Then "
});
formatter.examples({
  "line": 132,
  "name": "",
  "description": "",
  "id": "pull-mechanism-scenarios;tc-pull-006---when-both-webhook-is-down,-verify-messages-for-peek-of-group-a-and-recover-of-group-b;",
  "rows": [
    {
      "cells": [
        "Amount",
        "AccountNo",
        "CreditDebit",
        "GroupIDA",
        "GroupIDB"
      ],
      "line": 133,
      "id": "pull-mechanism-scenarios;tc-pull-006---when-both-webhook-is-down,-verify-messages-for-peek-of-group-a-and-recover-of-group-b;;1"
    },
    {
      "cells": [
        "5555",
        "17082017",
        "D",
        "INDGROUP",
        "INDGRP"
      ],
      "line": 134,
      "id": "pull-mechanism-scenarios;tc-pull-006---when-both-webhook-is-down,-verify-messages-for-peek-of-group-a-and-recover-of-group-b;;2"
    }
  ],
  "keyword": "Examples"
});
formatter.before({
  "duration": 552785205,
  "status": "passed"
});
formatter.scenario({
  "line": 134,
  "name": "TC_PULL_006 - When both webhook is down, verify messages for Peek of Group A and Recover of Group B",
  "description": "",
  "id": "pull-mechanism-scenarios;tc-pull-006---when-both-webhook-is-down,-verify-messages-for-peek-of-group-a-and-recover-of-group-b;;2",
  "type": "scenario",
  "keyword": "Scenario Outline",
  "tags": [
    {
      "line": 115,
      "name": "@ab"
    },
    {
      "line": 115,
      "name": "@peekAndConsume"
    },
    {
      "line": 115,
      "name": "@regression"
    },
    {
      "line": 115,
      "name": "@pull6"
    },
    {
      "line": 115,
      "name": "@pull"
    }
  ]
});
formatter.step({
  "comments": [
    {
      "line": 117,
      "value": "#When Add Group Services of CADM is called for the group \u0027\u003cGroupID\u003e\u0027 to disable the group"
    },
    {
      "line": 118,
      "value": "#Then APIBanking should be disabled in CADM for the group \u0027\u003cGroupID\u003e\u0027"
    }
  ],
  "line": 119,
  "name": "\u0027activationKey and activate\u0027 API",
  "keyword": "Given "
});
formatter.step({
  "line": 120,
  "name": "user has valid SSL certificate",
  "keyword": "And "
});
formatter.step({
  "line": 121,
  "name": "user has already generated the JWT token for the group \u0027INDGROUP\u0027",
  "matchedColumns": [
    3
  ],
  "keyword": "And "
});
formatter.step({
  "line": 122,
  "name": "a POST request is made to axway endpoint for the group \u0027INDGROUP\u0027",
  "matchedColumns": [
    3
  ],
  "keyword": "When "
});
formatter.step({
  "line": 123,
  "name": "user should be registered successfully",
  "keyword": "Then "
});
formatter.step({
  "comments": [
    {
      "line": 124,
      "value": "#And APIBanking should be enabled in CADM for the group \u0027\u003cGroupIDA\u003e\u0027"
    },
    {
      "line": 125,
      "value": "#Given user has already generated the JWT token for the group \u0027\u003cGroupIDB\u003e\u0027"
    },
    {
      "line": 126,
      "value": "#When a POST request is made to axway endpoint for the group \u0027\u003cGroupIDB\u003e\u0027"
    },
    {
      "line": 127,
      "value": "#Then user should be registered successfully"
    },
    {
      "line": 128,
      "value": "#And APIBanking should be enabled in CADM for the group \u0027\u003cGroupIDB\u003e\u0027"
    },
    {
      "line": 129,
      "value": "#When user modifies Stub with amount \u0027\u003cAmount\u003e\u0027 account number \u0027\u003cAccountNo\u003e\u0027 transaction type \u0027\u003cCreditDebit\u003e\u0027 Currency Code \u0027INR\u0027 BIC \u0027SCBLINBBXXX\u0027"
    }
  ],
  "line": 130,
  "name": "Consume response should be displayed with amount \u00275555\u0027 accountNo \u002717082017\u0027 transactionType \u0027D\u0027 the expected value for the group \u0027INDGROUP\u0027",
  "matchedColumns": [
    0,
    1,
    2,
    3
  ],
  "keyword": "Then "
});
formatter.step({
  "line": 131,
  "name": "Recover response should be displayed with amount \u00275555\u0027 accountNo \u002717082017\u0027 transactionType \u0027D\u0027 the expected value for the group \u0027INDGRP\u0027",
  "matchedColumns": [
    0,
    1,
    2,
    4
  ],
  "keyword": "Then "
});
formatter.match({
  "arguments": [
    {
      "val": "activationKey and activate",
      "offset": 1
    }
  ],
  "location": "commonApiMethods.an_API(String)"
});
formatter.result({
  "duration": 227424737,
  "status": "passed"
});
formatter.match({
  "location": "activationKey.user_has_valid_SSL_certificate()"
});
formatter.result({
  "duration": 8861439,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "INDGROUP",
      "offset": 56
    }
  ],
  "location": "activationKey.user_has_already_generated_the_JWT_token_for_the_group(String)"
});
formatter.result({
  "duration": 612640795,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "INDGROUP",
      "offset": 56
    }
  ],
  "location": "activationKey.a_POST_request_is_made_to_axway_endpoint(String)"
});
formatter.result({
  "duration": 5134263893,
  "status": "passed"
});
formatter.match({
  "location": "activationKey.user_should_be_registered_successfully()"
});
formatter.result({
  "duration": 173310,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "5555",
      "offset": 50
    },
    {
      "val": "17082017",
      "offset": 67
    },
    {
      "val": "D",
      "offset": 94
    },
    {
      "val": "INDGROUP",
      "offset": 131
    }
  ],
  "location": "PeekAndConsume.consumeValueTest(String,String,String,String)"
});
formatter.result({
  "duration": 873845406,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "5555",
      "offset": 50
    },
    {
      "val": "17082017",
      "offset": 67
    },
    {
      "val": "D",
      "offset": 94
    },
    {
      "val": "INDGRP",
      "offset": 131
    }
  ],
  "location": "PeekAndConsume.recoverValueTest(String,String,String,String)"
});
formatter.result({
  "duration": 672464668,
  "status": "passed"
});
});