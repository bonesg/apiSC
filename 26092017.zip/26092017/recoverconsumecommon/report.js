$(document).ready(function() {var formatter = new CucumberHTML.DOMFormatter($('.cucumber-report'));formatter.uri("features/api/pull.feature");
formatter.feature({
  "line": 1,
  "name": "Pull Mechanism scenarios",
  "description": "",
  "id": "pull-mechanism-scenarios",
  "keyword": "Feature"
});
formatter.scenarioOutline({
  "line": 160,
  "name": "TC_PULL_008 - When both webhook is down, verify messages for Peek of Group A and Consume of Group B",
  "description": "",
  "id": "pull-mechanism-scenarios;tc-pull-008---when-both-webhook-is-down,-verify-messages-for-peek-of-group-a-and-consume-of-group-b",
  "type": "scenario_outline",
  "keyword": "Scenario Outline",
  "tags": [
    {
      "line": 159,
      "name": "@ab"
    },
    {
      "line": 159,
      "name": "@peekAndConsume"
    },
    {
      "line": 159,
      "name": "@regression"
    },
    {
      "line": 159,
      "name": "@pull"
    },
    {
      "line": 159,
      "name": "@pull8"
    }
  ]
});
formatter.step({
  "comments": [
    {
      "line": 161,
      "value": "#When Add Group Services of CADM is called for the group \u0027\u003cGroupID\u003e\u0027 to disable the group"
    },
    {
      "line": 162,
      "value": "#Then APIBanking should be disabled in CADM for the group \u0027\u003cGroupID\u003e\u0027"
    }
  ],
  "line": 163,
  "name": "\u0027activationKey and activate\u0027 API",
  "keyword": "Given "
});
formatter.step({
  "line": 164,
  "name": "user has valid SSL certificate",
  "keyword": "And "
});
formatter.step({
  "line": 165,
  "name": "user has already generated the JWT token for the group \u0027\u003cGroupIDA\u003e\u0027",
  "keyword": "And "
});
formatter.step({
  "line": 166,
  "name": "a POST request is made to axway endpoint for the group \u0027\u003cGroupIDA\u003e\u0027",
  "keyword": "When "
});
formatter.step({
  "comments": [
    {
      "line": 167,
      "value": "#Then user should be registered successfully"
    },
    {
      "line": 168,
      "value": "#And APIBanking should be enabled in CADM for the group \u0027\u003cGroupIDA\u003e\u0027"
    },
    {
      "line": 169,
      "value": "#Given user has already generated the JWT token for the group \u0027\u003cGroupIDB\u003e\u0027"
    },
    {
      "line": 170,
      "value": "#When a POST request is made to axway endpoint for the group \u0027\u003cGroupIDB\u003e\u0027"
    },
    {
      "line": 171,
      "value": "#Then user should be registered successfully"
    },
    {
      "line": 172,
      "value": "#And APIBanking should be enabled in CADM for the group \u0027\u003cGroupIDB\u003e\u0027"
    },
    {
      "line": 173,
      "value": "#When user modifies Stub with amount \u0027\u003cAmount\u003e\u0027 account number \u0027\u003cAccountNo\u003e\u0027 transaction type \u0027\u003cCreditDebit\u003e\u0027 Currency Code \u0027INR\u0027 BIC \u0027SCBLINBBXXX\u0027"
    }
  ],
  "line": 174,
  "name": "Recover response should be displayed with amount \u0027\u003cAmount\u003e\u0027 accountNo \u0027\u003cAccountNo\u003e\u0027 transactionType \u0027\u003cCreditDebit\u003e\u0027 the expected value for the group \u0027\u003cGroupIDA\u003e\u0027",
  "keyword": "Then "
});
formatter.step({
  "line": 175,
  "name": "Consume response should be displayed with amount \u0027\u003cAmount\u003e\u0027 accountNo \u0027\u003cAccountNo\u003e\u0027 transactionType \u0027\u003cCreditDebit\u003e\u0027 the expected value for the group \u0027\u003cGroupIDB\u003e\u0027",
  "keyword": "Then "
});
formatter.examples({
  "line": 176,
  "name": "",
  "description": "",
  "id": "pull-mechanism-scenarios;tc-pull-008---when-both-webhook-is-down,-verify-messages-for-peek-of-group-a-and-consume-of-group-b;",
  "rows": [
    {
      "cells": [
        "Amount",
        "AccountNo",
        "CreditDebit",
        "GroupIDA",
        "GroupIDB"
      ],
      "line": 177,
      "id": "pull-mechanism-scenarios;tc-pull-008---when-both-webhook-is-down,-verify-messages-for-peek-of-group-a-and-consume-of-group-b;;1"
    },
    {
      "cells": [
        "5555",
        "17082017",
        "D",
        "INDGROUP",
        "INDGRP"
      ],
      "line": 178,
      "id": "pull-mechanism-scenarios;tc-pull-008---when-both-webhook-is-down,-verify-messages-for-peek-of-group-a-and-consume-of-group-b;;2"
    },
    {
      "cells": [
        "5555",
        "17082017",
        "D",
        "INDGROUP",
        "INDGROUP"
      ],
      "line": 179,
      "id": "pull-mechanism-scenarios;tc-pull-008---when-both-webhook-is-down,-verify-messages-for-peek-of-group-a-and-consume-of-group-b;;3"
    }
  ],
  "keyword": "Examples"
});
formatter.before({
  "duration": 716079384,
  "status": "passed"
});
formatter.scenario({
  "line": 178,
  "name": "TC_PULL_008 - When both webhook is down, verify messages for Peek of Group A and Consume of Group B",
  "description": "",
  "id": "pull-mechanism-scenarios;tc-pull-008---when-both-webhook-is-down,-verify-messages-for-peek-of-group-a-and-consume-of-group-b;;2",
  "type": "scenario",
  "keyword": "Scenario Outline",
  "tags": [
    {
      "line": 159,
      "name": "@ab"
    },
    {
      "line": 159,
      "name": "@peekAndConsume"
    },
    {
      "line": 159,
      "name": "@pull8"
    },
    {
      "line": 159,
      "name": "@regression"
    },
    {
      "line": 159,
      "name": "@pull"
    }
  ]
});
formatter.step({
  "comments": [
    {
      "line": 161,
      "value": "#When Add Group Services of CADM is called for the group \u0027\u003cGroupID\u003e\u0027 to disable the group"
    },
    {
      "line": 162,
      "value": "#Then APIBanking should be disabled in CADM for the group \u0027\u003cGroupID\u003e\u0027"
    }
  ],
  "line": 163,
  "name": "\u0027activationKey and activate\u0027 API",
  "keyword": "Given "
});
formatter.step({
  "line": 164,
  "name": "user has valid SSL certificate",
  "keyword": "And "
});
formatter.step({
  "line": 165,
  "name": "user has already generated the JWT token for the group \u0027INDGROUP\u0027",
  "matchedColumns": [
    3
  ],
  "keyword": "And "
});
formatter.step({
  "line": 166,
  "name": "a POST request is made to axway endpoint for the group \u0027INDGROUP\u0027",
  "matchedColumns": [
    3
  ],
  "keyword": "When "
});
formatter.step({
  "comments": [
    {
      "line": 167,
      "value": "#Then user should be registered successfully"
    },
    {
      "line": 168,
      "value": "#And APIBanking should be enabled in CADM for the group \u0027\u003cGroupIDA\u003e\u0027"
    },
    {
      "line": 169,
      "value": "#Given user has already generated the JWT token for the group \u0027\u003cGroupIDB\u003e\u0027"
    },
    {
      "line": 170,
      "value": "#When a POST request is made to axway endpoint for the group \u0027\u003cGroupIDB\u003e\u0027"
    },
    {
      "line": 171,
      "value": "#Then user should be registered successfully"
    },
    {
      "line": 172,
      "value": "#And APIBanking should be enabled in CADM for the group \u0027\u003cGroupIDB\u003e\u0027"
    },
    {
      "line": 173,
      "value": "#When user modifies Stub with amount \u0027\u003cAmount\u003e\u0027 account number \u0027\u003cAccountNo\u003e\u0027 transaction type \u0027\u003cCreditDebit\u003e\u0027 Currency Code \u0027INR\u0027 BIC \u0027SCBLINBBXXX\u0027"
    }
  ],
  "line": 174,
  "name": "Recover response should be displayed with amount \u00275555\u0027 accountNo \u002717082017\u0027 transactionType \u0027D\u0027 the expected value for the group \u0027INDGROUP\u0027",
  "matchedColumns": [
    0,
    1,
    2,
    3
  ],
  "keyword": "Then "
});
formatter.step({
  "line": 175,
  "name": "Consume response should be displayed with amount \u00275555\u0027 accountNo \u002717082017\u0027 transactionType \u0027D\u0027 the expected value for the group \u0027INDGRP\u0027",
  "matchedColumns": [
    0,
    1,
    2,
    4
  ],
  "keyword": "Then "
});
formatter.match({
  "arguments": [
    {
      "val": "activationKey and activate",
      "offset": 1
    }
  ],
  "location": "commonApiMethods.an_API(String)"
});
formatter.result({
  "duration": 254121198,
  "status": "passed"
});
formatter.match({
  "location": "activationKey.user_has_valid_SSL_certificate()"
});
formatter.result({
  "duration": 19611538,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "INDGROUP",
      "offset": 56
    }
  ],
  "location": "activationKey.user_has_already_generated_the_JWT_token_for_the_group(String)"
});
formatter.result({
  "duration": 598213439,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "INDGROUP",
      "offset": 56
    }
  ],
  "location": "activationKey.a_POST_request_is_made_to_axway_endpoint(String)"
});
formatter.result({
  "duration": 6826481315,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "5555",
      "offset": 50
    },
    {
      "val": "17082017",
      "offset": 67
    },
    {
      "val": "D",
      "offset": 94
    },
    {
      "val": "INDGROUP",
      "offset": 131
    }
  ],
  "location": "PeekAndConsume.recoverValueTest(String,String,String,String)"
});
formatter.result({
  "duration": 1705382903,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "5555",
      "offset": 50
    },
    {
      "val": "17082017",
      "offset": 67
    },
    {
      "val": "D",
      "offset": 94
    },
    {
      "val": "INDGRP",
      "offset": 131
    }
  ],
  "location": "PeekAndConsume.consumeValueTest(String,String,String,String)"
});
formatter.result({
  "duration": 839359080,
  "status": "passed"
});
formatter.before({
  "duration": 13025399,
  "status": "passed"
});
formatter.scenario({
  "line": 179,
  "name": "TC_PULL_008 - When both webhook is down, verify messages for Peek of Group A and Consume of Group B",
  "description": "",
  "id": "pull-mechanism-scenarios;tc-pull-008---when-both-webhook-is-down,-verify-messages-for-peek-of-group-a-and-consume-of-group-b;;3",
  "type": "scenario",
  "keyword": "Scenario Outline",
  "tags": [
    {
      "line": 159,
      "name": "@ab"
    },
    {
      "line": 159,
      "name": "@peekAndConsume"
    },
    {
      "line": 159,
      "name": "@pull8"
    },
    {
      "line": 159,
      "name": "@regression"
    },
    {
      "line": 159,
      "name": "@pull"
    }
  ]
});
formatter.step({
  "comments": [
    {
      "line": 161,
      "value": "#When Add Group Services of CADM is called for the group \u0027\u003cGroupID\u003e\u0027 to disable the group"
    },
    {
      "line": 162,
      "value": "#Then APIBanking should be disabled in CADM for the group \u0027\u003cGroupID\u003e\u0027"
    }
  ],
  "line": 163,
  "name": "\u0027activationKey and activate\u0027 API",
  "keyword": "Given "
});
formatter.step({
  "line": 164,
  "name": "user has valid SSL certificate",
  "keyword": "And "
});
formatter.step({
  "line": 165,
  "name": "user has already generated the JWT token for the group \u0027INDGROUP\u0027",
  "matchedColumns": [
    3
  ],
  "keyword": "And "
});
formatter.step({
  "line": 166,
  "name": "a POST request is made to axway endpoint for the group \u0027INDGROUP\u0027",
  "matchedColumns": [
    3
  ],
  "keyword": "When "
});
formatter.step({
  "comments": [
    {
      "line": 167,
      "value": "#Then user should be registered successfully"
    },
    {
      "line": 168,
      "value": "#And APIBanking should be enabled in CADM for the group \u0027\u003cGroupIDA\u003e\u0027"
    },
    {
      "line": 169,
      "value": "#Given user has already generated the JWT token for the group \u0027\u003cGroupIDB\u003e\u0027"
    },
    {
      "line": 170,
      "value": "#When a POST request is made to axway endpoint for the group \u0027\u003cGroupIDB\u003e\u0027"
    },
    {
      "line": 171,
      "value": "#Then user should be registered successfully"
    },
    {
      "line": 172,
      "value": "#And APIBanking should be enabled in CADM for the group \u0027\u003cGroupIDB\u003e\u0027"
    },
    {
      "line": 173,
      "value": "#When user modifies Stub with amount \u0027\u003cAmount\u003e\u0027 account number \u0027\u003cAccountNo\u003e\u0027 transaction type \u0027\u003cCreditDebit\u003e\u0027 Currency Code \u0027INR\u0027 BIC \u0027SCBLINBBXXX\u0027"
    }
  ],
  "line": 174,
  "name": "Recover response should be displayed with amount \u00275555\u0027 accountNo \u002717082017\u0027 transactionType \u0027D\u0027 the expected value for the group \u0027INDGROUP\u0027",
  "matchedColumns": [
    0,
    1,
    2,
    3
  ],
  "keyword": "Then "
});
formatter.step({
  "line": 175,
  "name": "Consume response should be displayed with amount \u00275555\u0027 accountNo \u002717082017\u0027 transactionType \u0027D\u0027 the expected value for the group \u0027INDGROUP\u0027",
  "matchedColumns": [
    0,
    1,
    2,
    4
  ],
  "keyword": "Then "
});
formatter.match({
  "arguments": [
    {
      "val": "activationKey and activate",
      "offset": 1
    }
  ],
  "location": "commonApiMethods.an_API(String)"
});
formatter.result({
  "duration": 74005,
  "status": "passed"
});
formatter.match({
  "location": "activationKey.user_has_valid_SSL_certificate()"
});
formatter.result({
  "duration": 589025,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "INDGROUP",
      "offset": 56
    }
  ],
  "location": "activationKey.user_has_already_generated_the_JWT_token_for_the_group(String)"
});
formatter.result({
  "duration": 16590137,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "INDGROUP",
      "offset": 56
    }
  ],
  "location": "activationKey.a_POST_request_is_made_to_axway_endpoint(String)"
});
formatter.result({
  "duration": 1479931401,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "5555",
      "offset": 50
    },
    {
      "val": "17082017",
      "offset": 67
    },
    {
      "val": "D",
      "offset": 94
    },
    {
      "val": "INDGROUP",
      "offset": 131
    }
  ],
  "location": "PeekAndConsume.recoverValueTest(String,String,String,String)"
});
formatter.result({
  "duration": 673190757,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "5555",
      "offset": 50
    },
    {
      "val": "17082017",
      "offset": 67
    },
    {
      "val": "D",
      "offset": 94
    },
    {
      "val": "INDGROUP",
      "offset": 131
    }
  ],
  "location": "PeekAndConsume.consumeValueTest(String,String,String,String)"
});
formatter.result({
  "duration": 1030705611,
  "error_message": "java.lang.AssertionError: Consume Response is not displayed as expected. Expected Response - [{\"groupId\":\"INDGROUP\",\"transactionIdentifier\":{\"type\":\"Other\",\"identifiercreditDate\":\"2015-11-16\",\"accountIdentifier\":{\"accountId\":\"17082017\",\"currencyCode\":{\"isoCode\":\"INR\"},\"bankCode\":\"SCBLINBBXXX\"},\"debitDate\":\"2015-11-16\",\"adviceType\":\"Debit\",\"transactionCode\":\"002\",\"transactionDescription\":\"UPIPAY-SCBAccttoBeneAcctSCB\u0026Non-SCB-DR\",\"postExecutionBalance\":{\"currencyCode\":\"INR\",\"amount\":99803990},\"preExecutionBalance\":{\"currencyCode\":\"INR\",\"amount\":99809545},\"transactionFreeText\":[\"UPI/715615346607/\",\"UPICYCLE2/SIVAAACHEN@SCBL/\",\"75110011017/EMAILSLOWNESS/\",\"123-13123-13123\"],\"transactionAmount\":{\"currencyCode\":\"INR\",\"amount\":5555},\"clientIdentifier\":{\"type\":\"Other\",\"identifier\":\"\"},\"externalIdentifier\":{\"type\":\"Other\",\"identifier\":\"\"}}]. Actual Response - ]\r\n\tat org.junit.Assert.fail(Assert.java:88)\r\n\tat org.junit.Assert.assertTrue(Assert.java:41)\r\n\tat ab.glue.api.PeekAndConsume.consumeValueTest(PeekAndConsume.java:164)\r\n\tat ✽.Then Consume response should be displayed with amount \u00275555\u0027 accountNo \u002717082017\u0027 transactionType \u0027D\u0027 the expected value for the group \u0027INDGROUP\u0027(features/api/pull.feature:175)\r\n",
  "status": "failed"
});
});