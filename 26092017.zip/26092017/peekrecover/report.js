$(document).ready(function() {var formatter = new CucumberHTML.DOMFormatter($('.cucumber-report'));formatter.uri("features/api/pull.feature");
formatter.feature({
  "line": 1,
  "name": "Pull Mechanism scenarios",
  "description": "",
  "id": "pull-mechanism-scenarios",
  "keyword": "Feature"
});
formatter.scenarioOutline({
  "line": 50,
  "name": "TC_PULL_003 - When both webhook is down, verify messages for Peek of Group A and Recover of Group B",
  "description": "",
  "id": "pull-mechanism-scenarios;tc-pull-003---when-both-webhook-is-down,-verify-messages-for-peek-of-group-a-and-recover-of-group-b",
  "type": "scenario_outline",
  "keyword": "Scenario Outline",
  "tags": [
    {
      "line": 49,
      "name": "@ab"
    },
    {
      "line": 49,
      "name": "@peekAndConsume"
    },
    {
      "line": 49,
      "name": "@regression"
    },
    {
      "line": 49,
      "name": "@pull"
    },
    {
      "line": 49,
      "name": "@pull3"
    }
  ]
});
formatter.step({
  "comments": [
    {
      "line": 51,
      "value": "#When Add Group Services of CADM is called for the group \u0027\u003cGroupID\u003e\u0027 to disable the group"
    },
    {
      "line": 52,
      "value": "#Then APIBanking should be disabled in CADM for the group \u0027\u003cGroupID\u003e\u0027"
    },
    {
      "line": 53,
      "value": "#Given \u0027activationKey and activate\u0027 API"
    },
    {
      "line": 54,
      "value": "#And user has valid SSL certificate"
    }
  ],
  "line": 55,
  "name": "user has already generated the JWT token for the group \u0027\u003cGroupIDA\u003e\u0027",
  "keyword": "And "
});
formatter.step({
  "line": 56,
  "name": "a POST request is made to axway endpoint for the group \u0027\u003cGroupIDA\u003e\u0027",
  "keyword": "When "
});
formatter.step({
  "line": 57,
  "name": "user should be registered successfully",
  "keyword": "Then "
});
formatter.step({
  "comments": [
    {
      "line": 58,
      "value": "#And APIBanking should be enabled in CADM for the group \u0027\u003cGroupIDA\u003e\u0027"
    },
    {
      "line": 59,
      "value": "#Given user has already generated the JWT token for the group \u0027\u003cGroupIDB\u003e\u0027"
    },
    {
      "line": 60,
      "value": "#When a POST request is made to axway endpoint for the group \u0027\u003cGroupIDB\u003e\u0027"
    },
    {
      "line": 61,
      "value": "#Then user should be registered successfully"
    },
    {
      "line": 62,
      "value": "#And APIBanking should be enabled in CADM for the group \u0027\u003cGroupIDB\u003e\u0027"
    },
    {
      "line": 63,
      "value": "#When user modifies Stub with amount \u0027\u003cAmount\u003e\u0027 account number \u0027\u003cAccountNo\u003e\u0027 transaction type \u0027\u003cCreditDebit\u003e\u0027 Currency Code \u0027INR\u0027 BIC \u0027SCBLINBBXXX\u0027"
    }
  ],
  "line": 64,
  "name": "Peek response should be displayed with amount \u0027\u003cAmount\u003e\u0027 accountNo \u0027\u003cAccountNo\u003e\u0027 transactionType \u0027\u003cCreditDebit\u003e\u0027 the expected value for the group \u0027\u003cGroupIDA\u003e\u0027",
  "keyword": "Then "
});
formatter.step({
  "line": 65,
  "name": "Recover response should be displayed with amount \u0027\u003cAmount\u003e\u0027 accountNo \u0027\u003cAccountNo\u003e\u0027 transactionType \u0027\u003cCreditDebit\u003e\u0027 the expected value for the group \u0027\u003cGroupIDB\u003e\u0027",
  "keyword": "Then "
});
formatter.examples({
  "line": 66,
  "name": "",
  "description": "",
  "id": "pull-mechanism-scenarios;tc-pull-003---when-both-webhook-is-down,-verify-messages-for-peek-of-group-a-and-recover-of-group-b;",
  "rows": [
    {
      "cells": [
        "Amount",
        "AccountNo",
        "CreditDebit",
        "GroupIDA",
        "GroupIDB"
      ],
      "line": 67,
      "id": "pull-mechanism-scenarios;tc-pull-003---when-both-webhook-is-down,-verify-messages-for-peek-of-group-a-and-recover-of-group-b;;1"
    },
    {
      "cells": [
        "5555",
        "17082017",
        "D",
        "INDGROUP",
        "INDGRP"
      ],
      "line": 68,
      "id": "pull-mechanism-scenarios;tc-pull-003---when-both-webhook-is-down,-verify-messages-for-peek-of-group-a-and-recover-of-group-b;;2"
    },
    {
      "cells": [
        "5555",
        "17082017",
        "D",
        "INDGROUP",
        "INDGRP"
      ],
      "line": 69,
      "id": "pull-mechanism-scenarios;tc-pull-003---when-both-webhook-is-down,-verify-messages-for-peek-of-group-a-and-recover-of-group-b;;3"
    }
  ],
  "keyword": "Examples"
});
formatter.before({
  "duration": 563892117,
  "status": "passed"
});
formatter.scenario({
  "line": 68,
  "name": "TC_PULL_003 - When both webhook is down, verify messages for Peek of Group A and Recover of Group B",
  "description": "",
  "id": "pull-mechanism-scenarios;tc-pull-003---when-both-webhook-is-down,-verify-messages-for-peek-of-group-a-and-recover-of-group-b;;2",
  "type": "scenario",
  "keyword": "Scenario Outline",
  "tags": [
    {
      "line": 49,
      "name": "@ab"
    },
    {
      "line": 49,
      "name": "@peekAndConsume"
    },
    {
      "line": 49,
      "name": "@regression"
    },
    {
      "line": 49,
      "name": "@pull3"
    },
    {
      "line": 49,
      "name": "@pull"
    }
  ]
});
formatter.step({
  "comments": [
    {
      "line": 51,
      "value": "#When Add Group Services of CADM is called for the group \u0027\u003cGroupID\u003e\u0027 to disable the group"
    },
    {
      "line": 52,
      "value": "#Then APIBanking should be disabled in CADM for the group \u0027\u003cGroupID\u003e\u0027"
    },
    {
      "line": 53,
      "value": "#Given \u0027activationKey and activate\u0027 API"
    },
    {
      "line": 54,
      "value": "#And user has valid SSL certificate"
    }
  ],
  "line": 55,
  "name": "user has already generated the JWT token for the group \u0027INDGROUP\u0027",
  "matchedColumns": [
    3
  ],
  "keyword": "And "
});
formatter.step({
  "line": 56,
  "name": "a POST request is made to axway endpoint for the group \u0027INDGROUP\u0027",
  "matchedColumns": [
    3
  ],
  "keyword": "When "
});
formatter.step({
  "line": 57,
  "name": "user should be registered successfully",
  "keyword": "Then "
});
formatter.step({
  "comments": [
    {
      "line": 58,
      "value": "#And APIBanking should be enabled in CADM for the group \u0027\u003cGroupIDA\u003e\u0027"
    },
    {
      "line": 59,
      "value": "#Given user has already generated the JWT token for the group \u0027\u003cGroupIDB\u003e\u0027"
    },
    {
      "line": 60,
      "value": "#When a POST request is made to axway endpoint for the group \u0027\u003cGroupIDB\u003e\u0027"
    },
    {
      "line": 61,
      "value": "#Then user should be registered successfully"
    },
    {
      "line": 62,
      "value": "#And APIBanking should be enabled in CADM for the group \u0027\u003cGroupIDB\u003e\u0027"
    },
    {
      "line": 63,
      "value": "#When user modifies Stub with amount \u0027\u003cAmount\u003e\u0027 account number \u0027\u003cAccountNo\u003e\u0027 transaction type \u0027\u003cCreditDebit\u003e\u0027 Currency Code \u0027INR\u0027 BIC \u0027SCBLINBBXXX\u0027"
    }
  ],
  "line": 64,
  "name": "Peek response should be displayed with amount \u00275555\u0027 accountNo \u002717082017\u0027 transactionType \u0027D\u0027 the expected value for the group \u0027INDGROUP\u0027",
  "matchedColumns": [
    0,
    1,
    2,
    3
  ],
  "keyword": "Then "
});
formatter.step({
  "line": 65,
  "name": "Recover response should be displayed with amount \u00275555\u0027 accountNo \u002717082017\u0027 transactionType \u0027D\u0027 the expected value for the group \u0027INDGRP\u0027",
  "matchedColumns": [
    0,
    1,
    2,
    4
  ],
  "keyword": "Then "
});
formatter.match({
  "arguments": [
    {
      "val": "INDGROUP",
      "offset": 56
    }
  ],
  "location": "activationKey.user_has_already_generated_the_JWT_token_for_the_group(String)"
});
formatter.result({
  "duration": 815115005,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "INDGROUP",
      "offset": 56
    }
  ],
  "location": "activationKey.a_POST_request_is_made_to_axway_endpoint(String)"
});
formatter.result({
  "duration": 13431291466,
  "status": "passed"
});
formatter.match({
  "location": "activationKey.user_should_be_registered_successfully()"
});
formatter.result({
  "duration": 94772,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "5555",
      "offset": 47
    },
    {
      "val": "17082017",
      "offset": 64
    },
    {
      "val": "D",
      "offset": 91
    },
    {
      "val": "INDGROUP",
      "offset": 128
    }
  ],
  "location": "PeekAndConsume.peekValueTest(String,String,String,String)"
});
formatter.result({
  "duration": 1498437005,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "5555",
      "offset": 50
    },
    {
      "val": "17082017",
      "offset": 67
    },
    {
      "val": "D",
      "offset": 94
    },
    {
      "val": "INDGRP",
      "offset": 131
    }
  ],
  "location": "PeekAndConsume.recoverValueTest(String,String,String,String)"
});
formatter.result({
  "duration": 1147200561,
  "status": "passed"
});
formatter.before({
  "duration": 20762403,
  "status": "passed"
});
formatter.scenario({
  "line": 69,
  "name": "TC_PULL_003 - When both webhook is down, verify messages for Peek of Group A and Recover of Group B",
  "description": "",
  "id": "pull-mechanism-scenarios;tc-pull-003---when-both-webhook-is-down,-verify-messages-for-peek-of-group-a-and-recover-of-group-b;;3",
  "type": "scenario",
  "keyword": "Scenario Outline",
  "tags": [
    {
      "line": 49,
      "name": "@ab"
    },
    {
      "line": 49,
      "name": "@peekAndConsume"
    },
    {
      "line": 49,
      "name": "@regression"
    },
    {
      "line": 49,
      "name": "@pull3"
    },
    {
      "line": 49,
      "name": "@pull"
    }
  ]
});
formatter.step({
  "comments": [
    {
      "line": 51,
      "value": "#When Add Group Services of CADM is called for the group \u0027\u003cGroupID\u003e\u0027 to disable the group"
    },
    {
      "line": 52,
      "value": "#Then APIBanking should be disabled in CADM for the group \u0027\u003cGroupID\u003e\u0027"
    },
    {
      "line": 53,
      "value": "#Given \u0027activationKey and activate\u0027 API"
    },
    {
      "line": 54,
      "value": "#And user has valid SSL certificate"
    }
  ],
  "line": 55,
  "name": "user has already generated the JWT token for the group \u0027INDGROUP\u0027",
  "matchedColumns": [
    3
  ],
  "keyword": "And "
});
formatter.step({
  "line": 56,
  "name": "a POST request is made to axway endpoint for the group \u0027INDGROUP\u0027",
  "matchedColumns": [
    3
  ],
  "keyword": "When "
});
formatter.step({
  "line": 57,
  "name": "user should be registered successfully",
  "keyword": "Then "
});
formatter.step({
  "comments": [
    {
      "line": 58,
      "value": "#And APIBanking should be enabled in CADM for the group \u0027\u003cGroupIDA\u003e\u0027"
    },
    {
      "line": 59,
      "value": "#Given user has already generated the JWT token for the group \u0027\u003cGroupIDB\u003e\u0027"
    },
    {
      "line": 60,
      "value": "#When a POST request is made to axway endpoint for the group \u0027\u003cGroupIDB\u003e\u0027"
    },
    {
      "line": 61,
      "value": "#Then user should be registered successfully"
    },
    {
      "line": 62,
      "value": "#And APIBanking should be enabled in CADM for the group \u0027\u003cGroupIDB\u003e\u0027"
    },
    {
      "line": 63,
      "value": "#When user modifies Stub with amount \u0027\u003cAmount\u003e\u0027 account number \u0027\u003cAccountNo\u003e\u0027 transaction type \u0027\u003cCreditDebit\u003e\u0027 Currency Code \u0027INR\u0027 BIC \u0027SCBLINBBXXX\u0027"
    }
  ],
  "line": 64,
  "name": "Peek response should be displayed with amount \u00275555\u0027 accountNo \u002717082017\u0027 transactionType \u0027D\u0027 the expected value for the group \u0027INDGROUP\u0027",
  "matchedColumns": [
    0,
    1,
    2,
    3
  ],
  "keyword": "Then "
});
formatter.step({
  "line": 65,
  "name": "Recover response should be displayed with amount \u00275555\u0027 accountNo \u002717082017\u0027 transactionType \u0027D\u0027 the expected value for the group \u0027INDGRP\u0027",
  "matchedColumns": [
    0,
    1,
    2,
    4
  ],
  "keyword": "Then "
});
formatter.match({
  "arguments": [
    {
      "val": "INDGROUP",
      "offset": 56
    }
  ],
  "location": "activationKey.user_has_already_generated_the_JWT_token_for_the_group(String)"
});
formatter.result({
  "duration": 11839795,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "INDGROUP",
      "offset": 56
    }
  ],
  "location": "activationKey.a_POST_request_is_made_to_axway_endpoint(String)"
});
formatter.result({
  "duration": 2581500966,
  "status": "passed"
});
formatter.match({
  "location": "activationKey.user_should_be_registered_successfully()"
});
formatter.result({
  "duration": 97038,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "5555",
      "offset": 47
    },
    {
      "val": "17082017",
      "offset": 64
    },
    {
      "val": "D",
      "offset": 91
    },
    {
      "val": "INDGROUP",
      "offset": 128
    }
  ],
  "location": "PeekAndConsume.peekValueTest(String,String,String,String)"
});
formatter.result({
  "duration": 1868839064,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "5555",
      "offset": 50
    },
    {
      "val": "17082017",
      "offset": 67
    },
    {
      "val": "D",
      "offset": 94
    },
    {
      "val": "INDGRP",
      "offset": 131
    }
  ],
  "location": "PeekAndConsume.recoverValueTest(String,String,String,String)"
});
formatter.result({
  "duration": 2295434560,
  "status": "passed"
});
});