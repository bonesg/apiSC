$(document).ready(function() {var formatter = new CucumberHTML.DOMFormatter($('.cucumber-report'));formatter.uri("features/api/endToEnd.feature");
formatter.feature({
  "line": 1,
  "name": "End to End Scenarios for APIBanking",
  "description": "",
  "id": "end-to-end-scenarios-for-apibanking",
  "keyword": "Feature"
});
formatter.scenarioOutline({
  "line": 126,
  "name": "TC_007 - When information services is turned off, Peek consume, recover and webhook messages should not be displayed.",
  "description": "",
  "id": "end-to-end-scenarios-for-apibanking;tc-007---when-information-services-is-turned-off,-peek-consume,-recover-and-webhook-messages-should-not-be-displayed.",
  "type": "scenario_outline",
  "keyword": "Scenario Outline",
  "tags": [
    {
      "line": 125,
      "name": "@ab"
    },
    {
      "line": 125,
      "name": "@tc7"
    },
    {
      "line": 125,
      "name": "@regression"
    }
  ]
});
formatter.step({
  "line": 127,
  "name": "\u0027activationKey and activate\u0027 API",
  "keyword": "Given "
});
formatter.step({
  "line": 128,
  "name": "user has valid SSL certificate",
  "keyword": "And "
});
formatter.step({
  "line": 129,
  "name": "user has already generated the JWT token for the group \u0027\u003cGroupID\u003e\u0027",
  "keyword": "And "
});
formatter.step({
  "comments": [
    {
      "line": 130,
      "value": "#When Add Group Services of CADM is called for the group \u0027\u003cGroupID\u003e\u0027 to disable the group"
    },
    {
      "line": 131,
      "value": "#Then APIBanking should be disabled in CADM for the group \u0027\u003cGroupID\u003e\u0027"
    }
  ],
  "line": 132,
  "name": "a POST request is made to axway endpoint for the group \u0027\u003cGroupID\u003e\u0027",
  "keyword": "When "
});
formatter.step({
  "comments": [
    {
      "line": 133,
      "value": "#Then user should be registered successfully"
    },
    {
      "line": 134,
      "value": "#Then APIBanking should be enabled in CADM for the group \u0027\u003cGroupID\u003e\u0027"
    },
    {
      "line": 135,
      "value": "#When the webhook is turned off"
    },
    {
      "line": 136,
      "value": "#When user modifies Stub with amount \u0027\u003cAmount\u003e\u0027 account number \u0027\u003cAccountNo\u003e\u0027 transaction type \u0027\u003cCreditDebit\u003e\u0027 Currency Code \u0027INR\u0027 BIC \u0027SCBLINBBXXX\u0027"
    }
  ],
  "line": 137,
  "name": "Peek response should be displayed with the empty message for the group \u0027\u003cGroupID\u003e\u0027",
  "keyword": "Then "
});
formatter.examples({
  "comments": [
    {
      "line": 138,
      "value": "#And Consume response should be displayed with the empty message for the group \u0027\u003cGroupID\u003e\u0027"
    },
    {
      "line": 139,
      "value": "#And Recover response should be displayed with the empty message for the group \u0027\u003cGroupID\u003e\u0027"
    },
    {
      "line": 140,
      "value": "#When the Webhook is turned on"
    },
    {
      "line": 141,
      "value": "#Then Webhook should be displayed with the empty message"
    }
  ],
  "line": 142,
  "name": "",
  "description": "",
  "id": "end-to-end-scenarios-for-apibanking;tc-007---when-information-services-is-turned-off,-peek-consume,-recover-and-webhook-messages-should-not-be-displayed.;",
  "rows": [
    {
      "cells": [
        "Amount",
        "AccountNo",
        "CreditDebit",
        "GroupID"
      ],
      "line": 143,
      "id": "end-to-end-scenarios-for-apibanking;tc-007---when-information-services-is-turned-off,-peek-consume,-recover-and-webhook-messages-should-not-be-displayed.;;1"
    },
    {
      "cells": [
        "3260",
        "22505806238",
        "D",
        "INRCMS02"
      ],
      "line": 144,
      "id": "end-to-end-scenarios-for-apibanking;tc-007---when-information-services-is-turned-off,-peek-consume,-recover-and-webhook-messages-should-not-be-displayed.;;2"
    }
  ],
  "keyword": "Examples"
});
formatter.before({
  "duration": 651724921,
  "status": "passed"
});
formatter.scenario({
  "line": 144,
  "name": "TC_007 - When information services is turned off, Peek consume, recover and webhook messages should not be displayed.",
  "description": "",
  "id": "end-to-end-scenarios-for-apibanking;tc-007---when-information-services-is-turned-off,-peek-consume,-recover-and-webhook-messages-should-not-be-displayed.;;2",
  "type": "scenario",
  "keyword": "Scenario Outline",
  "tags": [
    {
      "line": 125,
      "name": "@ab"
    },
    {
      "line": 125,
      "name": "@regression"
    },
    {
      "line": 125,
      "name": "@tc7"
    }
  ]
});
formatter.step({
  "line": 127,
  "name": "\u0027activationKey and activate\u0027 API",
  "keyword": "Given "
});
formatter.step({
  "line": 128,
  "name": "user has valid SSL certificate",
  "keyword": "And "
});
formatter.step({
  "line": 129,
  "name": "user has already generated the JWT token for the group \u0027INRCMS02\u0027",
  "matchedColumns": [
    3
  ],
  "keyword": "And "
});
formatter.step({
  "comments": [
    {
      "line": 130,
      "value": "#When Add Group Services of CADM is called for the group \u0027\u003cGroupID\u003e\u0027 to disable the group"
    },
    {
      "line": 131,
      "value": "#Then APIBanking should be disabled in CADM for the group \u0027\u003cGroupID\u003e\u0027"
    }
  ],
  "line": 132,
  "name": "a POST request is made to axway endpoint for the group \u0027INRCMS02\u0027",
  "matchedColumns": [
    3
  ],
  "keyword": "When "
});
formatter.step({
  "comments": [
    {
      "line": 133,
      "value": "#Then user should be registered successfully"
    },
    {
      "line": 134,
      "value": "#Then APIBanking should be enabled in CADM for the group \u0027\u003cGroupID\u003e\u0027"
    },
    {
      "line": 135,
      "value": "#When the webhook is turned off"
    },
    {
      "line": 136,
      "value": "#When user modifies Stub with amount \u0027\u003cAmount\u003e\u0027 account number \u0027\u003cAccountNo\u003e\u0027 transaction type \u0027\u003cCreditDebit\u003e\u0027 Currency Code \u0027INR\u0027 BIC \u0027SCBLINBBXXX\u0027"
    }
  ],
  "line": 137,
  "name": "Peek response should be displayed with the empty message for the group \u0027INRCMS02\u0027",
  "matchedColumns": [
    3
  ],
  "keyword": "Then "
});
formatter.match({
  "arguments": [
    {
      "val": "activationKey and activate",
      "offset": 1
    }
  ],
  "location": "commonApiMethods.an_API(String)"
});
formatter.result({
  "duration": 243232528,
  "status": "passed"
});
formatter.match({
  "location": "activationKey.user_has_valid_SSL_certificate()"
});
formatter.result({
  "duration": 55864563,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "INRCMS02",
      "offset": 56
    }
  ],
  "location": "activationKey.user_has_already_generated_the_JWT_token_for_the_group(String)"
});
formatter.result({
  "duration": 563078052,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "INRCMS02",
      "offset": 56
    }
  ],
  "location": "activationKey.a_POST_request_is_made_to_axway_endpoint(String)"
});
formatter.result({
  "duration": 5933321528,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "INRCMS02",
      "offset": 72
    }
  ],
  "location": "PeekAndConsume.peekEmptyTest(String)"
});
formatter.result({
  "duration": 1571301381,
  "error_message": "java.lang.AssertionError: Peek Response is not displayed as expected. Expected Response - []. Actual Response - [{\"groupId\":\"INRCMS02\",\"transactionIdentifier\":{\"type\":\"Other\",\"identifier\":\"201511162394227\"},\"creditDate\":\"2015-11-16\",\"accountIdentifier\":{\"accountId\":\"22205269504\",\"currencyCode\":{\"isoCode\":\"INR\"},\"bankCode\":\"SCBLINBBXXX\"},\"debitDate\":\"2015-11-16\",\"adviceType\":\"Credit\",\"transactionCode\":null,\"transactionDescription\":\"Cash Deposits Customer in Person-credit\",\"postExecutionBalance\":{\"currencyCode\":\"INR\",\"amount\":138522.11},\"preExecutionBalance\":{\"currencyCode\":\"INR\",\"amount\":138078.110},\"transactionFreeText\":[\"CASH DEPOSIT\",\"2015-11-16100SUPPORTM1585\",\"22205269504\"],\"transactionAmount\":{\"currencyCode\":\"INR\",\"amount\":444.00},\"clientIdentifier\":{\"type\":\"Other\",\"identifier\":\"\"},\"externalIdentifier\":{\"type\":\"Other\",\"identifier\":\"\"}},{\"groupId\":\"INRCMS02\",\"transactionIdentifier\":{\"type\":\"Other\",\"identifier\":\"201511162394231\"},\"creditDate\":\"2015-11-16\",\"accountIdentifier\":{\"accountId\":\"22205269504\",\"currencyCode\":{\"isoCode\":\"INR\"},\"bankCode\":\"SCBLINBBXXX\"},\"debitDate\":\"2015-11-16\",\"adviceType\":\"Debit\",\"transactionCode\":null,\"transactionDescription\":\"Cash Withdrawal LcY-Debit\",\"postExecutionBalance\":{\"currencyCode\":\"INR\",\"amount\":138621.11},\"preExecutionBalance\":{\"currencyCode\":\"INR\",\"amount\":139188.11},\"transactionFreeText\":[\"CASH WITHDRAWAL -LCY\",\"2015-11-16100SUPPORTM1587\",\"22205269504\"],\"transactionAmount\":{\"currencyCode\":\"INR\",\"amount\":567.00},\"clientIdentifier\":{\"type\":\"Other\",\"identifier\":\"\"},\"externalIdentifier\":{\"type\":\"Other\",\"identifier\":\"\"}},{\"groupId\":\"INRCMS02\",\"transactionIdentifier\":{\"type\":\"Other\",\"identifier\":\"201511162394237\"},\"creditDate\":\"2015-11-16\",\"accountIdentifier\":{\"accountId\":\"22205269504\",\"currencyCode\":{\"isoCode\":\"INR\"},\"bankCode\":\"SCBLINBBXXX\"},\"debitDate\":\"2015-11-16\",\"adviceType\":\"Credit\",\"transactionCode\":null,\"transactionDescription\":\"Cash Deposits Customer in Person-credit\",\"postExecutionBalance\":{\"currencyCode\":\"INR\",\"amount\":140843.11},\"preExecutionBalance\":{\"currencyCode\":\"INR\",\"amount\":130967.110},\"transactionFreeText\":[\"CASH DEPOSIT\",\"2015-11-16100SUPPORTM1590\",\"22205269504\"],\"transactionAmount\":{\"currencyCode\":\"INR\",\"amount\":9876.00},\"clientIdentifier\":{\"type\":\"Other\",\"identifier\":\"\"},\"externalIdentifier\":{\"type\":\"Other\",\"identifier\":\"\"}},{\"groupId\":\"INRCMS02\",\"transactionIdentifier\":{\"type\":\"Other\",\"identifier\":\"201511162394214\"},\"creditDate\":\"2015-11-16\",\"accountIdentifier\":{\"accountId\":\"22205269504\",\"currencyCode\":{\"isoCode\":\"INR\"},\"bankCode\":\"SCBLINBBXXX\"},\"debitDate\":\"2015-11-16\",\"adviceType\":\"Credit\",\"transactionCode\":null,\"transactionDescription\":\"Cash Deposits Customer in Person-credit\",\"postExecutionBalance\":{\"currencyCode\":\"INR\",\"amount\":138543.11},\"preExecutionBalance\":{\"currencyCode\":\"INR\",\"amount\":138384.110},\"transactionFreeText\":[\"CASH DEPOSIT\",\"2015-11-16100SUPPORTM1580\",\"22205269504\"],\"transactionAmount\":{\"currencyCode\":\"INR\",\"amount\":159.00},\"clientIdentifier\":{\"type\":\"Other\",\"identifier\":\"\"},\"externalIdentifier\":{\"type\":\"Other\",\"identifier\":\"\"}},{\"groupId\":\"INRCMS02\",\"transactionIdentifier\":{\"type\":\"Other\",\"identifier\":\"201511162394225\"},\"creditDate\":\"2015-11-16\",\"accountIdentifier\":{\"accountId\":\"22205269504\",\"currencyCode\":{\"isoCode\":\"INR\"},\"bankCode\":\"SCBLINBBXXX\"},\"debitDate\":\"2015-11-16\",\"adviceType\":\"Credit\",\"transactionCode\":null,\"transactionDescription\":\"Cash Deposits Customer in Person-credit\",\"postExecutionBalance\":{\"currencyCode\":\"INR\",\"amount\":138078.11},\"preExecutionBalance\":{\"currencyCode\":\"INR\",\"amount\":137745.110},\"transactionFreeText\":[\"CASH DEPOSIT\",\"2015-11-16100SUPPORTM1584\",\"22205269504\"],\"transactionAmount\":{\"currencyCode\":\"INR\",\"amount\":333.00},\"clientIdentifier\":{\"type\":\"Other\",\"identifier\":\"\"},\"externalIdentifier\":{\"type\":\"Other\",\"identifier\":\"\"}},{\"groupId\":\"INRCMS02\",\"transactionIdentifier\":{\"type\":\"Other\",\"identifier\":\"201511162394227\"},\"creditDate\":\"2015-11-16\",\"accountIdentifier\":{\"accountId\":\"22205269504\",\"currencyCode\":{\"isoCode\":\"INR\"},\"bankCode\":\"SCBLINBBXXX\"},\"debitDate\":\"2015-11-16\",\"adviceType\":\"Credit\",\"transactionCode\":null,\"transactionDescription\":\"Cash Deposits Customer in Person-credit\",\"postExecutionBalance\":{\"currencyCode\":\"INR\",\"amount\":138522.11},\"preExecutionBalance\":{\"currencyCode\":\"INR\",\"amount\":138078.110},\"transactionFreeText\":[\"CASH DEPOSIT\",\"2015-11-16100SUPPORTM1585\",\"22205269504\"],\"transactionAmount\":{\"currencyCode\":\"INR\",\"amount\":444.00},\"clientIdentifier\":{\"type\":\"Other\",\"identifier\":\"\"},\"externalIdentifier\":{\"type\":\"Other\",\"identifier\":\"\"}},{\"groupId\":\"INRCMS02\",\"transactionIdentifier\":{\"type\":\"Other\",\"identifier\":\"201511162394227\"},\"creditDate\":\"2015-11-16\",\"accountIdentifier\":{\"accountId\":\"22205269504\",\"currencyCode\":{\"isoCode\":\"INR\"},\"bankCode\":\"SCBLINBBXXX\"},\"debitDate\":\"2015-11-16\",\"adviceType\":\"Credit\",\"transactionCode\":null,\"transactionDescription\":\"Cash Deposits Customer in Person-credit\",\"postExecutionBalance\":{\"currencyCode\":\"INR\",\"amount\":138522.11},\"preExecutionBalance\":{\"currencyCode\":\"INR\",\"amount\":138078.110},\"transactionFreeText\":[\"CASH DEPOSIT\",\"2015-11-16100SUPPORTM1585\",\"22205269504\"],\"transactionAmount\":{\"currencyCode\":\"INR\",\"amount\":444.00},\"clientIdentifier\":{\"type\":\"Other\",\"identifier\":\"\"},\"externalIdentifier\":{\"type\":\"Other\",\"identifier\":\"\"}},{\"groupId\":\"INRCMS02\",\"transactionIdentifier\":{\"type\":\"Other\",\"identifier\":\"201511162394227\"},\"creditDate\":\"2015-11-16\",\"accountIdentifier\":{\"accountId\":\"22205269504\",\"currencyCode\":{\"isoCode\":\"INR\"},\"bankCode\":\"SCBLINBBXXX\"},\"debitDate\":\"2015-11-16\",\"adviceType\":\"Credit\",\"transactionCode\":null,\"transactionDescription\":\"Cash Deposits Customer in Person-credit\",\"postExecutionBalance\":{\"currencyCode\":\"INR\",\"amount\":138522.11},\"preExecutionBalance\":{\"currencyCode\":\"INR\",\"amount\":138078.110},\"transactionFreeText\":[\"CASH DEPOSIT\",\"2015-11-16100SUPPORTM1585\",\"22205269504\"],\"transactionAmount\":{\"currencyCode\":\"INR\",\"amount\":444.00},\"clientIdentifier\":{\"type\":\"Other\",\"identifier\":\"\"},\"externalIdentifier\":{\"type\":\"Other\",\"identifier\":\"\"}},{\"groupId\":\"INRCMS02\",\"transactionIdentifier\":{\"type\":\"Other\",\"identifier\":\"201511162394229\"},\"creditDate\":\"2015-11-16\",\"accountIdentifier\":{\"accountId\":\"22205269504\",\"currencyCode\":{\"isoCode\":\"INR\"},\"bankCode\":\"SCBLINBBXXX\"},\"debitDate\":\"2015-11-16\",\"adviceType\":\"Credit\",\"transactionCode\":null,\"transactionDescription\":\"Cash Deposits Customer in Person-credit\",\"postExecutionBalance\":{\"currencyCode\":\"INR\",\"amount\":139188.11},\"preExecutionBalance\":{\"currencyCode\":\"INR\",\"amount\":138522.110},\"transactionFreeText\":[\"CASH DEPOSIT\",\"2015-11-16100SUPPORTM1586\",\"22205269504\"],\"transactionAmount\":{\"currencyCode\":\"INR\",\"amount\":666.00},\"clientIdentifier\":{\"type\":\"Other\",\"identifier\":\"\"},\"externalIdentifier\":{\"type\":\"Other\",\"identifier\":\"\"}},{\"groupId\":\"INRCMS02\",\"transactionIdentifier\":{\"type\":\"Other\",\"identifier\":\"201511162394233\"},\"creditDate\":\"2015-11-16\",\"accountIdentifier\":{\"accountId\":\"22205269504\",\"currencyCode\":{\"isoCode\":\"INR\"},\"bankCode\":\"SCBLINBBXXX\"},\"debitDate\":\"2015-11-16\",\"adviceType\":\"Credit\",\"transactionCode\":null,\"transactionDescription\":\"Cash Deposits Customer in Person-credit\",\"postExecutionBalance\":{\"currencyCode\":\"INR\",\"amount\":139855.11},\"preExecutionBalance\":{\"currencyCode\":\"INR\",\"amount\":138621.110},\"transactionFreeText\":[\"CASH DEPOSIT\",\"2015-11-16100SUPPORTM1588\",\"22205269504\"],\"transactionAmount\":{\"currencyCode\":\"INR\",\"amount\":1234.00},\"clientIdentifier\":{\"type\":\"Other\",\"identifier\":\"\"},\"externalIdentifier\":{\"type\":\"Other\",\"identifier\":\"\"}},{\"groupId\":\"INRCMS02\",\"transactionIdentifier\":{\"type\":\"Other\",\"identifier\":\"201511162394235\"},\"creditDate\":\"2015-11-16\",\"accountIdentifier\":{\"accountId\":\"22205269504\",\"currencyCode\":{\"isoCode\":\"INR\"},\"bankCode\":\"SCBLINBBXXX\"},\"debitDate\":\"2015-11-16\",\"adviceType\":\"Debit\",\"transactionCode\":null,\"transactionDescription\":\"Cash Withdrawal LcY-Debit\",\"postExecutionBalance\":{\"currencyCode\":\"INR\",\"amount\":130967.11},\"preExecutionBalance\":{\"currencyCode\":\"INR\",\"amount\":139855.11},\"transactionFreeText\":[\"CASH WITHDRAWAL -LCY\",\"2015-11-16100SUPPORTM1589\",\"22205269504\"],\"transactionAmount\":{\"currencyCode\":\"INR\",\"amount\":8888.00},\"clientIdentifier\":{\"type\":\"Other\",\"identifier\":\"\"},\"externalIdentifier\":{\"type\":\"Other\",\"identifier\":\"\"}},{\"groupId\":\"INRCMS02\",\"transactionIdentifier\":{\"type\":\"Other\",\"identifier\":\"201511162394239\"},\"creditDate\":\"2015-11-16\",\"accountIdentifier\":{\"accountId\":\"22205269504\",\"currencyCode\":{\"isoCode\":\"INR\"},\"bankCode\":\"SCBLINBBXXX\"},\"debitDate\":\"2015-11-16\",\"adviceType\":\"Debit\",\"transactionCode\":null,\"transactionDescription\":\"Cash Withdrawal LcY-Debit\",\"postExecutionBalance\":{\"currencyCode\":\"INR\",\"amount\":140776.61},\"preExecutionBalance\":{\"currencyCode\":\"INR\",\"amount\":140843.11},\"transactionFreeText\":[\"CASH WITHDRAWAL -LCY\",\"2015-11-16100SUPPORTM1591\",\"22205269504\"],\"transactionAmount\":{\"currencyCode\":\"INR\",\"amount\":66.50},\"clientIdentifier\":{\"type\":\"Other\",\"identifier\":\"\"},\"externalIdentifier\":{\"type\":\"Other\",\"identifier\":\"\"}}]\r\n\tat org.junit.Assert.fail(Assert.java:88)\r\n\tat org.junit.Assert.assertTrue(Assert.java:41)\r\n\tat ab.glue.api.PeekAndConsume.peekEmptyTest(PeekAndConsume.java:273)\r\n\tat ✽.Then Peek response should be displayed with the empty message for the group \u0027INRCMS02\u0027(features/api/endToEnd.feature:137)\r\n",
  "status": "failed"
});
});