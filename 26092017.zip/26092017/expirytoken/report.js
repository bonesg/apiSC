$(document).ready(function() {var formatter = new CucumberHTML.DOMFormatter($('.cucumber-report'));formatter.uri("features/api/activationKey.feature");
formatter.feature({
  "line": 1,
  "name": "Generate Activation Key and JWT",
  "description": "",
  "id": "generate-activation-key-and-jwt",
  "keyword": "Feature"
});
formatter.before({
  "duration": 955382808,
  "status": "passed"
});
formatter.scenario({
  "line": 132,
  "name": "Verify error displayed for activate request when an expired token is passed",
  "description": "",
  "id": "generate-activation-key-and-jwt;verify-error-displayed-for-activate-request-when-an-expired-token-is-passed",
  "type": "scenario",
  "keyword": "Scenario",
  "tags": [
    {
      "line": 131,
      "name": "@ab"
    },
    {
      "line": 131,
      "name": "@ExpireToken"
    }
  ]
});
formatter.step({
  "line": 133,
  "name": "\u0027activationKey\u0027 API",
  "keyword": "Given "
});
formatter.step({
  "comments": [
    {
      "line": 134,
      "value": "#When a POST request is made to the activationKey API for group \u0027INDTEST\u0027"
    }
  ],
  "line": 135,
  "name": "user has already generated the JWT token for the group \u0027INDTEST\u0027",
  "keyword": "Given "
});
formatter.step({
  "line": 136,
  "name": "Client generates token and make it expire for the group \u0027INDTEST\u0027",
  "keyword": "When "
});
formatter.step({
  "line": 137,
  "name": "a POST request to axway endpoint for the group \u0027INDTEST\u0027 should return expiry token error",
  "keyword": "Then "
});
formatter.match({
  "arguments": [
    {
      "val": "activationKey",
      "offset": 1
    }
  ],
  "location": "commonApiMethods.an_API(String)"
});
formatter.result({
  "duration": 194990940,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "INDTEST",
      "offset": 56
    }
  ],
  "location": "activationKey.user_has_already_generated_the_JWT_token_for_the_group(String)"
});
formatter.result({
  "duration": 654068186,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "INDTEST",
      "offset": 57
    }
  ],
  "location": "activationKey.verify(String)"
});
formatter.result({
  "duration": 30029087679,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "INDTEST",
      "offset": 48
    }
  ],
  "location": "activationKey.verifyExpiryTokenError(String)"
});
formatter.result({
  "duration": 4695939612,
  "status": "passed"
});
});