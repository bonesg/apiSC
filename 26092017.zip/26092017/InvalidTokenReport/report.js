$(document).ready(function() {var formatter = new CucumberHTML.DOMFormatter($('.cucumber-report'));formatter.uri("features/api/activationKey.feature");
formatter.feature({
  "line": 1,
  "name": "Generate Activation Key and JWT",
  "description": "",
  "id": "generate-activation-key-and-jwt",
  "keyword": "Feature"
});
formatter.scenarioOutline({
  "line": 153,
  "name": "Validate the Activate request with invalid token",
  "description": "",
  "id": "generate-activation-key-and-jwt;validate-the-activate-request-with-invalid-token",
  "type": "scenario_outline",
  "keyword": "Scenario Outline",
  "tags": [
    {
      "line": 152,
      "name": "@ab"
    },
    {
      "line": 152,
      "name": "@invalidToken"
    }
  ]
});
formatter.step({
  "line": 154,
  "name": "\u0027activationKey\u0027 API",
  "keyword": "Given "
});
formatter.step({
  "comments": [
    {
      "line": 155,
      "value": "#And user has already generated the JWT token for the group \u0027\u003cgroup\u003e\u0027"
    }
  ],
  "line": 156,
  "name": "a POST request is made to axway endpoint with the token \u0027\u003ctoken\u003e\u0027",
  "keyword": "When "
});
formatter.step({
  "line": 157,
  "name": "the response should be displayed as 403 error",
  "keyword": "Then "
});
formatter.examples({
  "line": 158,
  "name": "",
  "description": "",
  "id": "generate-activation-key-and-jwt;validate-the-activate-request-with-invalid-token;",
  "rows": [
    {
      "cells": [
        "token",
        "group"
      ],
      "line": 159,
      "id": "generate-activation-key-and-jwt;validate-the-activate-request-with-invalid-token;;1"
    },
    {
      "cells": [
        "",
        "INDGROUP"
      ],
      "line": 160,
      "id": "generate-activation-key-and-jwt;validate-the-activate-request-with-invalid-token;;2"
    },
    {
      "cells": [
        "eyJhbGciOiJSUzI1NiJ9.eyJpc3MiOiJTQ0IiLCJhdWQiOiJTQ0ItQVBJQmFua2luZyIsImlhdCI6MTUwMzUwNTE0MiwiZXhwIj",
        "INDGROUP"
      ],
      "line": 161,
      "id": "generate-activation-key-and-jwt;validate-the-activate-request-with-invalid-token;;3"
    }
  ],
  "keyword": "Examples"
});
formatter.before({
  "duration": 732757497,
  "status": "passed"
});
formatter.scenario({
  "line": 160,
  "name": "Validate the Activate request with invalid token",
  "description": "",
  "id": "generate-activation-key-and-jwt;validate-the-activate-request-with-invalid-token;;2",
  "type": "scenario",
  "keyword": "Scenario Outline",
  "tags": [
    {
      "line": 152,
      "name": "@ab"
    },
    {
      "line": 152,
      "name": "@invalidToken"
    }
  ]
});
formatter.step({
  "line": 154,
  "name": "\u0027activationKey\u0027 API",
  "keyword": "Given "
});
formatter.step({
  "comments": [
    {
      "line": 155,
      "value": "#And user has already generated the JWT token for the group \u0027\u003cgroup\u003e\u0027"
    }
  ],
  "line": 156,
  "name": "a POST request is made to axway endpoint with the token \u0027\u0027",
  "matchedColumns": [
    0
  ],
  "keyword": "When "
});
formatter.step({
  "line": 157,
  "name": "the response should be displayed as 403 error",
  "keyword": "Then "
});
formatter.match({
  "arguments": [
    {
      "val": "activationKey",
      "offset": 1
    }
  ],
  "location": "commonApiMethods.an_API(String)"
});
formatter.result({
  "duration": 183640112,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "",
      "offset": 57
    }
  ],
  "location": "activationKey.a_POST_request_is_made_to_axway_withToken(String)"
});
formatter.result({
  "duration": 3798565646,
  "status": "passed"
});
formatter.match({
  "location": "activationKey.verify400ResponseError()"
});
formatter.result({
  "duration": 1947561,
  "error_message": "java.lang.AssertionError: \r\n\tat org.junit.Assert.fail(Assert.java:88)\r\n\tat org.junit.Assert.assertTrue(Assert.java:41)\r\n\tat ab.glue.api.activationKey.verify400ResponseError(activationKey.java:540)\r\n\tat ✽.Then the response should be displayed as 403 error(features/api/activationKey.feature:157)\r\n",
  "status": "failed"
});
formatter.before({
  "duration": 12586650,
  "status": "passed"
});
formatter.scenario({
  "line": 161,
  "name": "Validate the Activate request with invalid token",
  "description": "",
  "id": "generate-activation-key-and-jwt;validate-the-activate-request-with-invalid-token;;3",
  "type": "scenario",
  "keyword": "Scenario Outline",
  "tags": [
    {
      "line": 152,
      "name": "@ab"
    },
    {
      "line": 152,
      "name": "@invalidToken"
    }
  ]
});
formatter.step({
  "line": 154,
  "name": "\u0027activationKey\u0027 API",
  "keyword": "Given "
});
formatter.step({
  "comments": [
    {
      "line": 155,
      "value": "#And user has already generated the JWT token for the group \u0027\u003cgroup\u003e\u0027"
    }
  ],
  "line": 156,
  "name": "a POST request is made to axway endpoint with the token \u0027eyJhbGciOiJSUzI1NiJ9.eyJpc3MiOiJTQ0IiLCJhdWQiOiJTQ0ItQVBJQmFua2luZyIsImlhdCI6MTUwMzUwNTE0MiwiZXhwIj\u0027",
  "matchedColumns": [
    0
  ],
  "keyword": "When "
});
formatter.step({
  "line": 157,
  "name": "the response should be displayed as 403 error",
  "keyword": "Then "
});
formatter.match({
  "arguments": [
    {
      "val": "activationKey",
      "offset": 1
    }
  ],
  "location": "commonApiMethods.an_API(String)"
});
formatter.result({
  "duration": 100059,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "eyJhbGciOiJSUzI1NiJ9.eyJpc3MiOiJTQ0IiLCJhdWQiOiJTQ0ItQVBJQmFua2luZyIsImlhdCI6MTUwMzUwNTE0MiwiZXhwIj",
      "offset": 57
    }
  ],
  "location": "activationKey.a_POST_request_is_made_to_axway_withToken(String)"
});
formatter.result({
  "duration": 1038346333,
  "status": "passed"
});
formatter.match({
  "location": "activationKey.verify400ResponseError()"
});
formatter.result({
  "duration": 32094,
  "status": "passed"
});
});