$(document).ready(function() {var formatter = new CucumberHTML.DOMFormatter($('.cucumber-report'));formatter.uri("features/api/endToEnd.feature");
formatter.feature({
  "line": 1,
  "name": "End to End Scenarios for APIBanking",
  "description": "",
  "id": "end-to-end-scenarios-for-apibanking",
  "keyword": "Feature"
});
formatter.scenarioOutline({
  "line": 4,
  "name": "TC_001 - When group is activated, messages should be displayed for Peek, Consume and recover",
  "description": "",
  "id": "end-to-end-scenarios-for-apibanking;tc-001---when-group-is-activated,-messages-should-be-displayed-for-peek,-consume-and-recover",
  "type": "scenario_outline",
  "keyword": "Scenario Outline",
  "tags": [
    {
      "line": 3,
      "name": "@ab"
    },
    {
      "line": 3,
      "name": "@peekAndConsume"
    },
    {
      "line": 3,
      "name": "@regression"
    },
    {
      "line": 3,
      "name": "@tc1"
    }
  ]
});
formatter.step({
  "comments": [
    {
      "line": 5,
      "value": "#When Add Group Services of CADM is called for the group \u0027\u003cGroupID\u003e\u0027 to disable the group"
    },
    {
      "line": 6,
      "value": "#Then APIBanking should be disabled in CADM for the group \u0027\u003cGroupID\u003e\u0027"
    },
    {
      "line": 7,
      "value": "#Given \u0027activationKey and activate\u0027 API"
    },
    {
      "line": 8,
      "value": "#And user has valid SSL certificate"
    }
  ],
  "line": 9,
  "name": "user has already generated the JWT token for the group \u0027\u003cGroupID\u003e\u0027",
  "keyword": "Given "
});
formatter.step({
  "line": 10,
  "name": "a POST request is made to axway endpoint for the group \u0027\u003cGroupID\u003e\u0027",
  "keyword": "When "
});
formatter.step({
  "comments": [
    {
      "line": 11,
      "value": "#Then user should be registered successfully"
    },
    {
      "line": 12,
      "value": "#And APIBanking should be enabled in CADM for the group \u0027\u003cGroupID\u003e\u0027"
    },
    {
      "line": 13,
      "value": "#When user modifies Stub with amount \u0027\u003cAmount\u003e\u0027 account number \u0027\u003cAccountNo\u003e\u0027 transaction type \u0027\u003cCreditDebit\u003e\u0027 Currency Code \u0027INR\u0027 BIC \u0027SCBLINBBXXX\u0027"
    }
  ],
  "line": 14,
  "name": "Peek response should be displayed with amount \u0027\u003cAmount\u003e\u0027 accountNo \u0027\u003cAccountNo\u003e\u0027 transactionType \u0027\u003cCreditDebit\u003e\u0027 the expected value for the group \u0027\u003cGroupID\u003e\u0027",
  "keyword": "Then "
});
formatter.step({
  "line": 15,
  "name": "Consume response should be displayed with amount \u0027\u003cAmount\u003e\u0027 accountNo \u0027\u003cAccountNo\u003e\u0027 transactionType \u0027\u003cCreditDebit\u003e\u0027 the expected value for the group \u0027\u003cGroupID\u003e\u0027",
  "keyword": "And "
});
formatter.step({
  "line": 16,
  "name": "Recover response should be displayed with amount \u0027\u003cAmount\u003e\u0027 accountNo \u0027\u003cAccountNo\u003e\u0027 transactionType \u0027\u003cCreditDebit\u003e\u0027 the expected value for the group \u0027\u003cGroupID\u003e\u0027",
  "keyword": "And "
});
formatter.examples({
  "line": 17,
  "name": "",
  "description": "",
  "id": "end-to-end-scenarios-for-apibanking;tc-001---when-group-is-activated,-messages-should-be-displayed-for-peek,-consume-and-recover;",
  "rows": [
    {
      "cells": [
        "Amount",
        "AccountNo",
        "CreditDebit",
        "GroupID"
      ],
      "line": 18,
      "id": "end-to-end-scenarios-for-apibanking;tc-001---when-group-is-activated,-messages-should-be-displayed-for-peek,-consume-and-recover;;1"
    },
    {
      "cells": [
        "5555",
        "17082017",
        "D",
        "INDGRP"
      ],
      "line": 19,
      "id": "end-to-end-scenarios-for-apibanking;tc-001---when-group-is-activated,-messages-should-be-displayed-for-peek,-consume-and-recover;;2"
    }
  ],
  "keyword": "Examples"
});
formatter.before({
  "duration": 606746762,
  "status": "passed"
});
formatter.scenario({
  "line": 19,
  "name": "TC_001 - When group is activated, messages should be displayed for Peek, Consume and recover",
  "description": "",
  "id": "end-to-end-scenarios-for-apibanking;tc-001---when-group-is-activated,-messages-should-be-displayed-for-peek,-consume-and-recover;;2",
  "type": "scenario",
  "keyword": "Scenario Outline",
  "tags": [
    {
      "line": 3,
      "name": "@ab"
    },
    {
      "line": 3,
      "name": "@peekAndConsume"
    },
    {
      "line": 3,
      "name": "@regression"
    },
    {
      "line": 3,
      "name": "@tc1"
    }
  ]
});
formatter.step({
  "comments": [
    {
      "line": 5,
      "value": "#When Add Group Services of CADM is called for the group \u0027\u003cGroupID\u003e\u0027 to disable the group"
    },
    {
      "line": 6,
      "value": "#Then APIBanking should be disabled in CADM for the group \u0027\u003cGroupID\u003e\u0027"
    },
    {
      "line": 7,
      "value": "#Given \u0027activationKey and activate\u0027 API"
    },
    {
      "line": 8,
      "value": "#And user has valid SSL certificate"
    }
  ],
  "line": 9,
  "name": "user has already generated the JWT token for the group \u0027INDGRP\u0027",
  "matchedColumns": [
    3
  ],
  "keyword": "Given "
});
formatter.step({
  "line": 10,
  "name": "a POST request is made to axway endpoint for the group \u0027INDGRP\u0027",
  "matchedColumns": [
    3
  ],
  "keyword": "When "
});
formatter.step({
  "comments": [
    {
      "line": 11,
      "value": "#Then user should be registered successfully"
    },
    {
      "line": 12,
      "value": "#And APIBanking should be enabled in CADM for the group \u0027\u003cGroupID\u003e\u0027"
    },
    {
      "line": 13,
      "value": "#When user modifies Stub with amount \u0027\u003cAmount\u003e\u0027 account number \u0027\u003cAccountNo\u003e\u0027 transaction type \u0027\u003cCreditDebit\u003e\u0027 Currency Code \u0027INR\u0027 BIC \u0027SCBLINBBXXX\u0027"
    }
  ],
  "line": 14,
  "name": "Peek response should be displayed with amount \u00275555\u0027 accountNo \u002717082017\u0027 transactionType \u0027D\u0027 the expected value for the group \u0027INDGRP\u0027",
  "matchedColumns": [
    0,
    1,
    2,
    3
  ],
  "keyword": "Then "
});
formatter.step({
  "line": 15,
  "name": "Consume response should be displayed with amount \u00275555\u0027 accountNo \u002717082017\u0027 transactionType \u0027D\u0027 the expected value for the group \u0027INDGRP\u0027",
  "matchedColumns": [
    0,
    1,
    2,
    3
  ],
  "keyword": "And "
});
formatter.step({
  "line": 16,
  "name": "Recover response should be displayed with amount \u00275555\u0027 accountNo \u002717082017\u0027 transactionType \u0027D\u0027 the expected value for the group \u0027INDGRP\u0027",
  "matchedColumns": [
    0,
    1,
    2,
    3
  ],
  "keyword": "And "
});
formatter.match({
  "arguments": [
    {
      "val": "INDGRP",
      "offset": 56
    }
  ],
  "location": "activationKey.user_has_already_generated_the_JWT_token_for_the_group(String)"
});
formatter.result({
  "duration": 788461589,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "INDGRP",
      "offset": 56
    }
  ],
  "location": "activationKey.a_POST_request_is_made_to_axway_endpoint(String)"
});
formatter.result({
  "duration": 3799901527,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "5555",
      "offset": 47
    },
    {
      "val": "17082017",
      "offset": 64
    },
    {
      "val": "D",
      "offset": 91
    },
    {
      "val": "INDGRP",
      "offset": 128
    }
  ],
  "location": "PeekAndConsume.peekValueTest(String,String,String,String)"
});
formatter.result({
  "duration": 943000052,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "5555",
      "offset": 50
    },
    {
      "val": "17082017",
      "offset": 67
    },
    {
      "val": "D",
      "offset": 94
    },
    {
      "val": "INDGRP",
      "offset": 131
    }
  ],
  "location": "PeekAndConsume.consumeValueTest(String,String,String,String)"
});
formatter.result({
  "duration": 729983790,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "5555",
      "offset": 50
    },
    {
      "val": "17082017",
      "offset": 67
    },
    {
      "val": "D",
      "offset": 94
    },
    {
      "val": "INDGRP",
      "offset": 131
    }
  ],
  "location": "PeekAndConsume.recoverValueTest(String,String,String,String)"
});
formatter.result({
  "duration": 837754362,
  "status": "passed"
});
});